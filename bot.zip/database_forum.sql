CREATE TABLE IF NOT EXISTS `forum_connections` (
  `id` int NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `api_url` varchar(500) NOT NULL,
  `api_key` text NOT NULL,
  `admin_user_id` bigint NOT NULL DEFAULT 0,
  `date_created` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peer_id` (`peer_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `forum_links` (
  `id` int NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `vk_id` bigint NOT NULL,
  `forum_user_id` bigint NOT NULL,
  `forum_username` varchar(255) NOT NULL DEFAULT '',
  `date_linked` datetime NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peer_vk` (`peer_id`, `vk_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `forum_roles` (
  `id` int NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `priority` varchar(50) NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peer_priority` (`peer_id`, `priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS `forum_watchers` (
  `id` int NOT NULL AUTO_INCREMENT,
  `peer_id` bigint NOT NULL,
  `node_id` int NOT NULL,
  `last_check` int NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `peer_node` (`peer_id`, `node_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;
