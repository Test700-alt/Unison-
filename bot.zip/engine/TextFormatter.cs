﻿using Newtonsoft.Json.Linq;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GrandManager.engine
{
    public static class TextFormatter
    {
        // Вспомогательный класс для удобной работы с элементами форматирования
        private class FormatEntry
        {
            // Имена свойств должны совпадать с ключами в JSON для корректной десериализации
            public int offset { get; set; }
            public int length { get; set; }
            public string type { get; set; }
            public string url { get; set; } // Будет null, если тип не 'url'
        }

        // Класс для возвращаемого результата из метода FromMarkdown
        public class ParsedResult
        {
            public string PlainText { get; set; }
            public JObject FormatData { get; set; }
        }

        /// <summary>
        /// Преобразует обычный текст и данные о форматировании в строку с Markdown-подобной разметкой.
        /// </summary>
        /// <param name="text">Исходный обычный текст.</param>
        /// <param name="format_data">JObject с описанием форматирования.</param>
        /// <returns>Строка с Markdown-подобной разметкой.</returns>
        public static string ToMarkdown(string text, JObject? format_data)
        {
            try
            {
                if (string.IsNullOrEmpty(text))
                    return text; // Возвращаем исходный текст, если он пуст

                if (format_data == null || !format_data.ContainsKey("items"))
                    return text; // Нет данных для форматирования

                Console.WriteLine(text);
                Console.WriteLine(format_data.ToString());

                var itemsToken = format_data["items"];
                if (itemsToken == null || itemsToken.Type != JTokenType.Array)
                    return text;

                List<FormatEntry> items;
                try
                {
                    // Десериализуем элементы, фильтруя возможные null и некорректные записи
                    items = itemsToken.Children<JObject>()
                                      .Select(jo => jo.ToObject<FormatEntry>(JsonSerializer.CreateDefault(new JsonSerializerSettings { NullValueHandling = NullValueHandling.Ignore })))
                                      .Where(item => item != null && !string.IsNullOrEmpty(item.type) && item.length >= 0 && item.offset >= 0)
                                      .ToList();
                }
                catch (JsonSerializationException)
                {
                    // В случае ошибки десериализации (например, неверный формат элемента)
                    // можно логировать ошибку и вернуть исходный текст.
                    Console.Error.WriteLine("Ошибка при десериализации format_data items.");
                    return text;
                }

                if (items.Count == 0)
                    return text;

                // Сортируем элементы по offset В ОБРАТНОМ ПОРЯДКЕ.
                // Это важно, т.к. мы будем вставлять теги в строку.
                // Вставка тегов изменяет длину строки и смещает последующие индексы.
                // Обработка с конца к началу позволяет избежать проблем с индексами.
                items.Sort((a, b) => b.offset.CompareTo(a.offset));

                StringBuilder sb = new StringBuilder(text);

                foreach (var item in items)
                {
                    // Проверка корректности offset и length относительно исходного текста
                    if (item.offset < 0 || item.length < 0 || item.offset + item.length > text.Length)
                    {
                        Console.Error.WriteLine($"Пропуск некорректного элемента форматирования: offset={item.offset}, length={item.length} для текста длиной {text.Length}");
                        continue;
                    }

                    string openTag = "";
                    string closeTag = "";

                    switch (item.type.ToLowerInvariant())
                    {
                        case "italic":
                            openTag = "[i]";
                            closeTag = "[/i]";
                            break;
                        case "bold":
                            openTag = "[b]";
                            closeTag = "[/b]";
                            break;
                        case "underline":
                            openTag = "[u]";
                            closeTag = "[/u]";
                            break;
                        case "url":
                            if (string.IsNullOrEmpty(item.url)) // Пропускаем, если для типа url не указан сам url
                                continue;
                            openTag = $"[url={item.url}]";
                            closeTag = "[/url]";
                            break;
                        default:
                            // Неизвестный тип форматирования, пропускаем
                            continue;
                    }

                    // Вставляем закрывающий тег первым, так как он находится правее
                    sb.Insert(item.offset + item.length, closeTag);
                    // Затем вставляем открывающий тег
                    sb.Insert(item.offset, openTag);
                }
                return sb.ToString();
            }
            catch
            {
                return "";
            }
        }

        
        private const char EmDash = '\u2014'; // Тире em-dash

        /// <summary>
        /// Вспомогательная функция для подсчета "эффективной" длины строки для format_data.
        /// - Теги <br>, <br/>, <br /> считаются за 1 символ.
        /// - Символ em-dash '—' (U+2014) считается за 0 символов (не влияет на длину).
        /// - Символы новой строки \n считаются за 1 символ.
        /// - Все остальные символы (включая пробелы) считаются за 1 символ.
        /// </summary>
        private static int CalculateEffectiveLength(string textBlock)
        {
            if (string.IsNullOrEmpty(textBlock)) return 0;

            int effectiveLength = 0;
            for (int i = 0; i < textBlock.Length;)
            {
                bool consumedSpecial = false;

                // Проверка <br> тегов - считаются за 1
                if (textBlock[i] == '<')
                {
                    if (i + 6 <= textBlock.Length && textBlock.Substring(i, 6).Equals("<br />", StringComparison.OrdinalIgnoreCase))
                    { i += 6; effectiveLength++; consumedSpecial = true; }
                    else if (i + 5 <= textBlock.Length && textBlock.Substring(i, 5).Equals("<br/>", StringComparison.OrdinalIgnoreCase))
                    { i += 5; effectiveLength++; consumedSpecial = true; }
                    else if (i + 4 <= textBlock.Length && textBlock.Substring(i, 4).Equals("<br>", StringComparison.OrdinalIgnoreCase))
                    { i += 4; effectiveLength++; consumedSpecial = true; }

                    if (consumedSpecial) continue;
                }

                consumedSpecial = false;

                // Проверка em-dash '—' - НЕ считается (длина 0)
                if (textBlock[i] == EmDash)
                {
                    i++; // Просто пропускаем символ em-dash
                    consumedSpecial = true;
                }

                if (consumedSpecial) continue;

                // Все остальные символы (включая \n, пробелы и т.д.)
                effectiveLength++;
                i++;
            }
            return effectiveLength;
        }

        private static readonly Regex VkLinkRegex = new Regex(
            @"\[(id|club|public|app|event|group)(\d+)\|(?<displayText>.*?)\]",
            RegexOptions.Compiled | RegexOptions.Singleline);

        private static string ResolveVkLinks(string text)
        {
            if (string.IsNullOrEmpty(text)) return text;
            return VkLinkRegex.Replace(text, m => m.Groups["displayText"].Value);
        }

        public static ParsedResult FromMarkdown(string markdownText)
        {
            // ... (логика FromMarkdown остается такой же, как в предыдущем ответе)
            if (string.IsNullOrEmpty(markdownText))
            {
                var emptyFormatData = new JObject { { "version", "1" }, { "items", new JArray() } };
                return new ParsedResult { PlainText = markdownText ?? string.Empty, FormatData = emptyFormatData };
            }

            StringBuilder plainTextBuilder = new StringBuilder();
            List<FormatEntry> formatEntries = new List<FormatEntry>();
            int currentEffectiveOffsetForFormatData = 0;

            string bbCodePattern =
                @"(?<itag>\[i\](?<itext>.*?)\[/i\])|" +
                @"(?<btag>\[b\](?<btext>.*?)\[/b\])|" +
                @"(?<utag>\[u\](?<utext>.*?)\[/u\])|" +
                @"(?<urltag>\[url=(?<urlval>.*?)\](?<urltext>.*?)\[/url\])";
            Regex bbCodeRegex = new Regex(bbCodePattern, RegexOptions.Singleline);

            int lastIndexProcessedInMarkdown = 0;

            foreach (Match bbMatch in bbCodeRegex.Matches(markdownText))
            {
                if (bbMatch.Index > lastIndexProcessedInMarkdown)
                {
                    string precedingTextOriginal = markdownText.Substring(lastIndexProcessedInMarkdown, bbMatch.Index - lastIndexProcessedInMarkdown);
                    plainTextBuilder.Append(precedingTextOriginal);
                    string precedingTextResolved = ResolveVkLinks(precedingTextOriginal);
                    currentEffectiveOffsetForFormatData += CalculateEffectiveLength(precedingTextResolved);
                }

                string originalContentInBbCode = "";
                string type = "";
                string urlValue = null;

                if (bbMatch.Groups["itag"].Success) { type = "italic"; originalContentInBbCode = bbMatch.Groups["itext"].Value; }
                else if (bbMatch.Groups["btag"].Success) { type = "bold"; originalContentInBbCode = bbMatch.Groups["btext"].Value; }
                else if (bbMatch.Groups["utag"].Success) { type = "underline"; originalContentInBbCode = bbMatch.Groups["utext"].Value; }
                else if (bbMatch.Groups["urltag"].Success) { type = "url"; urlValue = bbMatch.Groups["urlval"].Value; originalContentInBbCode = bbMatch.Groups["urltext"].Value; }
                else { lastIndexProcessedInMarkdown = bbMatch.Index + bbMatch.Length; continue; }

                plainTextBuilder.Append(originalContentInBbCode);

                string resolvedContentInBbCode = ResolveVkLinks(originalContentInBbCode);
                string contentForLengthCalculation = resolvedContentInBbCode.TrimEnd(' ');
                int itemEffectiveLength = CalculateEffectiveLength(contentForLengthCalculation);

                formatEntries.Add(new FormatEntry
                {
                    offset = currentEffectiveOffsetForFormatData,
                    length = itemEffectiveLength,
                    type = type,
                    url = urlValue
                });

                currentEffectiveOffsetForFormatData += CalculateEffectiveLength(resolvedContentInBbCode);

                lastIndexProcessedInMarkdown = bbMatch.Index + bbMatch.Length;
            }

            if (lastIndexProcessedInMarkdown < markdownText.Length)
            {
                string trailingTextOriginal = markdownText.Substring(lastIndexProcessedInMarkdown);
                plainTextBuilder.Append(trailingTextOriginal);
            }

            formatEntries.Sort((a, b) => a.offset.CompareTo(b.offset));
            JArray itemsJArray = new JArray();
            foreach (var entry in formatEntries)
            {
                JObject formatItemJObject = new JObject {
                { "offset", entry.offset }, { "length", entry.length }, { "type", entry.type }
            };
                if (entry.url != null) formatItemJObject.Add("url", entry.url);
                itemsJArray.Add(formatItemJObject);
            }
            JObject resultFormatData = new JObject { { "version", "1" }, { "items", itemsJArray } };

            return new ParsedResult { PlainText = plainTextBuilder.ToString(), FormatData = resultFormatData };
        }

        // Пример использования:
        public static void textett()
        { 
            string originalText = "/zudilov";
            JObject formatData1 = JObject.Parse(@"
        {
          ""version"": ""1"",
          ""items"": [
            { ""offset"": 3, ""length"": 3, ""type"": ""italic"" }
          ]
        }");

            Console.WriteLine($"Original Text: {originalText}");
            Console.WriteLine($"Original Format Data 1:\n{formatData1.ToString(Formatting.Indented)}");

            string markdown1 = ToMarkdown(originalText, formatData1);
            Console.WriteLine($"\nMarkdown 1: {markdown1}"); // Ожидается: /zu[i]dil[/i]ov

            ParsedResult parsed1 = FromMarkdown(markdown1);
            Console.WriteLine($"\nParsed Plain Text 1: {parsed1.PlainText}");
            Console.WriteLine($"Parsed Format Data 1:\n{parsed1.FormatData.ToString(Formatting.Indented)}");

            Console.WriteLine("\n---------------------------\n");

            string originalText2 = "/zudilov";
            JObject formatData2 = JObject.Parse(@"
        {
          ""version"": ""1"",
          ""items"": [
            { ""offset"": 1, ""length"": 3, ""type"": ""bold"" },
            { ""offset"": 6, ""length"": 2, ""type"": ""url"", ""url"": ""https://grandmanager.ru""}
          ]
        }");
            Console.WriteLine($"Original Text: {originalText2}");
            Console.WriteLine($"Original Format Data 2:\n{formatData2.ToString(Formatting.Indented)}");

            string markdown2 = ToMarkdown(originalText2, formatData2);
            Console.WriteLine($"\nMarkdown 2: {markdown2}"); // Ожидается: /[b]zud[/b]il[url=https://grandmanager.ru]ov[/url]

            ParsedResult parsed2 = FromMarkdown(markdown2);
            Console.WriteLine($"\nParsed Plain Text 2: {parsed2.PlainText}");
            Console.WriteLine($"Parsed Format Data 2:\n{parsed2.FormatData.ToString(Formatting.Indented)}");

            Console.WriteLine("\n---------------------------\n");
            // Тест с текстом без форматирования
            string textNoFormat = "Просто текст";
            JObject formatNoFormat = JObject.Parse(@"{""version"": ""1"", ""items"": []}");
            string markdownNoFormat = ToMarkdown(textNoFormat, formatNoFormat);
            Console.WriteLine($"Markdown (no format): {markdownNoFormat}");
            ParsedResult parsedNoFormat = FromMarkdown(markdownNoFormat);
            Console.WriteLine($"Parsed Plain Text (no format): {parsedNoFormat.PlainText}");
            Console.WriteLine($"Parsed Format Data (no format):\n{parsedNoFormat.FormatData.ToString(Formatting.Indented)}");

            Console.WriteLine("\n---------------------------\n");
            // Тест с markdown текстом без тегов
            string plainMarkdown = "Просто текст без тегов";
            ParsedResult parsedPlainMarkdown = FromMarkdown(plainMarkdown);
            Console.WriteLine($"Parsed Plain Text (from plain markdown): {parsedPlainMarkdown.PlainText}");
            Console.WriteLine($"Parsed Format Data (from plain markdown):\n{parsedPlainMarkdown.FormatData.ToString(Formatting.Indented)}");
        }
    }
}
