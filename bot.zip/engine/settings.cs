//using NsfwSpyNS;
using NsfwSpyNS;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Linq;
using System.Net.NetworkInformation;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

//apt-get install -y libgdiplus

namespace GrandManager.engine
{
    internal class settings
    {
       public static ConcurrentDictionary<string, long> a_tokens = new();

        public static string USER_VK_KATE_MOBILE_TOKEN = "";
        public static long USER_VK_KATE_MOBILE_ID = 882524612;

        public static DateTimeOffset date_uptime = DateTimeOffset.Now;

        public static NsfwSpy? nsfwSpyr = null;
        public static void SetATokens()
        {
            if (!Program.is_beta) 
            {
                // Вставлен твой токен
                settings.a_tokens.TryAdd("vk1.a.vFHKxfvvgKRaTlTtjH6f0oaga-w4zcu3l8hQfbP8qC4gsybMVPgd5XujLC05UQ7NKoyDsxwu8x47gk7ZkXTC4XLLvm3Iv-H4SZ2B0vv69lkhRZXhkTsd5Pu83ieckVYTeGzoqya6rCABOo0UKWgVDzpzHQCuAsLddcjn8cGu8xjMDldf7Fkd0OdSlhYJG5uEGTGey8Pob4m6pXZkeOF-uw", 0);
                GROUP_ID = 242358307; // Твой ID сообщества
                MYSQL_HOST = "178.130.53.66"; // Твой хост БД
                MYSQL_DB = "gs352413"; // Твоя база
                PEER_ID_BANK = 2000080633; // Можешь потом поменять на свой ID беседы для логов
            }
            else
            {
                settings.a_tokens.TryAdd("vk1.a.vFHKxfvvgKRaTlTtjH6f0oaga-w4zcu3l8hQfbP8qC4gsybMVPgd5XujLC05UQ7NKoyDsxwu8x47gk7ZkXTC4XLLvm3Iv-H4SZ2B0vv69lkhRZXhkTsd5Pu83ieckVYTeGzoqya6rCABOo0UKWgVDzpzHQCuAsLddcjn8cGu8xjMDldf7Fkd0OdSlhYJG5uEGTGey8Pob4m6pXZkeOF-uw", 0);
                GROUP_ID = 242358307;
                MYSQL_HOST = "178.130.53.66";
                MYSQL_DB = "gs352413";
                PEER_ID_BANK = 2000000049;
            }
        }

        public static long PEER_ID_BANK = 0;

        public static long GROUP_ID = 242358307;

        public static bool ENABLE_MESSAGES_LOG = false;
        public static bool ENABLE_TIMEOUT_CLICK = true;

        public static bool isPeer(long peerid)
        {
            if (peerid > 2e9 && peerid < 2e9 + 1e8)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        public static bool isUserChat(long peerid)
        {
            if ((peerid >= 1 && peerid < 1.9e9) || (peerid >= 200e9 && peerid < 100e10))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        // Вставлены твои данные от БД
        public static string MYSQL_HOST = "178.130.53.66";
        public static string MYSQL_DB = "gs352413";
        public static string MYSQL_USER = "gs352413";
        public static string MYSQL_PASSWORD = "kRKHebl802UG";

        public static Dictionary<long, OWNER_STRUCT> OWNER_IDS = new(); 

        public class OWNER_STRUCT
        {
            public long id;
            public long user_id;
            public DateTimeOffset? expire;
            public long access_give;
            public long access_sysinfo;
            public long access_reports;
            public long access_closed;
            public long access_answer;
            public long access_banreport;
            public long access_unbanreport;
            public long access_sysban;
            public long access_sysunban;
            public long access_sysrole;
            public long access_givevip;
            public long access_getbotstats;
            public long access_spam;
            public long access_givemoney;
            public long access_getquest;
            public long access_fakecmd;
            public long admin;
            public long answers;
            public long marks;
            public long average_mark;
        }

        public static long PEERS_CHATID = 2000000000;
        public static long REPORT_CHAT_PEER_ID = 0;
        
        public static string TOKEN_USER = "";
        public static long TOKEN_USER_ID = 1251372816;

        public static string confirmation_token = "YOUR_CONFIRMATION_TOKEN";
        public static string secret_key = "YOUR_SECRET_KEY";

        public static System.Numerics.BigInteger rate_rating = 60000; // default = 100000
        public static System.Numerics.BigInteger rate_vip = 100000; // default = 3000000;
        public static double euro_course = 500;
        public static DateTimeOffset euro_tranferDate = DateTimeOffset.Now;

        public static string MERCHANT_ID = "39437";
        public static string MERCHANT_SECRET = "ropjCMd{^_5.KP]";
        public static string MERCHANT_SECRET2 = "bHg!@@OXmC";

        public long GetMicroTime()
        {
            return DateTime.Now.Ticks / 10;
        }

        public TimeSpan TimeSpanFromTicks(long ticks)
        {
            TimeSpan interval = TimeSpan.FromTicks(ticks);
            return interval;
        }

        public TimeSpan TimeSpanFromMs(long ms)
        {
            TimeSpan interval = TimeSpan.FromTicks(ms);
            return interval;
        }

        public TimeSpan TimeSpanFromSec(long secs)
        {
            TimeSpan interval = TimeSpan.FromTicks(secs);
            return interval;
        }

        public decimal getSecondsFromMicros(long ms)
        {
            decimal s = Convert.ToDecimal(ms);
            return s / 1000000;
        }

        public static string CreateMD5(string input)
        {
            using (System.Security.Cryptography.MD5 md5 = System.Security.Cryptography.MD5.Create())
            {
                byte[] inputBytes = System.Text.Encoding.ASCII.GetBytes(input);
                byte[] hashBytes = md5.ComputeHash(inputBytes);
                return Convert.ToHexString(hashBytes).ToLower(); 
            }
        }

        public static bool isMatchUrl(string input)
        {
            if (input.Length <= 2 || input == "")
            {
                return false;
            }
            input = input.Replace("\n", " ");
            Regex validateDateRegex = new Regex("https?:\\/\\/(?:www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b(?:[-a-zA-Z0-9()@:%_\\+.~#?&\\/=]*)", RegexOptions.IgnoreCase);
            if (validateDateRegex.IsMatch(input))
            {
                return true;
                Regex extractDateRegex = new Regex("https?:\\/\\/(?:www\\.)?[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b(?:[-a-zA-Z0-9()@:%_\\+.~#?&\\/=]*)");
                string[] extracted = extractDateRegex.Matches(input)
                    .Cast<Match>()
                    .Select(m => m.Value)
                    .ToArray();
                foreach (var item in extracted)
                {
                    if (PingHost(item.Replace("http://", "").Replace("https://", "")))
                    {
                        return true;
                    }
                }
            }
            else
            {
                Regex validateDateRegex2 = new Regex("[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b(?:[-a-zA-Z0-9()@:%_\\+.~#?&\\/=]*)", RegexOptions.IgnoreCase);
                if (validateDateRegex2.IsMatch(input))
                {
                    Regex extractDateRegex2 = new Regex("[-a-zA-Z0-9@:%._\\+~#=]{1,256}\\.[a-zA-Z0-9()]{1,6}\\b(?:[-a-zA-Z0-9()@:%_\\+.~#?&\\/=]*)");
                    string[] extracted = extractDateRegex2.Matches(input)
                        .Cast<Match>()
                        .Select(m => m.Value)
                        .ToArray();
                    foreach (var item in extracted)
                    {
                        var target_host_ping = item;
                        if (!item.Contains("http") && !item.Contains("https"))
                        {
                            target_host_ping = "http://" + item;
                        }
                        Uri? target_Url;
                        try
                        {
                            target_Url = new Uri(target_host_ping);
                        }
                        catch
                        {
                            return false;
                        }
                        
                        if (PingHost(target_Url.Host))
                        {
                            return true;
                        }
                    }
                }
            }
            return false;
        }

        public static List<string>? urlMatches(string input)
        {
            input = input.Replace("\n", " ");
            input = input.Trim();
            if (input.Contains(" "))
            {
                var inputs = input.Split(" ");
                var listLinks = new List<string>();
                foreach (var item in inputs) 
                {
                    if (!settings.isMatchUrl(item))
                    {
                        continue;
                    }
                    var target_ItemUrl = "";
                    if (!item.Contains("http://") && !item.Contains("https://"))
                    {
                        target_ItemUrl = "http://" + item;
                    }

                    Uri? targetOne;
                    try
                    {
                        targetOne = new Uri(target_ItemUrl);
                    }
                    catch
                    {
                        continue;
                    }

                    var host = targetOne.Host;
                    if (PingHost(host))
                    {
                        listLinks.Add(host);
                        continue;
                    }
                }

                if (listLinks.Count <= 0)
                {
                    return null;
                }
                else
                {
                    return listLinks;
                }
            }
            else
            {
                if (!input.Contains("http://") && !input.Contains("https://"))
                {
                    input = "http://" + input;
                }

                Uri? target;
                try
                {
                    target = new Uri(input);
                }
                catch
                {
                    return null;
                }

                var host = target.Host;
                if (PingHost(host))
                {
                    return new List<string>() { host };
                }
                return null;
            }
        }

        public static bool PingHost(string nameOrAddress)
        {
            Cache cach = new();
            if (cach.Get<string>("pinging_" + nameOrAddress) != null)
            {
                return true;
            }
            bool pingable = false;
            Ping pinger = null;

            try
            {
                pingable = false;
            }
            catch (PingException e)
            {
            }
            finally
            {
                if (pinger != null)
                {
                    pinger.Dispose();
                }

                if (pingable)
                {
                    cach.Set("pinging_" + nameOrAddress, "tru", 500);
                }
            }

            return pingable;
        }

        public static System.Numerics.BigInteger getUlongMoney(string money)
        {
            System.Numerics.BigInteger temp = 0;
            try
            {
                temp = System.Numerics.BigInteger.Parse(money);
            }
            catch
            {

            }
            return temp;
        }
    }
}

public static class setTimeOff
{
    public static string ToReadableAgeString(this TimeSpan span)
    {
        return string.Format("{0:0}", span.Days / 365.25);
    }

    public static string ToReadableString(this TimeSpan span)
    {
        string formatted = string.Format("{0}{1}{2}{3}",
            span.Duration().Days > 0 ? string.Format("{0:0} day{1}, ", span.Days, span.Days == 1 ? string.Empty : "s") : string.Empty,
            span.Duration().Hours > 0 ? string.Format("{0:0} hour{1}, ", span.Hours, span.Hours == 1 ? string.Empty : "s") : string.Empty,
            span.Duration().Minutes > 0 ? string.Format("{0:0} minut{1}, ", span.Minutes, span.Minutes == 1 ? string.Empty : "s") : string.Empty,
            span.Duration().Seconds > 0 ? string.Format("{0:0} second{1}", span.Seconds, span.Seconds == 1 ? string.Empty : "s") : string.Empty);

        if (formatted.EndsWith(", ")) formatted = formatted.Substring(0, formatted.Length - 2);

        if (string.IsNullOrEmpty(formatted)) formatted = "0 seconds";

        return formatted;
    }
}