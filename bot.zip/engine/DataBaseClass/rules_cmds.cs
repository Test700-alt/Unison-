﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.DataBaseClass
{
    public struct rules_cmds
    {
        public long peer_id;
        public string command;
        public int priority;
        public long admin;
    }
}
