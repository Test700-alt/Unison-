﻿using MySqlX.XDevAPI.Relational;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.DataBaseClass
{
    internal class warns_list
    {
            public int? id { get; set; }
            public long? peer_id { get; set; }
            public long? user_id { get; set; }
            public long? admin_id { get; set; }
            public string? reason { get; set; }
            public int? deleted { get; set; }
            public string? date_created { get; set; }

    }
}
