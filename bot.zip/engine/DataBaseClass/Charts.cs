﻿using LiveCharts.Definitions.Charts;
using Org.BouncyCastle.Asn1.Crmf;
using System;
using System.Collections.Generic;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using LiveChartsCore.SkiaSharpView.SKCharts;
using LiveChartsCore;
using LiveChartsCore.Geo;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore.SkiaSharpView.Drawing.Geometries;
using LiveChartsCore.Kernel.Sketches;
using LiveChartsCore.SkiaSharpView.Painting;
using LiveChartsCore.SkiaSharpView.VisualElements;
using SkiaSharp;

namespace GrandManager.engine.DataBaseClass
{

    public class Charts
    {

        public void GetImgae()
        {
            var cartesianChart = new SKCartesianChart
            {
                XAxes = new List<Axis>
                {
                    new Axis
                    {
                        // Use the labels property to define named labels.
                        Labels = new string[] { "Anne", "Johnny", "Zac", "Rosa" }
                    }
                },
                Width = 900,
                Height = 600,
                Series = new ISeries[]
                {
                    new LineSeries<int> { Values = new int[] { 1, 5, 4, 6 }, DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                    DataLabelsSize = 22,
                    // for more information about available positions see:
                    // https://lvcharts.com/api/2.0.0-beta.240/LiveChartsCore.Measure.PolarLabelsPosition
                    DataLabelsPosition = (LiveChartsCore.Measure.DataLabelsPosition)LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                    DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " elements" },
                    new ColumnSeries<int> { Values = new int[] { 4, 8, 2, 4 }, Name = "Two", Stroke = null }
                }
            };

            // you can save the image to png (by default)
            // or use the second argument to specify another format.
            cartesianChart.SaveImage("cartesianChart.png");

            var pieChart = new SKPieChart
            {
                
                Width = 900,
                Height = 600,
                Series = new ISeries[]
                {
        new PieSeries<int> { Values = new int[] { 10, } , Name = "dsad"},
        new PieSeries<int> { Values = new int[] { 6 }, Name = "dsdsdsds" },
        new PieSeries<int> { Values = new int[] { 4 } }
                }
               
            };

            pieChart.SaveImage("pieChart.png");

            var geoHeatMap = new SKGeoMap
            {
                Width = 900,
                Height = 600,
                Series = new IGeoSeries[]
                {
        new HeatLandSeries
        {
            Lands = new HeatLand[]
            {
                new() { Name = "mex", Value = 10 },
                new() { Name = "usa", Value = 15 },
                new() { Name = "can", Value = 8 }
            }
        }
                }
            };

            geoHeatMap.SaveImage("geoHeatMap.png");

            // alternatively you can get the image and do different operations:
            using var image = cartesianChart.GetImage();
            using var data = image.Encode();
            var base64CartesianChart = Convert.ToBase64String(data.AsSpan());

            Console.WriteLine("Images saved at the root folder!");
        }
    }
}
