﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.properties
{
    internal class boats
    {
        public static bool load(Database dbh)
        {
            var res = dbh.loadBoats();
            if (res != null)
            {
                list = res;
                return true;
            }
            return false;
        }

        public static Dictionary<long, Dictionary<string, string>>list = new();
    }
}
