using Google.Protobuf;
using GrandManager.engine.DataBaseClass;
using HarfBuzzSharp;
using Microsoft.VisualBasic;
using MySql.Data.MySqlClient;
using MySqlX.XDevAPI.Common;
using MySqlX.XDevAPI.Relational;
using Org.BouncyCastle.Utilities.Collections;
using Pipelines.Sockets.Unofficial.Buffers;
using StackExchange.Redis;
using System;
using System.Collections;
using System.Collections.Generic;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Xml.Linq;
using static GrandManager.engine.settings;
using static SkiaSharp.HarfBuzz.SKShaper;
using static System.Net.Mime.MediaTypeNames;

namespace GrandManager.engine
{
    internal class Database : IDisposable
    {
        private bool IsDisposed = false;
        public MySqlConnection? handle = null;
        private static MySqlConnection? staticHandle = null;
        private static readonly object dbLock = new object();

        private Cache Cache = null;

        public Database(Cache Cach)
        {
            Cache = Cach;
        }

        public void initClient()
        {
            lock (dbLock)
            {
                if (handle != null && handle.State == ConnectionState.Open)
                {
                    return;
                }

                if (handle != null)
                {
                    try { handle.Close(); handle.Dispose(); } catch { }
                    handle = null;
                }

                var builder = new MySqlConnectionStringBuilder
                {
                    Server = settings.MYSQL_HOST,
                    UserID = settings.MYSQL_USER,
                    Password = settings.MYSQL_PASSWORD,
                    Database = settings.MYSQL_DB,
                    Pooling = true,
                    MinimumPoolSize = 2,
                    MaximumPoolSize = 100,
                    ConnectionTimeout = 10,
                    DefaultCommandTimeout = 30,
                    AllowUserVariables = true,
                    ConnectionLifeTime = 60,
                };
                handle = new MySqlConnection(builder.ConnectionString);
                try
                {
                    handle.Open();
                }
                catch (MySqlException err)
                {
                    Console.WriteLine("[DB] Error: " + err.Message);
                    handle = null;
                }
                catch (Exception ex)
                {
                    Console.WriteLine("[DB] Error: " + ex.Message);
                    handle = null;
                }
            }
        }

        public void Dispose()
        {
            handle = null;
        }


        public Dictionary<string, string>? DbSelectOne(Dictionary<string, string> where, string table)
        {
            MySqlCommand? command = null;
            MySqlDataReader? reader = null;

            try
            {
                if (handle == null || handle.State == ConnectionState.Closed)
                {
                    initClient();
                }

                if (handle == null)
                {
                    Console.WriteLine("[DATABASE ERROR] DbSelectOne: Connection not established.");
                    return null;
                }

                string sql = $"SELECT * FROM `{table}` WHERE ";

                var parameters = new List<string>();
                foreach (var item in where)
                {
                    parameters.Add($"`{item.Key}` = @param_{item.Key}");
                }
                sql += string.Join(" AND ", parameters);
                sql += ";";

                command = new MySqlCommand(sql, handle);
                foreach (var item in where)
                {
                    command.Parameters.AddWithValue($"@param_{item.Key}", item.Value);
                }

                Dictionary<string, string> result = new();

                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    for (int i = 0; i < reader.FieldCount; i++)
                    {
                        result[reader.GetName(i)] = reader[i]?.ToString() ?? "";
                    }
                }

                return result.Count > 0 ? result : null;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DATABASE ERROR] DbSelectOne: {ex.Message}");
                return null;
            }
            finally
            {
                if (reader != null)
                {
                    reader.Dispose();
                }
                if (command != null)
                {
                    command.Dispose();
                }
                if (handle != null)
                {
                    try
                    {
                        handle.Close();
                        handle.Dispose();
                        handle = null;
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"[DATABASE ERROR] Closing connection: {ex.Message}");
                    }
                }
            }
        }

        public long DbInsert(Dictionary<string, object> data, string table, bool getId = false)
        {
            try
            {
                initClient();
                string sql = $"REPLACE INTO `{table}` (";// (`userid`) VALUES (@param_id);";

                foreach (var item in data)
                {
                    sql += $"`{item.Key}`, ";
                }

                sql = sql.Substring(0, sql.Length - 2);
                sql += ") VALUES (";

                foreach (var item in data)
                {
                    sql += $"@param_{item.Key}, ";
                }
                sql = sql.Substring(0, sql.Length - 2);
                sql += ");";

                MySqlCommand command = new MySqlCommand(sql, handle);

                foreach (var item in data)
                {
                    sql += $"@param_{item.Key}, ";
                    command.Parameters.AddWithValue($"@param_{item.Key}", item.Value);
                }

                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
                
                
                if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                

                try
                {
                    if (getId)
                    {
                        long idLast = command.LastInsertedId;
                        
                        return idLast;
                    }
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                    return 0;
                }
                
                    

                return 0;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
                return 0;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
            }
        }

        public void DbDelete(Dictionary<string, object> data, string table)
        {
            try
            {
                initClient();
                //DELETE FROM `Grandgram`.`tokens` WHERE  `token`='123';
                string sql = $"DELETE FROM `{table}` WHERE ";// (`userid`) VALUES (@param_id);";

                foreach (var item in data)
                {
                    sql += $"`{item.Key}` = @param_{item.Key} AND ";
                }

                sql = sql.Substring(0, sql.Length - 5);
                sql += ";";

                MySqlCommand command = new MySqlCommand(sql, handle);

                foreach (var item in data)
                {
                    command.Parameters.AddWithValue($"@param_{item.Key}", item.Value);
                }

                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {

                }

                if (command != null) { try { command.Dispose(); } catch { } }
                if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }

                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }

                
            }
        }

        public void DbUpdate(Dictionary<string, string> where, Dictionary<string, string> data, string table)
        {
            try
            {
                initClient();
                //"UPDATE `peer_members` SET `priority` = @param_priorit WHERE `peer_id` = @param_id AND `user_id` = @param_user_id;";
                string sql = "UPDATE `" + table + "` SET ";

                foreach (var item in data)
                {
                    if (item.Value == "CURRENT_TIMESTAMP()")
                    {
                        sql = sql + "`" + item.Key + "` = CURRENT_TIMESTAMP(), ";
                    }
                    else if (item.Value == "NULL")
                    {
                        sql = sql + "`" + item.Key + "` = NULL, ";
                    }
                    else
                    {
                        sql = sql + "`" + item.Key + "` = @param_d" + item.Key + ", ";
                    }

                    //foo(item.Key);
                    //bar(item.Value);
                }
                sql = sql.Substring(0, sql.Length - 2);
                sql = sql + " WHERE ";
                foreach (var item in where)
                {
                    sql = sql + "`" + item.Key + "` = @param_" + item.Key + " AND ";
                    //foo(item.Key);
                    //bar(item.Value);
                }
                sql = sql.Substring(0, sql.Length - 5);
                sql = sql + ";";
                MySqlCommand command = new MySqlCommand(sql, handle);
                foreach (var item in data)
                {
                    if (item.Value == "CURRENT_TIMESTAMP()")
                    {
                        continue;
                    }
                    if (item.Value == "NULL")
                    {
                        continue;
                    }
                    command.Parameters.AddWithValue("@param_d" + item.Key, item.Value);
                }
                foreach (var item in where)
                {
                    command.Parameters.AddWithValue("@param_" + item.Key, item.Value);
                }

                try
                {
                    command.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    Console.WriteLine($"[UPDATE ERROR] at {table}, {ex.Message}");
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                    if (command != null)
                    {
                        command.Dispose();
                    }
                    return;
                }
                catch
                {
                    Console.WriteLine($"[UPDATE ERROR] UNHANDLED at {table}");
                    if (handle != null || handle.State != ConnectionState.Closed) { try { handle.Close(); handle.Dispose(); } catch { } }
                    if (command != null)
                    {
                        command.Dispose();
                    }
                    return;
                }
                if (command != null)
                {
                    command.Dispose();
                }
                if (handle != null || handle.State != ConnectionState.Closed) { try { handle.Close(); handle.Dispose(); } catch { } }
                //if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose();  } catch { } }
                }
            }
            
        }

        public List<Dictionary<string, string>>? DbSelectMoore(Dictionary<string, object> where, string table, long min = 0, long max = 9999, string customSql = "", string OrOrAnd = "AND")
        {
            try
            {
                initClient();
                string sql = "SELECT * FROM `" + table + "` WHERE ";
                foreach (var item in where)
                {
                    sql = sql + "`" + item.Key + "` LIKE @param_" + item.Key + $" {OrOrAnd} ";
                    //foo(item.Key);
                    //bar(item.Value);
                }

                if (OrOrAnd == "OR")
                {
                    sql = sql.Substring(0, sql.Length - 4);
                }
                else
                {
                    sql = sql.Substring(0, sql.Length - 5);
                }

                sql = sql + $" LIMIT {min}, {max};";

                MySqlCommand command;
                if (customSql != "")
                {
                    sql = customSql;
                    command = new MySqlCommand(sql, handle);

                }
                else
                {
                    command = new MySqlCommand(sql, handle);
                    foreach (var item in where)
                    {
                        command.Parameters.AddWithValue("@param_" + item.Key, item.Value);
                    }
                }

                List<Dictionary<string, string>>? result = new();

                using (var sqlQueryResult = command.ExecuteReader())
                {
                    while (sqlQueryResult.Read())
                    {
                        var tempRes = new Dictionary<string, string>();
                        for (int i = 0; i < sqlQueryResult.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempRes[sqlQueryResult.GetName(i)] = sqlQueryResult[i].ToString();
                            //Console.WriteLine(reader[i].ToString());
                        }
                        result.Add(tempRes);

                    }
                    try
                    {
                        sqlQueryResult.Close();
                    }
                    catch
                    {
                        if (command != null) { try { command.Dispose(); } catch { } }
                    }
                    if (handle != null) { try { handle.Close(); } catch { } }
                }

                if (handle != null) { try { handle.Close(); } catch { } }
                if (command != null) { try { command.Dispose(); } catch { } }
                if (result.Count > 0)
                {
                    return result;
                }
                else
                {
                    return null;
                }
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
            }
        }

        private Dictionary<string, string>? usersRegUser(long userid)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `accounts` (`userid`) VALUES (@param_id);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", userid);
                try { long s = command.ExecuteNonQuery(); } catch { }
                


                if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                if (command != null) { try { command.Dispose(); } catch { } }
                //CountriesAddMember(1);

                accountsGetCacheCount(true);

                return usersGetUser(userid);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle.Dispose(); } catch { } }
                }
            }
        }

        public Dictionary<string, string>? usersGetUser(long userid, bool update_cache = false)
        {
            try
            {
                Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("user_" + userid.ToString());
                if (result == null || update_cache == true)
                {
                    result = DbSelectOne(new Dictionary<string, string>() { { "userid", userid.ToString() } }, "accounts");
                    if (result == null)
                    {
                        result = usersRegUser(userid);
                    }
                    Cache.Set("user_" + userid.ToString(), result);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>>? getQuestsWhereDay(long userid, string date)
        {
            try
            {
                List<Dictionary<string, string>> result = new();
                initClient();
                string sql = "SELECT * FROM `peers` WHERE `sys_mention_worker` LIKE '" + userid + "' AND `sys_mention_date` >= '" + date + "';";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        Dictionary<string, string> local_res = new();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            local_res.Add(reader.GetName(i), reader[i].ToString());
                        }
                        result_db.Add(local_res);
                        //Console.WriteLine(reader[1]);
                    }
                    result = result_db;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        // ---------------------------------- �������

        public void gameSetUserRub(long userid, string rub)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "rubs", rub } }, "accounts");
                usersGetUser(userid, true);

                var topInfo = gameTopGetRubs();
                if (topInfo == null || topInfo.Count <= 0)
                {
                    return;
                }

                System.Numerics.BigInteger money_user = 0;

                System.Numerics.BigInteger min = 0;
                System.Numerics.BigInteger max = 0;

                foreach (var item in topInfo)
                {
                    if (item.Value > max)
                    {
                        max = item.Value;
                        continue;
                    }
                }

                min = max;

                foreach (var item in topInfo)
                {
                    if (item.Value < min)
                    {
                        min = item.Value;
                        continue;
                    }
                }

                foreach (var item in topInfo)
                {
                    if (min <= System.Numerics.BigInteger.Parse(rub) || max <= System.Numerics.BigInteger.Parse(rub))
                    {
                        gameTopGetRubs(true);
                        break;
                    }

                    /*if (item.Key == userid && min > System.Numerics.BigInteger.Parse(rating))
                    {
                        gameTopGetRatings(true);
                        break;
                    }*/
                    if (item.Key != userid)
                    {
                        break;
                    }

                    try
                    {
                        topInfo[item.Key] = System.Numerics.BigInteger.Parse(rub);
                    }
                    catch
                    {

                    }
                    var sortedDict = from entry in topInfo orderby entry.Value descending select entry;
                    //
                    //var news = topInfo.OrderByDescending(x => x["rubs"]).ToList();
                    var data = sortedDict.ToDictionary(pair => pair.Key, pair => pair.Value);
                    Cache.Set("top_rubs", data, 10);
                    break;
                }
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void gameSetUserRating(long userid, string rating)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "rating", rating } }, "accounts");
                usersGetUser(userid, true);

                var topInfo = gameTopGetRatings();
                if (topInfo == null || topInfo.Count <= 0)
                {
                    return;
                }

                System.Numerics.BigInteger money_user = 0;

                try
                {
                    decimal.Parse(rating);
                }
                catch
                {

                }

                System.Numerics.BigInteger min = 0;
                System.Numerics.BigInteger max = 0;

                foreach (var item in topInfo)
                {
                    if (item.Value > max)
                    {
                        max = item.Value;
                        continue;
                    }
                }

                min = max;

                foreach (var item in topInfo)
                {
                    if (item.Value < min)
                    {
                        min = item.Value;
                        continue;
                    }
                }

                foreach (var item in topInfo)
                {
                    if (min <= System.Numerics.BigInteger.Parse(rating) || max <= System.Numerics.BigInteger.Parse(rating))
                    {
                        gameTopGetRatings(true);
                        break;
                    }

                    /*if (item.Key == userid && min > System.Numerics.BigInteger.Parse(rating))
                    {
                        gameTopGetRatings(true);
                        break;
                    }*/
                    if (item.Key != userid)
                    {
                        break;
                    }

                    try
                    {
                        topInfo[item.Key] = System.Numerics.BigInteger.Parse(rating);
                    }
                    catch
                    {

                    }
                    var sortedDict = from entry in topInfo orderby entry.Value descending select entry;
                    //
                    //var news = topInfo.OrderByDescending(x => x["rubs"]).ToList();
                    var data = sortedDict.ToDictionary(pair => pair.Key, pair => pair.Value);
                    Cache.Set("top_ratings", data, 10);
                    break;
                }
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void gameSetLastBonus(long userid, string bonus)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "date_bonus_last", bonus } }, "accounts");
                usersGetUser(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void gameSetUserEuros(long userid, string euro)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "euros", euro } }, "accounts");
                usersGetUser(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void gameSetUserNG31(long userid, int ng31)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "opros", ng31.ToString() } }, "accounts");
                usersGetUser(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void gameSetUserNG01(long userid, int ng31)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "8march", ng31.ToString() } }, "accounts");
                usersGetUser(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void gameSetLevel(long userid, long level)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "level", level.ToString() } }, "accounts");
                usersGetUser(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public Dictionary<long, System.Numerics.BigInteger>? gameTopGetRubs(bool update_cache = false)
        {
            try
            {
                Dictionary<long, System.Numerics.BigInteger>? result = Cache.Get<Dictionary<long, System.Numerics.BigInteger>>("top_rubs");

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `accounts` order by `rubs`*1 DESC LIMIT 30;";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    Dictionary<long, System.Numerics.BigInteger>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            result_db.Add(long.Parse(reader["userid"].ToString()), System.Numerics.BigInteger.Parse(reader["rubs"].ToString()));
                        }
                    }
                    result = result_db;

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("top_rubs", result, 10);
                    return result;
                }
                Cache.Set("top_rubs", result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public Dictionary<long, System.Numerics.BigInteger> gameTopGetRatings(bool update_cache = false)
        {
            try
            {
                Dictionary<long, System.Numerics.BigInteger>? result = Cache.Get<Dictionary<long, System.Numerics.BigInteger>>("top_ratings");

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `accounts` order by `rating` DESC LIMIT 20;";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    Dictionary<long, System.Numerics.BigInteger>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            result_db.Add(long.Parse(reader["userid"].ToString()), System.Numerics.BigInteger.Parse(reader["rating"].ToString()));
                        }
                    }
                    result = result_db;

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("top_ratings", result, 10);
                    return result;
                }
                Cache.Set("top_ratings", result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>>? MarriagesGetMarries(long peerid, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("marriages_" + peerid.ToString());

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `marriages` WHERE `peer_id` = '" + peerid + "' ORDER BY `husband` ASC;";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result_db.Add(local_res);
                            //Console.WriteLine(reader[1]);
                        }
                        result = result_db;
                    }
                    

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("marriages_" + peerid, result, 10);
                    return result;
                }
                Cache.Set("marriages_" + peerid, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        //INSERT INTO `vk_test`.`marriages` (`peer_id`, `husband`, `wife`) VALUES ('1', '2', '3');
        public Dictionary<string, string>? MarriagesGetUser(long peerid, long userid, bool update_cache = false)
        {
            try
            {
                var marries = MarriagesGetMarries(peerid, update_cache);
                if (marries == null)
                {
                    return null;
                }

                if (marries.Count <= 0)
                {
                    return null;
                }

                foreach (var item in marries)
                {
                    if (item["husband"] == userid.ToString() || item["wife"] == userid.ToString())
                    {
                        return item;
                    }
                }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void MarriagesAddMarrie(long peerid, long husband, long wife)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `marriages` (`peer_id`, `husband`, `wife`, `date_create`) VALUES " +
                    "(@param_id, @param_husband, @param_wife, CURRENT_TIMESTAMP());";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_husband", husband);
                command.Parameters.AddWithValue("@param_wife", wife);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    MarriagesGetMarries(peerid, true);
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                MarriagesGetMarries(peerid, true);
                
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }


        public void MarriagesDelMarrie(long peerid, long husband, long wife)
        {
            try
            {
                initClient();
                string sql = "DELETE FROM `marriages` WHERE `peer_id` = @param_id AND `husband` = @param_husband AND `wife` = @param_wife;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_husband", husband);
                command.Parameters.AddWithValue("@param_wife", wife);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    MarriagesGetMarries(peerid, true);
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                MarriagesGetMarries(peerid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }


        public void gameSetAcceptLs(long userid, long accept)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "accept_ls", accept.ToString() } }, "accounts");

                var result = Cache.Get<Dictionary<string, string>>("user_" + userid.ToString());
                if (result != null && result.ContainsKey("accept_ls"))
                {
                    result["accept_ls"] = accept.ToString();
                    Cache.Set("user_" + userid.ToString(), result);
                }
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        // --------------------------------------------- ������ -----------------------------------------------
        public Dictionary<string, string> CountriesGetCountry(long country)
        {
            try
            {
                var countries = CountriesGetList();
                if (countries == null || countries.Count <= 0)
                {
                    return null;
                }
                foreach (var item in countries)
                {
                    if (item["id"] == country.ToString())
                    {
                        return item;
                    }
                }

                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>> CountriesGetList(bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("countries");

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `countries` ORDER BY `members` DESC, `id` ASC;";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result_db.Add(local_res);
                            //Console.WriteLine(reader[1]);

                        }
                    }
                    result = result_db;

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("countries", result, 30);
                    return result;
                }
                Cache.Set("countries", result, 30);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void CountriesAddMember(long country)
        {
            try
            {
                initClient();
                string sql = "UPDATE `countries` SET `members` = `members` + 1 WHERE `id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", country);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                var countries = CountriesGetList();
                if (countries == null || countries.Count <= 0)
                {
                    return;
                }


                for (int key = 0; key < countries.Count; ++key)
                {
                    if (countries[key]["id"] == country.ToString())
                    {
                        countries[key]["members"] = (long.Parse(countries[key]["members"]) + 1).ToString();
                        Cache.Set("countries", countries, 30);
                        return;
                    }
                }

                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void CountriesRemoveMember(long country)
        {
            try
            {
                initClient();
                string sql = "UPDATE `countries` SET `members` = `members` - 1 WHERE `id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", country);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                var countries = CountriesGetList();
                if (countries == null || countries.Count <= 0)
                {
                    return;
                }


                for (int key = 0; key < countries.Count; ++key)
                {
                    if (countries[key]["id"] == country.ToString())
                    {
                        countries[key]["members"] = (long.Parse(countries[key]["members"]) - 1).ToString();
                        Cache.Set("countries", countries, 30);
                        return;
                    }
                }

                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void userSetCountry(long userid, long country)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "country", country.ToString() } }, "accounts");
                usersGetUser(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }


        public void CountriesSetRub(long country, string rub)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "id", country.ToString() } },
                new Dictionary<string, string>() { { "rubles", rub } }, "countries");
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("countries");
                if (result != null)
                {
                    for (int key = 0; key < result.Count; ++key)
                    {
                        if (result[key]["id"] == country.ToString())
                        {
                            result[key]["rubles"] = rub;
                        }
                    }
                    Cache.Set("countries", result, 30);

                }
                else
                {
                    CountriesGetList(true);
                }
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void CountriesSetTaxLast(long country, string tax)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "id", country.ToString() } },
                new Dictionary<string, string>() { { "date_tax", tax } }, "countries");
                //usersGetUser(userid, true);
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("countries");
                if (result != null)
                {
                    for (int key = 0; key < result.Count; ++key)
                    {
                        if (result[key]["id"] == country.ToString())
                        {
                            result[key]["date_tax"] = tax;
                        }
                    }
                    Cache.Set("countries", result, 30);

                }
                else
                {
                    CountriesGetList(true);
                }
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Database.candidatePresident> GetCandidatesCountry(long country)
        {
            List<Database.candidatePresident>? result = Cache.Get<List<Database.candidatePresident>>("candidates_country_" + country);

            if (result == null)
            {
                if (result == null)
                {
                    result = new();
                }

                Cache.Set("candidates_country_" + country, result, 1440);
                return result;
            }
            return result;
        }

        public void CandidatesAddCountry(long country, Database.candidatePresident candidate)
        {
            List<Database.candidatePresident>? result = Cache.Get<List<Database.candidatePresident>>("candidates_country_" + country);

            if (result == null)
            {
                if (result == null)
                {
                    result = new();
                }
            }
            result.Add(candidate);
            Cache.Set("candidates_country_" + country, result, 1440);

            List<long>? countries_candidats = Cache.Get<List<long>>("countries_candidats");
            if (countries_candidats == null || countries_candidats.Count <= 0)
            {
                countries_candidats = new();
            }
            countries_candidats.Add(country);
            Cache.Set("countries_candidats", countries_candidats, 1440);
            return;
        }

        public List<long>? CandidatesGetCountries ()
        {
            List<long>? countries_candidats = Cache.Get<List<long>>("countries_candidats");
            if (countries_candidats == null || countries_candidats.Count <= 0)
            {
                return null;
            }
            return countries_candidats;
        }

        public void CandidatesCountriesClear()
        {
            Cache.Delete("countries_candidats");
        }

        public void CountriesSetOwner(long userid, long country)
        {
            try
            {
                initClient();
                string sql = "UPDATE `countries` SET `owner` = '" + userid + "' WHERE `id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", country);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                var countries = CountriesGetList();
                if (countries == null || countries.Count <= 0)
                {
                    return;
                }


                for (int key = 0; key < countries.Count; ++key)
                {
                    if (countries[key]["id"] == country.ToString())
                    {
                        countries[key]["owner"] = userid.ToString();
                        Cache.Set("countries", countries, 30);
                        return;
                    }
                }

                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public class candidatePresident
        {
            public long id;
            public long id_country = 0;
            public long voices = 0;
            public string text_comp = "�� ����������.";
        }

        // ------------------------------------------

        // ----------------------------------------- ������� --------------------------------------------------------

        public long CreateQuestion(long userid, long fromid, string text)
        {
            long res = DbInsert(new Dictionary<string, object>()
            {
                { "user_id", userid },
                { "from_id", fromid },
                { "question", text },
            }, "questions", true);

            questionGetList(userid, true);
            questionGetList(fromid, true);
            return res;
        }

        public List<Dictionary<string, string>> questionGetList(long userid, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("questions_" + userid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `questions` WHERE `user_id` = '" + userid + "' OR `from_id` = '" + userid + "' ORDER BY `id` DESC";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        List<Dictionary<string, string>>? result_db = new();
                        if (reader.HasRows == true)
                        {
                            while (reader.Read())
                            {
                                Dictionary<string, string> local_res = new();
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    local_res.Add(reader.GetName(i), reader[i].ToString());
                                }

                                result_db.Add(local_res);
                            }
                        }
                        result = result_db;
                        if (reader != null) { try { reader.Close(); } catch { } }
                    }

                    // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    Cache.Set("questions_" + userid, result, 10);
                    return result;
                }
                Cache.Set("questions_" + userid, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public Dictionary<string, string>? questionGetQuest(long id, bool update_cache = false)
        {
            try
            {
                Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("question_" + id.ToString());
                if (result == null || update_cache == true)
                {
                    result = DbSelectOne(new Dictionary<string, string>() { { "id", id.ToString() } }, "questions");
                    if (result != null)
                    {
                        Cache.Set("question_" + id.ToString(), result);
                    }
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void questionSetAnswer(long id, string text, long user_id, long from_id)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "id", id.ToString() } },
                new Dictionary<string, string>() { { "answer", text.ToString() } }, "questions");
                questionGetQuest(id, true);
                questionGetList(user_id, true);
                questionGetList(from_id, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        // ----------------------------------------------------------------------------------------------------------

        public List<Dictionary<string, string>>? BanreportsGetList(bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("banreports");

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `banreports` WHERE `active` = '1';";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result_db.Add(local_res);
                            //Console.WriteLine(reader[1]);
                        }
                        result = result_db;
                    }


                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("banreports", result, 10);
                    return result;
                }
                Cache.Set("banreports", result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        public Dictionary<string, string>? BanreportsGetBan(long userid, bool update_cache = false)
        {
            try
            {
                Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("banreport_" + userid.ToString());
                if (result == null || update_cache == true)
                {
                    result = DbSelectOne(new Dictionary<string, string>() { { "user_id", userid.ToString() }, { "active", "1" } }, "banreports");

                    if (handle != null)
                    {
                        if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    }

                    if (result != null)
                    {
                        var timeUnban = timeGetForMysql( result["date_unban"] );
                        if (DateTimeOffset.Now >= timeUnban )
                        {
                            BanreportsSetBanNonActive(userid);
                            return null;
                        }
                    }

                    Cache.Set("banreport_" + userid.ToString(), result);
                    return result;
                }
                if (result != null)
                {
                    var timeUnban = timeGetForMysql(result["date_unban"]);
                    if (DateTimeOffset.Now >= timeUnban)
                    {
                        BanreportsSetBanNonActive(userid);
                        return null;
                    }
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public int BanreportsGetAllBansCount(long userid)
        {
            try
            {
                
                initClient();
                string sql = "SELECT COUNT(*) FROM `banreports` WHERE `user_id` = '" + userid + "';";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                int result_db = 0;
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        if (reader[0] != null)
                        {
                            string resCount = reader[0].ToString();
                            try
                            {
                                result_db = int.Parse(resCount);
                            }
                            catch
                            {

                            }
                        }
                        
                        //Console.WriteLine(reader[1]);
                    }

                }
                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result_db;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        public void BanreportsAddBan(long user_id, long admin_id, string reason, string date_unban)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `banreports` (`user_id`, `admin_id`, `reason`, `date_unban`) VALUES (@param_idr, @param_userid, @param_priority, @param_punban);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_idr", user_id);
                command.Parameters.AddWithValue("@param_userid", admin_id);
                command.Parameters.AddWithValue("@param_priority", reason);
                command.Parameters.AddWithValue("@param_punban", date_unban);
                try
                {
                    command.ExecuteNonQuery();
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                BanreportsGetList(true);
                BanreportsGetBan(user_id, true);

                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void BanreportsSetBanNonActive(long userid)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() }, { "active", "1" } },
                new Dictionary<string, string>() { { "active", "0" } }, "banreports");
                BanreportsGetList(true);
                BanreportsGetBan(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void usersSetBanReport(long userid, long banreport)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "ban_report", banreport.ToString() } }, "accounts");
                usersGetUser(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }







        public int questsGetAllQuests()
        {
            try
            {

                initClient();
                string sql = "SELECT COUNT(*) FROM `peers` WHERE `sys_mention_worker` != 0 AND `sys_mention_non_active` != 0;";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                int result_db = 0;
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        if (reader[0] != null)
                        {
                            string resCount = reader[0].ToString();
                            try
                            {
                                result_db = int.Parse(resCount);
                            }
                            catch
                            {

                            }
                        }

                        //Console.WriteLine(reader[1]);
                    }

                }
                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result_db;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        public int questsGetAllQuestsInWork()
        {
            try
            {

                initClient();
                string sql = "SELECT COUNT(*) FROM `peers` WHERE `sys_mention_worker` != 0 AND `sys_mention_non_active` LIKE '0';";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                int result_db = 0;
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        if (reader[0] != null)
                        {
                            string resCount = reader[0].ToString();
                            try
                            {
                                result_db = int.Parse(resCount);
                            }
                            catch
                            {

                            }
                        }

                        //Console.WriteLine(reader[1]);
                    }

                }
                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result_db;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        public int questsGetAllQuestsActiveAfterWork()
        {
            try
            {

                initClient();
                string sql = "SELECT COUNT(*) FROM `peers` WHERE `sys_mention_worker` != 0 AND `active` LIKE '1';";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                int result_db = 0;
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        if (reader[0] != null)
                        {
                            string resCount = reader[0].ToString();
                            try
                            {
                                result_db = int.Parse(resCount);
                            }
                            catch
                            {

                            }
                        }

                        //Console.WriteLine(reader[1]);
                    }

                }
                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result_db;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        public int questsGetAllQuestsNewer()
        {
            try
            {

                initClient();
                string sql = "SELECT COUNT(*) FROM `peers` WHERE `sys_mention_worker` LIKE '0' AND `active` LIKE '0';";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                int result_db = 0;
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        if (reader[0] != null)
                        {
                            string resCount = reader[0].ToString();
                            try
                            {
                                result_db = int.Parse(resCount);
                            }
                            catch
                            {

                            }
                        }

                        //Console.WriteLine(reader[1]);
                    }

                }
                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result_db;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }





        private Dictionary<string, string>? peersRegPeer(long peerid)
        {
            try
            {
                initClient();
                string sql = "INSERT IGNORE INTO `peers` (`peer_id`) VALUES (@param_id);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch (Exception e)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return peersGetPeer(peerid, false, false);
            }
            catch (Exception e)
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peersSetInviter(long peerid, long inviter)
        {
            try
            {
                initClient();
                string sql = "UPDATE `peers` SET `inviter` = @param_inviter WHERE `peer_id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_inviter", inviter);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void usersSetVipType(long userid, long vipType)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "vip_type", vipType.ToString() } }, "accounts");
                usersGetUser(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void usersSetVipTime(long userid, string? vipTime)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "vip", vipTime } }, "accounts");
                usersGetUser(userid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peersSetActive(long peerid, long active, long inviter, long owner_id)
        {
            try
            {
                initClient();
                string sql = "UPDATE `peers` SET `inviter` = @param_inviter, `active` = @param_active, `owner` = @param_owner WHERE `peer_id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_inviter", inviter);
                command.Parameters.AddWithValue("@param_active", active);
                command.Parameters.AddWithValue("@param_owner", owner_id);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peersGetPeer(peerid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
            
        }

        public Dictionary<string, string>? peersGetPeer(long peerid, bool update_cache = false, bool regPeer = true)
        {
            try
            {
                Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("peer_" + peerid.ToString());
                if (result == null || update_cache == true)
                {
                    result = DbSelectOne(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } }, "peers");
                    if (result == null)
                    {
                        if (regPeer)
                        {
                            result = peersRegPeer(peerid);
                        }
                        else
                        {
                            return null;
                        }
                    }
                    if (result != null)
                    {
                        Cache.Set("peer_" + peerid.ToString(), result);
                    }
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        private Dictionary<string, string>? peersRegMember(long peerid, long userid, long priority = 0, bool return_user = false)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `peer_members` (`peer_id`, `user_id`, `priority`) VALUES (@param_id, @param_userid, @param_priority);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_userid", userid);
                command.Parameters.AddWithValue("@param_priority", priority);
                try
                {
                    command.ExecuteNonQuery();
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                if (return_user)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return peersGetMember(peerid, userid, true, false);
                }

                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void bansAddBan(long peerid, long userid, long admin_id, string reason, string date_unban)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `bans` (`peer_id`, `user_id`, `admin_id`, `reason`, `date_ban`, `date_unban`) " +
                    "VALUES (@param_id, @param_userid, @param_adminid, @param_reason, CURRENT_TIMESTAMP(), @param_unban);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_userid", userid);
                command.Parameters.AddWithValue("@param_adminid", admin_id);
                command.Parameters.AddWithValue("@param_reason", reason);
                command.Parameters.AddWithValue("@param_unban", date_unban);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                bansGetBan(peerid, userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
            
        }

        //
        public Dictionary<string, string>? bansGetBan(long peerid, long userid, bool update_cache = false)
        {
            try
            {
                var bans = bansGetBansAll(peerid, update_cache);

                if (bans == null || bans.Count <= 0)
                {
                    return null;
                }

                string new_id = userid.ToString();
                foreach (var item in bans)
                {
                    if (item["user_id"] == new_id)
                    {
                        return item;
                    }
                }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
            
        }

        public List<Dictionary<string, string>> bansGetBansAll(long peerid, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("allbans_" + peerid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `bans` WHERE `peer_id` = '" + peerid + "' ORDER BY `user_id` ASC";
                    MySqlCommand command = new MySqlCommand(sql, handle);


                    Dictionary<long, List<long>> bansDel = new();
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        List<Dictionary<string, string>>? result_db = new();
                        if (reader.HasRows == true)
                        {
                            while (reader.Read())
                            {
                                Dictionary<string, string> local_res = new();
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    local_res.Add(reader.GetName(i), reader[i].ToString());
                                }

                                if (local_res["date_unban"] != "")
                                {
                                    var date_unban = timeGetForMysql(local_res["date_unban"]);
                                    if (date_unban.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                                    {
                                        // �������� ����
                                        if (bansDel.ContainsKey(peerid))
                                        {
                                            bansDel[peerid].Add(long.Parse(local_res["user_id"]));
                                        }
                                        else
                                        {
                                            bansDel.Add(peerid, new List<long> { long.Parse(local_res["user_id"]) });
                                        }

                                        //var thread = new Thread(
                                        //async () =>
                                        //{
                                        //try
                                        //{
                                        //bansDeleteBan(peerid, long.Parse(local_res["user_id"]));
                                        //}
                                        //catch
                                        //{

                                        //}
                                        //});
                                        //thread.Start();
                                    }
                                    else
                                    {
                                        result_db.Add(local_res);
                                    }
                                }
                                else
                                {
                                    result_db.Add(local_res);
                                }
                                //Console.WriteLine(reader[1]);

                            }
                        }
                        result = result_db;
                        if (reader != null) { try { reader.Close(); } catch { } }
                    }

                    // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    try
                    {

                    }
                    catch
                    {

                    }
                    if (bansDel != null && bansDel.Count >= 1)
                    {
                        foreach (var item in bansDel)
                        {
                            foreach (var item23 in item.Value)
                            {
                                bansDeleteBan(item.Key, item23);
                            }
                        }
                    }

                    Cache.Set("allbans_" + peerid, result, 10);
                    return result;
                }
                Cache.Set("allbans_" + peerid, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>> reportBansGetAll()
        {
            try
            {
               
                initClient();
                string sql = "SELECT * FROM `accounts` WHERE `ban_report` NOT LIKE '0' ORDER BY `userid` ASC";
                MySqlCommand command = new MySqlCommand(sql, handle);

                List<Dictionary<string, string>>? result_db = new();

                Dictionary<long, List<long>> bansDel = new();
                using (MySqlDataReader reader = command.ExecuteReader())
                {
                    
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }

                            //Console.WriteLine(reader[1]);

                        }
                    }
                    if (reader != null) { try { reader.Close(); } catch { } }
                }

                // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result_db;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void bansDeleteBan(long peerid, long user_id)
        {
            try
            {
                initClient();
                //DELETE FROM `vk_test`.`bans` WHERE  `peer_id`=1 AND `user_id`=5
                string sql = "DELETE FROM `bans` WHERE `peer_id` = @param_id AND `user_id` = @param_user;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_user", user_id);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    bansGetBan(peerid, user_id, true);
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                bansGetBan(peerid, user_id, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>> bansGetBansForUser(long userid, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("UserBans_" + userid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `bans` WHERE `user_id` = '" + userid + "' ORDER BY `date_ban` DESC";
                    MySqlCommand command = new MySqlCommand(sql, handle);


                    Dictionary<long, List<long>> bansDel = new();
                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        List<Dictionary<string, string>>? result_db = new();
                        if (reader.HasRows == true)
                        {
                            while (reader.Read())
                            {
                                Dictionary<string, string> local_res = new();
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    local_res.Add(reader.GetName(i), reader[i].ToString());
                                }

                                if (local_res["date_unban"] != "")
                                {
                                    var date_unban = timeGetForMysql(local_res["date_unban"]);
                                    if (date_unban.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                                    {
                                        long peerId = long.Parse(local_res["peer_id"]);
                                        // �������� ����
                                        if (bansDel.ContainsKey(peerId))
                                        {
                                            bansDel[peerId].Add(long.Parse(local_res["user_id"]));
                                        }
                                        else
                                        {
                                            bansDel.Add(peerId, new List<long> { long.Parse(local_res["user_id"]) });
                                        }
                                    }
                                    else
                                    {
                                        result_db.Add(local_res);
                                    }
                                }
                                else
                                {
                                    result_db.Add(local_res);
                                }
                                //Console.WriteLine(reader[1]);

                            }
                        }
                        result = result_db;
                        if (reader != null) { try { reader.Close(); } catch { } }
                    }

                    // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    try
                    {
                        if (bansDel != null && bansDel.Count >= 1)
                        {
                            foreach (var item in bansDel)
                            {
                                foreach (var item23 in item.Value)
                                {
                                    bansDeleteBan(item.Key, item23);
                                }
                            }
                            bansGetBansForUser(userid, true);
                        }
                    }
                    catch
                    {

                    }
                    
                    Cache.Set("UserBans_" + userid, result, 10);
                    return result;
                }
                Cache.Set("UserBans_" + userid, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        // ------------------------------------------------ ���������

        public Dictionary<string, string>? promosCheckPost(long postId, bool update_cache = false)
        {
            //promos_quests
            try
            {
                Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("promo_post_" + postId.ToString());
                if (result == null || update_cache == true)
                {
                    result = DbSelectOne(new Dictionary<string, string>() { { "post_id", postId.ToString() } }, "promos_quests");
                    if (result == null)
                    {
                        Cache.Set("promo_post_" + postId.ToString(), new Dictionary<string, string>());
                        return null;
                    }
                    if (result != null)
                    {
                        Cache.Set("promo_post_" + postId.ToString(), result);
                    }
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public Dictionary<string, string>? userGetPromo(long userid, long postId)
        {
            try
            {
                Dictionary<string, string>? result;
                result = DbSelectOne(new Dictionary<string, string>() { { "user_id", userid.ToString() }, { "post_id", postId.ToString() } }, "promos_successed");
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                if (result == null)
                {
                    return null;
                }
                return result;
                
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void userAddPromocode(long userid, long postId)
        {
            try
            {
                initClient();
                //DELETE FROM `vk_test`.`bans` WHERE  `peer_id`=1 AND `user_id`=5
                //INSERT INTO `vk_test_beta`.`promos_successed` (`user_id`, `post_id`) VALUES(1, 2);
                string sql = "REPLACE INTO `promos_successed` (`user_id`, `post_id`) VALUES (@param_id, @param_user);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", userid);
                command.Parameters.AddWithValue("@param_user", postId);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    userGetPromo(userid, postId);
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                userGetPromo(userid, postId);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void userSetCountPromocode(long userid, long postId, int countPromo)
        {
            try
            {
                
                initClient();
                //DELETE FROM `vk_test`.`bans` WHERE  `peer_id`=1 AND `user_id`=5
                //INSERT INTO `vk_test_beta`.`promos_successed` (`user_id`, `post_id`) VALUES(1, 2);
                string sql = "UPDATE `promos_successed` SET `count` = @param_count WHERE  `user_id`= @param_id AND `post_id`= @param_user;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", userid);
                command.Parameters.AddWithValue("@param_user", postId);
                command.Parameters.AddWithValue("@param_count", countPromo);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    userGetPromo(userid, postId);
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                userGetPromo(userid, postId);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        //UPDATE `vk_test_beta`.`promos_successed` SET `deleted`=1 WHERE  `user_id`=71082469 AND `post_id`=141;
        public void userSetDeletedPromocode(long userid, long postId, bool deleted = false)
        {
            try
            {
                initClient();
                //DELETE FROM `vk_test`.`bans` WHERE  `peer_id`=1 AND `user_id`=5
                //INSERT INTO `vk_test_beta`.`promos_successed` (`user_id`, `post_id`) VALUES(1, 2);
                string sql = "UPDATE `promos_successed` SET `deleted` = @param_del WHERE `user_id` = @param_id AND `post_id` = @param_user;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                int del = 0;
                if (deleted)
                {
                    del = 1;
                }
                command.Parameters.AddWithValue("@param_id", userid);
                command.Parameters.AddWithValue("@param_user", postId);
                command.Parameters.AddWithValue("@param_del", del);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    userGetPromo(userid, postId);
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                userGetPromo(userid, postId);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        // ----------------------------------------------------------

        //------------------------------------ SLAVES

        public List<Dictionary<string, string>> slavesGetAllForOwner(long owner, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("slaves_" + owner);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `slaves` WHERE `owner` = '" + owner + "' ORDER BY `job_pay` DESC";
                    MySqlCommand command = new MySqlCommand(sql, handle);


                    using (MySqlDataReader reader = command.ExecuteReader())
                    {
                        List<Dictionary<string, string>>? result_db = new();
                        if (reader.HasRows == true)
                        {
                            while (reader.Read())
                            {
                                Dictionary<string, string> local_res = new();
                                for (int i = 0; i < reader.FieldCount; i++)
                                {
                                    local_res.Add(reader.GetName(i), reader[i].ToString());
                                }

                                result_db.Add(local_res);
                                //Console.WriteLine(reader[1]);

                            }
                        }
                        result = result_db;
                        if (reader != null) { try { reader.Close(); } catch { } }
                    }

                    // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    try
                    {

                    }
                    catch
                    {

                    }
                    

                    Cache.Set("slaves_" + owner, result, 10);
                    return result;
                }
                Cache.Set("slaves_" + owner, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public Dictionary<string, string>? slavesGetSlave(long user_id, bool update_cache = false)
        {
            //promos_quests
            try
            {
                Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("slave_" + user_id.ToString());
                if (result == null || update_cache == true)
                {
                    result = DbSelectOne(new Dictionary<string, string>() { { "user_id", user_id.ToString() } }, "slaves");
                    if (result == null)
                    {
                        return slavesRegSlave(user_id);
                    }
                    if (result != null)
                    {
                        Cache.Set("slave_" + user_id.ToString(), result);
                    }
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }


        private Dictionary<string, string>? slavesRegSlave(long userid)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `slaves` (`user_id`) VALUES (@param_id);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", userid);
                long s = command.ExecuteNonQuery();

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                //CountriesAddMember(1);

                slavesGetSlave(userid, true);

                return slavesGetSlave(userid);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void slavesSetOwner(long userid, long owner)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "owner", owner.ToString() } }, "slaves");
                slavesGetSlave(userid, true);
                if (owner != 0)
                {
                    slavesGetAllForOwner(owner, true);
                }
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void slavesSetCost(long userid, string cost)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "cost", cost } }, "slaves");
                slavesGetSlave(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void slavesSetJobPay(long userid, string job_pay)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "job_pay", job_pay } }, "slaves");
                slavesGetSlave(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void slavesSetJob(long userid, string job)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "job", job } }, "slaves");
                slavesGetSlave(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void slaveSetLastJobZP(long userid, string dat)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "date_last_zp", dat } }, "slaves");
                slavesGetSlave(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void slaveSetArmour(long userid, string dat)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "armour", dat } }, "slaves");
                slavesGetSlave(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void slavesSetArmours(long userid, int job)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "armours", job.ToString() } }, "slaves");
                slavesGetSlave(userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }
        // ----------- BOT BANS


        public List<Dictionary<string, string>> BotBansGetBansAll(bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("botbans");
                List<long> forDelete = new();

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `botbans`;";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }

                            result_db.Add(local_res);

                            
                            //Console.WriteLine(reader[1]);

                        }
                    }
                    result = result_db;

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("botbans", result, 10);
                    //return result;
                }

                try
                {
                    if (result != null && result.Count >= 1)
                    {
                        foreach (var item in result.ToArray())
                        {
                            if (item["date_unban"] != "")
                            {
                                var date_unban = timeGetForMysql(item["date_unban"]);
                                if (date_unban.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                                {
                                    // �������� ����
                                    result.Remove(item);
                                    BotBansDeleteBan(long.Parse(item["user_id"]));
                                    //forDelete.Add(long.Parse(item["user_id"]));
                                }
                            }
                        }
                    }
                }
                catch
                {

                }
                
                Cache.Set("botbans", result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public Dictionary<string, string>? BotBansGetBan(long user_id)
        {
            try
            {
                var bans = BotBansGetBansAll();
                if (bans == null || bans.Count <= 0)
                {
                    return null;
                }

                foreach (var item in bans)
                {
                    if (item["user_id"] == user_id.ToString())
                    {
                        return item;
                    }
                }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
            
        }

        public void BotBansDeleteBan(long user_id)
        {
            try
            {
                initClient();
                //DELETE FROM `vk_test`.`bans` WHERE  `peer_id`=1 AND `user_id`=5
                string sql = "DELETE FROM `botbans` WHERE `user_id` = @param_user;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_user", user_id);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    BotBansGetBansAll(true);
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                BotBansGetBansAll(true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void BotBansAddBan(long userid, long typeBan, long admin_id, string reason, string date_unban)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `botbans` (`user_id`, `type_ban`, `banned_by`, `reason`, `date_ban`, `date_unban`) " +
                    "VALUES (@param_userid, @param_type, @param_adminid, @param_reason, CURRENT_TIMESTAMP(), @param_unban);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_type", typeBan);
                command.Parameters.AddWithValue("@param_userid", userid);
                command.Parameters.AddWithValue("@param_adminid", admin_id);
                command.Parameters.AddWithValue("@param_reason", reason);
                command.Parameters.AddWithValue("@param_unban", date_unban);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                BotBansGetBansAll(true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void BotBansAddBan(long userid, long typeBan, long admin_id, string reason, string date_unban, string comment)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `botbans` (`user_id`, `type_ban`, `banned_by`, `reason`, `date_ban`, `date_unban`, `comment`) " +
                    "VALUES (@param_userid, @param_type, @param_adminid, @param_reason, CURRENT_TIMESTAMP(), @param_unban, @param_comment);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_type", typeBan);
                command.Parameters.AddWithValue("@param_userid", userid);
                command.Parameters.AddWithValue("@param_adminid", admin_id);
                command.Parameters.AddWithValue("@param_reason", reason);
                command.Parameters.AddWithValue("@param_unban", date_unban);
                command.Parameters.AddWithValue("@param_comment", comment);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                BotBansGetBansAll(true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void BotBansSetMention(long userid, long mention)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "mention", mention.ToString() } }, "botbans");
                BotBansGetBansAll(true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        //---------------------

        public void peersDeleteMember(long peer_id, long user_id)
        {
            try
            {
                initClient();
                //DELETE FROM `vk_test`.`bans` WHERE  `peer_id`=1 AND `user_id`=5
                string sql = "DELETE FROM `peer_members` WHERE `user_id` = @param_user AND `peer_id` = @param_peer;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_user", user_id);
                command.Parameters.AddWithValue("@param_peer", peer_id);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    Cache.Delete("member_" + user_id + "_" + peer_id);
                    peerGetPeersWhereMembers(user_id, true);
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                Cache.Delete("member_" + user_id + "_" + peer_id);
                peerGetPeersWhereMembers(user_id, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public Dictionary<string, string>? peersGetMember(long peerid, long userid, bool update_cache = false, bool reg_user = true)
        {
            try
            {
                Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("member_" + userid + "_" + peerid);
                if (result == null || update_cache == true)
                {
                    result = DbSelectOne(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } }, "peer_members");
                    if (result == null)
                    {
                        if (reg_user)
                        {
                            if (handle != null)
                            {
                                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                            }
                            return peersRegMember(peerid, userid, 0, true);
                        }
                    }
                    //Cache.Delete("member_" + userid + "_" + peerid);

                    if (result != null)
                    {
                        Cache.Set("member_" + userid + "_" + peerid, result, 60);
                    }
                    else
                    {
                        Cache.Set("member_" + userid + "_" + peerid, null, 60);
                    }
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
            
        }

        public Dictionary<string, NamesRoles>? peerGetRoles(long peerid, bool update_cache = false)
        {
            try
            {
                Dictionary<string, NamesRoles>? result = Cache.Get<Dictionary<string, NamesRoles>>("peer_names_role_" + peerid);
                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `names_roles` WHERE `peer_id` = '" + peerid + "' ORDER BY `priority` DESC";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    Dictionary<string, NamesRoles>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            string prioKey = ((int)reader["priority"]).ToString();
                            if (!result_db.ContainsKey(prioKey))
                            {
                                result_db.Add(prioKey,
                                new NamesRoles
                                {
                                    admin = (long)reader["admin"],
                                    peer_id = (long)reader["peer_id"],
                                    name = reader["name"].ToString(),
                                    date_create = reader["date_create"].ToString(),
                                    priority = (int)reader["priority"]
                                });
                            }

                        }
                    }
                    result = result_db;

                    if (!result.ContainsKey("0"))
                        result.Add("0", new NamesRoles { name = "Пользователь", priority = 0, peer_id = peerid });
                    if (!result.ContainsKey("20"))
                        result.Add("20", new NamesRoles { name = "Помощник", priority = 20, peer_id = peerid });
                    if (!result.ContainsKey("40"))
                        result.Add("40", new NamesRoles { name = "Модератор", priority = 40, peer_id = peerid });
                    if (!result.ContainsKey("60"))
                        result.Add("60", new NamesRoles { name = "Администратор", priority = 60, peer_id = peerid });
                    if (!result.ContainsKey("80"))
                        result.Add("80", new NamesRoles { name = "Главный Администратор", priority = 80, peer_id = peerid });
                    if (!result.ContainsKey("100"))
                        result.Add("100", new NamesRoles { name = "Владелец", priority = 100, peer_id = peerid });

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("peer_names_role_" + peerid.ToString(), result, 10);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<warns_list>? peerGetWarnsList(long peerid, long userid, bool update_cache = false, long limit = 200)
        {
            try
            {
                List<warns_list>? result = Cache.Get<List<warns_list>>("warns_" + peerid + "_" + userid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `warns_list` WHERE `peer_id` = '" + peerid + "' AND `user_id` = '" + userid + "' ORDER BY `id` DESC LIMIT " + limit;
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<warns_list>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            result_db.Add(
                                new warns_list
                                {
                                    id = (int)reader["id"],
                                    user_id = (long)reader["user_id"],
                                    peer_id = (long)reader["peer_id"],
                                    admin_id = (long)reader["admin_id"],
                                    reason = reader["reason"].ToString(),
                                    date_created = reader["date_created"].ToString(),
                                    deleted = int.Parse(reader["deleted"].ToString())
                                });
                        }
                    }

                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("warns_" + peerid + "_" + userid, result, 10);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<warns_list>? peerGetWarnsListActive(long peerid, long userid, long limit = 200)
        {
            try
            {
                List<warns_list>? result =  new List<warns_list>();

                initClient();
                string sql = "SELECT * FROM `warns_list` WHERE `peer_id` = '" + peerid + "' AND `user_id` = '" + userid + "' AND `deleted` LIKE '0' ORDER BY `id` DESC LIMIT " + limit;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<warns_list>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result_db.Add(
                            new warns_list
                            {
                                id = (int)reader["id"],
                                user_id = (long)reader["user_id"],
                                peer_id = (long)reader["peer_id"],
                                admin_id = (long)reader["admin_id"],
                                reason = reader["reason"].ToString(),
                                date_created = reader["date_created"].ToString(),
                                deleted = int.Parse(reader["deleted"].ToString())
                            });
                    }
                }

                    result = result_db;

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<warns_list>? peerGetWarnsMans(long peerid, bool update_cache = false)
        {
            try
            {
                List<warns_list>? result = Cache.Get<List<warns_list>>("warns_" + peerid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `warns_list` WHERE `peer_id` = '" + peerid + "' AND `deleted` = '0' ORDER BY `id` DESC";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<warns_list>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            result_db.Add(
                                new warns_list
                                {
                                    id = (int)reader["id"],
                                    user_id = (long)reader["user_id"],
                                    peer_id = (long)reader["peer_id"],
                                    admin_id = (long)reader["admin_id"],
                                    reason = reader["reason"].ToString(),
                                    date_created = reader["date_created"].ToString(),
                                    deleted = int.Parse(reader["deleted"].ToString())
                                });
                        }
                    }

                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("warns_" + peerid, result, 10);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>>? peerGetAllMembers(long peerid, bool update_cache = false, long limit = 200)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("allmembers_" + peerid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `peer_members` WHERE `peer_id` = '" + peerid + "' ORDER BY `priority` DESC LIMIT " + limit;
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            if (!result_db.Contains(local_res))
                            {
                                result_db.Add(local_res);
                            }

                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("allmembers_" + peerid, result, 10);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>>? peerGetAllNotLeaveMembers(long peerid, bool update_cache = false, long limit = 200)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("allmembers_" + peerid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `peer_members` WHERE `peer_id` = '" + peerid + "' AND `leave_peer` = '0' ORDER BY `priority` DESC LIMIT " + limit;
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            if (!result_db.Contains(local_res))
                            {
                                result_db.Add(local_res);
                            }

                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("allmembers_" + peerid, result, 10);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<long>? peerGetMembersWhenRole(long peerid, bool update_cache = false, long limit = 200)
        {
            try
            {
                List<long>? result = Cache.Get<List<long>>("rolemembers_" + peerid);

                if (result == null || update_cache == true)
                {
                    result = null;
                    result = new();
                    initClient();
                    string sql = "SELECT * FROM `peer_members` WHERE `peer_id` = '" + peerid + "' AND `priority` > 0 ORDER BY `priority` DESC LIMIT " + limit;
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<long>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            if (!result_db.Contains(long.Parse(reader["user_id"].ToString())))
                            {
                                result_db.Add(long.Parse(reader["user_id"].ToString()));
                            }

                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("rolemembers_" + peerid, result, 10);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<long>? peerGetPeersWhereMembers(long userid, bool update_cache = false)
        {
            try
            {
                List<long>? result = new();

                result = new();
                initClient();
                string sql = "SELECT `peer_id` FROM `peer_members` WHERE `user_id` = '" + userid + "';";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<long>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (!result_db.Contains(long.Parse(reader["peer_id"].ToString())))
                        {
                            result_db.Add(long.Parse(reader["peer_id"].ToString()));
                        }

                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public List<Dictionary<string, string>>? getAllLogsUser(long userid, long min = 0, long max = 25)
        {
            try
            {
                   
                initClient();
                string sql = "SELECT * FROM `logs` WHERE `user_id` = '" + userid + "' OR `target_id` = '" + userid + "' ORDER BY `id` DESC LIMIT " + min + ", " + max + ";";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        Dictionary<string, string> local_res = new();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            local_res.Add(reader.GetName(i), reader[i].ToString());
                        }
                        if (!result_db.Contains(local_res))
                        {
                            result_db.Add(local_res);
                        }

                        //Console.WriteLine(reader[1]);

                    }
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result_db;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public long? agentGetQuests(long userid)
        {
            try
            {
                long? result = 0;
                initClient();
                string sql = "SELECT COUNT(*) FROM `peers` WHERE `sys_mention_worker` = '" + userid + "';";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result = long.Parse(reader["COUNT(*)"].ToString());

                        //Console.WriteLine(reader[1]);

                    }
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peersAddWarn(long peerid, long userid, long admin_id, string reason)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `warns_list` (`peer_id`, `user_id`, `admin_id`, `reason`) VALUES (@param_id, @param_userid, @param_admin, @param_reason);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_userid", userid);
                command.Parameters.AddWithValue("@param_admin", admin_id);
                command.Parameters.AddWithValue("@param_reason", reason);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peerGetWarnsList(peerid, userid, true);
                peerGetWarnsMans(peerid, true);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peerWarnsDeleteWarn(long warn_id)
        {
            try
            {
                initClient();
                string sql = "UPDATE `warns_list` SET `deleted` = 1 WHERE `id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", warn_id);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peerMembersSetWarns(long peerid, long userid, long warns)
        {
            try
            {
                initClient();
                string sql = "UPDATE `peer_members` SET `warns` = @param_warns WHERE `peer_id` = @param_id AND `user_id` = @param_userid;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_userid", userid);
                command.Parameters.AddWithValue("@param_warns", warns);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peersGetMember(peerid, userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peerMembersSetNoMention(long peerid, long userid, bool no_mention)
        {
            try
            {
                initClient();
                string sql = "UPDATE `peer_members` SET `no_mention` = @param_warns WHERE `peer_id` = @param_id AND `user_id` = @param_userid;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_userid", userid);
                command.Parameters.AddWithValue("@param_warns", no_mention);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peersGetMember(peerid, userid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peerMembersSetWelcome(long peerid, string welcome)
        {
            try
            {
                initClient();
                string sql = "UPDATE `peers` SET `welcome_text` = @param_welcome WHERE `peer_id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_welcome", welcome);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peersGetPeer(peerid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peersSetRules(long peerid, string rules)
        {
            try
            {
                initClient();
                string sql = "UPDATE `peers` SET `rules_text` = @param_welcome WHERE `peer_id` = @param_id;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_welcome", rules);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peersGetPeer(peerid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void peerWarnsClear(long peerid, long userid)
        {
            try
            {
                initClient();
                string sql = "UPDATE `warns_list` SET `deleted` = 1 WHERE `peer_id` = @param_id AND `user_id` = @param_userid;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_userid", userid);
                //command.Parameters.AddWithValue("@param_warns", warns);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peerGetWarnsList(peerid, userid, true);
                peerMembersSetWarns(peerid, userid, 0);
                peerGetWarnsMans(peerid, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
            
}

        public string rolesGetName(long peerid, string priority)
        {
            try
            {
                Dictionary<string, NamesRoles>? peerRoles = peerGetRoles(peerid);
                if (peerRoles == null) return "Роль не найдена";

                string key = priority?.Trim() ?? "";
                if (long.TryParse(key, out long prioVal))
                    key = prioVal.ToString();

                if (peerRoles.ContainsKey(key))
                {
                    return peerRoles[key].name;
                }

                foreach (var kv in peerRoles)
                {
                    if (long.TryParse(kv.Key, out long kPrio) && kPrio == prioVal)
                    {
                        return kv.Value.name;
                    }
                }

                return "Роль не найдена";
            }
            catch
            {
                return "Ошибка получения роли";
            }
        }

        public string namesRolesGetName(string priority)
        {
                    long prio = long.Parse(priority);
                    if (prio == 100)
                    {
                        return "��������";
                    }
                    else if (prio < 100 && prio >= 80)
                    {
                        return "������� �������������";
                    }
                    else if (prio < 80 && prio >= 60)
                    {
                        return "�������������";
                    }
                    else if (prio < 60 && prio >= 40)
                    {
                        return "���������";
                    }
                    else if (prio < 40 && prio >= 20)
                    {
                        return "��������";
                    }
                    else
                    {
                        return "������������";
                    }
        }

        public string peersGetNickUrl(long peerid, long userid)
        {
            Dictionary<string, string>? result = peersGetMember(peerid, userid, false, false);
            if (result == null && userid > 0)
            {
                return "[id"+userid+"|������������]";
            }
            else if (result == null && userid < 0)
            {
                return "[club" + userid.ToString().Substring(1) + "|����������]";
            }

            if (result["nick"] != "")
            {
                return "[id" + userid + "|" + result["nick"] + "]";
            }
            else
            {
                if (userid > 0)
                {
                    return "[id" + userid + "|" + rolesGetName(peerid, result["priority"]) + "]";
                }
                else
                {
                    return "[club" + userid.ToString().Substring(1) + "|����������]";
                }
            }
        }

        public async void peersMemberSetPriority(long peerid, long userid, int priority)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "priority", priority.ToString() } }, "peer_members");

            Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("member_" + userid + "_" + peerid);
            if (result != null)
            {
                result["priority"] = priority.ToString();
                Cache.Set("member_" + userid + "_" + peerid, result, 10);
            }
            else
            {
                peersGetMember(peerid, userid, true);
            }

            List<long>? result2 = Cache.Get<List<long>>("rolemembers_" + peerid);
            if (result2 != null)
            {
                result2 = result2.ToList();
                if (!result2.Contains(userid) && priority >= 1)
                {
                    result2.Add(userid);
                }
                else if (result2.Contains(userid) && priority <= 0)
                {
                    result2.Remove(userid);
                }
                Cache.Set("rolemembers_" + peerid, result2, 10);
            }
            //peerGetNickNames(peerid, true);
            return;

            //peersGetMember(peerid, userid, true);
            peerGetMembersWhenRole(peerid, true);
            return;
        }

        public async void peersMemberSetGamemode(long peerid, long userid, int gamemode, long gamemode_by)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "gamemode", gamemode.ToString() }, { "gamemode_by", gamemode_by.ToString() } }, "peer_members");

            Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("member_" + userid + "_" + peerid);
            if (result != null)
            {
                result["gamemode"] = gamemode.ToString();
                result["gamemode_by"] = gamemode_by.ToString();
                Cache.Set("member_" + userid + "_" + peerid, result, 10);
            }
            else
            {
                peersGetMember(peerid, userid, true);
            }

            List<Dictionary<string, string>>? result2 = Cache.Get<List<Dictionary<string, string>>>("gamemodes_" + peerid);
            if (result2 != null)
            {
                //result2 = result2.ToList();
                bool finded = false;
                foreach (var item in result2.ToList())
                {
                    if (item["user_id"] == userid.ToString() && gamemode <= 0)
                    {
                        finded = true;
                        result2.Remove(item);
                        break;
                    }
                    if (item["user_id"] == userid.ToString())
                    {
                        if (item["gamemode"] != gamemode.ToString())
                        {
                            item["gamemode"] = gamemode.ToString();
                        }
                        if (item["gamemode_by"] != gamemode_by.ToString())
                        {
                            item["gamemode_by"] = gamemode_by.ToString();
                        }
                        finded = true;
                        break;
                    }
                }
                if (!finded)
                {
                    result2.Add(new Dictionary<string, string>()
                    {
                        { "gamemode", gamemode.ToString() },
                        { "gamemode_by", gamemode_by.ToString() },
                        { "peer_id", peerid.ToString() },
                        { "user_id", userid.ToString() }
                    });
                }
                Cache.Set("gamemodes_" + peerid, result2, 10);
            }
            //peerGetNickNames(peerid, true);
            return;

            //peersGetMember(peerid, userid, true);
            peerGetMembersWhenRole(peerid, true);
            return;
        }


        public List<Dictionary<string, string>> peerGetGamemodes(long peer_id = 0, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                result = Cache.Get<List<Dictionary<string, string>>>("gamemodes_" + peer_id);


                if (result == null || update_cache)
                {
                    initClient();
                    string sql = "SELECT `user_id`, `peer_id`, `gamemode`, `gamemode_by` FROM `peer_members` WHERE `peer_id` = '" + peer_id + "' AND `gamemode` != '0';";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var tempDict = new Dictionary<string, string>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                //columns.Add(reader.GetName(i));
                                tempDict[reader.GetName(i)] = reader[i].ToString();
                            }
                            result_db.Add(tempDict);
                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                        if (reader != null) { try { reader.Close(); } catch { } }
                        if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    }
                    else
                    {
                        if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                        if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                        Cache.Set("gamemodes_" + peer_id.ToString(), new List<Dictionary<string, string>>(), 10);
                        return result;
                    }
                }

                Cache.Set("gamemodes_" + peer_id.ToString(), result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }

        }



        public async void peersMemberSetNickName(long peerid, long userid, string? nick)
        {
            if ((nick != null && nick.Replace( " ", "") ==  "") || (nick !=null && nick == ""))
            {
                nick = null;
            }
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "nick", nick } }, "peer_members");
            
            Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("member_" + userid + "_" + peerid);
            if (result != null)
            {
                if (nick == null || nick == "")
                {
                    peersGetMember(peerid, userid, true, false);

                }
                else
                {
                    result["nick"] = nick;
                    Cache.Set("member_" + userid + "_" + peerid, result, 10);
                }
            }
            else
            {
                peersGetMember(peerid, userid, true, false);
            }

            try
            {
                var result2 = Cache.Get<List<Dictionary<string, string>>>("peer_nicks_" + peerid);
                if (result2 != null)
                {
                    result2 = result2.ToList();
                    bool isFind = false;
                    for (int i = 0; i < result2.Count; i++)
                    {
                        if (result2[i]["user_id"] == userid.ToString())
                        {
                            if (nick == null)
                            {
                                result2.RemoveAt(i);
                                isFind = true;
                                break;
                            }
                            result2[i]["nick"] = nick;
                            isFind = true;
                            break;
                        }
                    }
                    if (!isFind)
                    {
                        result2.Add(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() }, { "nick", nick } });
                    }
                    Cache.Set("peer_nicks_" + peerid, result2, 10);
                }
            }
            catch (Exception ex)
            {
                //
                Console.WriteLine(ex.Message);
            }
            
            //peerGetNickNames(peerid, true);
            return;
        }

        public async void peersMemberSetLeavePeer(long peerid, long userid, string leave)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "leave_peer", leave } }, "peer_members");
            peersGetMember(peerid, userid, true);
            peerGetAllMembers(peerid, true, 10000);
            return;
        }

        public async void peersMemberSetInviter(long peerid, long userid, long inviter)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "invited_by", inviter.ToString() } }, "peer_members");
            peersGetMember(peerid, userid, true);
            peerGetAllMembers(peerid, true, 10000);
            return;
        }

        public void peersMemberSetMute(long peerid, long userid, string? mute)
        {
            if (mute == "")
            {
                mute = null;
            }
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "mute", mute } }, "peer_members");
            peersGetMember(peerid, userid, true);
            return;
        }

        /*public void peersMemberSetPriority(long peerid, long userid, int? role)
        {
            if (role == null)
            {
                role = 0;
            }
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "priority", role.ToString() } }, "peer_members");
            peersGetMember(peerid, userid, true);
            return;
        }*/

        public void peersSetKickexit(long peerid, long kickExit)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickexit", kickExit.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        /*public void peersSetKickPhotos(long peerid, long kickExit)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickphotos", kickExit.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }*/

        public void peersSetKickExitRole(long peerid, long kickExit)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickexitrole", kickExit.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetKickInviter(long peerid, long kickInviter)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickinviter", kickInviter.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetExitRemoveNick(long peerid, long removeNick)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_exitremovenick", removeNick.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetKickExitGroup(long peerid, long kickGroup)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickexitgroup", kickGroup.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetTypeMute(long peerid, long typeMute)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_typemute", typeMute.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetSilence(long peerid, long silence)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "silence", silence.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetInPool(long peerid, long pool)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "in_pool", pool.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetKickPhotos(long peerid, long kick_photos)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickphotos", kick_photos.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetKickWalls(long peerid, long kick_photos)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickposts", kick_photos.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetKickLinks(long peerid, long kick_photos)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kicklinks", kick_photos.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetKickObscen(long peerid, long kick_photos)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickobscen", kick_photos.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetActionActive(long peerid, long kick_photos)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_action_activity", kick_photos.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetActionKickNsfw(long peerid, long kick_photos)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kicknsfw", kick_photos.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }
        //
        public void peersSetMentions(long peerid, long mentions)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_mentions", mentions.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetGames(long peerid, long set_games)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_games", set_games.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void unitesPlusUnity(long unityid, long plus)
        {
            initClient();
            string sql = "UPDATE `pools` SET `peers` = `peers` + '" + plus + "' WHERE `id` = '" + unityid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            unitesGetUnity(unityid, true);
            return;
        }

        public void unitesMinusUnity(long unityid, long plus)
        {
            initClient();
            string sql = "UPDATE `pools` SET `peers` = `peers` - '" + plus + "' WHERE `id` = '" + unityid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            unitesGetUnity(unityid, true);
            return;
        }

        public void unitesSetName(long unityid, string name)
        {
            initClient();
            string sql = "UPDATE `pools` SET `name` = @param_name WHERE `id` = '" + unityid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_name", name);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            /*catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }*/
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            unitesGetUnity(unityid, true);
            return;
        }

        public void unitesSetDesc(long unityid, string name)
        {
            initClient();
            string sql = "UPDATE `pools` SET `description` = @param_name WHERE `id` = '" + unityid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_name", name);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            /**/
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            unitesGetUnity(unityid, true);
            return;
        }

        public void unitesDeleteUnity(long unityid)
        {
            initClient();
            string sql = "DELETE FROM `pools` WHERE `id` = '" + unityid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }

        public void peersClearUnityFromUnity(long unityid)
        {
            initClient();
            string sql = "UPDATE `peers` SET `in_pool`= '0' WHERE `in_pool` = '" + unityid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }

        //

        public void peersSetRoleInviter(long peerid, long priority)
        {
            initClient();
            string sql = "UPDATE `peers` SET `set_inviterrole`= '" + priority +"' WHERE `peer_id` = '" + peerid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                peersGetPeer(peerid, true);
                return;
            }
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            peersGetPeer(peerid, true);
            return;
        }


        public Dictionary<string, DataBaseClass.rules_cmds>? CommandsGetRulesDb(long peerid, bool update_cache = false)
        {
            try
            {
                Dictionary<string, rules_cmds>? result_cache = Cache.Get<Dictionary<string, rules_cmds>>("peercmds_" + peerid.ToString());
                if (result_cache != null && update_cache == false)
                {
                    return result_cache;
                }
                //--------------------
                initClient();
                string sql = "SELECT * FROM `rules_cmds` WHERE `peer_id` = '" + peerid + "'";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<string, rules_cmds>? result = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        if (!result.ContainsKey(reader["command"].ToString()))
                        {
                            result.Add(reader["command"].ToString(),
                            new rules_cmds
                            {
                                admin = (long)reader["admin"],
                                peer_id = (long)reader["peer_id"],
                                command = reader["command"].ToString(),
                                priority = (int)reader["priority"]

                            });
                        }

                    }
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                if (result.Count > 0)
                {
                    Cache.Set("peercmds_" + peerid.ToString(), result, 10);
                    return result;
                }
                else
                {
                    Cache.Set("peercmds_" + peerid.ToString(), result, 10);
                    return null;
                }
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public void CommandsSetRuleDb(long peerid, string command_text, long priority, long admin_id)
        {
            var commands = CommandsGetRulesDb(peerid);
            if (commands != null && commands.ContainsKey(command_text))
            {
                DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "command", command_text } },
                new Dictionary<string, string>() { { "priority", priority.ToString() }, { "admin", admin_id.ToString() } }, "rules_cmds");
                CommandsGetRulesDb(peerid, true);
                return;
            }
            else
            {
                initClient();
                string sql = "INSERT INTO `rules_cmds` (`peer_id`, `command`, `priority`, `admin`) VALUES (@param_id, @param_comm, @param_priority, @param_admin);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peerid);
                command.Parameters.AddWithValue("@param_comm", command_text);
                command.Parameters.AddWithValue("@param_priority", priority);
                command.Parameters.AddWithValue("@param_admin", admin_id);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                CommandsGetRulesDb(peerid, true);
                return;
            }
        }

        public void peersSetVip(long peerid, string? vipTime)
        {

            if (vipTime == "")
            {
                vipTime = null;
            }
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "vip", vipTime } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public void peersSetAccessToken(long peerid, string access_token)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "access_token", access_token.ToString() } }, "peers");
            if (access_token == null || access_token == "")
            {
                DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "set_kickexitgroup", "0" } }, "peers");
            }
            
            peersGetPeer(peerid, true);
            return;
        }

        public void usersSetAccessToken(long userid, string access_token)
        {
            if (access_token == "")
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "access_token", "NULL" } }, "accounts");
            }
            else
            {
                DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "access_token", SysUtils.EncryptString(access_token) } }, "accounts");
            }

            usersGetUser(userid, true);
            return;
        }

        public void peerSetData(long peerid, string title, long members, string photo = "", long owner_id = 0, long inviter = 0)
        {
            if (photo != "")
            {
                if (owner_id != 0 && inviter != 0)
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() }, 
                            { "logo", photo }, { "owner", owner_id.ToString() }, { "inviter", inviter.ToString() }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
                else if (owner_id == 0 && inviter != 0)
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() },
                            { "logo", photo }, { "inviter", inviter.ToString() }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
                else if (owner_id != 0 && inviter == 0)
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() },
                            { "logo", photo }, { "owner", owner_id.ToString() }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
                else
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() },
                            { "logo", photo }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
            }
            else
            {
                if (owner_id != 0 && inviter != 0)
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() },
                            { "owner", owner_id.ToString() }, { "inviter", inviter.ToString() }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
                else if (owner_id == 0 && inviter != 0)
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() },
                            { "inviter", inviter.ToString() }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
                else if (owner_id != 0 && inviter == 0)
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() },
                            { "owner", owner_id.ToString() }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
                else
                {
                    DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                        new Dictionary<string, string>() { { "title", title }, { "current_members", members.ToString() }, { "date_sync", "CURRENT_TIMESTAMP()" } }, "peers");
                }
            }
            peersGetPeer(peerid, true);
            return;
        }

        public void peerDeactivate(long peerid)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "active", "0" }, { "date_last", "CURRENT_TIMESTAMP()" } }, "peers");
                DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                    new Dictionary<string, string>() { { "leave_peer", "1" } }, "peer_members");
                peersGetPeer(peerid, true);
                var users = peerGetAllMembers(peerid, true, 3000);
                foreach (var item in users)
                {
                    peersGetMember(peerid, long.Parse(item["user_id"]), true, false);
                }
            }
            catch
            {

            }
            return;
        }

        public void peerMembersDeleteForPeer(long peerid)
        {
            initClient();
            string sql = "DELETE FROM `peer_members` WHERE `peer_id` = '" + peerid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }

        public bool PeerIsVip(Dictionary<string, string>PeerInfo)
        {
            if (PeerInfo["vip"] != "")
            {
                var vip_time = timeGetForMysql(PeerInfo["vip"]);
                if (vip_time.ToUnixTimeSeconds() > DateTimeOffset.Now.ToUnixTimeSeconds())
                {
                    return true;
                }
                else
                {
                    peersSetVip(long.Parse(PeerInfo["peer_id"]), "");
                    return false;
                }
            }
            else
            {
                return false;
            }
        }

        public bool UserIsVip(long userid)
        {
            return true;
            var globalAccount = usersGetUser(userid);
            if (globalAccount["vip_type"] != "0")
            {
                if (globalAccount["vip"] == "")
                {
                    return true;
                }
                var vip_time_user = timeGetForMysql(globalAccount["vip"]);

                if (vip_time_user.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                {
                    usersSetVipType(userid, 0);
                    usersSetVipTime(userid, null);
                    return false;
                }
                else
                {
                    return true;
                }
            }
            else
            {
                return false;
            }
        }

        public long peersGetCount()
        {
            try
            {
                //SELECT COUNT(*) FROM `vk_test`.`peers`;
                initClient();
                string sql = "SELECT COUNT(*) FROM `peers`";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                long count = 0;
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        count = long.Parse(reader[0].ToString());
                        //Console.WriteLine(reader[1]);
                    }
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return count;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
            
        }

        public long accountsGetCacheCount(bool update_cache = false)
        {
            try
            {
                string? result = Cache.Get<string>("count_accounts");

                if (result == null || update_cache)
                {
                    initClient();
                    string sql = "SELECT COUNT(*) FROM `accounts`";
                    //SELECT `peer_id` FROM `peers` LIMIT 1000;
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    long count = 0;
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            count = long.Parse(reader[0].ToString());
                            //Console.WriteLine(reader[1]);
                        }
                    }
                    Cache.Set("count_accounts", count.ToString(), 50);
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return count;
                }

                return long.Parse(result);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
        }

        public long peersGetCacheCount(bool update_cache = false)
        {
            try
            {
                string? result = Cache.Get<string>("count_cached_peers");

                if (result == null || update_cache)
                {
                    initClient();
                    string sql = "SELECT COUNT(*) FROM `peers`";
                    //SELECT `peer_id` FROM `peers` LIMIT 1000;
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    long count = 0;
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            count = long.Parse(reader[0].ToString());
                            //Console.WriteLine(reader[1]);
                        }
                    }
                    Cache.Set("count_cached_peers", count.ToString(), 50);
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return count;
                }

                return long.Parse(result);
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return 0;
            }
        }

        public void peersSetGroup(long peerid, long group_id)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "group", group_id.ToString() } }, "peers");
            peersGetPeer(peerid, true);
            return;
        }

        public long peersGetActiveCount()
        {
            //SELECT COUNT(*) FROM `vk_test`.`peers`;
            initClient();
            string sql = "SELECT COUNT(*) FROM `peers` WHERE `active` = '1' AND `set_mentions` = '1'";
            //SELECT `peer_id` FROM `peers` LIMIT 1000;
            MySqlCommand command = new MySqlCommand(sql, handle);

            MySqlDataReader reader = command.ExecuteReader();

            long count = 0;
            if (reader.HasRows)
            {
                while (reader.Read())
                {
                    count = long.Parse(reader[0].ToString());
                    //Console.WriteLine(reader[1]);
                }
            }

            if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return count;
        }

        public string getDateRegCache(long userid)
        {
            string? results = Cache.Get<string>("date_reg_" + userid.ToString());
            if (results == null || results == "")
            {
                return null;
            }
            else
            {
                return results;
            }
        }

        public void setDateRegCache(long userid, string date_reg)
        {
            Cache.Set("date_reg_" + userid.ToString(), date_reg, 10);
        }

        public void setDateRegVkUser(long userid, string date_reg)
        {
            DbUpdate(new Dictionary<string, string>() { { "userid", userid.ToString() } },
                new Dictionary<string, string>() { { "date_reg_vk", date_reg.ToString() } }, "accounts");
            usersGetUser(userid, true);
            return;
        }

        public List<long>? peersGetAllIds(long min = 0, long max = 1000)
        {
            try
            {
                List<long>? result = new();

                initClient();
                //string sql = "SELECT * FROM `peers` WHERE `active` = '1' AND peer_id > 2000048000 LIMIT " + min + "," + max;
                string sql = "SELECT * FROM `peers` WHERE `active` = '1' ORDER BY `peer_id` DESC LIMIT " + min + "," + max;
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<long>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result_db.Add(long.Parse(reader[1].ToString()));
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<long>? peersGetAllIdsForSendMass(long min = 0, long max = 100000)
        {
            try
            {
                List<long>? result = new();

                initClient();
                string sql = "SELECT * FROM `peers` WHERE (`set_mentions` IS NULL OR `set_mentions` = '0') LIMIT " + max;
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<long>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        result.Add(long.Parse(reader[1].ToString()));
                        //Console.WriteLine(reader[1]);

                    }
                    //result.Add(result_db);
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<string, string>? unitesGetUnity(long unityid, bool update_cache = false)
        {
            Dictionary<string, string>? result = Cache.Get<Dictionary<string, string>>("unity_" + unityid.ToString());
            if (result == null || update_cache == true)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "id", unityid.ToString() } }, "pools");
                if (result == null)
                {
                    return null;
                }
                if (result != null)
                {
                    Cache.Set("unity_" + unityid.ToString(), result, 10);
                }
                return result;
            }
            return result;
        }

        public List<Dictionary<string, string>>? unitesGetListUnity(long owner_id, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("unitylist_" + owner_id);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `pools` WHERE `owner_id` = '" + owner_id + "'";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result_db.Add(local_res);
                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("unitylist_" + owner_id, result, 15);
                    return result;
                }
                Cache.Set("unitylist_" + owner_id, result, 15);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<long>? unitesGetPeers(long unityid, bool update_cache = false)
        {
            try
            {
                List<long>? result = Cache.Get<List<long>>("unity_peers_" + unityid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT `peer_id` FROM `peers` WHERE `in_pool` = '" + unityid + "'";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<long>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            result_db.Add(long.Parse(reader[0].ToString()));
                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("unity_peers_" + unityid, result, 10);
                    return result;
                }
                Cache.Set("unity_peers_" + unityid, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public long unitesAddUnity(long ownerid)
        {
            initClient();
            string sql = "INSERT INTO `pools` (`owner_id`) VALUES (@param_id);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_id", ownerid);
            try
            {
                long s = command.ExecuteNonQuery();
                //comm.ExecuteNonQuery();              // Execute the command
                long id = command.LastInsertedId;
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                unitesGetListUnity(ownerid, true);
                return id;
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return 0;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            
            return 0; 
        }

        public List<Dictionary<string, string>> peerGetNickNames(long peer_id = 0, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                result = Cache.Get<List<Dictionary<string, string>>>("peer_nicks_" + peer_id);


                if (result == null || update_cache)
                {
                    initClient();
                    string sql = "SELECT `user_id`, `peer_id`, `nick` FROM `peer_members` WHERE `peer_id` = '" + peer_id + "' AND `nick` IS NOT NULL AND `nick` != '';";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var tempDict = new Dictionary<string, string>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                //columns.Add(reader.GetName(i));
                                tempDict[reader.GetName(i)] = reader[i].ToString();
                            }
                            result_db.Add(tempDict);
                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                        if (reader != null) { try { reader.Close(); } catch { } }
                        if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    }
                    else
                    {
                        if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                        if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                        Cache.Set("peer_nicks_" + peer_id.ToString(), new List<Dictionary<string, string>>(), 10);
                        return result;
                    }
                }

                Cache.Set("peer_nicks_" + peer_id.ToString(), result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            
        }

        public void rolesAddName(long peerid, long role, string rolename, long by_id)
        {
            initClient();
            string sql = "INSERT INTO `names_roles` (`peer_id`, `priority`, `name`, `date_create`, `admin`) VALUES " +
                "(@param_peerid, @param_priority, @param_name, CURRENT_TIMESTAMP(), @param_admin);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peerid", peerid);
            command.Parameters.AddWithValue("@param_priority", role);
            command.Parameters.AddWithValue("@param_name", rolename);
            command.Parameters.AddWithValue("@param_admin", by_id);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch (Exception e)
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            peerGetRoles(peerid, true);
            
            return;
        }

        public void rolesDelName(long peerid, long role)
        {
            initClient();
            string sql = "DELETE FROM `names_roles` WHERE `peer_id` = @param_peerid AND `priority` = @param_priority;";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peerid", peerid);
            command.Parameters.AddWithValue("@param_priority", role);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            peerGetRoles(peerid, true);
            return;
        }

        public void rolesSetName(long peerid, long role, string rolename, long by_id)
        {
            initClient();
            string sql = "UPDATE `names_roles` SET `name` = @param_name, `admin` = '" + by_id + "', `date_create` = CURRENT_TIMESTAMP()" +
                " WHERE `peer_id` = '" + peerid + "' AND `priority` = '" + role + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_name", rolename);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            peerGetRoles(peerid, true);
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }

        public Dictionary<string, string> reportGet(long from_id = 0, long peer_id = 0, bool update_cache = false)
        {
            var result = Cache.Get<Dictionary<string, string>>("report_" + from_id + "_" + peer_id);
            if (result == null || update_cache == true)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "from_id", from_id.ToString() }, { "closed", "0" } }, "reports");
                if (result == null)
                {
                    Cache.Delete("report_" + from_id + "_" + peer_id);
                }
                else
                {
                    Cache.Set("report_" + from_id + "_" + peer_id, result, 10);
                }
                
                return result;
            }
            return result;
        }

        public List<string> reportGetForUser(long user_id = 0, bool update_cache = false)
        {
            try
            {
                var result = Cache.Get<List<string>>("reports_" + user_id);
                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `reports` WHERE `from_id` = '" + user_id + "'";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result.Add(local_res["id"]);
                            //Console.WriteLine(reader[1]);

                        }
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("reports_" + user_id, result, 15);
                    return result;
                }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<string, string> reportGet(long report_id, bool update_cache = false)
        {
            var result = Cache.Get<Dictionary<string, string>>("report_" + report_id);
            if (result == null || update_cache == true)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "id", report_id.ToString() } }, "reports");
                Cache.Set("report_" + report_id, result, 10);
                return result;
            }
            return result;
        }

        public List<Dictionary<string, string>> reportMessagesGet(long report_id = 0, long max = 10)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `reports_messages` WHERE `report_id` = '" + report_id + "' ORDER BY `date_created` DESC LIMIT " + max + ";";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(tempDict);
                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } }
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        //

        public List<Dictionary<string, string>> reportsGetAllOpenned(long min = 0, long max = 20)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `reports` WHERE `closed` = '0' ORDER BY `last_activity` ASC LIMIT " + min + "," + max + ";";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<Dictionary<string, string>> peerGetNotActiveButReggistred(long min = 0, long max = 20)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `peers` WHERE `active` = '0' AND `inviter` != '0' AND `sys_mention_worker` = '0' ORDER BY `date_last` ASC LIMIT " + min + "," + max + ";";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<Dictionary<string, string>> AgentsGetPeersNotAnsweredQuest(long from_id = 0, long min = 0, long max = 20)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                initClient();
                string sql = $"SELECT * FROM peers WHERE sys_mention_worker = '{from_id}' AND sys_mention_non_active = 0 ORDER BY `date_last` ASC LIMIT " + min + "," + max + ";";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<Dictionary<string, string>> peerGetNotActiveButReggistredAndAnswered(long min = 0, long max = 20)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `peers` WHERE `sys_mention_non_active` != '0' ORDER BY `date_last` DESC LIMIT " + min + "," + max + ";";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public void peersSetMentionWorker(long peerid, long worker)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "sys_mention_worker", worker.ToString() } }, "peers");
            peersGetPeer(peerid, true, false);
            return;
        }

        public void peersSetMentionDate(long peerid, string date)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "sys_mention_date", date } }, "peers");
            peersGetPeer(peerid, true, false);
            return;
        }

        public void peersSetMentionComment(long peerid, string comment)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "sys_mention_comment", comment } }, "peers");
            peersGetPeer(peerid, true, false);
            return;
        }

        public void peersSetMentionType(long peerid, long comment)
        {
            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "sys_mention_non_active", comment.ToString() } }, "peers");
            peersGetPeer(peerid, true, false);
            return;
        }

        public List<Dictionary<string, string>> ClosePeerDialogGetMessages(long peer_id = 0, long max = 10)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `closepeer_attachments` WHERE `peer_id` = '" + peer_id + "' ORDER BY `id` DESC LIMIT " + max + ";";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public void reportInsert(long from_id = 0, long peer_id = 0)
        {
            initClient();
            string sql = "INSERT INTO `reports` (`from_id`, `peer_id`, `last_activity`) VALUES (@param_userid, @param_id, CURRENT_TIMESTAMP());";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_id", peer_id);
            command.Parameters.AddWithValue("@param_userid", from_id);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("[REPORT DEBUG] reportInsert ERROR: " + ex.Message);
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }


            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            reportGetForUser(from_id, true);
            return;
        }

        public void reportAttachmentsAddPhoto(long peer_id = 0, long report_id = 0, long report_message_id = 0, long from_id = 0, string access_key = "",
            long id = 0, long album_id = 0, long owner_id = 0, long user_id = 0, string text = "nil", string url_photo = "")
        {
            initClient();
            string sql = "INSERT INTO `report_attachments` (`peer_id`, `report_id`, `report_message_id`, " +
                "`from_id`, `type`, `access_key`, `photo_id`, `photo_album_id`, `photo_owner_id`, `photo_user_id`, `photo_text`, `photo_link`) VALUES " +
                "(@param_peerid, @param_reportid, @param_message_id, @param_from_id, 'photo', @param_access_key, @param_photoid, " +
                "@param_album_id, @param_owner_id, @param_user_id, @param_text, @param_link);";
            //INSERT INTO `vk_test`.`report_attachments` (`peer_id`, `report_id`, `report_message_id`, `from_id`, `type`, `access_key`, `photo_id`, `photo_album_id`, `photo_owner_id`, `photo_user_id`, `photo_text`) VALUES ('4', '4', '4', '4', 'dd', '2', '2', '2', '2', '2', '2');

            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peerid", peer_id);
            command.Parameters.AddWithValue("@param_reportid", report_id);
            command.Parameters.AddWithValue("@param_message_id", report_message_id);
            command.Parameters.AddWithValue("@param_from_id", from_id);
            command.Parameters.AddWithValue("@param_access_key", access_key);
            command.Parameters.AddWithValue("@param_photoid", id);
            command.Parameters.AddWithValue("@param_album_id", album_id);
            command.Parameters.AddWithValue("@param_owner_id", owner_id);
            command.Parameters.AddWithValue("@param_user_id", user_id);
            command.Parameters.AddWithValue("@param_text", text);
            command.Parameters.AddWithValue("@param_link", url_photo);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }

        public void closePeerAddAttachments(long peer_id = 0, long from_id = 0, string access_key = "",
            long id = 0, long album_id = 0, long owner_id = 0, long user_id = 0, string text = "nil", string system_text = "nil", string type = "photo")
        {
            initClient();
            string sql = "INSERT INTO `closepeer_attachments` (`peer_id`, " +
                "`from_id`, `type`, `access_key`, `photo_id`, `photo_album_id`, `photo_owner_id`, `photo_user_id`, `photo_text`, `text`) VALUES " +
                "(@param_peerid, @param_from_id, @param_type, @param_access_key, @param_photoid, " +
                "@param_album_id, @param_owner_id, @param_user_id, @param_text, @param_systext);";
            //INSERT INTO `vk_test`.`report_attachments` (`peer_id`, `report_id`, `report_message_id`, `from_id`, `type`, `access_key`, `photo_id`, `photo_album_id`, `photo_owner_id`, `photo_user_id`, `photo_text`) VALUES ('4', '4', '4', '4', 'dd', '2', '2', '2', '2', '2', '2');

            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peerid", peer_id);
            command.Parameters.AddWithValue("@param_from_id", from_id);
            command.Parameters.AddWithValue("@param_access_key", access_key);
            command.Parameters.AddWithValue("@param_photoid", id);
            command.Parameters.AddWithValue("@param_album_id", album_id);
            command.Parameters.AddWithValue("@param_owner_id", owner_id);
            command.Parameters.AddWithValue("@param_user_id", user_id);
            command.Parameters.AddWithValue("@param_text", text);
            command.Parameters.AddWithValue("@param_systext", system_text);
            command.Parameters.AddWithValue("@param_type", type);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }


        public Dictionary<string, string> reportGetAttachmentMessId(long report_id = 0, long messageId = 0)
        {
            var result = Cache.Get<Dictionary<string, string>>("report_att_" + report_id + "_" + messageId);
            if (result == null)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "report_id", report_id.ToString() }, { "report_message_id", messageId.ToString() } }, "report_attachments");
                Cache.Set("report_att_" + report_id + "_" + messageId, result, 10);
                return result;
            }
            return result;
        }

        // SELECT * FROM `vk_test`.`report_attachments` LIMIT 1000;
        public void reportAddMessage(long report_id = 0, long from_id = 0, long attachments = 0, string message = "nil", bool is_worker = false)
        {
            initClient();
            int workerVal = is_worker ? 1 : 0;
            string sql = "INSERT INTO `reports_messages` (`report_id`, `from_id`, `message`, `attachments`, `is_worker`) " +
                "VALUES (@param_reportid, @param_userid, @param_text, @param_att, @param_worker);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_reportid", report_id);
            command.Parameters.AddWithValue("@param_userid", from_id);
            command.Parameters.AddWithValue("@param_text", message);
            command.Parameters.AddWithValue("@param_att", attachments);
            command.Parameters.AddWithValue("@param_worker", workerVal);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine("[REPORT DEBUG] reportAddMessage ERROR: " + ex.Message);
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }

        public void reportSetClose(long reportid, long closed, long from_id, long peer_id, long admin_id)
        {
            if (closed == 1)
            {
                DbUpdate(new Dictionary<string, string>() { { "id", reportid.ToString() } },
                new Dictionary<string, string>() { { "closed", closed.ToString() }, { "close_time", timeGetForString(DateTimeOffset.Now) },
                    { "close_id", admin_id.ToString() } }, "reports");
            }
            else
            {
                DbUpdate(new Dictionary<string, string>() { { "id", reportid.ToString() } },
                new Dictionary<string, string>() { { "closed", closed.ToString() } }, "reports");
            }
            
            reportGet(reportid, true);
            reportGet(from_id, peer_id, true);
            return;
        }

        public void reportSetWorker(long reportid, long worker_id, long peer_id, long from_id)
        {
            DbUpdate(new Dictionary<string, string>() { { "id", reportid.ToString() } },
                new Dictionary<string, string>() { { "worker", worker_id.ToString() } }, "reports");
            reportGet(reportid, true);
            reportGet(from_id, peer_id, true);
            return;
        }

        public void reportSetMark(long reportid, long mark)
        {
            DbUpdate(new Dictionary<string, string>() { { "id", reportid.ToString() } },
                new Dictionary<string, string>() { { "mark", mark.ToString() } }, "reports");
            reportGet(reportid, true);
            return;
        }

        // --------------------------------------------------------------------------------------- CUSTOM CMDS ��������� ���


        public Dictionary<string, Dictionary<string, string>> CustomCmdsGetAll(long peerid, bool update_cache = false)
        {
            try
            {
                Dictionary<string, Dictionary<string, string>>? result = Cache.Get<Dictionary<string, Dictionary<string, string>>>($"ccmds_{peerid}");

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = $"SELECT * FROM `custom_cmds` WHERE `peer_id` LIKE '{peerid}';";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    Dictionary<string, Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result_db.Add(local_res["command"], local_res);
                            //Console.WriteLine(reader[1]);

                        }
                    }
                    result = result_db;

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set($"ccmds_{peerid}", result, 30);
                    return result;
                }
                else
                {

                }
                Cache.Set($"ccmds_{peerid}", result, 30);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }



        // -------------------------------------------------------------------------------------- ������ � ����� ������ ������

        public List<Dictionary<string, string>>? whiteListLinksGet(long peer_id, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("whitelinks_" + peer_id);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT * FROM `whitelist_links` WHERE `peer_id` = '" + peer_id + "'";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result_db.Add(local_res);
                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("whitelinks_" + peer_id, result, 30);
                    return result;
                }
                Cache.Set("whitelinks_" + peer_id, result, 30);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public void whiteListLinksAdd(long peerid, string domain, long user_id)
        {
            initClient();
            string sql = "INSERT INTO `whitelist_links` (`peer_id`, `domain`, `owner_id`) VALUES " +
                "(@param_peerid, @param_domain, @param_owner_id);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peerid", peerid);
            command.Parameters.AddWithValue("@param_domain", domain);
            command.Parameters.AddWithValue("@param_owner_id", user_id);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                List<Dictionary<string, string>>? res = Cache.Get<List<Dictionary<string, string>>>("whitelinks_" + peerid);
                if (res != null)
                {
                    res.Add(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "domain", domain }, { "owner_id", user_id.ToString() },
                    { "date_add", timeGetForString(DateTimeOffset.Now) } });
                    Cache.Set("whitelinks_" + peerid, res, 30);
                }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("whitelinks_" + peerid);
            if (result != null)
            {
                result.Add(new Dictionary<string, string>() { { "peer_id", peerid.ToString() }, { "domain", domain }, { "owner_id", user_id.ToString() }, 
                    { "date_add", timeGetForString(DateTimeOffset.Now) } });
                Cache.Set("whitelinks_" + peerid, result, 30);
            }
            //peerGetRoles(peerid, true);
            return;
        }

        public void whiteListLinksDel(long peerid, string domain)
        {
            initClient();
            string sql = "DELETE FROM `whitelist_links` WHERE `peer_id` = @param_peerid AND `domain` = @param_priority;";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peerid", peerid);
            command.Parameters.AddWithValue("@param_priority", domain);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                List<Dictionary<string, string>>? res = Cache.Get<List<Dictionary<string, string>>>("whitelinks_" + peerid);
                if (res != null)
                {
                    foreach (var item in res)
                    {
                        if (item["domain"] == domain)
                        {
                            res.Remove(item);
                            break;
                        }
                    }
                    Cache.Set("whitelinks_" + peerid, res, 30);
                }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            List<Dictionary<string, string>>? result = Cache.Get<List<Dictionary<string, string>>>("whitelinks_" + peerid);
            if (result != null)
            {
                foreach (var item in result)
                {
                    if (item["domain"] == domain)
                    {
                        result.Remove(item);
                        break;
                    }
                }
                Cache.Set("whitelinks_" + peerid, result, 30);
            }
            return;
        }


        public Dictionary<string, string>? deletedMessagesGet(long peer_id, long mess_id)
        {
            try
            {
                var result = DbSelectOne(new Dictionary<string, string>() { { "peer_id", peer_id.ToString() }, { "message_id", mess_id.ToString() } }, "deletedFilter");
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }

        }

        public Dictionary<string, Dictionary<string, string>> FilterWordsGetWords(long peerid, bool update_cache = false)
        {
            try
            {
                Dictionary<string, Dictionary<string, string>>? result = Cache.Get<Dictionary<string, Dictionary<string, string>>>($"black_words_{peerid}");

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = $"SELECT * FROM `blacklist_words` WHERE `peer_id` LIKE '{peerid}';";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    Dictionary<string, Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            Dictionary<string, string> local_res = new();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                local_res.Add(reader.GetName(i), reader[i].ToString());
                            }
                            result_db.Add(local_res["word"], local_res);
                            //Console.WriteLine(reader[1]);

                        }
                    }
                    result = result_db;

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set($"black_words_{peerid}", result, 30);
                    return result;
                }
                else
                {

                }
                Cache.Set($"black_words_{peerid}", result, 30);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            finally
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
            }
        }

        public void FilterWordsAddWord(long peerid, string word, long from_id)
        {
            try
            {
                DbInsert(new Dictionary<string, object>() {
                { "peer_id", peerid },
                { "word", word },
                { "admin_id", from_id },
                { "type", "1" }
            }, "blacklist_words");
                FilterWordsGetWords(peerid, true);
            }
            catch
            {

            }
            
        }

        public void FilterWordsDelWord(long peerid, string word)
        {
            try
            {
                DbDelete(new Dictionary<string, object>() {
                { "peer_id", peerid },
                { "word", word },
            }, "blacklist_words");
                FilterWordsGetWords(peerid, true);
            }
            catch
            {

            }

        }

        public void FilterWordsSetType(long peerid, string word, int type)
        {
            try
            {
                DbUpdate(new Dictionary<string, string>() {
                { "peer_id", peerid.ToString() },
                { "word", word }
            }, new Dictionary<string, string>() { { "type", type.ToString() } }, "blacklist_words");
                FilterWordsGetWords(peerid, true);
            }
            catch
            {

            }

        }
        // ------------------------------------------------------------------------------------------

        // ------------------------------------------------------------------------------------------- SESSION ������

        public Dictionary<string, string>? sessionGet(string sessionId)
        {
            var result = Cache.Get<Dictionary<string, string>>("session_" + sessionId);
            if (result == null)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "session_id", sessionId.ToString() } }, "sessions");
                Cache.Set("session_" + sessionId, result, 60);
                return result;
            }
            return result;
        }

        public void sessionSetLast(string sessionId, string ip)
        {
            DbUpdate(new Dictionary<string, string>() { { "session_id", sessionId } },
                new Dictionary<string, string>() { { "ipLast", ip } }, "sessions");
            //reportGet(reportid, true);
            return;
        }

        public void sessionAdd(long user_id, string sessionId, string ip)
        {
            try
            {
                DbInsert(new Dictionary<string, object>() {
                { "session_id", sessionId },
                { "user_id", user_id },
                { "ipReg", ip },
                { "ipLast", ip },
            }, "sessions");
                sessionGet(sessionId);
            }
            catch
            {

            }

        }

        public void adminsAdd(long userid, long adminid)
        {
            initClient();
            string sql = "INSERT INTO `admins` (`user_id`, `admin`) VALUES " +
                "(@param_userid, @param_domain);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_userid", userid);
            command.Parameters.AddWithValue("@param_domain", adminid);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                engine.properties.admins.load(this);
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            engine.properties.admins.load(this);
            return;
        }
        public void adminsRemove(long userid)
        {
            initClient();
            string sql = "DELETE FROM `admins` WHERE  `user_id` = " + userid;
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                engine.properties.admins.load(this);
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            engine.properties.admins.load(this);
            return;
        }

        public void adminsSetFieldSettings(long userid, string fieldName, long toggle)
        {
            DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { fieldName, toggle.ToString() } }, "admins");
        }

        public void adminsSetExpire(long userid, string date)
        {
            DbUpdate(new Dictionary<string, string>() { { "user_id", userid.ToString() } },
                new Dictionary<string, string>() { { "expire", date } }, "admins");
        }

        public void adminsAddAnswer(long userid)
        {
            initClient();
            string sql = "UPDATE `admins` SET `answers` = `answers` + 1 WHERE `user_id` = '" + userid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                //engine.properties.admins.load(this);
                return;
            }
            settings.OWNER_IDS[userid].answers++;
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            //engine.properties.admins.load(this);
            return;
        }

        public void adminsAddMarkTicket(long userid, int mark)
        {
            initClient();
            string sql = "UPDATE `admins` SET `marks` = `marks` + '" + mark + "' WHERE `user_id` = '" + userid + "';";
            MySqlCommand command = new MySqlCommand(sql, handle);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                //engine.properties.admins.load(this);
                return;
            }
            settings.OWNER_IDS[userid].marks += mark;
            if (settings.OWNER_IDS[userid].answers != 0)
            {
                settings.OWNER_IDS[userid].average_mark = (settings.OWNER_IDS[userid].marks / settings.OWNER_IDS[userid].marks);
            }
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            //engine.properties.admins.load(this);
            return;
        }

        // ------------------------------------------------------------------------------------------ ����

        public Dictionary<string, string> propertyGetUser(long user_id, bool update_cache = false)
        {
            var result = Cache.Get<Dictionary<string, string>>("property_" + user_id);
            if (result == null || update_cache == true)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "user_id", user_id.ToString() } }, "property");
                Cache.Set("property_" + user_id, result, 10);
                return result;
            }
            return result;
        }

        public void propertyAddItemUser(long user_id, string name_item, long itemid)
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `property` (`user_id`, `" + name_item + "`) VALUES(@param_user_id, " +
                    "@param_item) ON DUPLICATE KEY UPDATE `" + name_item + "` = @param_item";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_user_id", user_id);
                command.Parameters.AddWithValue("@param_item", itemid);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {

                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    propertyGetUser(user_id, true);
                    return;
                }

                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                propertyGetUser(user_id, true);
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
        }

        public Dictionary<long, Dictionary<string, string>>? loadHouses()
        {
            try
            {
                Dictionary<long, Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `settings_houses` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(long.Parse(tempDict["id"]), tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<long, OWNER_STRUCT>? loadAdmins()
        {
            try
            {
                Dictionary<long, OWNER_STRUCT>? result = new();

                initClient();
                string sql = "SELECT * FROM `admins` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, OWNER_STRUCT>? result_db = new();

                List<long> toDelete = new();

                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        var tempStruct = new OWNER_STRUCT()
                        {
                            access_sysinfo = long.Parse(tempDict["access_sysinfo"]),
                            access_answer = long.Parse(tempDict["access_answer"]),
                            access_banreport = long.Parse(tempDict["access_banreport"]),
                            access_closed = long.Parse(tempDict["access_closed"]),
                            access_give = long.Parse(tempDict["access_give"]),
                            access_reports = long.Parse(tempDict["access_reports"]),
                            access_sysban = long.Parse(tempDict["access_sysban"]),
                            access_sysrole = long.Parse(tempDict["access_sysrole"]),
                            access_givevip = long.Parse(tempDict["access_givevip"]),
                            access_sysunban = long.Parse(tempDict["access_sysunban"]),
                            access_unbanreport = long.Parse(tempDict["access_unbanreport"]),
                            access_givemoney = long.Parse(tempDict["access_givemoney"]),
                            access_getquest = long.Parse(tempDict["access_getquest"]),
                            access_fakecmd = long.Parse(tempDict["access_fakecmd"]),
                            admin = long.Parse(tempDict["admin"]),
                            answers = long.Parse(tempDict["answers"]),
                            marks = long.Parse(tempDict["marks"]),
                            //average_mark = marks / answers,
                            id = long.Parse(tempDict["id"]),
                            user_id = long.Parse(tempDict["user_id"]),
                            access_getbotstats = long.Parse(tempDict["access_getbotstats"]),
                            access_spam = long.Parse(tempDict["access_spam"])
                        };

                        if (tempDict["expire"] != "")
                        {
                            var time = timeGetForMysql(tempDict["expire"]);
                            if (time.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                            {
                                //DELETE FROM `vk_test_beta`.`admins` WHERE  `id`=295;
                                toDelete.Add(long.Parse(tempDict["user_id"]));
                                continue;
                            }
                            tempStruct.expire = time;
                        }

                        if (!result_db.ContainsKey(tempStruct.user_id))
                        {
                            result_db.Add(tempStruct.user_id, tempStruct);
                        }
                        
                        //Console.WriteLine(reader[1]);

                    }

                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                    if (toDelete.Count >= 1)
                    {
                        foreach (var item in toDelete)
                        {
                            DbDelete(new Dictionary<string, object>() { { "user_id", item } }, "admins");
                        }
                    }
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<long, Dictionary<string, string>>? loadCars()
        {
            try
            {
                Dictionary<long, Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `settings_cars` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(long.Parse(tempDict["id"]), tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    result = result_db;
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<long, Dictionary<string, string>>? loadBoats()
        {
            try
            {
                Dictionary<long, Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `settings_boats` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(long.Parse(tempDict["id"]), tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<long, Dictionary<string, string>>? loadAirplanes()
        {
            try
            {
                Dictionary<long, Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `settings_airplanes` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(long.Parse(tempDict["id"]), tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<long, Dictionary<string, string>>? loadHelicopters()
        {
            try
            {
                Dictionary<long, Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `settings_helicopters` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(long.Parse(tempDict["id"]), tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }


        public Dictionary<long, Dictionary<string, string>>? loadSmartphones()
        {
            try
            {
                Dictionary<long, Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `settings_smartphones` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(long.Parse(tempDict["id"]), tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public Dictionary<long, Dictionary<string, string>>? loadComputers()
        {
            try
            {
                Dictionary<long, Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `settings_computers` ORDER BY `id` ASC;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(long.Parse(tempDict["id"]), tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return result;
                }
                else
                {
                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return null;
                }


                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return null;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }
        // -------------------------------------------------------------------------------------------


        public void messageInsert(long peer_id = 0, long from_id = 0, string text = "")
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `messages` (`peer_id`, `from_id`, `text`) VALUES (@param_id, @param_userid, @param_text);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peer_id);
                command.Parameters.AddWithValue("@param_userid", from_id);
                command.Parameters.AddWithValue("@param_text", text);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }


                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
            
        }

        public void messageDeletedFilterInsert(long peer_id = 0, long from_id = 0, long message_id = 0, string text = "", string attachments = "")
        {
            try
            {
                initClient();
                string sql = "INSERT INTO `deletedFilter` (`peer_id`, `from_id`, `message_id`, `text`, `attachments`) VALUES (@param_id, @param_userid, " +
                    "@param_messid, @param_text, @param_att);";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", peer_id);
                command.Parameters.AddWithValue("@param_userid", from_id);
                command.Parameters.AddWithValue("@param_messid", message_id);
                command.Parameters.AddWithValue("@param_text", text);
                command.Parameters.AddWithValue("@param_att", attachments);

                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }


                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }

        }

        public Dictionary<string, string> messageDeletedFilterGet(long mess_id = 0, long peer_id = 0, bool update_cache = false)
        {
            var result = Cache.Get<Dictionary<string, string>>("delmes_" + mess_id + "_" + peer_id);
            if (result == null || update_cache == true)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "peer_id", peer_id.ToString() }, { "message_id", mess_id.ToString() } }, "deletedFilter");
                Cache.Set("delmes_" + mess_id + "_" + peer_id, result, 10);
                return result;
            }
            return result;
        }

        public async Task peerTruncuteWarns(long peerid)
        {

            var dataUsers = peerGetWarnsMans(peerid, true);
            foreach (var item in dataUsers)
            {
                peerWarnsClear(peerid, (int)item.user_id);
            }
            /*initClient();
            string sql = "DELETE FROM `warns_list` WHERE `peer_id` = @param_id;";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_id", peerid);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            if (handle != null) { try { handle.Close(); handle = null; } catch { } }

            peerGetWarnsMans(peerid, true);

            DbUpdate(new Dictionary<string, string>() { { "peer_id", peerid.ToString() } },
                new Dictionary<string, string>() { { "warns", "0" } }, "peer_members");
            peersGetPeer(peerid, true);*/
            return;
        }

        public async Task peerTruncuteBans(long peerid)
        {
            initClient();
            string sql = "DELETE FROM `bans` WHERE `peer_id` = @param_id;";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_id", peerid);
            //command.Parameters.AddWithValue("@param_warns", warns);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            bansGetBansAll(peerid, true);
            return;
        }

        public async Task peerTruncuteNicknames(long peerid)
        {
            var dataUsers = peerGetNickNames(peerid, true);
            if (dataUsers != null)
            {
                foreach (var item in dataUsers)
                {
                    peersMemberSetNickName(peerid, long.Parse(item["user_id"]), null);
                }
                return;
            }
            else
            {
                return;
            }
        }

        public async Task peerTruncuteRolesUsers(long peerid)
        {
            var dataUsers = peerGetMembersWhenRole(peerid, true);
            var PeerInfo = peersGetPeer(peerid);
            if (dataUsers != null)
            {
                foreach (var item in dataUsers)
                {
                    if (PeerInfo["owner"] == item.ToString())
                    {
                        continue;
                    }
                    peersMemberSetPriority(peerid, item, 0);
                }
            }
            
            return;
        }

        // -------------------------------------------------------------------------------------- ���� ���� ����

        public List<long>? peersGetForOwner(long ownerid, bool update_cache = false)
        {
            try
            {
                List<long>? result = Cache.Get<List<long>>("peers_owner_" + ownerid);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT `peer_id` FROM `peers` WHERE `owner` = '" + ownerid + "' AND `active` = '1'";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<long>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            result_db.Add(long.Parse(reader[0].ToString()));
                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("peers_owner_" + ownerid, result, 10);
                    return result;
                }
                Cache.Set("peers_owner_" + ownerid, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<long>? peersGetForLead(long lead_id, bool update_cache = false)
        {
            try
            {
                List<long>? result = Cache.Get<List<long>>("peers_lead_" + lead_id);

                if (result == null || update_cache == true)
                {
                    if (result == null)
                    {
                        result = new();
                    }
                    initClient();
                    string sql = "SELECT `peer_id` FROM `peer_members` WHERE `user_id` = '" + lead_id + "' AND " +
                        "`priority` >= '80' AND `leave_peer` = '0'";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<long>? result_db = new();
                    if (reader.HasRows == true)
                    {
                        while (reader.Read())
                        {
                            result_db.Add(long.Parse(reader[0].ToString()));
                        }
                        result = result_db;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }


                    Cache.Set("peers_lead_" + lead_id, result, 10);
                    return result;
                }
                Cache.Set("peers_lead_" + lead_id, result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<long>? peersGet50MEMBERS()
        {
            try
            {
                List<long>? result = new();
                
                initClient();
                string sql = "SELECT peer_id from peers WHERE current_members >= 20 ORDER BY current_members DESC;";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<long>? result_db = new();
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        result_db.Add(long.Parse(reader[0].ToString()));
                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        public List<string>? peersGetForumMembers()
        {
            try
            {
                List<string>? result = new();

                initClient();
                //SELECT  `user_id`,  `field_id`, LEFT(`field_value`, 256) FROM `forum`.`xf_user_field_value` LIMIT 1000;
                string sql = "SELECT `field_id`, LEFT(`field_value`, 256) FROM `forum`.`xf_user_field_value`;";
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<string>? result_db = new();
                if (reader.HasRows == true)
                {
                    while (reader.Read())
                    {
                        result_db.Add(reader[1].ToString());
                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
        }

        // --------------------------------------------------------------------------------------

        // -------------------------------------------------------------------------------------- ��������

        public void antifloodAddPriority(long user_id)
        {
            try
            {
                initClient();
                /*INSERT INTO `usage` (`thing_id`, `times_used`, `first_time_used`) VALUES (4815162342, 1, NOW()) ON DUPLICATE KEY UPDATE `times_used` = `times_used` + 1*/
                string sql = "INSERT INTO `botflooders` (`id`, `priority`) VALUES (@param_id, @param_priority) ON DUPLICATE KEY UPDATE `priority` = `priority` + 1;";
                MySqlCommand command = new MySqlCommand(sql, handle);
                command.Parameters.AddWithValue("@param_id", user_id);
                command.Parameters.AddWithValue("@param_priority", 1);
                try
                {
                    long s = command.ExecuteNonQuery();
                }
                catch
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    return;
                }


                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return;
            }
        }

        // --------------------------------------------------------------------------------------


        // -------------------------------------------------------------------------------------- ����
        public void logsAddLog(long peerid = 0, logsId type = 0, long user_id = 0, long target_id = 0, string text = "", string args1 = "", string args2 = "")
        {
            initClient();
            string sql = "INSERT INTO `logs` (`peer_id`, `user_id`, `target_id`, `type`, `text`, `data1`, `data2`) " +
                "VALUES (@param_peerid, @param_userid, @param_target, @param_type, @param_text, @param_data1, @param_data2);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peerid", peerid);
            command.Parameters.AddWithValue("@param_userid", user_id);
            command.Parameters.AddWithValue("@param_target", target_id);
            command.Parameters.AddWithValue("@param_type", (int)type);
            command.Parameters.AddWithValue("@param_text", text);
            command.Parameters.AddWithValue("@param_data1", args1);
            command.Parameters.AddWithValue("@param_data2", args2);
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }

            var result = Cache.Get<List<Dictionary<string, string>>>("peer_logs_" + peerid);
            if (result == null)
            {
                return;
            }
            else
            {
                result.Insert(0, new Dictionary<string, string>() { { "peer_id", peerid.ToString() },
                    { "user_id", user_id.ToString() },
                    { "target_id", target_id.ToString() },
                    { "type", type.ToString() },
                    { "text", text.ToString() },
                    { "data1", args1 }, { "data2", args2 } });
                Cache.Set("peer_logs_" + peerid, result);
            }
            return;
        }

        public enum logsId
        {
            /// <summary>
            /// RP ��������
            /// </summary>
            ROLEPLAY_USE = 1,
            /// <summary>
            /// ����������� ����
            /// </summary>
            INIT_BOT,
            /// <summary>
            /// ��������� ������������
            /// </summary>
            USER_KICK,
            /// <summary>
            /// ����� ���������� ����
            /// </summary>
            USER_UNMUTE,
            /// <summary>
            /// ������ ���������� ����
            /// </summary>
            USER_MUTE,
            /// <summary>
            /// ������ ��������������
            /// </summary>
            USER_WARN,
            /// <summary>
            /// ����� ��������������
            /// </summary>
            USER_UNWARN,
            /// <summary>
            /// ������������� ������������
            /// </summary>
            USER_BAN,
            /// <summary>
            /// �������������� ������������
            /// </summary>
            USER_UNBAN,
            /// <summary>
            /// ���������� ��������� ������������
            /// </summary>
            USER_SETROLE,
            /// <summary>
            /// ���������� ������� ������������
            /// </summary>
            USER_SETNICK,
            /// <summary>
            /// ������� ������� ������������
            /// </summary>
            USER_REMOVENICK,

            /// <summary>
            /// ���������� � ����
            /// </summary>
            ADMIN_SYSBAN,
            
            /// <summary>
            /// ������������� � ����
            /// </summary>
            ADMIN_SYSUNBAN,
            /// <summary>
            /// ������ ������ �� �������
            /// </summary>
            ADMIN_GIVERUB,
            /// <summary>
            /// ������ VIP �������
            /// </summary>
            ADMIN_GIVEVIP,
            /// <summary>
            /// ������� ����� ����
            /// </summary>
            VIP_VOICE,

            USER_GAMEMODE,

            USER_BANREPORT,
            USER_UNBANREPORT,

            ADMIN_GETSYSLOGFULL,
            /// <summary>
            /// ������ ���� � �����
            /// </summary>
            ADMIN_GSYSROLE,

            /// <summary>
            /// �������� �������� ����
            /// </summary>
            USER_DELETEACCOUNT,
            /// <summary>
            /// MAINING
            /// </summary>
            USER_MAINING,
        }

        public List<Dictionary<string, string>>? logsGetForPeer(long peer_id, bool update_cache = false)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                result = Cache.Get<List<Dictionary<string, string>>>("peer_logs_" + peer_id);


                if (result == null || update_cache)
                {
                    initClient();
                    string sql = "SELECT * FROM `logs` WHERE `peer_id` = '" + peer_id + "' ORDER BY `id` DESC LIMIT 500;";
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    MySqlDataReader reader = command.ExecuteReader();

                    List<Dictionary<string, string>>? result_db = new();
                    if (reader.HasRows)
                    {
                        while (reader.Read())
                        {
                            var tempDict = new Dictionary<string, string>();
                            for (int i = 0; i < reader.FieldCount; i++)
                            {
                                //columns.Add(reader.GetName(i));
                                tempDict[reader.GetName(i)] = reader[i].ToString();
                            }
                            result_db.Add(tempDict);
                            //Console.WriteLine(reader[1]);

                        }
                        result = result_db;
                    }
                    else
                    {
                        if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                        if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                        Cache.Set("peer_logs_" + peer_id.ToString(), new List<Dictionary<string, string>>(), 10);
                        return result;
                    }

                    if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }

                Cache.Set("peer_logs_" + peer_id.ToString(), result, 10);
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            
        }

        public List<Dictionary<string, string>>? logsGetForUser(long peer_id, long user_id = 0, bool update_cache = false)
        {
            var logs = logsGetForPeer(peer_id);
            List<Dictionary<string, string>> result = new();
            string target_id = user_id.ToString();
            if (logs == null)
            {
                return result;
            }
            foreach (var item in logs)
            {
                if (item["user_id"] == target_id || item["target_id"] == target_id)
                {
                    result.Add(item);
                }
            }
            return result;
        }

        // --------------------------------------------------------------------------------------

        public Dictionary<string, Dictionary<string, long>> statsGetStatPeerCache(long peer_id)
        {
            Dictionary<string, Dictionary<string, long>>? result = Cache.Get<Dictionary<string, Dictionary<string, long>>>("statistic_" + peer_id.ToString());
            return result;
        }

        public Dictionary<string, Dictionary<string, long>> statsGetStatUserPeerCache(long peer_id, long user_id)
        {
            Dictionary<string, Dictionary<string, long>>? result = Cache.Get<Dictionary<string, Dictionary<string, long>>>("statistic_" + peer_id.ToString() +
                "_" + user_id.ToString());
            return result;
        }
        //result = DbSelectOne(new Dictionary<string, string>() { { "report_id", report_id.ToString() }, { "report_message_id", messageId.ToString() } }, "report_attachments");
        public Dictionary<string, long>? statsGetStatForBDDay(long peer_id, string key_day, long? userid = null)
        {
            //string key_day = day.Year.ToString() + "_" + day.Month.ToString() + "_" + day.Day.ToString();
            Dictionary<string, string>? result = null;
            if (userid == null)
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "peer_id", peer_id.ToString() }, { "date_create", key_day }, { "user_id", "-1" } }, "stats_peers");
            }
            else
            {
                result = DbSelectOne(new Dictionary<string, string>() { { "peer_id", peer_id.ToString() }, { "date_create", key_day }, { "user_id", userid.ToString() } }, "stats_peers");
            }
            if (result == null)
            {
                return null;
            }
            else
            {
                Dictionary<string, long> export = new();
                foreach (var item in result)
                {
                    if (item.Key == "date_create" || item.Key == "auto_data")
                    {
                        continue;
                    }
                    export[item.Key] = int.Parse(item.Value);
                }
                return export;
            }
        }

        public void statsUpdateDb(long peer_id, string key_day, string messages, string words, string obscen_words, string symbols,
            string voices, string photos, string videos, string audios, string posts, string stickers, string smiles, string commands, string? userid)
        {
            Dictionary<string, string> where = new () { { "peer_id", peer_id.ToString() }, { "date_create", key_day } };
            if (userid != null)
            {
                if (userid != "" && userid != "0")
                {
                    where.Add("user_id", userid);
                }
                else
                {
                    where.Add("user_id", "-1");
                }
            }
            else
            {
                where.Add("user_id", "-1");
            }
            DbUpdate( where,
                new Dictionary<string, string>() { { "messages", messages }, { "words", words },
                { "obscen_words", obscen_words }, { "symbols", symbols },
                { "voices", voices }, { "photos", photos }, { "posts", posts }, { "stickers", stickers },
                { "videos", videos }, { "audios", audios },
                { "smiles", smiles }, { "commands", commands } }, "stats_peers");
            return;
        }


        public void statsInsert(long peer_id, string key_day, string messages, string words, string obscen_words, string symbols,
            string voices, string photos, string videos, string audios, string posts, string stickers, string smiles, string commands, string? user_id)
        {
            initClient();
            string sql = "REPLACE INTO `stats_peers` (`peer_id`, `messages`, `commands`, `words`, `obscen_words`, `symbols`, `voices`, " +
                "`photos`, `videos`, `audios`, `posts`, `stickers`, `smiles`, `date_create`, `user_id`) VALUES " +
                "(@param_peer_id, @param_messages, @param_commands, @param_words, @param_obscen_words, @param_symbols, @param_voices, " +
                "@param_photos, @param_videos, @param_audios, @param_posts, @param_stickers, @param_smiles, @param_key_day, @param_userid);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_peer_id", peer_id);
            command.Parameters.AddWithValue("@param_messages", messages);
            command.Parameters.AddWithValue("@param_commands", commands);
            command.Parameters.AddWithValue("@param_words", words);
            command.Parameters.AddWithValue("@param_obscen_words", obscen_words);
            command.Parameters.AddWithValue("@param_symbols", symbols);
            command.Parameters.AddWithValue("@param_voices", voices);
            command.Parameters.AddWithValue("@param_photos", photos);
            command.Parameters.AddWithValue("@param_videos", videos);
            command.Parameters.AddWithValue("@param_audios", audios);
            command.Parameters.AddWithValue("@param_posts", posts);
            command.Parameters.AddWithValue("@param_stickers", stickers);
            command.Parameters.AddWithValue("@param_smiles", smiles);
            command.Parameters.AddWithValue("@param_key_day", key_day);
            if (user_id != null && user_id != "" && user_id != "0")
            {
                command.Parameters.AddWithValue("@param_userid", user_id);
            }
            else
            {
                command.Parameters.AddWithValue("@param_userid", "-1");
            }
            
            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }


        public List<Dictionary<string, long>>? statsGetActualStatBd(string date_create)
        {
            try
            {
                List<Dictionary<string, long>>? result = new();

                initClient();
                string sql = "SELECT * FROM `stats_peers` WHERE `user_id` = '-1' AND `date_create` = '" + date_create + "' ORDER BY `peer_id`;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, long>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, long>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            if (reader.GetName(i) == "auto_data" || reader.GetName(i) == "date_create")
                            {
                                continue;
                            }
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = long.Parse(reader[i].ToString());
                        }
                        result_db.Add(tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            
        }

        public Dictionary<string, long>? statsUserGetMessagesForBd(long peerid, long user_id, bool update_cache = false)
        {
            // result = DbSelectOne(new Dictionary<string, string>() { { "peer_id", peer_id.ToString() }, { "date_create", key_day }, { "user_id", "-1" } }, "stats_peers");
            Dictionary<string, long>? result = Cache.Get<Dictionary<string, long>>("userMessagesStatDb_" + peerid.ToString() + "_" + user_id.ToString());
            if (result == null || update_cache == true)
            {
                //result = DbSelectOne(new Dictionary<string, string>() { { "id", unityid.ToString() } }, "pools");

                try
                {
                    initClient();
                    string sql = "SELECT SUM(`messages`) FROM `stats_peers` WHERE `peer_id` = '" + peerid.ToString() + "' " +
                        "AND `user_id` = '" + user_id.ToString() + "'";
                   
                    MySqlCommand command = new MySqlCommand(sql, handle);

                    Dictionary<string, long>? resultDb = new();
                    // ������ ���������

                    //SqlDataReader reader = await command.ExecuteReaderAsync();

                    using (var sqlQueryResult = command.ExecuteReader())
                    {
                        while (sqlQueryResult.Read())
                        {
                            for (int i = 0; i < sqlQueryResult.FieldCount; i++)
                            {
                                //columns.Add(reader.GetName(i));
                                resultDb["messages"] = long.Parse(sqlQueryResult[i].ToString());
                                //Console.WriteLine(reader[i].ToString());
                            }
                        }
                        //if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    }
                   // if (handle != null && handle.)
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }

                    if (resultDb.Count > 0)
                    {
                        result = resultDb;
                    }
                }
                catch
                {
                    if (handle != null)
                    {
                        if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                    }
                    return null;
                }


                if (result == null)
                {
                    Cache.Set("userMessagesStatDb_" + peerid.ToString() + "_" + user_id.ToString(), result, 60);
                    return null;
                }
                if (result != null)
                {
                    Cache.Set("userMessagesStatDb_" + peerid.ToString() + "_" + user_id.ToString(), result, 60);
                }
                return result;
            }
            return result;
        }

        public Dictionary<string, long>? statsUserGetMessagesForCacheAndDb (long peerid, long user_id)
        {
            var result = new Dictionary<string, long>();
            var resultdb = statsUserGetMessagesForBd(peerid, user_id);
            if (resultdb != null)
            {
                if (result.ContainsKey("messages"))
                {
                    result["messages"] += resultdb["messages"];
                }
                else
                {
                    result["messages"] = resultdb["messages"];
                }
                
            }

            Dictionary<string, Dictionary<string, long>>? result_two = Cache.Get<Dictionary<string, Dictionary<string, long>>>("statistic_" + peerid.ToString() +
                "_" + user_id.ToString());
            DateTimeOffset current_time = DateTimeOffset.Now;
            string key_day = current_time.Year.ToString() + "_" + current_time.Month.ToString() + "_" + current_time.Day.ToString();
            if (result_two != null)
            {
                if (result_two.ContainsKey(key_day))
                {
                    if (result.ContainsKey("messages"))
                    {
                        result["messages"] += result_two[key_day]["messages"];
                    }
                    else
                    {
                        result["messages"] = result_two[key_day]["messages"];
                    }
                }
            }
            return result;
        }

        public Dictionary<long, Dictionary<string, long>>? topMessagesGetForDB(long peer_id, string param)
        {
            try
            {
                //select user_id, sum(`messages`) as `count_messages`,  sum(`words`) as `count_words` from stats_peers WHERE `peer_id`= '2000000421' group by `user_id` order by 2 desc
                Dictionary<long, Dictionary<string, long>>? result = new();

                initClient();
                string sql = $"SELECT user_id, sum(`{param}`) as `{param}` FROM `stats_peers` WHERE `peer_id` = '" + peer_id + "' AND `user_id` != '-1' group by `user_id` order by 2 desc;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                Dictionary<long, Dictionary<string, long>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, long>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = long.Parse(reader[i].ToString());
                        }
                        result_db.Add(tempDict["user_id"], tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }
            
        }


        public Dictionary<long, Dictionary<string, long>>? topMessagesGetPeer(long peer_id, string param)
        {
            var result = Cache.Get<Dictionary<long, Dictionary<string, long>>>($"peer_message{param}_countcache_" + peer_id);
            if (result == null)
            {
                var db_res = topMessagesGetForDB(peer_id, param);

                if (db_res != null)
                {
                    
                    result = db_res;
                    Cache.Set($"peer_message{param}_countcache_" + peer_id, db_res, 20);
                }
                else
                {
                    var res = new Dictionary<long, Dictionary<string, long>>();
                    Cache.Set($"peer_message{param}_countcache_" + peer_id, res, 20);
                }
            }

            List<string>? list_for_syncUser = Cache.Get<List<string>>("list_statsUsers_" + peer_id.ToString());
            if (list_for_syncUser != null)
            {
                foreach (var item in list_for_syncUser)
                {
                    var result_two = Cache.Get<Dictionary<string, Dictionary<string, long>>>(item.ToString());
                    if (result_two != null)
                    {
                        foreach (var item2 in result_two)
                        {
                            if (item2.Value["user_id"] == -1)
                            {
                                continue;
                            }
                            if (!result.ContainsKey(item2.Value["user_id"]))
                            {
                                result.Add(item2.Value["user_id"], item2.Value);
                            }
                            else
                            {
                                var minus_stata = Cache.Get<string>("parse_minus_stata_" + peer_id + "_" + item2.Value["user_id"] + "_" + param);
                                if (minus_stata == null || minus_stata == "")
                                {
                                    Cache.Set("parse_minus_stata_" + peer_id + "_" + item2.Value["user_id"] + "_" + param,
                                        item2.Value[param].ToString(), 20);
                                    result[item2.Value["user_id"]][param] = result[item2.Value["user_id"]][param] + item2.Value[param];
                                }
                                else
                                {
                                    result[item2.Value["user_id"]][param] = result[item2.Value["user_id"]][param] + item2.Value[param] - long.Parse(minus_stata);
                                    Cache.Set("parse_minus_stata_" + peer_id + "_" + item2.Value["user_id"] + "_" + param,
                                        (item2.Value[param]).ToString(), 20);
                                }
                                
                            }
                        }
                    }
                }
            }

            if (result != null)
            {

                var sortedDict = from entry in result orderby entry.Value[param] descending select entry;
                //
                //var news = topInfo.OrderByDescending(x => x["rubs"]).ToList();
                var data = sortedDict.ToDictionary(pair => pair.Key, pair => pair.Value);
                if (data.Count >= 16)
                {
                    foreach (var obj in data.Keys.Skip(16).ToList()) data.Remove(obj);
                }
                //var date = sortedDict.ToList();
                Cache.Set($"peer_message{param}_countcache_" + peer_id, result, 20);
                return data;
            }

            return result;
        }

        public List<Dictionary<string, string>>? statsGetActiveUsers(long peer_id, long user_id)
        {
            try
            {
                List<Dictionary<string, string>>? result = new();

                initClient();
                string sql = "SELECT * FROM `stats_peers` WHERE `user_id` = '" + user_id + "' AND `peer_id` = '" + peer_id + "' ORDER BY `date_create` DESC LIMIT 2;";
                //SELECT `peer_id` FROM `peers` LIMIT 1000;
                MySqlCommand command = new MySqlCommand(sql, handle);

                MySqlDataReader reader = command.ExecuteReader();

                List<Dictionary<string, string>>? result_db = new();
                if (reader.HasRows)
                {
                    while (reader.Read())
                    {
                        var tempDict = new Dictionary<string, string>();
                        for (int i = 0; i < reader.FieldCount; i++)
                        {
                            //if (reader.GetName(i) == "auto_data" || reader.GetName(i) == "date_create")
                            //{
                                //continue;
                            //}
                            //columns.Add(reader.GetName(i));
                            tempDict[reader.GetName(i)] = reader[i].ToString();
                        }
                        result_db.Add(tempDict);
                        //Console.WriteLine(reader[1]);

                    }
                    result = result_db;
                }

                if (reader != null) { try { reader.Close(); } catch { } } // ��������� reader
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return result;
            }
            catch
            {
                if (handle != null)
                {
                    if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                }
                return null;
            }

        }


        public Dictionary<string, string>? paymentsGetForUser(long user_id, long amount, bool payed = false, bool update_cache = false)
        {
            //string key_day = day.Year.ToString() + "_" + day.Month.ToString() + "_" + day.Day.ToString();
            var result = Cache.Get<Dictionary<string, string>>($"payms_{user_id}_{amount}_{payed}");
            //Dictionary<string, string>? result = null;
            if (result == null || update_cache)
            {
                string pays = "0";
                if (payed != false)
                {
                    pays = "1";
                }
                result = DbSelectOne(new Dictionary<string, string>() { { "from_id", user_id.ToString() }, 
                    { "amount", amount.ToString() }, { "payed", pays } }, "payments");
                Cache.Set($"payms_{user_id}_{amount}_{payed}", result, 15);
            }

            return result;
        }

        public Dictionary<string, string>? paymentsGetForID(long paym_id)
        {
            //string key_day = day.Year.ToString() + "_" + day.Month.ToString() + "_" + day.Day.ToString();
            
            Dictionary<string, string>? result = DbSelectOne(new Dictionary<string, string>() { { "id", paym_id.ToString() } }, "payments");
            return result;
        }

        public void paymentsAdd(long user_id, long amount, bool payed = false)
        {
            initClient();
            string sql = "REPLACE INTO `payments` (`from_id`, `payed`, `amount`) VALUES " +
                "(@param_userId, @param_payed, @param_amount);";
            MySqlCommand command = new MySqlCommand(sql, handle);
            command.Parameters.AddWithValue("@param_userId", user_id);
            command.Parameters.AddWithValue("@param_amount", amount);
            if (payed)
            {
                command.Parameters.AddWithValue("@param_payed", "1");
            }
            else
            {
                command.Parameters.AddWithValue("@param_payed", "0");
            }

            try
            {
                long s = command.ExecuteNonQuery();
            }
            catch
            {
                if (handle != null) { try { handle.Close(); handle = null; } catch { } }
                return;
            }

            if (handle != null) { try { handle.Close(); handle = null; } catch { } }
            return;
        }

        public void paymentsSetPayed(long payment_id, long payed)
        {
            DbUpdate(new Dictionary<string, string>() { { "id", payment_id.ToString() } },
                new Dictionary<string, string>() { { "payed", payed.ToString() } }, "payments");
            //peersGetPeer(peerid, true);
            return;
        }

        public DateTimeOffset timeGetForMysql(string time)
        {
            if (string.IsNullOrEmpty(time))
            {
                return DateTimeOffset.Now;
            }
            return DateTimeOffset.Parse(time);
        }

        public string timeGetForString(DateTimeOffset time)
        {
            return time.ToString("yyyy-MM-dd HH:mm:ss");
        }

        public long timeGetUnix()
        {
            return DateTimeOffset.Now.ToUnixTimeSeconds();
        }

        public DateTimeOffset timeGetDateTimeOffset()
        {
            return DateTimeOffset.Now;
        }

        public static async void DbLog(string method, string time_ms)
        {
            //long seconds = DateTime.Now.Ticks / 10 / 1000000;
            
            /*DateTime secondss = DateTime.UtcNow;
            long seco = secondss.Ticks / 10 / 1000000;*/
            string path = "stats/" + method + " - timing.txt";

            string originalText = "����� � " + method + "\n" +
                "����� ����������: " + time_ms;
            // ������ ������
            try
            {
                File.WriteAllTextAsync(path, originalText);
            }
            catch
            {

            }
        }

        // ===== Вспомогательные методы для DbTools =====

        public List<Dictionary<string, string>> fetchAll(string sql, params object[] args)
        {
            MySqlCommand command = null;
            MySqlDataReader reader = null;
            try
            {
                initClient();
                if (handle == null) return null;

                command = new MySqlCommand(sql, handle);
                for (int i = 0; i < args.Length; i++)
                    command.Parameters.AddWithValue($"@p{i}", args[i] ?? DBNull.Value);

                var result = new List<Dictionary<string, string>>();
                reader = command.ExecuteReader();
                while (reader.Read())
                {
                    var row = new Dictionary<string, string>();
                    for (int i = 0; i < reader.FieldCount; i++)
                        row[reader.GetName(i)] = reader.IsDBNull(i) ? "" : reader[i].ToString();
                    result.Add(row);
                }
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DB fetchAll ERROR] {ex.Message}");
                return null;
            }
            finally
            {
                if (reader != null) try { reader.Dispose(); } catch { }
                if (command != null) try { command.Dispose(); } catch { }
                if (handle != null) try { handle.Close(); handle.Dispose(); handle = null; } catch { }
            }
        }

        public int executeQuery(string sql, params object[] args)
        {
            MySqlCommand command = null;
            try
            {
                initClient();
                if (handle == null) return 0;

                command = new MySqlCommand(sql, handle);
                for (int i = 0; i < args.Length; i++)
                    command.Parameters.AddWithValue($"@p{i}", args[i] ?? DBNull.Value);

                return command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[DB executeQuery ERROR] {ex.Message}");
                if (ex is MySqlException mysqlEx) throw mysqlEx;
                throw;
            }
            finally
            {
                if (command != null) try { command.Dispose(); } catch { }
                if (handle != null) try { handle.Close(); handle.Dispose(); handle = null; } catch { }
            }
        }

        public long peersGetOwner(long peerid)
        {
            try
            {
                var peer = peersGetPeer(peerid);
                if (peer == null) return 0;
                if (!peer.ContainsKey("owner") || string.IsNullOrEmpty(peer["owner"])) return 0;
                return long.TryParse(peer["owner"], out long owner) ? owner : 0;
            }
            catch { return 0; }
        }

    }
}
