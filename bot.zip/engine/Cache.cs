using System;
using System.Runtime.Caching;

namespace GrandManager.engine
{
    public class Cache
    {
        private static MemoryCache cache = MemoryCache.Default;
        private static readonly object lockObj = new object();
        private const int MAX_CACHE_ITEMS = 5000;

        public static Cache Instance { get; } = new Cache();

        public Cache() { }

        public void Set(string key, object? objCache, long minutes = 5)
        {
            if (objCache == null)
            {
                Delete(key);
                return;
            }

            lock (lockObj)
            {
                if (cache.GetCount() >= MAX_CACHE_ITEMS)
                {
                    cache.Trim(25);
                }
                var policy = new CacheItemPolicy { SlidingExpiration = TimeSpan.FromMinutes(Math.Min(minutes, 30)) };
                cache.Set(key, objCache, policy);
            }
        }

        public T? Get<T>(object key) where T : class
        {
            if (key == null) return null;
            lock (lockObj)
            {
                return cache.Get(key.ToString()) as T;
            }
        }

        public void Delete(object key)
        {
            if (key == null) return;
            lock (lockObj)
            {
                cache.Remove(key.ToString());
            }
        }

        public void clearCache()
        {
            lock (lockObj)
            {
                var oldCache = cache;
                cache = new MemoryCache("NewCache");
                oldCache.Dispose();
            }
        }
    }
}
