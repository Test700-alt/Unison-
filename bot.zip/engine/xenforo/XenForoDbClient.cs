using System;
using System.Collections.Generic;
using System.Threading.Tasks;
using MySqlConnector;

namespace GrandManager.engine.xenforo
{
    internal class XenForoDbClient : IDisposable
    {
        private readonly MySqlConnection _conn;
        private readonly string _tablePrefix;

        public XenForoDbClient(string host, int port, string user, string password, string database, string tablePrefix = "xf_")
        {
            _tablePrefix = tablePrefix;
            var csb = new MySqlConnectionStringBuilder
            {
                Server = host,
                Port = (uint)port,
                UserID = user,
                Password = password,
                Database = database,
                SslMode = MySqlSslMode.None,
                ConnectionTimeout = 10
            };
            _conn = new MySqlConnection(csb.ConnectionString);
        }

        public async Task<bool> TestConnection()
        {
            try
            {
                await _conn.OpenAsync();
                await _conn.CloseAsync();
                return true;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XFDB] Connection error: {ex.Message}");
                return false;
            }
        }

        private async Task EnsureOpen()
        {
            if (_conn.State != System.Data.ConnectionState.Open)
                await _conn.OpenAsync();
        }

        public async Task<Dictionary<string, object>> GetUserByName(string username)
        {
            try
            {
                await EnsureOpen();
                string sql = $"SELECT u.user_id, u.username, u.user_group_id, u.secondary_group_ids, " +
                             $"u.message_count, u.reaction_score, u.register_date, u.user_state, " +
                             $"COALESCE(o.user_title, '') AS user_title " +
                             $"FROM {_tablePrefix}user u " +
                             $"LEFT JOIN {_tablePrefix}user_option o ON o.user_id = u.user_id " +
                             $"WHERE u.username = @name LIMIT 1";

                using var cmd = new MySqlCommand(sql, _conn);
                cmd.Parameters.AddWithValue("@name", username);

                using var reader = await cmd.ExecuteReaderAsync();
                if (!await reader.ReadAsync())
                    return null;

                return ReadUser(reader);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XFDB] GetUserByName error: {ex.Message}");
                return null;
            }
            finally
            {
                await _conn.CloseAsync();
            }
        }

        public async Task<Dictionary<string, object>> GetUserById(long userId)
        {
            try
            {
                await EnsureOpen();
                string sql = $"SELECT u.user_id, u.username, u.user_group_id, u.secondary_group_ids, " +
                             $"u.message_count, u.reaction_score, u.register_date, u.user_state, " +
                             $"COALESCE(o.user_title, '') AS user_title " +
                             $"FROM {_tablePrefix}user u " +
                             $"LEFT JOIN {_tablePrefix}user_option o ON o.user_id = u.user_id " +
                             $"WHERE u.user_id = @id LIMIT 1";

                using var cmd = new MySqlCommand(sql, _conn);
                cmd.Parameters.AddWithValue("@id", userId);

                using var reader = await cmd.ExecuteReaderAsync();
                if (!await reader.ReadAsync())
                    return null;

                return ReadUser(reader);
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XFDB] GetUserById error: {ex.Message}");
                return null;
            }
            finally
            {
                await _conn.CloseAsync();
            }
        }

        private Dictionary<string, object> ReadUser(MySqlDataReader r)
        {
            string secGroups = r["secondary_group_ids"]?.ToString() ?? "";
            return new Dictionary<string, object>
            {
                { "user_id", Convert.ToInt64(r["user_id"]) },
                { "username", r["username"].ToString() },
                { "user_title", r["user_title"]?.ToString() ?? "Пользователь" },
                { "message_count", Convert.ToInt32(r["message_count"]) },
                { "reaction_score", Convert.ToInt32(r["reaction_score"]) },
                { "user_group_id", Convert.ToInt32(r["user_group_id"]) },
                { "secondary_group_ids", secGroups },
                { "register_date", Convert.ToInt64(r["register_date"]) },
                { "user_state", r["user_state"].ToString() }
            };
        }

        public async Task<string> AddGroup(long userId, int groupId)
        {
            try
            {
                await EnsureOpen();
                var user = await GetUserByIdInternal(userId);
                if (user == null) return "USER_NOT_FOUND";

                int primary = (int)user["user_group_id"];
                if (primary == groupId) return "ALREADY_PRIMARY";

                var secondary = ParseGroups(user["secondary_group_ids"].ToString());
                if (secondary.Contains(groupId)) return "ALREADY_EXISTS";

                secondary.Add(groupId);
                string newGroups = string.Join(",", secondary);

                string sql = $"UPDATE {_tablePrefix}user SET secondary_group_ids = @groups WHERE user_id = @id";
                using var cmd = new MySqlCommand(sql, _conn);
                cmd.Parameters.AddWithValue("@groups", newGroups);
                cmd.Parameters.AddWithValue("@id", userId);
                await cmd.ExecuteNonQueryAsync();

                return "OK";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XFDB] AddGroup error: {ex.Message}");
                return "ERROR";
            }
            finally
            {
                await _conn.CloseAsync();
            }
        }

        public async Task<string> RemoveGroup(long userId, int groupId)
        {
            try
            {
                await EnsureOpen();
                var user = await GetUserByIdInternal(userId);
                if (user == null) return "USER_NOT_FOUND";

                int primary = (int)user["user_group_id"];
                if (primary == groupId) return "IS_PRIMARY";

                var secondary = ParseGroups(user["secondary_group_ids"].ToString());
                if (!secondary.Contains(groupId)) return "NOT_IN_GROUP";

                secondary.Remove(groupId);
                string newGroups = string.Join(",", secondary);

                string sql = $"UPDATE {_tablePrefix}user SET secondary_group_ids = @groups WHERE user_id = @id";
                using var cmd = new MySqlCommand(sql, _conn);
                cmd.Parameters.AddWithValue("@groups", newGroups);
                cmd.Parameters.AddWithValue("@id", userId);
                await cmd.ExecuteNonQueryAsync();

                return "OK";
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XFDB] RemoveGroup error: {ex.Message}");
                return "ERROR";
            }
            finally
            {
                await _conn.CloseAsync();
            }
        }

        public async Task<Dictionary<string, object>> GetGroup(int groupId)
        {
            try
            {
                await EnsureOpen();
                string sql = $"SELECT user_group_id, title, user_title FROM {_tablePrefix}user_group WHERE user_group_id = @id LIMIT 1";
                using var cmd = new MySqlCommand(sql, _conn);
                cmd.Parameters.AddWithValue("@id", groupId);

                using var reader = await cmd.ExecuteReaderAsync();
                if (!await reader.ReadAsync())
                    return null;

                return new Dictionary<string, object>
                {
                    { "user_group_id", Convert.ToInt32(reader["user_group_id"]) },
                    { "title", reader["title"].ToString() },
                    { "user_title", reader["user_title"].ToString() }
                };
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XFDB] GetGroup error: {ex.Message}");
                return null;
            }
            finally
            {
                await _conn.CloseAsync();
            }
        }

        public async Task<List<Dictionary<string, object>>> SearchUsers(string query, int limit = 10)
        {
            try
            {
                await EnsureOpen();
                string sql = $"SELECT user_id, username, user_group_id, secondary_group_ids " +
                             $"FROM {_tablePrefix}user WHERE username LIKE @q LIMIT @limit";
                using var cmd = new MySqlCommand(sql, _conn);
                cmd.Parameters.AddWithValue("@q", query + "%");
                cmd.Parameters.AddWithValue("@limit", limit);

                var result = new List<Dictionary<string, object>>();
                using var reader = await cmd.ExecuteReaderAsync();
                while (await reader.ReadAsync())
                {
                    result.Add(new Dictionary<string, object>
                    {
                        { "user_id", Convert.ToInt64(reader["user_id"]) },
                        { "username", reader["username"].ToString() },
                        { "user_group_id", Convert.ToInt32(reader["user_group_id"]) },
                        { "secondary_group_ids", reader["secondary_group_ids"].ToString() ?? "" }
                    });
                }
                return result;
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[XFDB] SearchUsers error: {ex.Message}");
                return new List<Dictionary<string, object>>();
            }
            finally
            {
                await _conn.CloseAsync();
            }
        }

        private async Task<Dictionary<string, object>> GetUserByIdInternal(long userId)
        {
            string sql = $"SELECT user_id, username, user_group_id, secondary_group_ids " +
                         $"FROM {_tablePrefix}user WHERE user_id = @id LIMIT 1";
            using var cmd = new MySqlCommand(sql, _conn);
            cmd.Parameters.AddWithValue("@id", userId);

            using var reader = await cmd.ExecuteReaderAsync();
            if (!await reader.ReadAsync())
                return null;

            return new Dictionary<string, object>
            {
                { "user_id", Convert.ToInt64(reader["user_id"]) },
                { "username", reader["username"].ToString() },
                { "user_group_id", Convert.ToInt32(reader["user_group_id"]) },
                { "secondary_group_ids", reader["secondary_group_ids"].ToString() ?? "" }
            };
        }

        private List<int> ParseGroups(string groups)
        {
            var result = new List<int>();
            if (string.IsNullOrEmpty(groups))
                return result;

            foreach (var g in groups.Split(','))
            {
                if (int.TryParse(g.Trim(), out int id) && id > 0)
                    result.Add(id);
            }
            return result;
        }

        public void Dispose()
        {
            _conn?.Dispose();
        }
    }
}
