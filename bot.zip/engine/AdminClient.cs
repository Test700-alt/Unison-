﻿using System;
using System.IO;
using System.Text;
using System.Net.Sockets;
using System.Text.RegularExpressions;
using GrandManager.engine;
using Newtonsoft.Json.Linq;
using System.Net;
using System.Net.Http;
using System.Security.Policy;
using System.Globalization;
using System.Data;
//using GrandManager.engine.SiteEngine;
using System.Web;
using Newtonsoft.Json;

namespace GrandManager
{
    
    internal class AdminClient
    {
        HTTPHeaders heads;
        private Encoding charEncoder = Encoding.UTF8;
        public string ip = "";
        
        public async Task<string> GetSheet(HTTPHeaders head, string request, string ips, Dictionary<string, string> args = null)
        {
            heads = head;
            ip = ips;
            try {
                if (head.File == "/grandadmin/authtoken")
                {
                    return genError("not user", 1); //await engine.SiteEngine.AdminSite.GetToken.Work(args, head);
                   

                }
                else
                {
                    return genError("not user", 1);
                }

                    
                return "ok";
            }
            catch (Exception ex)
            {
                
                AdminInfo.AddErrorList("Ошибка обработки запроса сайта", "Дата: " + DateTimeOffset.Now.ToString("G") + "<br><br>" +
                    "Метод: " + head.Method.ToString() + " | Файл: " + head.File.ToString() + "<br>" +
                    "Request:<br>" + request + "<br><br>Exception: " + ex.Message + "<br>Source: " + ex.Source + "<br><br>" +
                    "Stack trace: " + ex.StackTrace);
                Console.WriteLine(ex.Message);
                return genError("not user", 1);
                //Console.WriteLine($"Func: GetSheet()    link: {head.RealPath}\nException: {ex}/nMessage: {ex.Message}");
            }
        }


        public static string genError(string message, int code = 0, object data = null)
        {
            var targetObject = new { error = new { message = message, code = code, data = data } };

            return Newtonsoft.Json.JsonConvert.SerializeObject(targetObject);
        }

        public static string genSuccessfull(string message, int code = 0, object data = null)
        {
            var targetObject = new { response = new { message = message, code = code, data = data } };

            return Newtonsoft.Json.JsonConvert.SerializeObject(targetObject);
        }

        public static bool IsValidEmail(string email)
        {
            var trimmedEmail = email.Trim();

            if (trimmedEmail.EndsWith("."))
            {
                return false; // suggested by @TK-421
            }
            try
            {
                var addr = new System.Net.Mail.MailAddress(email);
                return addr.Address == trimmedEmail;
            }
            catch
            {
                return false;
            }
        }

        public static bool HasSpecialChars(string yourString)
        {
            return Regex.IsMatch(yourString, "\\p{So}");
            return yourString.Any(ch => !char.IsLetterOrDigit(ch));
        }


        public static Dictionary<string, string>? getDataHash(Dictionary<string, string> args, HTTPHeaders head, Cache cache)
        {
            Dictionary<string, string>? data = null;
            if (!args.ContainsKey("hash"))
            {
                if (head.Ip != "127.0.0.1")
                {
                    data = cache.Get<Dictionary<string, string>>("hash_" + head.Ip);
                    if (data != null)
                    {
                        cache.Set("hash_" + head.Ip, data, 15);
                    }
                }
                else
                {
                    data = null;
                }
            }
            else
            {
                if (args.ContainsKey("hash"))
                {
                    var datrter_hash = HttpUtility.UrlDecode(args["hash"]);
                    data = cache.Get<Dictionary<string, string>>("hash_" + datrter_hash);
                    if (data != null)
                    {
                        cache.Set("hash_" + datrter_hash, data, 15);
                    }
                }
                else
                {
                    data = null;
                }
            }
            
            return data;
        }


        public string getRubsMoney(string money)
        {
            return getKKsMoney(money, "en-U") + "₽";
        }

        public string getDollMoney(string money)
        {
            return getKKsMoney(money, "en-US") + "$";
        }

        public string getEuroMoney(string money)
        {
            return getKKsMoney(money, "en-U") + "€";
        }
        /*
         * ru-RU - рубли
         * en-US - доллары
         * fr-FR - евро
         */
        public string getKKsMoney(string money, string country = "ru-RU")
        {
            System.Numerics.BigInteger temp = 0;
            try
            {
                temp = System.Numerics.BigInteger.Parse(money);
            }
            catch
            {

            }
            var counti = CultureInfo.CreateSpecificCulture(country);
            return temp.ToString("N0", counti);//temp.ToString("C2", counti);
        }


        

        private void sendResponse(Socket clientSocket, string strContent, string responseCode,
                                  string contentType)
        {
            byte[] bContent = charEncoder.GetBytes(strContent);
            sendResponse(clientSocket, bContent, responseCode, contentType);
        }

        // For byte arrays
        private void sendResponse(Socket clientSocket, byte[] bContent, string responseCode,
                                  string contentType)
        {
            try
            {
                byte[] bHeader = charEncoder.GetBytes(
                                    "HTTP/1.1 " + responseCode + "\r\n"
                                  + "Content-Length: " + bContent.Length.ToString() + "\r\n"
                                  + "Content-Type: " + contentType + "\r\n\r\n");
                clientSocket.Send(bHeader);
                clientSocket.Send(bContent);
                clientSocket.Close();
            }
            catch { }
        }
        

    }
}
