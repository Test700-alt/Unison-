﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class Auth : Templane
    {
        /*
         
        Auth
        Авторизация пользователя
         
        */

        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "auth",

                nameOfClass = "GrandManager.engine.API.Method.Auth",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        { 
            try
            {
                var session = await getUserSessionAsync(Cookies);
                if (session != null)
                {
                    //GrandManager.engine.API.Method.Profile method = new();
                    //return method.work(cache, Db, args, Cookies, false, ip);
                    result.htmlResponse = href("profile");

                    return result;
                }

                if (args.ContainsKey("code"))
                {
                    var code = args["code"];
                    if (string.IsNullOrEmpty(code))
                    {
                        result.htmlResponse = href("profile");
                        return result;//;
                    }

                    string clientId = "51710182";
                    string clientSecret = "WnNk5gEUmd74xmLry51Q"; // **ВНИМАНИЕ!** Этот секрет должен быть защищен!
                    string redirectUri = "https://grandmanager.ru/auth";

                    try
                    {
                        // Получаем токен
                        var tokenData = await GetAccessToken(clientId, clientSecret, redirectUri, code);

                        if (tokenData != null && !string.IsNullOrEmpty(tokenData.AccessToken))
                        {
                            //Console.WriteLine($"Успешно авторизован пользователь с ID: {tokenData.UserId}");
                            //Console.WriteLine($"Access token: {tokenData.AccessToken}");
                            Db.usersSetAccessToken(tokenData.UserId, tokenData.AccessToken);
                            var sessId = Guid.NewGuid().ToString();
                            regUserSession(sessId, tokenData.UserId, ip);
                            result.Cookies["session-id"] = sessId;//b8e781e6-403c-4736-9970-e2d82f19010f
                            //Console.WriteLine("token: " + tokenData.AccessToken);
                            //Console.WriteLine("UserId: " + tokenData.UserId);
                            result.htmlResponse = href("auth");
                            Console.WriteLine("reg user - " + sessId);
                            return result;
                        }
                        else
                        {
                            Console.WriteLine($"Ошибка получения токена: {tokenData?.Error ?? "Неизвестная ошибка"}");
                            if (tokenData != null && !string.IsNullOrEmpty(tokenData.ErrorDescription))
                            {
                                Console.WriteLine($"Описание ошибки: {tokenData.ErrorDescription}");
                            }
                            result.htmlResponse = getCacheTemplane("auth.html");
                            return result;
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine($"Произошла ошибка: {ex.Message}");
                        result.htmlResponse = getCacheTemplane("auth.html");
                        return result;
                    }
                }

                if (args.ContainsKey("reg"))
                {
                    var sessId = Guid.NewGuid().ToString();
                    regUserSession(sessId, 251372816, ip);
                    result.Cookies["session-id"] = sessId;//b8e781e6-403c-4736-9970-e2d82f19010f
                    result.htmlResponse = sessId;

                    return result;
                }

                result.htmlResponse = getCacheTemplane("auth.html");
                return result;
            }
            catch (Exception e)
            {
                result.htmlResponse = "error " + e.Message + " e source " + e.Source + " stacktrace " + e.StackTrace;
                return result;
            }
            
        }


        private static async Task<VkTokenResponse> GetAccessToken(string clientId, string clientSecret, string redirectUri, string code)
        {
            using var httpClient = new HttpClient();

            var tokenUrl = "https://oauth.vk.com/access_token";
            var parameters = new Dictionary<string, string>()
            {
                { "client_id", clientId },
                { "client_secret", clientSecret },
                { "code", code },
                { "redirect_uri", redirectUri }
            };

            var request = new HttpRequestMessage(HttpMethod.Post, tokenUrl)
            {
                Content = new FormUrlEncodedContent(parameters)
            };

            var response = await httpClient.SendAsync(request);
            response.EnsureSuccessStatusCode();

            var responseString = await response.Content.ReadAsStringAsync();

            var tokenData = JsonConvert.DeserializeObject<VkTokenResponse>(responseString);

            return tokenData;
        }

        public class VkTokenResponse
        {
            [JsonProperty("access_token")]
            public string AccessToken { get; set; }

            [JsonProperty("expires_in")]
            public int ExpiresIn { get; set; }

            [JsonProperty("user_id")]
            public long UserId { get; set; }

            [JsonProperty("error")]
            public string Error { get; set; }

            [JsonProperty("error_description")]
            public string ErrorDescription { get; set; }
        }
    }
}
