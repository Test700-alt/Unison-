﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API
{
    public class LoaderAPI
    {
        public static List<ApiInfo> listOfAllMethods = new();
        public static Dictionary<string, ApiInfo> nameCmd_CommandInfo = new();

        public static void preloaderAllCmds()
        {
            Console.WriteLine("[PRELOADER] Preloading APIs..");

            Type[] typelist = Assembly.GetExecutingAssembly().GetTypes().Where(t => t.Namespace == "GrandManager.engine.API.Method").ToArray();
            int preloaded = 0;
            foreach (Type type in typelist)
            {

                //создание объекта
#pragma warning disable CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.
#pragma warning disable CS8604 // Возможно, аргумент-ссылка, допускающий значение NULL.
                object targetObject = Activator.CreateInstance(Type.GetType(type.FullName));
#pragma warning restore CS8604 // Возможно, аргумент-ссылка, допускающий значение NULL.
#pragma warning restore CS8600 // Преобразование литерала, допускающего значение NULL или возможного значения NULL в тип, не допускающий значение NULL.

                MethodInfo? methodInfo = type.GetMethod("preloader");
                // Invoke the method on the instance we created above
                if (methodInfo != null)
                {
                    methodInfo.Invoke(targetObject, null);
                    preloaded++;
                }
            }

            Console.WriteLine($"[PRELOADER] Preloaded {preloaded} APIs.");
        }

        public static void loadAllCmds()
        {
            Console.WriteLine("[LOADERAPI] Loading APIs..");


            int loaded = 0;
            foreach (var Cmd in listOfAllMethods)
            {
                if (nameCmd_CommandInfo.ContainsKey(Cmd.name))
                {
                    Console.WriteLine($"[LOADERAPI] Already exists method APID '{Cmd.name}' of classes '{Cmd.nameOfClass}' AND '{nameCmd_CommandInfo[Cmd.name].nameOfClass}'!");
                    continue;
                }

                nameCmd_CommandInfo.Add(Cmd.name, Cmd);

               
                loaded++;
            }

            Console.WriteLine($"[LOADERAPI] Loaded {loaded} methods API.\n");
        }
    }


    public class ApiInfo
    {
        public string name = "";

        public string nameOfClass = "";
        public string nameOfMethod = "work";

        public bool is_admin = false;

        public bool is_post = false;
    }
}
