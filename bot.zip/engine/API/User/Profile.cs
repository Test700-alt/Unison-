﻿using GrandManager.engine.properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class Profile : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "profile",

                nameOfClass = "GrandManager.engine.API.Method.Profile",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                result.htmlResponse = getCacheTemplane("profile.html");

                if (settings.OWNER_IDS.ContainsKey(session.user_id) && settings.OWNER_IDS[session.user_id].admin != 1)
                {
                    result.htmlResponse = getCacheTemplane("profile.html", true, "profile", true);
                }

                var Vk = new vk(cache);

                var userVk = await Vk.UsersGetVkInfo(new long[] { session.user_id });

                if (userVk == null)
                {
                    result.htmlResponse = "error - user not user";
                    return result;
                }

                var firstName = "Имя";
                var lastName = "фамилия";

                if (userVk.ContainsKey("id"+session.user_id))
                {
                    firstName = userVk["id" + session.user_id.ToString()].first_name;
                    lastName = userVk["id" + session.user_id.ToString()].last_name;
                }

                var account = Db.usersGetUser(session.user_id);
                if (account == null)
                {
                    result.htmlResponse = "error - user not user 2";
                    return result;
                }

                result.htmlResponse = result.htmlResponse.Replace("%username%", firstName);
                result.htmlResponse = result.htmlResponse.Replace("%userlastname%", lastName);

                result.htmlResponse = result.htmlResponse.Replace("%userid%", session.user_id.ToString());

                result.htmlResponse = result.htmlResponse.Replace("%rubles%", account["rubs"]);
                result.htmlResponse = result.htmlResponse.Replace("%euros%", account["euros"]);

                // ИМУЩЕСТВО

                //var userInfo = db.usersGetUser(Vk.m_from_id);
                var property = Db.propertyGetUser(session.user_id);
                if (property == null || property.Count < 1)
                {
                    result.htmlResponse = result.htmlResponse.Replace("%property_car%", "—");
                    result.htmlResponse = result.htmlResponse.Replace("%property_car_dop%", "");
                    result.htmlResponse = result.htmlResponse.Replace("%property_house%", "—");
                    result.htmlResponse = result.htmlResponse.Replace("%property_house_dop%", "");
                    result.htmlResponse = result.htmlResponse.Replace("%property_boat%", "—");
                    result.htmlResponse = result.htmlResponse.Replace("%property_boat_dop%", "");
                    result.htmlResponse = result.htmlResponse.Replace("%property_airplane%", "—");
                    result.htmlResponse = result.htmlResponse.Replace("%property_airplane_dop%", "");
                    result.htmlResponse = result.htmlResponse.Replace("%property_helicopter%", "—");
                    result.htmlResponse = result.htmlResponse.Replace("%property_helicopter_dop%", "");
                    result.htmlResponse = result.htmlResponse.Replace("%property_smartphone%", "—");
                    result.htmlResponse = result.htmlResponse.Replace("%property_smartphone_dop%", "");
                    result.htmlResponse = result.htmlResponse.Replace("%property_computer%", "—");
                    result.htmlResponse = result.htmlResponse.Replace("%property_computer_dop%", "");
                    //Vk.MessagesSend("К сожалению, у вас нет никакого имущества. Вы можете купить его — !магазин");
                    return result;
                }

                string text;

                string house = (houses.list.ContainsKey(long.Parse(property["house"]))) ? houses.list[long.Parse(property["house"])]["name"] : "нет";
                string house_price = (houses.list.ContainsKey(long.Parse(property["house"]))) ? getRubsMoney(houses.list[long.Parse(property["house"])]["price"]) : "";

                string car = (houses.list.ContainsKey(long.Parse(property["car"]))) ? cars.list[long.Parse(property["car"])]["name"] : "нет";
                string car_price = (houses.list.ContainsKey(long.Parse(property["car"]))) ? getRubsMoney(cars.list[long.Parse(property["car"])]["price"]) : "";

                string boat = (boats.list.ContainsKey(long.Parse(property["boat"]))) ? boats.list[long.Parse(property["boat"])]["name"] : "нет";
                string boat_price = (boats.list.ContainsKey(long.Parse(property["boat"]))) ? getRubsMoney(boats.list[long.Parse(property["boat"])]["price"]) : "";

                string airplane = (airplanes.list.ContainsKey(long.Parse(property["airplane"]))) ? airplanes.list[long.Parse(property["airplane"])]["name"] : "нет";
                string airplane_price = (airplanes.list.ContainsKey(long.Parse(property["airplane"]))) ? getRubsMoney(airplanes.list[long.Parse(property["airplane"])]["price"]) : "";

                string helicopter = (helicopters.list.ContainsKey(long.Parse(property["helicopter"]))) ? helicopters.list[long.Parse(property["helicopter"])]["name"] : "нет";
                string helicopter_price = (helicopters.list.ContainsKey(long.Parse(property["helicopter"]))) ? getRubsMoney(helicopters.list[long.Parse(property["helicopter"])]["price"]) : "";

                string smartphone = (smartphones.list.ContainsKey(long.Parse(property["smartphone"]))) ? smartphones.list[long.Parse(property["smartphone"])]["name"] : "нет";
                string smartphone_price = (smartphones.list.ContainsKey(long.Parse(property["smartphone"]))) ? getRubsMoney(smartphones.list[long.Parse(property["smartphone"])]["price"]) : "";

                string computer = (computers.list.ContainsKey(long.Parse(property["computer"]))) ? computers.list[long.Parse(property["computer"])]["name"] : "нет";
                string computer_price = (computers.list.ContainsKey(long.Parse(property["computer"]))) ? getRubsMoney(computers.list[long.Parse(property["computer"])]["price"]) : "";
                

                result.htmlResponse = result.htmlResponse.Replace("%property_car%", car);
                result.htmlResponse = result.htmlResponse.Replace("%property_car_dop%", car_price);
                result.htmlResponse = result.htmlResponse.Replace("%property_house%", house);
                result.htmlResponse = result.htmlResponse.Replace("%property_house_dop%", house_price);
                result.htmlResponse = result.htmlResponse.Replace("%property_boat%", boat);
                result.htmlResponse = result.htmlResponse.Replace("%property_boat_dop%", boat_price);
                result.htmlResponse = result.htmlResponse.Replace("%property_airplane%", airplane);
                result.htmlResponse = result.htmlResponse.Replace("%property_airplane_dop%", airplane_price);
                result.htmlResponse = result.htmlResponse.Replace("%property_helicopter%", helicopter);
                result.htmlResponse = result.htmlResponse.Replace("%property_helicopter_dop%", helicopter_price);
                result.htmlResponse = result.htmlResponse.Replace("%property_smartphone%", smartphone);
                result.htmlResponse = result.htmlResponse.Replace("%property_smartphone_dop%", smartphone_price);
                result.htmlResponse = result.htmlResponse.Replace("%property_computer%", computer);
                result.htmlResponse = result.htmlResponse.Replace("%property_computer_dop%", computer_price);

                return result;
            }
            catch (Exception e)
            {
                result.htmlResponse = "error - undefined " + e.Message + " " + e.StackTrace;
                return result;
            }
        }
    }
}
