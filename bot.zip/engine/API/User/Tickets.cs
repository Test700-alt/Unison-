﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class Tickets : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "tickets",

                nameOfClass = "GrandManager.engine.API.Method.Tickets",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            var session = await getUserSessionAsync(Cookies);

            if (session == null)
            {
                result.htmlResponse = href("auth");
                return result;
            }

            long userId = session.user_id;
            var tickets = Db.reportGetForUser(userId);

            result.htmlResponse = getCacheTemplane("tickets.html");
            if (settings.OWNER_IDS.ContainsKey(session.user_id) && settings.OWNER_IDS[session.user_id].admin != 1)
            {
                result.htmlResponse = getCacheTemplane("tickets.html", true, "profile", true);
            }

            if (tickets == null || tickets.Count < 1)
            {
                return result;
            }
            //<!--UNANSWERED TICKETS-->

            List<Dictionary<string, string>> unanswered = new();
            List<Dictionary<string, string>> answered = new();

            foreach (var item in tickets)
            {
                var ticketInfo = Db.reportGet(long.Parse(item), false);

                if (ticketInfo["closed"] == "1")
                {
                    answered.Add(ticketInfo);
                }
                else
                {
                    unanswered.Add(ticketInfo);
                }
            }

            string unansweredText = "";

            if (unanswered.Count > 0)
            {
                foreach (var ticket in unanswered)
                {
                    var title = "Без названия";
                    if (ticket["title"] != "")
                    {
                        title = ticket["title"];
                    }
                    unansweredText += @$"<div class=""ticket-item"">
                    <img src=""/images/logo.png"" alt=""Обращение"" class=""ticket-avatar"">
                    <div class=""ticket-details"">
                        <h3 class=""ticket-title"">{title}</h3>
                        <p class=""ticket-meta"">
                            <span>Последняя активность: {Db.timeGetForMysql(ticket["last_activity"]).ToString("g")}</span>
                        </p>
                    </div>
                    <div class=""ticket-actions"">
                        <a href=""/ticketinfo?id={ticket["id"]}"" class=""ticket-button"">В диалог</a>
                    </div>
                </div>";
                }

                result.htmlResponse = result.htmlResponse.Replace("<!--UNANSWERED TICKETS-->", unansweredText);
            }

            string answeredText = "";
            if (answered.Count > 0)
            {
                foreach (var ticket in answered)
                {
                    var title = "Без названия";
                    if (ticket["title"] != "")
                    {
                        title = ticket["title"];
                    }
                    answeredText += @$"<div class=""ticket-item"">
                    <img src=""/images/logo.png"" alt=""Обращение"" class=""ticket-avatar"">
                    <div class=""ticket-details"">
                        <h3 class=""ticket-title"">{title}</h3>
                        <p class=""ticket-meta"">
                            <span>Последняя активность: {Db.timeGetForMysql(ticket["last_activity"]).ToString("g")}</span>
                        </p>
                    </div>
                    <div class=""ticket-actions"">
                        <a href=""/ticketinfo?id={ticket["id"]}"" class=""ticket-button"">В диалог</a>
                    </div>
                </div>";
                }

                result.htmlResponse = result.htmlResponse.Replace("<!--ANSWERED TICKETS-->", answeredText);
            }

            return result;
        }
    }
}
