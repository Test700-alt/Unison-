﻿using GrandManager.engine.DataBaseClass;
using GrandManager.engine.properties;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class RolesPanel : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "rolespanel",

                nameOfClass = "GrandManager.engine.API.Method.RolesPanel",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;
                
                result.htmlResponse = getCacheTemplane("rolespanel.html", true, "peers");
                if (settings.OWNER_IDS.ContainsKey(session.user_id) && settings.OWNER_IDS[session.user_id].admin != 1)
                {
                    result.htmlResponse = getCacheTemplane("rolespanel.html", true, "peers", true);
                }

                if (!args.ContainsKey("id"))
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                long peer_id = 0;
                try
                {
                    peer_id = long.Parse(args["id"]);
                }
                catch
                {
                    peer_id = 0;
                }

                if (peer_id <= 0)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                var peerInfo = Db.peersGetPeer(peer_id);
                if (peerInfo == null)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                if (peerInfo["active"] == "0")
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                var peerMember = Db.peersGetMember(peer_id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                if (long.Parse(peerMember["priority"]) < 80 && peerInfo["owner"] != userid.ToString())
                {
                    result.htmlResponse = href("peers");
                    return result;
                }

                result.htmlResponse = result.htmlResponse.Replace("%peerid%", peer_id.ToString());
                //result.htmlResponse = result.htmlResponse.Replace("%peertitle%", peerInfo["title"]);

                vk Vk = new(cache);

                List<long> createsIds = new();

                var rolesDb = Db.peerGetRoles(peer_id);

                if (rolesDb != null)
                {
                    
                    //roles = from entry in roles orderby entry.Value.priority ascending select entry;
                    //result.htmlResponse = result.htmlResponse.Replace("%peerCountRoles%", roles.Count.ToString());
                }
                else
                {
                    rolesDb = new();
                    //result.htmlResponse = result.htmlResponse.Replace("%peerCountRoles%", "—");
                }

                if (!rolesDb.ContainsKey("0"))
                {
                    rolesDb.Add("0", new NamesRoles() { name = "Пользователь", priority = 0, admin = 0 });
                }
                if (!rolesDb.ContainsKey("20"))
                {
                    rolesDb.Add("20", new NamesRoles() { name = "Помощник", priority = 20, admin = 0 });
                }
                if (!rolesDb.ContainsKey("40"))
                {
                    rolesDb.Add("40", new NamesRoles() { name = "Модератор", priority = 40, admin = 0 });
                }
                if (!rolesDb.ContainsKey("60"))
                {
                    rolesDb.Add("60", new NamesRoles() { name = "Администратор", priority = 60, admin = 0 });
                }
                if (!rolesDb.ContainsKey("80"))
                {
                    rolesDb.Add("80", new NamesRoles() { name = "Главный Администратор", priority = 80, admin = 0 });
                }
                if (!rolesDb.ContainsKey("100"))
                {
                    rolesDb.Add("100", new NamesRoles() { name = "Владелец", priority = 100, admin = 0 });
                }

                foreach (var item in rolesDb)
                {
                    if (item.Value.admin != 0)
                    {
                        createsIds.Add(item.Value.admin);
                    }
                }


                Dictionary<string, usersNameVk> names = new();
                //var usersVk = await Vk.UsersGetVkInfo(new long[] { long.Parse(peerInfo["owner"]) });

                if (createsIds.Count > 0)
                {
                    var resVk = await Vk.UsersGetVkInfo(createsIds.ToArray());
                    if (resVk != null)
                    {
                        names = resVk;
                    }
                }
                string rolesTextInput = "";

                var usersWhenRole = Db.peerGetMembersWhenRole(peer_id, false, 1000);

                Dictionary<long, long> countWhenRole = new();
                if (usersWhenRole != null)
                {
                    try
                    {
                        foreach (var user in usersWhenRole)
                        {
                            var DbUser = Db.peersGetMember(peer_id, user, false, false);
                            if (DbUser != null)
                            {
                                if (DbUser["priority"] != "0")
                                {
                                    if (countWhenRole.ContainsKey(long.Parse(DbUser["priority"])))
                                    {
                                        countWhenRole[long.Parse(DbUser["priority"])] += 1;
                                    }
                                    else
                                    {
                                        countWhenRole.Add(long.Parse(DbUser["priority"]), 1);
                                    }
                                    //countWhenRole[long.Parse(DbUser["priority"])]++;
                                }
                            }
                        }
                    }
                    catch
                    {

                    }
                }

                var roles = from entry in rolesDb orderby entry.Value.priority ascending select entry;

                foreach (var roleInfo in roles)
                {
                    var UserNameV = "Базовая роль";
                    var linkVk = "https://vk.com/";
                    var preLinkVk = "";
                    if (roleInfo.Value.admin < 0)
                    {
                        preLinkVk = "Создатель: ";
                        UserNameV = "Сообщество";
                        linkVk += "club" + roleInfo.Value.admin.ToString().Substring(1);
                    }
                    else
                    {
                        if (roleInfo.Value.admin == 0)
                        {

                            linkVk = "https://vk.com/";
                            UserNameV = "Базовая роль";
                        }
                        else
                        {
                            if (names != null)
                            {
                                if (names.ContainsKey("id" + roleInfo.Value.admin.ToString()))
                                {
                                    preLinkVk = "Создатель: ";
                                    UserNameV = names["id" + roleInfo.Value.admin.ToString()].first_name + " " + names["id" + roleInfo.Value.admin.ToString()].last_name;
                                }
                            }
                            linkVk += "id" + roleInfo.Value.admin.ToString();
                        }
                    }

                    var dateCreate = "—";
                    if (roleInfo.Value.date_create != "")
                    {
                        dateCreate = Db.timeGetForMysql(roleInfo.Value.date_create).ToString("d");
                    }

                    var countRolesText = "0";
                    if (countWhenRole.ContainsKey(roleInfo.Value.priority))
                    {
                        countRolesText = countWhenRole[roleInfo.Value.priority].ToString();
                    }

                    rolesTextInput += @$"<div class=""role-item"" data-role-id=""{roleInfo.Value.priority}"">
                    <div class=""role-info"">
                        <p><strong>ID:</strong> <span class=""role-id"">{roleInfo.Value.priority}</span></p>
                        <p><strong>Название:</strong> <span class=""role-name"">{roleInfo.Value.name}</span></p>
                        <p><strong>Дата создания:</strong> <span class=""role-date"">{dateCreate}</span></p>
                         <p><strong>{preLinkVk}</strong><a href=""{linkVk}"" target=""_blank"">{UserNameV}</a></p>
                    </div>
                     <div class=""role-actions"">
                         <a href=""userspanel?id={peer_id}&role={roleInfo.Value.priority}"" class=""role-users-count""> {countRolesText} участников </a>
                         <button class=""edit-role-button"" data-role-id=""{roleInfo.Value.priority}""><i class=""fas fa-edit""></i></button>
                        <button class=""delete-role-button"" data-role-id=""{roleInfo.Value.priority}""><i class=""fas fa-times""></i></button>
                    </div>
                </div>";
                }
                //<!--ROLESLIST-->
               

                result.htmlResponse = result.htmlResponse.Replace("<!--ROLESLIST-->", rolesTextInput);

                
                return result;
            }
            catch (Exception e)
            {
                result.htmlResponse = "error - undefined " + e.Message + " " + e.StackTrace;
                return result;
            }
        }
    }
}
