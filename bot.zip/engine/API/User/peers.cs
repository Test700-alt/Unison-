﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class peers : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "peers",

                nameOfClass = "GrandManager.engine.API.Method.peers",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                result.htmlResponse = getCacheTemplane("peers.html", true, "peers");
                if (settings.OWNER_IDS.ContainsKey(session.user_id) && settings.OWNER_IDS[session.user_id].admin != 1)
                {
                    result.htmlResponse = getCacheTemplane("peers.html", true, "peers", true);
                }

                if (!result.htmlResponse.Contains("<!--%MYPEERS ITEMS%-->"))
                {
                    return result;
                    /**/
                }

                if (!result.htmlResponse.Contains("<!--%JOINPEERS ITEMS%-->"))
                {
                    return result;
                    /**/
                }

                long user_id = session.user_id;

                var MypeersList = Db.peersGetForOwner(user_id);

                var Mypeers = new List<Dictionary<string, string>>();

                foreach (var item in MypeersList)
                {
                    var peerInfo = Db.peersGetPeer(item, false, false);
                    if (peerInfo == null)
                    {
                        continue;
                    }
                    var peerInfoAdd = new Dictionary<string, string>()
                    {
                        { "peer_id", peerInfo["peer_id"] },
                        { "owner", peerInfo["owner"] },
                        { "title", peerInfo["title"] },
                        { "date_reg", peerInfo["date_reg"] },
                        { "current_members", peerInfo["current_members"] },
                        { "logo", peerInfo["logo"] },
                    };
                    Mypeers.Add(peerInfoAdd);
                }

                Mypeers = Mypeers.OrderByDescending(peer => long.Parse(peer["peer_id"])).ToList();

                string peersResult = "";
                foreach (var item in Mypeers)
                {
                    string urlPhoto = "/images/logo.png";
                    if (item["logo"] != "")
                    {
                        urlPhoto = item["logo"];
                    }
                    peersResult += $@"<div class=""peer-item"">
                    <img src=""{urlPhoto}"" alt=""Беседа {item["peer_id"]}"" class=""peer-avatar"">
                    <div class=""peer-details"">
                        <h3 class=""peer-title"">{item["title"]}</h3>
                        <p class=""peer-meta"">
                            <span>Создана: {item["date_reg"]}</span>
                            <span>Владелец: <a href=""https://vk.com/id{item["owner"]}"">Вы</a></span>
                            <span>Участников: {item["current_members"]}</span>
                        </p>
                    </div>
                    <div class=""peer-actions"">
                        <a href=""infopeer?id={item["peer_id"]}"" class=""peer-button"">Детальнее</a>
                        <button class=""peer-close-button"" data-peer-id=""{item["peer_id"]}""><i class=""fas fa-times""></i></button>
                    </div>
                </div>";
                }

                result.htmlResponse = result.htmlResponse.Replace("<!--%MYPEERS ITEMS%-->", peersResult);

                //<!--%JOINPEERS ITEMS%-->


                var JoinpeersList = Db.peersGetForLead(user_id);

                var JoinPeers = new List<Dictionary<string, string>>();
                List<long> UserOwnerids = new();
                if (JoinpeersList != null)
                {
                    foreach (var item in JoinpeersList)
                    {
                        if (MypeersList.Contains(item)) continue;
                        var peerInfo = Db.peersGetPeer(item, false, false);
                        if (peerInfo == null)
                        {
                            continue;
                        }

                        var peerInfoAdd = new Dictionary<string, string>()
                        {
                            { "peer_id", peerInfo["peer_id"] },
                            { "owner", peerInfo["owner"] },
                            { "title", peerInfo["title"] },
                            { "date_reg", peerInfo["date_reg"] },
                            { "current_members", peerInfo["current_members"] },
                            { "logo", peerInfo["logo"] },
                            { "active", peerInfo["active"] },
                        };
                        JoinPeers.Add(peerInfoAdd);
                        if (long.Parse(peerInfo["owner"]) > 0)
                        {
                            UserOwnerids.Add(long.Parse(peerInfo["owner"]));
                        }
                    }

                    JoinPeers = JoinPeers.OrderByDescending(peer => long.Parse(peer["peer_id"])).ToList();

                    vk Vk = new(cache);

                    var usersVk = await Vk.UsersGetVkInfo(UserOwnerids.ToArray());

                    string peersResult2 = "";
                    foreach (var item in JoinPeers)
                    {
                        if (item["active"] == "0")
                        {
                            continue;
                        }

                        string urlPhoto = "/images/logo.png";
                        if (item["logo"] != "")
                        {
                            urlPhoto = item["logo"];
                        }
                        var UserNameV = "неизвестно";
                        var linkVk = "https://vk.com/";
                        if (long.Parse(item["owner"]) < 0)
                        {
                            UserNameV = "Сообщество";
                            linkVk += "club" + item["owner"].Substring(1);
                        }
                        else
                        {
                            if (item["owner"] == "0")
                            {

                                linkVk = "https://vk.com/";
                                UserNameV = "Не определено";
                            }
                            else
                            {
                                if (usersVk != null)
                                {
                                    if (usersVk.ContainsKey("id" + item["owner"]))
                                    {
                                        UserNameV = usersVk["id" + item["owner"]].first_name + " " + usersVk["id" + item["owner"]].last_name;
                                    }
                                }
                                linkVk += "id" + item["owner"];
                            }
                        }
                        

                        peersResult2 += $@"<div class=""peer-item"">
                    <img src=""{urlPhoto}"" alt=""Беседа {item["peer_id"]}"" class=""peer-avatar"">
                    <div class=""peer-details"">
                        <h3 class=""peer-title"">{item["title"]}</h3>
                        <p class=""peer-meta"">
                            <span>Создана: {item["date_reg"]}</span>
                            <span>Владелец: <a href=""{linkVk}"">{UserNameV}</a></span>
                            <span>Участников: {item["current_members"]}</span>
                        </p>
                    </div>
                    <div class=""peer-actions"">
                        <a href=""infopeer?id={item["peer_id"]}"" class=""peer-button"">Детальнее</a>
                        <button class=""peer-close-button"" data-peer-id=""{item["peer_id"]}""><i class=""fas fa-times""></i></button>
                    </div>
                </div>";
                    }

                    result.htmlResponse = result.htmlResponse.Replace("<!--%JOINPEERS ITEMS%-->", peersResult2);
                }
                
                return result;
            }
            catch
            {
                result.htmlResponse = "undefined error";
                return result;
            }
        }
    }
}
