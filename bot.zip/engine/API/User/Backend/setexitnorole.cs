﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class setexitnorole : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "setexitnorole",

                nameOfClass = "GrandManager.engine.API.Method.setexitnorole",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                if (!is_post)
                {
                    result.htmlResponse = "403";
                    return result;
                }

                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;

                if (!args.ContainsKey("id") || !args.ContainsKey("set"))
                {
                    result.htmlResponse = GenerateError("no args passed");
                    return result;
                }

                long id = 0;
                try
                {
                    id = long.Parse(args["id"]);
                }
                catch
                {
                    id = 0;
                }

                if (id == 0)
                {
                    result.htmlResponse = GenerateError("no id passed");
                    return result;
                }

                var set = args["set"];
                if (set != "false" && set != "true")
                {
                    result.htmlResponse = GenerateError("no type passed");
                    return result;
                }

                var peerInfo = Db.peersGetPeer(id);
                if (peerInfo == null)
                {
                    result.htmlResponse = GenerateError("peerInfo is NULL");
                    return result;
                }

                var peerMember = Db.peersGetMember(id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = GenerateError("403 forbidden");
                    return result;
                }

                if (int.Parse(peerMember["priority"]) < 80)
                {
                    result.htmlResponse = GenerateError("403 forbidden — role not 80");
                    return result;
                }

                vk Vk = new(cache);

                string text = "";
                int settype = 1;

                var userName = await Vk.UserGetNameUrls(new long[] { userid });

                if (set == "true")
                {
                    text = userName[userid.ToString()] + " включил настройку 'исключать обычных пользователей при выходе' через панель управления.<br><br>" +
                        "🦠 Теперь любой пользователь без роли, вышедший из беседы - будет исключен.";
                }
                else if (set == "false")
                {
                    text = userName[userid.ToString()] + " выключил настройку 'исключать обычных пользователей при выходе' через панель управления.<br><br>" +
                        "🤖 Пользователи без роли теперь могут выходить, бот не будет их исключать.";
                    settype = 0;
                }

                Db.peersSetKickexit(id, settype);
                Vk.MessagesSend(text, 0, id);

                var res = GenerateSuccessfull("ok");
                result.htmlResponse = res;

                return result;
            }
            catch
            {
                result.htmlResponse = GenerateError("undefined exception error");
                return result;
            }
        }
    }
}
