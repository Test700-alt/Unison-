﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class deactivate : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "deactivate",

                nameOfClass = "GrandManager.engine.API.Method.deactivate",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                if (!is_post)
                {
                    result.htmlResponse = "403";
                    return result;
                }

                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;

                if (!args.ContainsKey("id"))
                {
                    result.htmlResponse = GenerateError("no args passed");
                    return result;
                }

                long id = 0;
                try
                {
                    id = long.Parse(args["id"]);
                }
                catch
                {
                    id = 0;
                }

                if (id == 0)
                {
                    result.htmlResponse = GenerateError("no id passed");
                    return result;
                }

                var peerInfo = Db.peersGetPeer(id);
                if (peerInfo == null)
                {
                    result.htmlResponse = GenerateError("peerInfo is NULL");
                    return result;
                }

                if (peerInfo["active"] == "0")
                {
                    result.htmlResponse = GenerateError("peerInfo already deactivated");
                    return result;
                }

                var peerMember = Db.peersGetMember(id, userid, false, false);
                if (peerMember == null)
                {
                    result.htmlResponse = GenerateError("403 forbidden");
                    return result;
                }

                if (int.Parse(peerMember["priority"]) < 100)
                {
                    result.htmlResponse = GenerateError("403 forbidden — role not 100");
                    return result;
                }

                vk Vk = new(cache);

                string text = "";

                var userName = await Vk.UserGetNameUrls(new long[] { userid });

                text = "🐩 " + userName[userid.ToString()] + " деактивировал беседу через панель управления.<br><br>" +
                    "👾 Вы можете вновь активировать беседу — /начать (или /start).";
                
                Db.peerDeactivate(id);
                Vk.MessagesSend(text, 0, id);
                Db.peersGetForOwner(userid, true);

                var res = GenerateSuccessfull("ok");
                result.htmlResponse = res;

                return result;
            }
            catch
            {
                result.htmlResponse = GenerateError("undefined exception error");
                return result;
            }
        }
    }
}
