﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class delaccount : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "delaccount",

                nameOfClass = "GrandManager.engine.API.Method.delaccount",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            try
            {
                if (!is_post)
                {
                    result.htmlResponse = "403";
                    return result;
                }

                var session = await getUserSessionAsync(Cookies);

                if (session == null)
                {
                    result.htmlResponse = href("auth");
                    return result;
                }

                var userid = session.user_id;

                if (!args.ContainsKey("id"))
                {
                    result.htmlResponse = GenerateError("no args passed");
                    return result;
                }

                long id = 0;
                try
                {
                    id = long.Parse(args["id"]);
                }
                catch
                {
                    id = 0;
                }

                //if (id != 123)
                //{
                   // result.htmlResponse = GenerateError("no id passed");
                    //return result;
                //}

                if (id != userid)
                {
                    result.htmlResponse = GenerateError("no id passed");
                    return result;
                }

                vk Vk = new(cache);

                string text = "";
                int settype = 1;

                var userName = await Vk.UserGetNameUrls(new long[] { userid });

                text = userName[userid.ToString()] + " обнулил свой аккаунт через панель управления.";
                var account = Db.usersGetUser(userid);

                if (account == null)
                {
                    result.htmlResponse = GenerateError("no account find");
                    return result;
                }

                Db.logsAddLog(0, Database.logsId.USER_DELETEACCOUNT, Vk.m_from_id, 0, "обнулил свой аккаунт", account["rubs"], account["euros"]);

                //Db.peersSetExitRemoveNick(id, settype);
                Db.gameSetUserRub(userid, "0");
                Db.gameSetUserEuros(userid, "0");
                Db.DbDelete(new Dictionary<string, object>() { { "user_id", userid } }, "property");
                Db.usersGetUser(userid, true);
                Db.propertyGetUser(userid, true);

                Vk.MessagesSend(text, 0, userid);

                var res = GenerateSuccessfull("ok");
                result.htmlResponse = res;

                return result;
            }
            catch
            {
                result.htmlResponse = GenerateError("undefined exception error");
                return result;
            }
        }
    }
}
