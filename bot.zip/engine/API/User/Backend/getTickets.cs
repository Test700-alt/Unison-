﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class getTickets : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "getTickets",

                nameOfClass = "GrandManager.engine.API.Method.getTickets",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public AnswerTemplane work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            if (!is_post)
            {
                result.htmlResponse = "403";
                return result;
            }

            if (args.ContainsKey("type") && args["type"] == "answered")
            {
                //var peer1 = new { id = "1", title = "тестовый вопрос", creationDate = "23122" };
                //var peer2 = new { id = "2", title = "текстоваыыыы ыыы ", creationDate = "23авв122" };
                var res = GenerateSuccessfull();
                result.htmlResponse = res;
            }
            else
            {
                var res = GenerateSuccessfull();
                result.htmlResponse = res;
            }
            
            

            return result;
        }
    }
}
