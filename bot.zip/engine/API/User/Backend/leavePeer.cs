﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class leavePeer : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "leavepeer",

                nameOfClass = "GrandManager.engine.API.Method.leavePeer",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            if (!is_post)
            {
                result.htmlResponse = "403";
                return result;
            }

            var session = await getUserSessionAsync(Cookies);

            if (session == null)
            {
                result.htmlResponse = GenerateError("Not session");
                return result;
            }

            if (!args.ContainsKey("id"))
            {
                result.htmlResponse = GenerateError("Not PEERID");
                return result;
            }

            long peer_id = 0;
            try { peer_id = long.Parse(args["id"]); } catch { peer_id = 0; }

            if (peer_id == 0)
            {
                result.htmlResponse = GenerateError("Not PEERID 2");
                return result;
            }
            
            var peerMemberInfo = Db.peersGetMember(peer_id, session.user_id, false, true);
            if (peerMemberInfo == null)
            {
                result.htmlResponse = GenerateError("Not peerMemberInfo");
                return result;
            }

            vk Vk = new vk(cache);

            var nicknameUser = await Vk.UserGetNameUrls(new long[] { session.user_id });

            var idMessage = await Vk.MessagesSendMassive($"{nicknameUser[session.user_id.ToString()]} решил выйти из беседы с помощью сайта.", new List<long> { peer_id });

            var resKick = await Vk.KickUser(peer_id, session.user_id);
            if (resKick == null || resKick["error"] != null)
            {
                await Vk.MessagesEdit($"{nicknameUser[session.user_id.ToString()]} решил выйти из беседы с помощью сайта, но произошла ошибка при попытке исключить его.", peer_id, "", true, "", idMessage);
                result.htmlResponse = GenerateError("Error VK API");
                return result;
            }


            Db.peersMemberSetLeavePeer(peer_id, session.user_id, "1");
            result.htmlResponse = GenerateSuccessfull(new { ok = true });

            return result;
        }
    }
}
