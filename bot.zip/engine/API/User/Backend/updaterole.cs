﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class updaterole : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "updaterole",

                nameOfClass = "GrandManager.engine.API.Method.updaterole",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            if (!is_post)
            {
                result.htmlResponse = "403";
                return result;
            }

            var session = await getUserSessionAsync(Cookies);

            if (session == null)
            {
                result.htmlResponse = GenerateError("Not session");
                return result;
            }

            if (!args.ContainsKey("id"))
            {
                result.htmlResponse = GenerateError("Not PEERID");
                return result;
            }

            long peer_id = 0;
            try { peer_id = long.Parse(args["id"]); } catch { peer_id = 0; }

            if (peer_id == 0)
            {
                result.htmlResponse = GenerateError("Not PEERID 2");
                return result;
            }

            if (!args.ContainsKey("role"))
            {
                result.htmlResponse = GenerateError("Not role");
                return result;
            }

            long role_id = 0;
            try { role_id = long.Parse(args["role"]); } catch { peer_id = 0; }

            if (role_id < 0 || role_id > 100)
            {
                result.htmlResponse = GenerateError("Not role 2");
                return result;
            }

            if (!args.ContainsKey("name"))
            {
                result.htmlResponse = GenerateError("Not new name");
                return result;
            }

            string name = args["name"];

            var peerInfo = Db.peersGetPeer(peer_id);
            if (peerInfo == null)
            {
                result.htmlResponse = GenerateError("peerInfo is NULL");
                return result;
            }

            var peerMember = Db.peersGetMember(peer_id, session.user_id, false, false);
            if (peerMember == null)
            {
                result.htmlResponse = GenerateError("403 forbidden");
                return result;
            }

            if (int.Parse(peerMember["priority"]) < 80)
            {
                result.htmlResponse = GenerateError("403 forbidden — role not 80");
                return result;
            }

            vk Vk = new vk(cache);

            var nicknameUser = await Vk.UserGetNameUrls(new long[] { session.user_id });

            var roles = Db.peerGetRoles(peer_id, true);
            string oldName = "";

            if (roles.ContainsKey(role_id.ToString()))
            {
                oldName = "Предыдущее название: " + roles[role_id.ToString()].name + "<br>";
            }

            string text = $"{nicknameUser[session.user_id.ToString()]} через панель управления изменил роль с приоритетом '{role_id}'.<br>{oldName}" +
                $"Новое название: {name}";

            Vk.MessagesSend(text, 0, peer_id);

            if (roles.ContainsKey(role_id.ToString()))
            {
                Db.rolesSetName(peer_id, role_id, name, session.user_id);
            }
            else
            {
                Db.rolesAddName(peer_id, role_id, name, session.user_id);
            }



            result.htmlResponse = GenerateSuccessfull(new { name = name, dateCreate = DateTimeOffset.Now.ToString("d") });

            return result;
        }
    }
}
