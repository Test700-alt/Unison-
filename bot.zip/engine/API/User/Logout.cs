﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace GrandManager.engine.API.Method
{
    internal class Logout : Templane
    {
        public void preloader()
        {
            ApiInfo commandInfo = new ApiInfo()
            {
                name = "logout",

                nameOfClass = "GrandManager.engine.API.Method.Logout",
                nameOfMethod = "work",

                is_admin = false,
            };

            LoaderAPI.listOfAllMethods.Add(commandInfo);
        }

        public async Task<AnswerTemplane> work(Cache cache, Database Db, Dictionary<string, string> args, Dictionary<string, string> Cookies, bool is_post, string ip)
        {
            var session = await getUserSessionAsync(Cookies);

            if (session != null)
            {
                SessionManager.RemoveSession(session.SessionId);
                result.RemoveCookies["session-id"] = "1";
                result.htmlResponse = href("auth");
            }
            else
            {
                result.htmlResponse = href("auth");
            }
            

            return result;
        }
    }
}
