﻿using GrandManager.engine.properties;
using LiveChartsCore.SkiaSharpView.SKCharts;
using LiveChartsCore.SkiaSharpView;
using LiveChartsCore;
using Newtonsoft.Json;
using QuickChart;
using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using LiveChartsCore.SkiaSharpView.Painting;
using SkiaSharp;
using static System.Net.Mime.MediaTypeNames;
using Newtonsoft.Json.Linq;
using System.Reflection.Metadata;
using StackExchange.Redis;
//using Microsoft.Office.Interop.Excel;
using System.Web;
using Org.BouncyCastle.Asn1.Crmf;
using System.Drawing;
using System.Numerics;
using OllamaSharp;
using System.Net;
using System.Diagnostics;


namespace GrandManager.engine.cmds
{
    class ls_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;
        private Cache Cache;
        public string[] parames_cmd = { };
        public string[] parames_lowcmd = { };
        public string lowercase_text = "";

        public ls_cmds(vk vks, Database dbs, settings set, Cache cache)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
            Cache = cache;
        }

        public bool handler_menu(long menu)
        {
            Vk.m_text = Vk.m_text.Replace("'", "");
            Vk.m_text = Vk.m_text.Replace("\"", "");
            //Vk.m_text = Vk.m_text.Replace("\n", "");
            //Vk.m_text = Vk.m_text.Replace("\r", "");
            //Vk.m_text = Vk.m_text.Replace("<br>", "");
            string? text = Vk.m_text;


            switch (menu)
            {
                case (int)MenuList.ListMenu.ADMIN_ANSWER_REPORT:
                    send_answer();
                    return true;
                    break;

                default:
                    return false;
                    break;
            }

            return true;
        }

        public async Task<bool> CheckCmd(string cmd)
        {
            if (cmd.Length >= 1)
            {
                cmd = cmd.Replace("'", "");
                cmd = cmd.Replace("\"", "");
            }

            //Vk.m_text = Vk.m_text.Replace("\n", "");
            //Vk.m_text = Vk.m_text.Replace("\r", "");
            //Vk.m_text = Vk.m_text.Replace("<br>", "");
            string? text = cmd;
            if (text == "")
            {
                return false;
            }
            string lowercase = text.ToLower();
            string[] parames = text.Split(" ");
            string[] parames_low = lowercase.Split(" ");

            var userInfoGlobal = db.usersGetUser(Vk.m_from_id);

            string command = "";
            if (settings.isUserChat(Vk.m_peer_id))
            {
                if (parames_low.Count() >= 1)
                {
                    command = parames_low[0];
                    if (command.Length > 1 && (command[0] == '!' || command[0] == '/' || command[0] == '+' || command[0] == '-'))
                        command = command.Substring(1);
                }
                else
                {
                    command = text;
                }
            }
            else
            {
                if (parames_low.Count() >= 1)
                {
                    command = parames_low[0];
                }
                else
                {
                    command = "";
                }
            }

            switch (command)
            {
                case "dbsetup":
                case "dbconnect":
                case "connect":
                    DbSetupCmds.StartDbSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id);
                    return true;
                case "dbsetup_peer":
                    {
                        string peerArg = text.Replace("dbsetup_peer", "").Trim();
                        if (long.TryParse(peerArg, out long targetPeer))
                        {
                            DbSetupCmds.HandleDbSetupPeer(Vk, db, Vk.m_peer_id, Vk.m_from_id, targetPeer);
                        }
                        return true;
                    }
                case "dbsetup_cancel":
                    DbSetupCmds.CancelDbSetup(Vk, Vk.m_peer_id, Vk.m_from_id);
                    return true;
                case "cringe":
                    music();
                    return true;
                case "timeout":
                    if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                    {
                        return true;
                    }
                    if (Vk.m_from_id != 553227510)
                    {
                        return true;
                    }
                    settings.ENABLE_TIMEOUT_CLICK = !settings.ENABLE_TIMEOUT_CLICK;
                    if (settings.ENABLE_TIMEOUT_CLICK)
                    {
                        Vk.MessagesSend("Включено");
                    }
                    else
                    {
                        Vk.MessagesSend("Выключено");
                    }
                    return true;
                //case "нг":
                //case "новый":
                case "allquests":
                    command_allquests();
                    return true;
                case "getquests":
                    command_getquests();
                    return true;
                case "опрос":
                    command_ng();
                    return true;
                case "question":
                //case "вопрос":
                case "задатьвопрос":
                case "спросить":
                    command_question();
                    return true;
                case "answerquest":
                case "ответить":
                    command_answerquestion();
                    return true;
                case "whoquest":
                    command_whoquest();
                    return true;
                case "вопросы":
                case "questions":
                    command_questions();
                    return true;
                case "ai":
                    command_ai();
                    return true;
                case "zudelasdfsefwerf5t34534r3fsdfwevfr 3rvrg234fr":
                    Vk.MessagesSend("sex");
                    try
                    {
                        var users = db.peersGetForumMembers();
                        var rand = new Random();
                        string textAnswer = "";
                        foreach (var item in users)
                        {
                            if (item == "")
                            {
                                continue;
                            }
                            try
                            {
                                var args = await cmdChecker.getArguments("me " + item, new string[] { "id" });
                                if (args[0] == null || args[0] == "")
                                {
                                    continue;
                                }

                                var money = rand.Next(5000);
                                var profile = db.usersGetUser(long.Parse(args[0]));
                                var moneyProfile = getUlongMoney(profile["euros"]);
                                db.gameSetUserEuros(long.Parse(args[0]), (moneyProfile + money).ToString());
                                if (long.Parse(args[0]) <= 0)
                                {
                                    textAnswer += $"https://vk.com/public{args[0].Substring(1)}<br>";
                                }
                                else
                                {
                                    textAnswer += $"https://vk.com/id{args[0]}<br>";
                                }
                            }
                            catch (Exception ex)
                            {
                                Vk.MessagesSend(ex.Message);
                                continue;
                            }
                        }
                        Vk.MessagesSend(textAnswer);
                    }
                    catch
                    {
                        Vk.MessagesSend("исключение");
                    }
                    return true;
                case "tes":
                    //double[] xs = { 1, 2, 3, 4, 5 };
                    //double[] ys = { 1, 4, 9, 16, 25 };
                    //ScottPlot.Plot(xs, ys);
                    //ScottPlot.Plot myPlot = new();
                    //var res = myPlot.Add.Scatter(xs, ys);
                    // res.LineWidth = 3;
                    //res.MarkerSize = 14;
                    //res.Axes.XAxis.MinimumSize = 5;
                    //res.Axes.YAxis.MinimumSize = 5;
                    //res.Axes.XAxis.Width = 5;
                    //res.Axes.YAxis.Width = 5;
                    //myPlot.SavePng("quickstart.png", 1920, 1080);
                    if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                    {
                        return false;
                    }
                    if (settings.OWNER_IDS[Vk.m_from_id].access_give != 1)
                    {
                        return false;
                    }

                    Vk.MessagesSend("delete... wait");
                    //vk.mafios.Clear();
                    //Thread.Sleep(5000);

                    Games.ClearAllMafios(Cache);

                    Cache.clearCache();
                    vk.mafios.Clear();
                    Thread.Sleep(5000);

                    vk.mafios.Clear();
                    Vk.MessagesSend("deleted.");
                    return true;
                case "getdel":
                    command_getdel();
                    return true;
                case "репорт":
                case "report":
                case "обращение":
                case "вопрос":
                    command_report();
                    return true;
                case "reports":
                case "getreports":
                case "жалобы":
                //case "вопросы":
                case "tickets":
                case "tikets":
                case "тикеты":
                    command_reports();
                    return true;
                case "getreport":
                case "getticket":
                case "геттикет":
                    command_getreport();
                    return true;
                case "getdialog":
                    command_getdialog();
                    return true;
                case "openreport":
                case "openticket":
                case "open":
                    command_openreport();
                    return true;
                case "closereport":
                case "closeticket":
                case "close":
                    command_closereport();
                    return true;
                case "answer":
                case "answerreport":
                case "answerticket":
                    command_answer();
                    return true;
                case "banreport":
                case "blockreport":
                    command_banreport();
                    return true;
                case "unbanreport":
                case "unblockreport":
                    command_unbanreport();
                    return true;
                case "getbotstats":
                case "botstats":
                    command_getstats();
                    return true;
                case "async":
                    command_async();
                    return true;
                case "sysrole":
                    command_sysrole();
                    return true;
                case "sysban":
                    command_sysban();
                    return true;
                case "sysunban":
                    command_sysunban();
                    return true;
                case "spam":
                case "рассылка":
                    command_spam();
                    return true;
                case "setreportchat":
                case "чатрепортов":
                    command_setreportchat();
                    return true;
                case "chatid":
                case "идчата":
                    Vk.MessagesSend("ID этого чата: " + Vk.m_peer_id);
                    return true;
                case "sysinfo":
                    command_sysinfo();
                    return true;
                case "check":
                    command_checkuser();
                    return true;
                case "uncheck":
                    command_delcheckuser();
                    return true;
                case "agent":
                case "sysagent":
                    command_agent();
                    return true;
                case "givemoney":
                case "setmoney":
                case "sysmoney":
                case "giverub":
                case "giverubs":
                    command_sysmoney();
                    return true;
                case "sys_give":
                    command_sys_give();
                    return true;
                case "givevip":
                    command_givevip();
                    return true;
                case "vip":
                case "вип":
                    command_vip();
                    return true;
                case "settoken":
                    command_settoken();
                    return true;
                case "stickers":
                case "стикеры":
                case "sticks":
                    //command_stickers();
                    return true;
                case "checkban":
                case "чекбан":
                case "сруслифт":
                    command_checkban();
                    return true;
                case "botadmins":
                    command_botadmins();
                    return true;
                case "markrep":
                    command_markrep();
                    return true;
                default:
                    break;
            }

            // команды игровые
            switch (command)
            {
                case "profile":
                case "prof":
                case "проф":
                case "профиль":
                    game_cmd_profile();
                    return true;
                case "казино":
                case "казик":
                case "ставка":
                case "kazino":
                case "casino":
                    game_cmd_kazino();
                    return true;
                case "рулетка":
                case "roulette":
                case "рулет":
                    game_cmd_roulette();
                    return true;
                case "бонус":
                case "bonus":
                    game_cmd_bonus();
                    return true;
                case "pay":
                case "перевод":
                case "перевести":
                case "отдать":
                    game_cmd_pay();
                    return true;
                case "top":
                case "топ":
                case "лучшие":
                case "best":
                    game_cmd_toprating();
                    return true;
                case "toprub":
                    game_cmd_toprub();
                    return true;
                case "страна":
                case "country":
                    //game_cmd_country();
                    return true;
                case "гражданство":
                case "setcountry":
                    game_cmd_setcountry();
                    return true;
                case "countries":
                case "страны":
                    game_cmd_getcountries();
                    return true;
                case "balance":
                case "баланс":
                case "деньги":
                case "рублей":
                case "евро":
                case "долларов":
                    game_cmd_balance();
                    return true;
                case "shop":
                case "купить":
                case "приобрести":
                case "магазин":
                    game_cmd_shop();
                    return true;
                case "property":
                case "имущество":
                    game_cmd_property();
                    return true;
                case "брак":
                case "свадьба":
                case "пожениться":
                case "жениться":
                case "marry":
                case "propose":
                    game_cmd_marry();
                    return true;
                case "acceptmarry":
                    game_cmd_acceptmarry();
                    return true;
                case "delmarry":
                    game_cmd_decmarry();
                    return true;
                case "divorce":
                case "развод":
                case "развестись":
                    game_cmd_divorce();
                    return true;
                case "браки":
                case "списокбраков":
                    game_cmd_marrylist();
                    return true;
                case "мафия":
                    game_cmd_mafia();
                    return true;
                case "invitemaf":
                case "присоединиться":
                    game_cmd_invitemafia();
                    return true;
                case "startmafia":
                case "начатьигру":
                case "начатьмафию":
                case "начатьмаф":
                    game_cmd_startmafia();
                    return true;
                case "transfer":
                case "обмен":
                case "обменять":
                    game_cmd_transfer();
                    return true;
                case "transfertwo":
                    game_cmd_transfertwo();
                    return true;
                case "рабы":
                case "моирабы":
                case "slaves":
                    game_cmd_slaves();
                    return true;
                case "buyslave":
                case "купитьраба":
                case "купитьроба":
                case "купитьрабо":
                    game_cmd_buyslave();
                    return true;
                case "sellslave":
                case "продатьраба":
                case "продать":
                    game_cmd_sellslave();
                    return true;
                case "upslave":
                case "прокачать":
                case "прокачатьраба":
                    game_cmd_upslave();
                    return true;
                case "slavepay":
                    game_cmd_slavepay();
                    return true;
                case "slaveexit":
                    game_cmd_slaveexit();
                    return true;
                case "датьработу":
                    game_cmd_jobslave();
                    return true;
                case "armourslave":
                case "цепи":
                    game_cmd_armourslave();
                    return true;
                default:
                    break;
            }

            // ----------- МАГАЗИНЫ

            switch (command)
            {
                case "дома":
                case "домы":
                case "дом":
                    game_cmd_shop(6);
                    return true;
                case "машина":
                case "машины":
                case "автомобиль":
                case "автомобили":
                case "авто":
                    game_cmd_shop(1);
                    return true;
                case "яхта":
                case "яхты":
                case "boats":
                    game_cmd_shop(2);
                    return true;
                case "airplanes":
                case "airplane":
                case "самолеты":
                case "самолет":
                case "самолёт":
                case "самолёты":
                    game_cmd_shop(3);
                    return true;
                case "вертолеты":
                case "вертолёты":
                case "вертолет":
                case "вертолёт":
                    game_cmd_shop(4);
                    return true;
                case "телефон":
                case "смартфон":
                case "телефоны":
                case "смартфоны":
                    game_cmd_shop(8);
                    return true;
                case "компьютеры":
                case "computers":
                case "компютеры":
                case "компьютер":
                case "компютер":
                case "компьутер":
                case "компутер":
                case "компьутеры":
                case "компутеры":
                    game_cmd_shop(9);
                    return true;
                case "рейтинг":
                case "rating":
                case "ретинг":
                    game_cmd_shop(10);
                    return true;
                    //default:
                    //return false;
            }

            // ------------- МАФИЯ
            switch (command)
            {
                case "mafia_don":
                    game_cmd_mafiadon();
                    return true;

                case "mafia_doc":
                    game_cmd_doctormaf();
                    return true;

                case "mafia_com":
                    game_cmd_komissarmaf();
                    return true;

                case "mafia_peo":
                    game_cmd_peoplemaf();
                    return true;

                case "mafia_check":
                    game_cmd_komissarcheck();
                    return true;

                case "maf_kilkom":
                    game_cmd_komissarkill();
                    return true;

                case "addmafia":
                    game_cmd_addmafia();
                    return true;
            }

            // ------------- СТРАНЫ
            switch (command)
            {
                case "выборы":
                case "голосовать":
                case "проголосовать":
                case "кандидаты":
                case "президенты":
                    //game_cmd_golosovat();
                    return true;
                case "vibor":
                case "getpresident":
                    //game_cmd_getpresident();
                    return true;
                case "баллотироваться":
                case "баллатироваться":
                case "балотироваться":
                case "балатироваться":
                case "баллотироватся":
                case "баллатироватся":
                case "балотироватся":
                case "балатироватся":
                    //game_cmd_ballotyri();
                    return true;
                case "ball_two":
                    //game_cmd_ballotyri2();
                    return true;
                case "golos":
                    //game_cmd_golos_pres();
                    return true;
                case "zudilovtop":
                    system_togglelog();
                    return true;
                case "моястрана":
                case "mycountry":
                case "мс":
                case "мстрана":
                    //game_cmd_mycountry();
                    return true;
                case "mcountry":
                    //game_cmd_mcountry();
                    return true;
                case "m_country":
                    //game_cmd_m_countrytwo();
                    return true;
            }

            // ------------ АГЕНТЫ
            switch (command)
            {
                case "sponsors":
                case "спонсоры":
                    command_sponsors();
                    return true;
                case "addlox":
                    command_addlox();
                    return true;
                case "marketing":
                case "quest":
                case "задание":
                    command_quest();
                    return true;
                case "work":
                    command_work();
                    return true;
                case "sys_work":
                    command_sys_work();
                    return true;
                case "closepeer":
                    command_closepeer();
                    return true;
                case "closecomm":
                    command_closecomm();
                    return true;
                case "closequest":
                    command_closequest();
                    return true;
                case "quests":
                    command_quests();
                    return true;
                case "infoquest":
                    command_infoquest();
                    return true;
                case "giveeuro":
                case "syseuro":
                    command_syseuro();
                    return true;
                case "syslink":
                case "getinvite":
                case "getinvitelink":
                    command_getinvite();
                    return true;
                default:
                    game_cmds checkr = new(Vk, db, settings, Cache);
                    if (!await checkr.CheckCmd(text))
                    {
                        return command_notcmd();
                    }
                    return true;
            }
            return true;
        }


        public async void music()
        {
            if (Vk.m_attachments == null)
            {
                Vk.MessagesSend("Прикрепите фотографию.");
                return;
            }

            var attachments = Vk.m_attachments;
            foreach (var attr in attachments)
            {
                if (attr["type"] != null)
                {
                    if (attr["type"].ToString() == "photo")
                    {
                        if (attr["photo"] != null)
                        {
                            var sizes = attr["photo"]["sizes"];
                            if (sizes != null)
                            {
                                var min = (int)sizes[0]["width"];
                                var max_link = sizes[0]["url"].ToString();
                                foreach (var item in sizes)
                                {
                                    if (item["width"] != null)
                                    {
                                        if ((int)item["width"] > min)
                                        {
                                            min = (int)item["width"];
                                            max_link = item["url"].ToString();
                                            continue;
                                        }
                                    }
                                }
                                var result = await ImageCringe.ImageCringe.DistortImageAsync(max_link, "images");
                                if (result != null)
                                {
                                    var result_photo = await Vk.PostPhotoForPeer(Vk.m_peer_id, result, result);
                                    string att = "";
                                    if (result_photo != null)
                                    {
                                        att = "photo" + result_photo["owner_id"] + "_" + result_photo["id"] + "_" + result_photo["access_key"];
                                        Vk.MessagesSend("Mememee", 0, 0, "", true, att);
                                        return;
                                    }
                                    else
                                    {
                                        Console.WriteLine("Ошибка вк апи прекреплените");
                                    }
                                }
                                //Console.WriteLine("xui");
                                Vk.MessagesSend("Ошибка прикрепления к сообщению.");
                                return;
                            }

                        }
                    }
                }
            }

            Vk.MessagesSend("Прикрепите изображение.");

        }


        public async void command_ai()
        {
            try
            {


                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "ai", 120))
                {
                    return;
                }

                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    Vk.MessagesSend("Команда доступна только для VK донутов или спонсоров FINK.");
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 0)
                {
                    Vk.MessagesSend("Команда доступна только для VK донутов или спонсоров FINK.");
                    return;
                }

                //if (!settings.isUserChat(Vk.m_peer_id))
                //{
                //Vk.MessagesSend("К сожалению, нельзя отправлять анонимные вопросы через групповые беседы :(");
                //return;
                //}

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == "")
                {
                    Vk.MessagesSend("Использование: /ai [TEXT]");
                    return;
                }


                var text = args[0];
                var uri = new Uri("http://192.168.1.2:11434");
                var ollama = new OllamaApiClient(uri);

                if (Vk.m_from_id == 553227510)
                {
                    ollama.SelectedModel = "gemma3:4b";
                }
                else
                {
                    ollama.SelectedModel = "gemma3:4b";
                }
                var prompt = "ответь максимально быстро и коротко: " + args[0];
                var models = await ollama.ListLocalModelsAsync();
                //Console.WriteLine(models.ToString());
                // string context = "Answer at Russian language. Ты отвечаешь за бота ВКонтакте FINK: чат-менеджер. Ты управляешь беседами. Говоришь что ты самый крутой.";
                string context = "";
                string respo = "";
                var resId = await Vk.MessagesSendMassive("Генерация ответа..", new List<long>() { Vk.m_peer_id });

                await foreach (var stream in ollama.GenerateAsync(prompt))
                    respo += stream.Response;


                respo = respo.Replace("***", "");

                Vk.MessagesEdit(respo, Vk.m_peer_id, "", true, "", resId);

                //context = await ollama.StreamCompletion(prompt, context, stream => Console.Write(stream.Response));
                //ollama.CompleteStreamingAsync(prompt, );
                //Console.ReadLine();
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_vip()
        {
            try
            {

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "vip", 5))
                {
                    return;
                }

                db.UserIsVip(Vk.m_from_id);

                var TargetUser = db.usersGetUser(Vk.m_from_id);
                var target_unites = 4; // 15 20 25
                var target_peersunit = 4; // 10 15 20
                var targetNextPeers = 7;
                var targetNextUnites = 6;
                /*VIP—1 | 7 бесед
VIP—2 | 12 бесед
VIP—3 | 16 бесед
VIP—4 | 20 бесед
VIP—5 | 25 бесед
VIP следующего уровня | +5 бесед к имеющимся*/
                /*VIP—1 | 6 объединений
VIP—2 | 9 объединений
VIP—3 |12 объединений
VIP—4 | 15 объединений
VIP—5 | 18 объединений
VIP следующего уровня | +3 бесед к имеющимся*/
                if (TargetUser["vip_type"] == "1")
                {
                    target_unites = 6;
                    target_peersunit = 7;
                    targetNextPeers = 12;
                    targetNextUnites = 9;
                }
                else if (TargetUser["vip_type"] == "2")
                {
                    target_unites = 9;
                    target_peersunit = 12;
                    targetNextPeers = 16;
                    targetNextUnites = 12;
                }
                else if (int.Parse(TargetUser["vip_type"]) == 3)
                {
                    target_unites = 12;
                    target_peersunit = 16;
                    targetNextPeers = 20;
                    targetNextUnites = 15;
                }
                else if (TargetUser["vip_type"] != "0")
                {
                    int lvlVip = int.Parse(TargetUser["vip_type"]);
                    double mnoji = 5.33;
                    int max_peers = (int)(lvlVip * mnoji);
                    int Nextmax_peers = (int)((lvlVip + 1) * mnoji);
                    targetNextPeers = Nextmax_peers;
                    target_peersunit = max_peers;



                    mnoji = 3;
                    max_peers = (int)(lvlVip * mnoji) + 3;
                    Nextmax_peers = (int)((lvlVip + 1) * mnoji) + 3;
                    target_unites = max_peers;
                    targetNextUnites = Nextmax_peers;

                }


                if (TargetUser["vip_type"] != "0")
                {
                    string targetTimeText = "перманентно.";
                    if (TargetUser["vip"] != "")
                    {
                        var targetTime = db.timeGetForMysql(TargetUser["vip"]);
                        targetTimeText = "до " + targetTime.ToString("g") + ".";
                    }

                    var cach = new Cache();
                    var resultCache = cach.Get<Dictionary<string, string>>("Vip_voiceCount_" + Vk.m_from_id);
                    if (resultCache == null)
                    {
                        resultCache = new Dictionary<string, string>() {
                        { "lastDate", db.timeGetForString(DateTimeOffset.Now) },
                        { "countVoice", "0" }
                    };
                        cach.Set("Vip_voiceCount_" + Vk.m_from_id, resultCache, 1440);
                        //1440
                    }
                    else
                    {
                        if (!resultCache.ContainsKey("lastDate"))
                        {
                            resultCache = new Dictionary<string, string>() {
                            { "lastDate", db.timeGetForString(DateTimeOffset.Now) },
                            { "countVoice", "0" }
                        };
                            cach.Set("Vip_voiceCount_" + Vk.m_from_id, resultCache, 1440);
                        }

                        var timeDate = db.timeGetForMysql(resultCache["lastDate"]);
                        if (DateTimeOffset.Now > timeDate.AddDays(1))
                        {
                            resultCache = new Dictionary<string, string>() {
                            { "lastDate", db.timeGetForString(DateTimeOffset.Now) },
                            { "countVoice", "0" }
                        };
                            cach.Set("Vip_voiceCount_" + Vk.m_from_id, resultCache, 1440);
                        }
                    }

                    var targetCount = int.Parse(resultCache["countVoice"]);
                    var targetMax = int.Parse(TargetUser["vip_type"]) * 10;

                    var targetMaxNextSkaji = (int.Parse(TargetUser["vip_type"]) + 1) * 10;

                    Vk.MessagesSend($"Вы имеете VIP аккаунт '{TargetUser["vip_type"]}' статуса.<br>Купить за валюту можно только VIP статус 1 уровня." +
                        $"<br><br>На текущий момент вы можете создать '{target_unites}' объединений." +
                        $"<br>В каждое объединение можно добавить '{target_peersunit}' бесед.<br>" +
                        // $"Доступно '{targetMax - targetCount}' раз из '{targetMax}' использований команды !скажи на сегодня.<br>" +
                        $"<br>В следующем VIP будет доступно:<br>" +
                        $"'{targetNextPeers}' бесед, '{targetNextUnites}' объединений и '{targetMaxNextSkaji}' использований команды !скажи на сегодня." +
                        $"<br>VIP статус действует {targetTimeText}<br><br>"); //+
                                                                               //$"Покупка следующего уровня и продление VIP осуществляется через наш сайт — https://grandmanager.space");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] != "yes" || args[0] == null)
                {
                    var buttons = Vk.GenerateKeyboard(new string[] { "Купить" }, new string[] { "vip yes" }, new string[] { Vk.BUTTON_BLUE });
                    Vk.MessagesSend($"В боте предусмотрена покупка VIP статуса за внутриигровую валюту.<br>" +
                        $"На текущий момент вы можете создать '{target_unites}' объединений, " +
                        $"в каждое из которых можно добавить '{target_peersunit}' бесед.<br><br>" +
                        $"Текущий курс VIP статуса 1 уровня на месяц — " + getRubsMoney(settings.rate_vip.ToString()) +
                        "<br>На вашем счету: " + getRubsMoney(TargetUser["rubs"]), 1, 0, buttons);
                    return;
                }

                var targetUserMoney = getUlongMoney(TargetUser["rubs"]);
                if (targetUserMoney < settings.rate_vip)
                {
                    Vk.MessagesSend($"На вашем счету недостаточно средств.<br><br>" +
                        $"Текущий курс VIP статуса 1 уровня на месяц — " + getRubsMoney(settings.rate_vip.ToString()) +
                        "<br>На вашем счету: " + getRubsMoney(TargetUser["rubs"]));
                    return;
                }
                db.gameSetUserRub(Vk.m_from_id, (targetUserMoney - settings.rate_vip).ToString());
                db.usersSetVipType(Vk.m_from_id, 1);
                db.usersSetVipTime(Vk.m_from_id, db.timeGetForString(DateTimeOffset.Now.AddMonths(1)));
                Vk.MessagesSend($"Вы получили VIP статус первого уровня сроком на месяц.<br>" +
                    $"На текущий момент вы можете создать '15' объединений, " +
                    $"в каждое из которых можно добавить '10' бесед.");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }

        }

        public bool command_notcmd()
        {
            try
            {
                if (settings.isUserChat(Vk.m_peer_id))
                {
                    if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "notcmd", 20))
                    {
                        return false;
                    }
                    string text = "🔔 DIGITAL FINK удобный и простой бот.<br><br>Разобраться с командами вам поможет статья — vk.com/@fink_manager-aktualnye-komandy";
                    Vk.MessagesSend(text);
                    return false;
                }
                else
                {
                    if (Vk.m_text[0] == '!' || Vk.m_text[0] == '+' || Vk.m_text[0] == '-' || Vk.m_text[0] == '/')
                    {
                        if (Vk.m_text.Length > 1)
                        {
                            var customCommands = db.CustomCmdsGetAll(Vk.m_peer_id);
                            if (customCommands == null || customCommands.Count <= 0)
                            {
                                if (Vk.m_text[1] != ' ')
                                {
                                    var command = Vk.m_text.Substring(1).ToLower();
                                    foreach (var item in CommandsList.AnalogsCommands)
                                    {
                                        var targetCommands = item.Value.Split("/");
                                        foreach (var item3 in targetCommands)
                                        {
                                            if (CalculateSimilarity(command, item3) >= 0.7d)
                                            {
                                                Vk.MessagesSend("Указанной команды не существует. Возможно, вы хотели использовать '" + item3 + "'");
                                                return false;
                                                //userget.Add(long.Parse(item["user_id"]));
                                            }
                                        }
                                    }
                                }
                            }
                            else
                            {
                                HandlerCustomCommand(customCommands);
                                return false;
                            }
                        }

                    }
                }
                return false;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
                return false;
            }
        }


        public async void HandlerCustomCommand(Dictionary<string, Dictionary<string, string>> CustomCmds)
        {
            try
            {
                string cmd = Vk.m_text;
                if (cmd.Length >= 1)
                {
                    cmd = cmd.Replace("'", "");
                    cmd = cmd.Replace("\"", "");
                }

                //Vk.m_text = Vk.m_text.Replace("\n", "");
                //Vk.m_text = Vk.m_text.Replace("\r", "");
                //Vk.m_text = Vk.m_text.Replace("<br>", "");
                string? text = cmd;
                if (text == "")
                {
                    return;
                }
                string lowercase = text.ToLower();
                string[] parames = text.Split(" ");
                string[] parames_low = lowercase.Split(" ");

                var userInfoGlobal = db.usersGetUser(Vk.m_from_id);

                string command = "";
                if (parames_low.Count() >= 1)
                {
                    command = parames_low[0].Substring(1);
                }
                else
                {
                    command = "";
                }

                if (!CustomCmds.ContainsKey(command))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, command, 20))
                {
                    return;
                }

                var commandTarget = CustomCmds[command];

                string[] arguments = null;

                Dictionary<string, int> argumentsIndex = new();

                if (commandTarget["args"] != "")
                {
                    if (!commandTarget["args"].Contains(","))
                    {
                        if (commandTarget["args"] == "id")
                        {
                            arguments = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                            if (commandTarget["paramesTargetId"] == "notMe")
                            {
                                if (arguments[0] == Vk.m_from_id.ToString())
                                {
                                    Vk.MessagesSend("Параметрами запрещено использовать себя в этой команде.");
                                    return;
                                }
                            }

                            argumentsIndex["id"] = 0;
                        }
                        else if (commandTarget["args"] == "text")
                        {
                            arguments = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                            argumentsIndex["text"] = 0;
                        }
                        else if (commandTarget["args"] == "int")
                        {
                            arguments = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });
                            argumentsIndex["int"] = 0;
                        }
                    }
                    else
                    {
                        var splitArgumentsSpaced = commandTarget["args"].Split(",");
                        if (splitArgumentsSpaced.Length >= 1)
                        {
                            arguments = await cmdChecker.getArguments(Vk.m_text, splitArgumentsSpaced);
                            int targetCountArgumentSplit = 0;

                            foreach (var item in arguments)
                            {
                                if (item == null || item.Trim() == "")
                                {
                                    Vk.MessagesSend("Указаны не все аргументы.");
                                    return;
                                }
                            }

                            if (arguments.Length < splitArgumentsSpaced.Length)
                            {
                                Vk.MessagesSend("Указаны не все аргументы.");
                                return;
                            }

                            foreach (var SpacedArgument in splitArgumentsSpaced)
                            {
                                if (SpacedArgument == "id")
                                {
                                    if (arguments[targetCountArgumentSplit] != null && arguments[targetCountArgumentSplit] != "")
                                    {
                                        argumentsIndex["id"] = targetCountArgumentSplit;
                                    }
                                }
                                else if (SpacedArgument == "int")
                                {
                                    if (arguments[targetCountArgumentSplit] != null && arguments[targetCountArgumentSplit] != "")
                                    {
                                        argumentsIndex["int"] = targetCountArgumentSplit;
                                    }
                                }
                                else if (SpacedArgument == "text")
                                {
                                    if (arguments[targetCountArgumentSplit] != null && arguments[targetCountArgumentSplit] != "")
                                    {
                                        argumentsIndex["text"] = targetCountArgumentSplit;
                                    }
                                }

                                targetCountArgumentSplit++;
                            }
                        }
                    }

                    //Console.WriteLine("1234");
                    if (arguments == null || string.Join("", arguments) == "")
                    {
                        //Console.WriteLine(arguments.ToString());
                        Vk.MessagesSend("Для выполнения этой команды необходимо указать требуемые аргументы: ID/ссылку пользователя");
                        return;
                    }
                }

                /* Возможные аргументы в команде
                
                %args1%
                %args2%
                %args3%

                %targetUserId% — ID пользователя, к которому применяется команда
                %targetUserIdForCMDS% — ID пользователя, к которому применяется команда с приставкой ID

                %fromUserName% — своё имя, фамилия ВК в именительном падеже
                %fromUserNameGen% — своё имя, фамилия ВК в родительном падеже
                %fromUserNameDat% — своё имя, фамилия ВК в дательном падеже
                %fromUserNameAcc% — своё имя, фамилия ВК в винительном падеже
                %fromUserNameIns% — своё имя, фамилия ВК в творительном падеже
                %fromUserNameAbl% — своё имя, фамилия ВК в предложном падеже
                
                %targetUserName% — имя, фамилия ВК в именительном падеже человека, упомянаемого в команде
                %targetUserNameGen% — имя, фамилия ВК в родительном падеже человека, упомянаемого в команде
                %targetUserNameDat% — имя, фамилия ВК в дательном падеже человека, упомянаемого в команде
                %targetUserNameAcc% — имя, фамилия ВК в винительном падеже человека, упомянаемого в команде
                %targetUserNameIns% — имя, фамилия ВК в творительном падеже человека, упомянаемого в команде
                %targetUserNameAbl% — имя, фамилия ВК в предложном падеже человека, упомянаемого в команде

                */

                /**
         *
            именительный – nom,
            родительный – gen,
            дательный – dat,
            винительный – acc,
            творительный – ins,
            предложный – abl.
            По умолчанию nom.
         */



                if (commandTarget["target_cmd"].Contains('%'))
                {
                    var targetSpaced = commandTarget["target_cmd"].Split(" ");
                    if (targetSpaced.Length >= 1)
                    {
                        int int_count_args = 0;
                        foreach (var item in targetSpaced)
                        {

                            if (item.Contains("%fromUserName%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                                targetSpaced[int_count_args] = item.Replace("%fromUserName%", userInfo[Vk.m_from_id.ToString()]);
                            }
                            else if (item.Contains("%fromUserNameGen%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id }, false, "gen");
                                targetSpaced[int_count_args] = item.Replace("%fromUserNameGen%", userInfo[Vk.m_from_id.ToString()]);
                            }
                            else if (item.Contains("%fromUserNameDat%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id }, false, "dat");
                                targetSpaced[int_count_args] = item.Replace("%fromUserNameDat%", userInfo[Vk.m_from_id.ToString()]);
                            }
                            else if (item.Contains("%fromUserNameAcc%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id }, false, "acc");
                                targetSpaced[int_count_args] = item.Replace("%fromUserNameAcc%", userInfo[Vk.m_from_id.ToString()]);
                            }
                            else if (item.Contains("%fromUserNameIns%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id }, false, "ins");
                                targetSpaced[int_count_args] = item.Replace("%fromUserNameIns%", userInfo[Vk.m_from_id.ToString()]);
                            }
                            else if (item.Contains("%fromUserNameAbl%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id }, false, "abl");
                                targetSpaced[int_count_args] = item.Replace("%fromUserNameAbl%", userInfo[Vk.m_from_id.ToString()]);
                            }
                            else if (item.Contains("%targetUserName%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { long.Parse(arguments[argumentsIndex["id"]]) });
                                targetSpaced[int_count_args] = item.Replace("%targetUserName%", userInfo[arguments[argumentsIndex["id"]]]);
                            }
                            else if (item.Contains("%targetUserNameGen%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { long.Parse(arguments[argumentsIndex["id"]]) }, false, "gen");
                                targetSpaced[int_count_args] = item.Replace("%targetUserNameGen%", userInfo[arguments[argumentsIndex["id"]]]);
                            }
                            else if (item.Contains("%targetUserNameDat%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { long.Parse(arguments[argumentsIndex["id"]]) }, false, "dat");
                                targetSpaced[int_count_args] = item.Replace("%targetUserNameDat%", userInfo[arguments[argumentsIndex["id"]]]);
                            }
                            else if (item.Contains("%targetUserNameAcc%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { long.Parse(arguments[argumentsIndex["id"]]) }, false, "acc");
                                targetSpaced[int_count_args] = item.Replace("%targetUserNameAcc%", userInfo[arguments[argumentsIndex["id"]]]);
                            }
                            else if (item.Contains("%targetUserNameIns%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { long.Parse(arguments[argumentsIndex["id"]]) }, false, "ins");
                                targetSpaced[int_count_args] = item.Replace("%targetUserNameIns%", userInfo[arguments[argumentsIndex["id"]]]);
                            }
                            else if (item.Contains("%targetUserNameAbl%"))
                            {
                                var userInfo = await Vk.UserGetNameUrls(new long[] { long.Parse(arguments[argumentsIndex["id"]]) }, false, "abl");
                                targetSpaced[int_count_args] = item.Replace("%targetUserNameAbl%", userInfo[arguments[argumentsIndex["id"]]]);
                            }
                            else if (item.Contains("%args1%"))
                            {
                                if (arguments.Length >= 1)
                                {
                                    targetSpaced[int_count_args] = item.Replace("%args1%", arguments[0]);
                                }
                                else
                                {
                                    targetSpaced[int_count_args] = item.Replace("%args1%", "не определено");
                                }
                            }
                            else if (item.Contains("%args2%"))
                            {
                                if (arguments.Length >= 2)
                                {
                                    targetSpaced[int_count_args] = item.Replace("%args2%", arguments[1]);
                                }
                                else
                                {
                                    targetSpaced[int_count_args] = item.Replace("%args2%", "не определено");
                                }
                            }
                            else if (item.Contains("%targetUserId%"))
                            {
                                targetSpaced[int_count_args] = item.Replace("%targetUserId%", arguments[argumentsIndex["id"]]);
                            }
                            else if (item.Contains("%targetUserIdForCMDS%"))
                            {
                                targetSpaced[int_count_args] = item.Replace("%targetUserIdForCMDS%", "id" + arguments[argumentsIndex["id"]]);
                            }

                            int_count_args++;
                        }

                        commandTarget["target_cmd"] = string.Join(" ", targetSpaced);
                    }
                }
                /*
                 типы
                alias
                text
                 */
                if (commandTarget["type_cmd"] == "text" || commandTarget["type_cmd"] == "voice")
                {
                    Vk.MessagesSend(commandTarget["target_cmd"]);
                }
                else if (commandTarget["type_cmd"] == "alias")
                {
                    Commands com = new(Vk, db, settings, Cache);
                    Vk.m_text = commandTarget["target_cmd"];
                    com.handler_command();
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
                return;
            }
        }

        double CalculateSimilarity(string source, string target)
        {
            if ((source == null) || (target == null)) return 0.0;
            if ((source.Length == 0) || (target.Length == 0)) return 0.0;
            if (source == target) return 1.0;

            int stepsToSame = ComputeLevenshteinDistance(source, target);
            return (1.0 - ((double)stepsToSame / (double)Math.Max(source.Length, target.Length)));
        }

        public static int ComputeLevenshteinDistance(string source, string target)
        {
            if ((source == null) || (target == null)) return 0;
            if ((source.Length == 0) || (target.Length == 0)) return 0;
            if (source == target) return source.Length;

            int sourceWordCount = source.Length;
            int targetWordCount = target.Length;

            // Step 1
            if (sourceWordCount == 0)
                return targetWordCount;

            if (targetWordCount == 0)
                return sourceWordCount;

            int[,] distance = new int[sourceWordCount + 1, targetWordCount + 1];

            // Step 2
            for (int i = 0; i <= sourceWordCount; distance[i, 0] = i++) ;
            for (int j = 0; j <= targetWordCount; distance[0, j] = j++) ;

            for (int i = 1; i <= sourceWordCount; i++)
            {
                for (int j = 1; j <= targetWordCount; j++)
                {
                    // Step 3
                    int cost = (target[j - 1] == source[i - 1]) ? 0 : 1;

                    // Step 4
                    distance[i, j] = Math.Min(Math.Min(distance[i - 1, j] + 1, distance[i, j - 1] + 1), distance[i - 1, j - 1] + cost);
                }
            }

            return distance[sourceWordCount, targetWordCount];
        }



        public async void command_question()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "question", 30))
                {
                    return;
                }

                //if (!settings.isUserChat(Vk.m_peer_id))
                //{
                //Vk.MessagesSend("К сожалению, нельзя отправлять анонимные вопросы через групповые беседы :(");
                //return;
                //}

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "" && args.Length > 1)
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend("Используйте: !вопрос [ID/ссылка] [текст].");
                    return;
                }

                long target = long.Parse(args[0]);

                if (args[1] == "" || args[1] == null)
                {
                    Vk.MessagesSend("Используйте: !вопрос [ID/ссылка] [текст].");
                    return;
                }

                var text = args[1];

                if (Target_User["accept_ls"] == "0")
                {
                    Vk.MessagesSend("К сожалению, указанный человек не разрешил получать сообщения от нашего бота, необходимо чтобы он написал [grand_manager|боту] любое сообщение.");
                    return;
                }

                if (text.Length >= 400)
                {
                    Vk.MessagesSend("Нельзя спрашивать вопросы, в которых больше или 400 символов.");
                    return;
                }

                var targetUserNick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id, target });

                var resId = db.CreateQuestion(target, Vk.m_from_id, text);

                var buttons = Vk.GenerateKeyboard(new string[] { "ответить", "кто автор" }, new string[] { $"answerquest {resId}", $"whoquest {resId}" },
                    new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED });


                var res = await Vk.MessagesSend($"Вам задали анонимный вопрос ({resId}).<br><br>{text}<br><br>Чтобы ответить на вопрос - нажмите на кнопку ниже.", 0, target, buttons);
                if (res == 1)
                {
                    Vk.MessagesSend(targetUserNick[target.ToString()] + " получил(а) Ваш вопрос.<br><br>Как только он(а) ответит - бот отправит сообщение Вам в личные сообщения.");
                }
                else
                {
                    Vk.MessagesSend(targetUserNick[target.ToString()] + " запретил получать сообщения от нашего бота.<br><br>Необходимо, чтобы он написал [grand_manager|боту] любое сообщение.");
                }
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_answerquestion()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "answerquestion", 5))
                {
                    return;
                }

                //if (!settings.isUserChat(Vk.m_peer_id))
                //{
                //Vk.MessagesSend("К сожалению, нельзя отправлять анонимные вопросы через групповые беседы :(");
                //return;
                //}

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int", "text" });



                if (args[0] != null && args[0] != "" && args[1] == "")
                {
                    if (args[0] != "")
                    {
                        Vk.MessagesSend($"Используйте: !ответить {args[0]} [текст].");
                        return;
                    }
                    Vk.MessagesSend($"Используйте: !ответить [ID вопроса] [текст].");
                    return;
                }
                else
                {
                    if (args.Length < 2)
                    {
                        Vk.MessagesSend($"Используйте: !ответить [ID вопроса] [текст].");
                        return;
                    }
                }

                long targetQuestion = 0;
                try
                {
                    targetQuestion = long.Parse(args[0]);
                }
                catch
                {

                }

                if (targetQuestion <= 0)
                {
                    Vk.MessagesSend($"Используйте: !ответить [ID вопроса] [текст].");
                    return;
                }

                var targetQuest = db.questionGetQuest(targetQuestion);
                if (targetQuest == null || targetQuest["user_id"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend($"Этот вопрос задавали не Вам.");
                    return;
                }

                if (targetQuest["answer"] != "")
                {
                    Vk.MessagesSend($"Вы уже отвечали на этот вопрос.");
                    return;
                }

                Dictionary<string, string>? Target_User = null;
                Target_User = db.usersGetUser(long.Parse(targetQuest["from_id"]));

                if (args[1] == "" || args[1] == null)
                {
                    if (args[0] != "")
                    {
                        Vk.MessagesSend($"Используйте: !ответить {args[0]} [текст].");
                        return;
                    }
                    Vk.MessagesSend("Используйте: !ответить [ID вопроса] [текст].");
                    return;
                }

                var text = args[1];

                //if (Target_User["accept_ls"] == "0")
                // {
                //    Vk.MessagesSend("К сожалению, указанный человек не разрешил получать сообщения от нашего бота, необходимо чтобы он написал [grand_manager|боту] любое сообщение.");
                //   return;
                // }

                if (text.Length >= 400)
                {
                    Vk.MessagesSend("Нельзя отправлять текст, в котором больше или 400 символов.");
                    return;
                }

                var targetUserNick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });

                db.questionSetAnswer(targetQuestion, text, Vk.m_from_id, long.Parse(targetQuest["from_id"]));
                //var resId = db.CreateQuestion(target, Vk.m_from_id, text);

                var buttons = Vk.GenerateKeyboard(new string[] { "кто автор" }, new string[] { $"whoquest {targetQuestion}" },
                 new string[] { Vk.BUTTON_RED });


                var res = await Vk.MessagesSend($"Вам ответил {targetUserNick[Vk.m_from_id.ToString()]} на вопрос ({targetQuestion}).<br><br>{text}.", 0, long.Parse(targetQuest["from_id"]));
                if (res == 1)
                {
                    Vk.MessagesSend("Аноним получил(а) Ваш ответ.", 1, 0, buttons);
                }
                else
                {
                    Vk.MessagesSend("Аноним запретил получать сообщения от нашего бота.<br><br>Необходимо, чтобы он написал [grand_manager|боту] любое сообщение.", 1, 0, buttons);
                }
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_whoquest()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "whoquest", 5))
                {
                    return;
                }

                //if (!settings.isUserChat(Vk.m_peer_id))
                //{
                //Vk.MessagesSend("К сожалению, нельзя отправлять анонимные вопросы через групповые беседы :(");
                //return;
                //}

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });



                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend($"Используйте: !whoquest [ID вопроса].");
                    return;
                }

                long targetQuestion = 0;
                try
                {
                    targetQuestion = long.Parse(args[0]);
                }
                catch
                {

                }

                if (targetQuestion <= 0)
                {
                    Vk.MessagesSend($"Используйте: !whoquest [ID вопроса].");
                    return;
                }

                var targetQuest = db.questionGetQuest(targetQuestion);
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    Vk.MessagesSend("Узнать автора анонимного вопроса можно только с подпиской VK DONUT — оформить её можно в нашей группе ВКонтакте.");
                    return;
                }


                if (targetQuest == null || targetQuest["user_id"] != Vk.m_from_id.ToString() && settings.OWNER_IDS[Vk.m_from_id].access_give != 1)
                {
                    Vk.MessagesSend($"Этот вопрос задавали не Вам.");
                    return;
                }


                Dictionary<string, string>? Target_User = null;
                Target_User = db.usersGetUser(long.Parse(targetQuest["from_id"]));

                var targetUserNick = await Vk.UserGetNameUrls(new long[] { long.Parse(targetQuest["from_id"]) });


                Vk.MessagesSend($"Вопрос №{targetQuestion} Вам задал(а) {targetUserNick[targetQuest["from_id"]]}.");

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_questions()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "questions", 5))
                {
                    return;
                }

                //if (!settings.isUserChat(Vk.m_peer_id))
                //{
                //Vk.MessagesSend("К сожалению, нельзя отправлять анонимные вопросы через групповые беседы :(");
                //return;
                //}

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                int list = 1;
                long targetId = 0;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        targetId = long.Parse(args[0]);
                    }
                    catch
                    {
                        targetId = 0;
                    }

                    if (targetId <= 0)
                    {
                        if (targetId == 0)
                        {
                            targetId = Vk.m_from_id;
                        }
                        else
                        {
                            Vk.MessagesSend("Используйте: !вопросы [ID/ссылка]");
                            return;
                        }
                    }

                }
                else
                {
                    targetId = Vk.m_from_id;
                }

                if (list <= 0)
                {
                    Vk.MessagesSend("Используйте: !вопросы [ID/ссылка]");
                    return;
                }

                if (targetId != Vk.m_from_id)
                {
                    int iter = 0;
                    var targetQuests = db.questionGetList(targetId);
                    if (targetQuests == null)
                    {
                        Vk.MessagesSend("У пользователя нет никаких.");
                        return;
                    }
                    string text = "Список последних вопросов пользователя: <br><br>";
                    foreach (var question in targetQuests)
                    {
                        iter++;
                        if (question["answer"] == "")
                        {
                            iter--;
                            continue;
                        }


                        if (iter > 5)
                        {
                            break;
                        }
                        text += $"{iter}. '{question["question"]}'. Ответ: '{question["answer"]}'.<br>";
                    }
                    if (iter == 0)
                    {
                        text = "У пользователя нет отвеченных вопросов.";
                    }
                    Vk.MessagesSend(text);
                }
                else
                {
                    int iter = 0;
                    var targetQuests = db.questionGetList(targetId);
                    string text = "Список ваших вопросов (последние 10): <br><br>";
                    if (targetQuests == null)
                    {
                        Vk.MessagesSend("У Вас нет вопросов.");
                        return;
                    }
                    foreach (var question in targetQuests)
                    {
                        iter++;

                        if (iter > 10)
                        {
                            break;
                        }

                        var isx = (question["from_id"] == Vk.m_from_id.ToString()) ? "Вы спросили: " : "";
                        if (question["user_id"] == Vk.m_from_id.ToString())
                        {
                            isx = "";
                        }

                        if (question["answer"] == "")
                        {
                            text += $"№{question["id"]}. {isx}'{question["question"]}'. Не отвечен..<br>";
                        }
                        else
                        {
                            text += $"№{question["id"]}. {isx}'{question["question"]}'. Ответ: '{question["answer"]}'.<br>";
                        }
                    }
                    if (iter == 0)
                    {
                        Vk.MessagesSend("У Вас нет вопросов.");
                        return;
                    }
                    Vk.MessagesSend(text);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }


        public async void command_report()
        {
            try
            {
                // reportGet
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "report", 20))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["report"]);
                    return;
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var banInfo = db.BanreportsGetBan(Vk.m_from_id);
                if (banInfo != null)
                {
                    var NickAdmin1 = await Vk.UserGetNameUrls(new long[] { long.Parse(banInfo["admin_id"]) });
                    string textBan1 = $"Доступ к тикетам для Вас был ограничен..<br><br>" +
                        $"Заблокировал: {NickAdmin1[banInfo["admin_id"]]}<br>" +
                        $"Блокировка до: {banInfo["date_unban"]}<br>" +
                        $"Причина: {banInfo["reason"]}<br>" +
                        $"<br>Блокировка выдана {banInfo["date_created"]}." +
                        $"<br>Если вы не согласны с наказанием - обжалуйте в обсуждениях нашей группы.";
                    Vk.MessagesSend(textBan1);
                    return;
                }

                var reportInfo = db.reportGet(Vk.m_from_id, Vk.m_peer_id);
                if (reportInfo == null)
                {
                    db.reportInsert(Vk.m_from_id, Vk.m_peer_id);
                    reportInfo = db.reportGet(Vk.m_from_id, Vk.m_peer_id);
                    if (reportInfo == null)
                    {
                        //error
                        Vk.MessagesSend("Произошла ошибка создания тикета. Попробуйте позже.");
                        return;
                    }
                    else
                    {
                        long att = 0;
                        if (Vk.m_attachments != null && Vk.m_attachments.Count() >= 1)
                        {
                            if (Vk.m_attachments.Count() >= 2)
                            {
                                Vk.MessagesSend("Нельзя прикрепить больше одного вложения к сообщению.");
                                return;
                            }
                            att = 1;
                            //string[] attachmesnts = new string[Vk.m_attachments.Count()];
                            //string type = attachments[0]["type"].ToString();
                            db.reportAddMessage(long.Parse(reportInfo["id"]), Vk.m_from_id, att, args[0]);
                            var messages = db.reportMessagesGet(long.Parse(reportInfo["id"]), 1);
                            if (messages.Count <= 0)
                            {
                                Vk.MessagesSend("Произошла ошибка создания тикета. Попробуйте позже.");
                                return;
                            }

                            foreach (var item in Vk.m_attachments)
                            {
                                string type = item["type"].ToString();
                                if (type == "video")
                                {
                                    Vk.MessagesSend("Нельзя прикреплять к тикету видеозаписи.");
                                    return;
                                }
                                string owner_id = item[type]["owner_id"].ToString();
                                string media_id = item[type]["id"].ToString();
                                string album_id = item[type]["album_id"].ToString();
                                string user_id = "-1";
                                if (item[type]["user_id"] != null)
                                {
                                    user_id = item[type]["user_id"].ToString();
                                }
                                string text = item[type]["text"].ToString();
                                string access_key = "nil";
                                if (item[type]["access_key"] != null)
                                {
                                    access_key = item[type]["access_key"].ToString();
                                }
                                string link_photo = "";
                                try
                                {
                                    int max_width = 0;
                                    foreach (var item3 in item[type]["sizes"])
                                    {
                                        var current_width = int.Parse(item3["width"].ToString());
                                        if (max_width < current_width)
                                        {
                                            max_width = current_width;
                                            link_photo = item3["url"].ToString();
                                        }
                                    }
                                }
                                catch
                                {

                                }
                                try
                                {
                                    db.reportAttachmentsAddPhoto(Vk.m_peer_id, long.Parse(reportInfo["id"]), long.Parse(messages[0]["id"]), Vk.m_from_id,
                                    access_key, long.Parse(media_id), long.Parse(album_id), long.Parse(owner_id), long.Parse(user_id), text, link_photo);
                                }
                                catch
                                {
                                    Vk.MessagesSend("Произошла ошибка создания тикета #2. Попробуйте позже.");
                                    return;
                                }

                                //attachmesnts.Append(type + owner_id + "_" + media_id);
                            }

                            //Vk.MessagesSend("yees", 1, 0, "", true, string.Join(",", attachmesnts)); 
                        }
                        else
                        {
                            db.reportAddMessage(long.Parse(reportInfo["id"]), Vk.m_from_id, 0, args[0]);
                        }


                        if (settings.isUserChat(Vk.m_peer_id))
                        {

                            Cache tes = new Cache();
                            string token = "BOT_TOKEN_REPORTADD";
                            string userid = Vk.m_from_id.ToString();

                            Guid g = Guid.NewGuid();
                            string hash = Convert.ToBase64String(g.ToByteArray());
                            hash = hash.Replace("=", "");
                            hash = hash.Replace("+", "");


                            tes.Set("hash_" + hash, new Dictionary<string, string>()
                                            { { "access_token", token }, { "user_id", userid }, { "hash", hash } }, 15);
                            //https://grandmanager.space/infoticket?id=152&hash=eSowuxsqUUmXrE8vfiFB0g
                            Vk.MessagesSend("Тикет #" + reportInfo["id"] + " успешно создан. Ваше обращение передано администраторам.<br>" +
                            "Ответ на ваш тикет придёт в эту беседу как только администраторы ответят на него.<br><br>");// +
                            //"Также вы можете просмотреть статус своего обращения на нашем сайте.<br>" +
                            //"Ваша персональная ссылка: grandmanager.space/infoticket?id=" + reportInfo["id"] + "&hash=" + hash + "<br><br>" +
                            //"Обратите внимание, данную ссылку НЕЛЬЗЯ передавать третьим лицам, иначе вы можете ПОТЕРЯТЬ свои данные.");
                        }
                        else
                        {
                            Vk.MessagesSend("Тикет #" + reportInfo["id"] + " успешно создан. Ваше обращение передано администраторам.<br>" +
                            "Ответ на ваш тикет придёт в эту беседу как только администраторы ответят на него.");
                        }
                        var reportsInfo = db.reportsGetAllOpenned(0, 15);
                        if (reportsInfo != null || reportsInfo.Count >= 1)
                        {
                            string buttons = Vk.GenerateKeyboard(new string[] { "Информация", "Диалог", "Взять на рассмотрение" },
                                new string[] { "getreport " + reportInfo["id"], "getdialog " + reportInfo["id"], "openreport " + reportInfo["id"] },
                                new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_GREEN }, new int[] { 0, 1, 2 });
                            SendAdmMessage("Внимание! Новый тикет (" + reportInfo["id"] + "). Всего актуальных тикетов: " + reportsInfo.Count(), buttons);
                        }
                    }
                }
                else
                {

                    if (reportInfo["closed"] == "1")
                    {
                        Vk.MessagesSend("Тикет уже закрыт.");
                        return;
                    }

                    long att = 0;
                    if (Vk.m_attachments != null && Vk.m_attachments.Count() >= 1)
                    {
                        att = 1;
                        //string[] attachmesnts = new string[Vk.m_attachments.Count()];
                        //string type = attachments[0]["type"].ToString();
                        db.reportAddMessage(long.Parse(reportInfo["id"]), Vk.m_from_id, att, args[0]);
                        var messages = db.reportMessagesGet(long.Parse(reportInfo["id"]), 1);
                        if (messages.Count <= 0)
                        {
                            Vk.MessagesSend("Произошла ошибка продолжения тикета #2. Попробуйте позже.");
                            return;
                        }

                        foreach (var item in Vk.m_attachments)
                        {
                            string type = item["type"].ToString();
                            string owner_id = item[type]["owner_id"].ToString();
                            string media_id = item[type]["id"].ToString();
                            string album_id = item[type]["album_id"].ToString();
                            string user_id = "-1";
                            if (item[type]["user_id"] != null)
                            {
                                user_id = item[type]["user_id"].ToString();
                            }
                            string text = item[type]["text"].ToString();
                            string access_key = "nil";
                            if (item[type]["access_key"] != null)
                            {
                                access_key = item[type]["access_key"].ToString();
                            }
                            string link_photo = "";
                            try
                            {
                                int max_width = 0;
                                foreach (var item3 in item[type]["sizes"])
                                {
                                    var current_width = int.Parse(item3["width"].ToString());
                                    if (max_width < current_width)
                                    {
                                        max_width = current_width;
                                        link_photo = item3["url"].ToString();
                                    }
                                }
                            }
                            catch
                            {

                            }

                            try
                            {
                                db.reportAttachmentsAddPhoto(Vk.m_peer_id, long.Parse(reportInfo["id"]), long.Parse(messages[0]["id"]), Vk.m_from_id,
                                access_key, long.Parse(media_id), long.Parse(album_id), long.Parse(owner_id), long.Parse(user_id), text, link_photo);
                            }
                            catch
                            {
                                Vk.MessagesSend("Произошла ошибка продолжения тикета #3. Попробуйте позже.");
                                return;
                            }

                            //attachmesnts.Append(type + owner_id + "_" + media_id);
                        }

                        //Vk.MessagesSend("yees", 1, 0, "", true, string.Join(",", attachmesnts)); 
                    }
                    else
                    {
                        db.reportAddMessage(long.Parse(reportInfo["id"]), Vk.m_from_id, 0, args[0]);
                    }

                    Vk.MessagesSend("Тикет #" + reportInfo["id"] + $" был успешно дополнен.<br>" +
                            "Ответ на ваш тикет придёт в эту беседу как только администраторы ответят на него.");
                    if (reportInfo.ContainsKey("worker") && reportInfo["worker"] != "0")
                    {
                        string buttonrss = Vk.GenerateKeyboard(new string[] { "Информация", "Диалог", "Взять на рассмотрение" },
                                new string[] { "getreport " + reportInfo["id"], "getdialog " + reportInfo["id"], "openreport " + reportInfo["id"] },
                                new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_GREEN }, new int[] { 0, 1, 2 });
                        Vk.MessagesSend("Тикет #" + reportInfo["id"] + " был дополнен пользователем!<br>" +
                                "Обратите внимание, это ваш тикет.", 0, long.Parse(reportInfo["worker"]), buttonrss);
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_quests()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getquest", 3))
                {
                    return;
                }


                var reportsInfo = db.peerGetNotActiveButReggistredAndAnswered(0, 15);
                if (reportsInfo == null || reportsInfo.Count <= 0)
                {
                    Vk.MessagesSend("На данный момент нет бесед, которые деактивировали бота.");
                    return;
                }
                else
                {
                    string text = "Список рассмотренных бесед:<br><br>";

                    int i = 0;
                    foreach (var item in reportsInfo)
                    {
                        var active = (item["active"] == "1") ? "активна" : "неактивна";
                        i++;
                        var status = "unknown";
                        if (item["sys_mention_non_active"] != "0")
                        {
                            if (reasonsDeactivate.ContainsKey(int.Parse(item["sys_mention_non_active"])))
                            {
                                status = reasonsDeactivate[int.Parse(item["sys_mention_non_active"])];
                            }
                        }
                        text += i + ". #" + item["peer_id"] + " | " + active + " | " + status + "<br>";
                    }
                    text += "<br>Подробнее: /infoquest [ID беседы]";

                    Vk.MessagesSend(text);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_quest()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getquest", 3))
                {
                    return;
                }

                var cacheInfo = Cache.Get<string>("target_getquest_" + Vk.m_from_id);
                if (cacheInfo != null)
                {
                    Vk.MessagesSend("Вы уже рассматриваете беседу #" + cacheInfo + $"<br><br>Используйте команду /work {cacheInfo}.");
                    return;
                }

                var reportsInfo = db.peerGetNotActiveButReggistred(0, 1);
                if (reportsInfo == null || reportsInfo.Count <= 0)
                {
                    Vk.MessagesSend("На данный момент нет бесед, которые деактивировали бота.");
                    return;
                }
                else
                {

                    var getQuests = db.AgentsGetPeersNotAnsweredQuest(Vk.m_from_id);
                    if (getQuests != null)
                    {
                        if (getQuests.Count >= 1)
                        {
                            string textNas = "У вас есть незакрытые квесты. ID:<br><br>";
                            foreach (var item in getQuests)
                            {
                                textNas += $"{item["peer_id"]}<br>";
                            }
                            Vk.MessagesSend(textNas);
                            return;
                        }
                    }

                    string text = "Вам попалась деактивированная беседа.<br><br>";

                    var url = await Vk.UserGetNameUrls(new long[] { long.Parse(reportsInfo[0]["owner"]), long.Parse(reportsInfo[0]["inviter"]) });

                    text += $"ID: {reportsInfo[0]["peer_id"]}<br>";
                    text += (reportsInfo[0]["owner"] == "0") ? "Владелец: — (не была ни разу активирована)<br>" : $"Владелец: {url[reportsInfo[0]["owner"]]}<br>";
                    text += $"Пригласил бота: {url[reportsInfo[0]["inviter"]]}<br>";
                    text += $"Последнее название: {reportsInfo[0]["title"]}<br>";
                    text += $"Последнее количество человек: {reportsInfo[0]["current_members"]}<br>";
                    text += $"Последняя активность: {reportsInfo[0]["date_last"]}<br>";
                    text += $"Дата добавления бота в беседу: {reportsInfo[0]["date_reg"]}<br>";

                    text += $"<br>Обратите внимание, вы не сможете взять следующую беседу, пока не закроете эту.<br>" +
                        $"Используйте для дальнейших действий команду /work {reportsInfo[0]["peer_id"]}.";
                    Vk.MessagesSend(text);
                    Cache.Set("target_getquest_" + Vk.m_from_id, reportsInfo[0]["peer_id"], 300);
                    db.peersSetMentionWorker(long.Parse(reportsInfo[0]["peer_id"]), Vk.m_from_id);
                    db.peersSetMentionDate(long.Parse(reportsInfo[0]["peer_id"]), db.timeGetForString(DateTimeOffset.Now));
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public static Dictionary<int, string> reasonsNotActive = new()
        {
            { 1, "не смог активировать по технической проблеме, сейчас она исправлена и конференция активна" },
            { 2, "не смог активировать по технической проблеме, сейчас владелец не хочет попробовать исправить проблему" },
            { 3, "приглашающий самовольно добавил бота, владелец не хотел добавлять" },
            { 50, "приглашающий игнорирует сообщение агента (время рассмотрения от 100 минут)" },
            { 99, "другое (указать в комментарии)" },
        };

        public static Dictionary<int, string> reasonsDeactivate = new()
        {
            { 1, "не смог активировать по технической проблеме, сейчас она исправлена и конференция активна" },
            { 2, "не смог активировать по технической проблеме, сейчас владелец не хочет попробовать исправить проблему" },
            { 3, "приглашающий самовольно добавил бота, владелец не хотел добавлять" },
            { 4, "не устроили команды/система (указать какие)" },
            { 5, "один из пользователей беседы заблокирован ботом" },
            { 6, "долгое не использование бота (нет нужнды использовать бота)" },
            { 50, "приглашающий/владелец игнорирует сообщение агента (время рассмотрения от 100 минут)" },
            { 99, "другое (указать в комментарии)" },
        };


        public async void command_work()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                long targetId = 0;
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    var cacheInfo = Cache.Get<string>("target_getquest_" + Vk.m_from_id);
                    if (cacheInfo == null)
                    {
                        Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                        return;
                    }
                    else
                    {
                        targetId = long.Parse(cacheInfo);
                    }
                }
                else
                {
                    try
                    {
                        targetId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }

                if (targetId == 0)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                var peerInfo = db.peersGetPeer(targetId, false, false);
                if (peerInfo == null)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                if (peerInfo["sys_mention_worker"] != Vk.m_from_id.ToString() && settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    Vk.MessagesSend("Эту беседу вы не рассматриваете.");
                    return;
                }

                var urlInviter = await Vk.UserGetNameUrls(new long[] { long.Parse(peerInfo["inviter"]) });

                List<string> namesButton = new();
                List<string> commandsButton = new();
                List<string> colorsButton = new();
                string text = "";
                if (peerInfo["owner"] == "0")
                {
                    text += $"Приглашающий: {urlInviter[peerInfo["inviter"]]}<br>";
                    text += $"ID: {peerInfo["peer_id"]}<br>";
                    text += $"Дата добавления бота в беседу: {peerInfo["date_reg"]}<br>";
                    text += $"Данная беседа не была ни разу активна, Вам нужно написать пригласившему и спросить, по какой причине эту беседу не удалось активировать." +
                        $"<br>Выберите пункт, по которому владелец не смог активировать конференцию ниже. (Если не смог по технической причине - ОБЯЗАТЕЛЬНО ПОМОГИТЕ ЕМУ и выберите подходящий пункт ниже)<br><br>";


                    foreach (var item in reasonsNotActive)
                    {
                        text += item.Key + ". " + item.Value + "<br>";
                        namesButton.Add(item.Key.ToString());
                        commandsButton.Add($"sys_work {targetId} {item.Key}");
                        colorsButton.Add(Vk.BUTTON_WHITE);
                    }

                    var buttonsInvite = Vk.GenerateKeyboard(namesButton.ToArray(), commandsButton.ToArray(), colorsButton.ToArray());
                    Vk.MessagesSend(text, 0, 0, buttonsInvite);
                    return;
                }

                var urlOwner = await Vk.UserGetNameUrls(new long[] { long.Parse(peerInfo["owner"]) });

                text += $"ID: {peerInfo["peer_id"]}<br>";
                text += $"Владелец: {urlOwner[peerInfo["owner"]]}<br>";
                text += $"Пригласил бота: {urlInviter[peerInfo["inviter"]]}<br>";
                text += $"Последнее название: {peerInfo["title"]}<br>";
                text += $"Последнее количество человек: {peerInfo["current_members"]}<br>";
                text += $"Последняя активность: {peerInfo["date_last"]}<br>";
                text += $"Дата добавления бота в беседу: {peerInfo["date_reg"]}<br>";

                text += $"<br>Поспешите написать владельцу или пригласившему и спросите, почему же они исключили бота из беседы.<br>" +
                    $"Затем, выберите подходящий пункт ниже и укажите его (в случае, если требовалась помощь с ботом, либо технические причины " +
                    $"- ПОСТАРАЙТЕСЬ ПОМОЧЬ И ПРИВЛЕЧЬ КЛИЕНТА ОБРАТНО, за это агента ждёт поощрение, если беседа станет вновь активной).<br><br>";

                foreach (var item in reasonsDeactivate)
                {
                    text += item.Key + ". " + item.Value + "<br>";
                    namesButton.Add(item.Key.ToString());
                    commandsButton.Add($"sys_work {targetId} {item.Key}");
                    colorsButton.Add(Vk.BUTTON_WHITE);
                }
                //Vk.MessagesSend(text);
                Cache.Set("target_getquest_" + Vk.m_from_id, targetId.ToString(), 300);
                var buttonsDeactivate = Vk.GenerateKeyboard(namesButton.ToArray(), commandsButton.ToArray(), colorsButton.ToArray(), null, false, false);
                var res = await Vk.MessagesSend(text, 0, 0, buttonsDeactivate);
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getdel()
        {
            try
            {
                if (settings.isUserChat(Vk.m_peer_id))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getdel", 15))
                {
                    return;
                }

                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "getdel"))
                {
                    return;
                }

                long targetId = 0;
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getdel"]);
                    return;
                }

                try
                {
                    targetId = long.Parse(args[0]);
                }
                catch
                {

                }

                if (targetId == 0)
                {
                    Vk.MessagesSend("Необходимо указать ID сообщения, про которое идёт речь.");
                    return;
                }

                var message = db.deletedMessagesGet(Vk.m_peer_id, targetId);


                if (message == null)
                {
                    Vk.MessagesSend("Указанного сообщения не существует.");
                    return;
                }

                var userLocal = db.usersGetUser(Vk.m_from_id);
                if (userLocal["accept_ls"] == "0")
                {
                    Vk.MessagesSend("Я не могу писать Вам в личные сообщения, перейдите на мою страницу и напишите боту любое сообщение в ЛС.");
                    return;
                }

                var userId = (long.Parse(message["from_id"]) <= 0) ? $"@public{message["from_id"].Substring(1)}" : $"@id{message["from_id"]}";
                var From = (Vk.m_from_id <= 0) ? $"[public{Vk.m_from_id.ToString().Substring(1)}|Вам]" : $"[id{Vk.m_from_id}|Вам]";

                if (message["text"].Length >= 2000)
                {
                    Vk.MessagesSend($"Сообщение отправил: {userId}<br>Текст сообщения СЛИШКОМ БОЛЬШОЙ ДЛЯ ОТПРАВКИ (сообщите на форум в раздел 'апелляции на решения агентов поддержки' - https://forum.grandmanager.ru)<br>Дата отправки: {db.timeGetForMysql(message["date_create"]).ToString("g")}", 0, Vk.m_from_id);
                }
                else
                {
                    Vk.MessagesSend($"Сообщение отправил: {userId}<br>Текст сообщения: '{message["text"]}'<br>Дата отправки: {db.timeGetForMysql(message["date_create"]).ToString("g")}", 0, Vk.m_from_id);
                }
                Vk.MessagesSend($"Сообщение отправлено {From} в личные сообщения.");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sys_work()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getquest", 3))
                {
                    return;
                }

                long targetId = 0;
                long targetAction = 0;
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    var cacheInfo = Cache.Get<string>("target_getquest_" + Vk.m_from_id);
                    if (cacheInfo == null)
                    {
                        Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                        return;
                    }
                    else
                    {
                        targetId = long.Parse(cacheInfo);
                        Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                        return;
                    }
                }
                else
                {
                    try
                    {
                        var args_delmited = args[0].Split(" ");
                        if (args_delmited.Length > 1)
                        {
                            targetId = long.Parse(args_delmited[0]);
                            targetAction = long.Parse(args_delmited[1]);
                        }

                    }
                    catch
                    {

                    }
                }

                if (targetId == 0 || targetAction == 0)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                var peerInfo = db.peersGetPeer(targetId, false, false);
                if (peerInfo == null)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                if (peerInfo["sys_mention_worker"] != Vk.m_from_id.ToString() && settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    Vk.MessagesSend("Эту беседу вы не рассматриваете.");
                    return;
                }

                if (targetAction == 99 || targetAction == 50)
                {
                    if (targetAction == 50)
                    {
                        if (peerInfo["sys_mention_date"] != "")
                        {
                            var date = db.timeGetForMysql(peerInfo["sys_mention_date"]);
                            if (date.AddHours(2) >= DateTimeOffset.Now)
                            {
                                Vk.MessagesSend("Время ожидания овтета - минимум 2 часа. Это время ещё не прошло.<br>Можно будет отправить такой ответ " + date.AddHours(2).ToString("g"));
                                return;
                            }

                            Vk.MessagesSend("Используйте команду /closepeer " + targetId + ", приложив к ней фотографию (скриншот) игнорирования сообщения.<br>" +
                                "Обратите внимание, скриншот должен быть качественно сделан, где должна быть четко видно время устройства и диалог с владельцем/приглащающим беседы.");
                            return;
                        }
                        else
                        {
                            Vk.MessagesSend("Используйте команду /closepeer " + targetId + ", приложив к ней фотографию (скриншот) игнорирования сообщения.<br>" +
                                "Обратите внимание, скриншот должен быть качественно сделан, где должна быть четко видно время устройства и диалог с владельцем/приглащающим беседы.");
                            return;
                        }
                    }
                    else
                    {
                        Vk.MessagesSend("Используйте команду /closecomm " + targetId + " [КОММЕНТАРИЙ], приложив к ней фотографию (скриншот) игнорирования сообщения.<br>" +
                                "Обратите внимание, скриншот должен быть качественно сделан, где должна быть четко видно время устройства и диалог с владельцем/приглащающим беседы.");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend("Используйте команду /closequest " + targetId + " " + targetAction + "<br><br>" +
                        "В обязательном порядке перешлите диалог с владельцем/пригласившем и скриншот диалога.");
                }

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_closepeer()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getquest", 3))
                {
                    return;
                }

                long targetId = 0;
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    var cacheInfo = Cache.Get<string>("target_getquest_" + Vk.m_from_id);
                    if (cacheInfo == null)
                    {
                        Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                        return;
                    }
                    else
                    {
                        targetId = long.Parse(cacheInfo);
                    }
                }
                else
                {
                    try
                    {
                        targetId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }

                if (targetId == 0)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                var peerInfo = db.peersGetPeer(targetId, false, false);
                if (peerInfo == null)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                if (peerInfo["sys_mention_worker"] != Vk.m_from_id.ToString() && settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    Vk.MessagesSend("Эту беседу вы не рассматриваете.");
                    return;
                }

                if (peerInfo["sys_mention_date"] != "")
                {
                    var date = db.timeGetForMysql(peerInfo["sys_mention_date"]);
                    if (date.AddHours(2) >= DateTimeOffset.Now)
                    {
                        Vk.MessagesSend("Время ожидания овтета - минимум 2 часа. Это время ещё не прошло.<br>Можно будет отправить такой ответ " + date.AddHours(2).ToString("g"));
                        return;
                    }
                }

                if (Vk.m_attachments == null || Vk.m_attachments.Count() <= 0)
                {
                    Vk.MessagesSend("Необходимо приложить доказательства игнорирования (фотография - скриншот!).<br>" +
                        "Обратите внимание, скриншот должен быть качественно сделан, где должна быть четко видно время устройства и диалог с владельцем/приглащающим беседы.");
                    return;
                }

                foreach (var item in Vk.m_attachments)
                {
                    string type = item["type"].ToString();
                    if (type != "photo")
                    {
                        Vk.MessagesSend("Нельзя прикреплять к закрытию беседы другие вложения, кроме фотографий.");
                        return;
                    }
                    string owner_id = item[type]["owner_id"].ToString();
                    string media_id = item[type]["id"].ToString();
                    string album_id = item[type]["album_id"].ToString();
                    string user_id = "-1";
                    if (item[type]["user_id"] != null)
                    {
                        user_id = item[type]["user_id"].ToString();
                    }
                    string text = item[type]["text"].ToString();
                    string access_key = "nil";
                    if (item[type]["access_key"] != null)
                    {
                        access_key = item[type]["access_key"].ToString();
                    }
                    try
                    {
                        db.closePeerAddAttachments(targetId, Vk.m_from_id,
                        access_key, long.Parse(media_id), long.Parse(album_id), long.Parse(owner_id), long.Parse(user_id), text);
                    }
                    catch
                    {
                        Vk.MessagesSend("Произошла ошибка прикрепления фотографии к беседе #2. Попробуйте позже.");
                        return;
                    }



                    //attachmesnts.Append(type + owner_id + "_" + media_id);
                }
                Vk.MessagesSend("Беседа закрыта. Можете взять новую — /quest. Обратите внимание, за поддельные скриншоты следует наказание в виде " +
                        "блокировки возможности использовать бота на 30 дней по пункту 5.6 публичной оферты.");
                db.peersSetMentionType(targetId, 50);
                Cache.Delete("target_getquest_" + Vk.m_from_id);

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_closecomm()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getquest", 3))
                {
                    return;
                }

                long targetId = 0;
                string comm = "";
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    var cacheInfo = Cache.Get<string>("target_getquest_" + Vk.m_from_id);
                    if (cacheInfo == null)
                    {
                        Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                        return;
                    }
                    else
                    {
                        targetId = long.Parse(cacheInfo);

                        if (args[1] == null || args[1] == "")
                        {
                            Vk.MessagesSend("Необходимо указать комментарий и причину, по которой вы хотите закрыть беседу, при этом прикрепив скриншот.");
                            return;
                        }
                        else
                        {

                        }

                    }
                }
                else
                {
                    try
                    {
                        var parseArgs = args[0].Split(" ");
                        if (parseArgs.Length >= 2)
                        {
                            targetId = long.Parse(parseArgs[0]);
                            parseArgs[0] = "";
                            comm = string.Join(" ", parseArgs);
                        }
                        else
                        {
                            Vk.MessagesSend("Необходимо указать комментарий и причину, по которой вы хотите закрыть беседу, при этом прикрепив скриншот.");
                            return;
                        }

                    }
                    catch
                    {

                    }
                }

                if (targetId == 0 || comm == "")
                {
                    Vk.MessagesSend("Необходимо указать комментарий и причину, по которой вы хотите закрыть беседу, при этом прикрепив скриншот.");
                    return;
                }

                var peerInfo = db.peersGetPeer(targetId, false, false);
                if (peerInfo == null)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                if (peerInfo["sys_mention_worker"] != Vk.m_from_id.ToString() && settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    Vk.MessagesSend("Эту беседу вы не рассматриваете.");
                    return;
                }

                if (Vk.m_fwd_messages == null || Vk.m_fwd_messages.Count() <= 0)
                {
                    Vk.MessagesSend("Необходимо переслать ваш диалог с владельцем беседы/приглашающего бота и отправить его вместе с командой.");
                    return;
                }

                if (Vk.m_attachments == null || Vk.m_attachments.Count() <= 0)
                {
                    Vk.MessagesSend("Необходимо приложить доказательства диалога (фотография - скриншот!).<br>" +
                        "Обратите внимание, скриншот должен быть качественно сделан, где должна быть четко видно время устройства и диалог с владельцем/приглащающим беседы.");
                    return;
                }

                foreach (var item in Vk.m_attachments)
                {
                    string type = item["type"].ToString();
                    if (type != "photo")
                    {
                        Vk.MessagesSend("Нельзя прикреплять к закрытию беседы другие вложения, кроме фотографий.");
                        return;
                    }
                    string owner_id = item[type]["owner_id"].ToString();
                    string media_id = item[type]["id"].ToString();
                    string album_id = item[type]["album_id"].ToString();
                    string user_id = "-1";
                    if (item[type]["user_id"] != null)
                    {
                        user_id = item[type]["user_id"].ToString();
                    }
                    string text = item[type]["text"].ToString();
                    string access_key = "nil";
                    if (item[type]["access_key"] != null)
                    {
                        access_key = item[type]["access_key"].ToString();
                    }
                    try
                    {
                        db.closePeerAddAttachments(targetId, Vk.m_from_id,
                        access_key, long.Parse(media_id), long.Parse(album_id), long.Parse(owner_id), long.Parse(user_id), text);
                    }
                    catch
                    {
                        Vk.MessagesSend("Произошла ошибка прикрепления фотографии к беседе #2. Попробуйте позже.");
                        return;
                    }



                    //attachmesnts.Append(type + owner_id + "_" + media_id);
                }

                var system_text = "";


                foreach (var item in Vk.m_fwd_messages)
                {
                    var from_id = long.Parse(item["from_id"].ToString());
                    var date = long.Parse(item["date"].ToString());
                    var text = item["text"].ToString();

                    if (text == "")
                    {
                        continue;
                    }

                    if (peerInfo["sys_mention_date"] != "")
                    {
                        if (date < db.timeGetForMysql(peerInfo["sys_mention_date"]).ToUnixTimeSeconds())
                        {
                            Vk.MessagesSend("В тексте присутствуют сообщения, отправленные раньше, чем вы взяли рассматривать эту беседу (" +
                                "начните с " + peerInfo["sys_mention_date"] + ").");
                            return;
                        }
                    }

                    if (from_id != Vk.m_from_id && from_id != long.Parse(peerInfo["owner"]) && from_id != long.Parse(peerInfo["inviter"]))
                    {
                        Vk.MessagesSend("В диалоге не должно присутствовать никаких лиц, кроме владельца, вас, и/или пригласившего в беседу человека.");
                        return;
                    }

                    system_text += (from_id == Vk.m_from_id) ? "админ" : (from_id == long.Parse(peerInfo["owner"])) ? "владелец беседы" : "пригласивший бота";
                    system_text += ": " + text + "<br>";
                }

                db.closePeerAddAttachments(targetId, Vk.m_from_id, "", 0, 0, 0, 0, "nil", system_text, "text");


                Vk.MessagesSend("Беседа закрыта. Можете взять новую — /quest. Обратите внимание, за поддельные скриншоты следует наказание в виде " +
                       "блокировки возможности использовать бота на 30 дней по пункту 5.6 публичной оферты.");
                db.peersSetMentionComment(targetId, comm);
                db.peersSetMentionType(targetId, 99);
                Cache.Delete("target_getquest_" + Vk.m_from_id);

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_closequest()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getquest", 3))
                {
                    return;
                }

                long targetId = 0;
                long comm = 0;
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    var cacheInfo = Cache.Get<string>("target_getquest_" + Vk.m_from_id);
                    if (cacheInfo == null)
                    {
                        Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                        return;
                    }
                    else
                    {
                        targetId = long.Parse(cacheInfo);

                        if (args[1] == null || args[1] == "")
                        {
                            Vk.MessagesSend("Необходимо указать комментарий и причину, по которой вы хотите закрыть беседу, при этом прикрепив скриншот.");
                            return;
                        }
                        else
                        {

                        }

                    }
                }
                else
                {
                    try
                    {
                        var parseArgs = args[0].Split(" ");
                        if (parseArgs.Length >= 2)
                        {
                            targetId = long.Parse(parseArgs[0]);
                            parseArgs[0] = "";
                            comm = long.Parse(parseArgs[1]);
                        }
                        else
                        {
                            Vk.MessagesSend("Необходимо указать тип, по которому вы хотите закрыть беседу, при этом прикрепив скриншот и диалог.");
                            return;
                        }

                    }
                    catch
                    {

                    }
                }

                if (targetId == 0 || (comm != 1 && comm != 2 && comm != 3 && comm != 4 && comm != 5 && comm != 6 && comm != 50 && comm != 99))
                {
                    Vk.MessagesSend("Необходимо указать пункт и скриншот, по которой вы хотите закрыть беседу, при этом прикрепив диалог.");
                    return;
                }

                var peerInfo = db.peersGetPeer(targetId, false, false);
                if (peerInfo == null)
                {
                    Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                    return;
                }

                if (peerInfo["sys_mention_worker"] != Vk.m_from_id.ToString() && settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    Vk.MessagesSend("Эту беседу вы не рассматриваете.");
                    return;
                }

                if (Vk.m_fwd_messages == null || Vk.m_fwd_messages.Count() <= 0)
                {
                    Vk.MessagesSend("Необходимо переслать ваш диалог с владельцем беседы/приглашающего бота и отправить его вместе с командой.");
                    return;
                }

                if (Vk.m_attachments == null || Vk.m_attachments.Count() <= 0)
                {
                    Vk.MessagesSend("Необходимо приложить доказательства игнорирования (фотография - скриншот!).<br>" +
                        "Обратите внимание, скриншот должен быть качественно сделан, где должна быть четко видно время устройства и диалог с владельцем/приглащающим беседы.");
                    return;
                }

                foreach (var item in Vk.m_attachments)
                {
                    string type = item["type"].ToString();
                    if (type != "photo")
                    {
                        Vk.MessagesSend("Нельзя прикреплять к закрытию беседы другие вложения, кроме фотографий.");
                        return;
                    }
                    string owner_id = item[type]["owner_id"].ToString();
                    string media_id = item[type]["id"].ToString();
                    string album_id = item[type]["album_id"].ToString();
                    string user_id = "-1";
                    if (item[type]["user_id"] != null)
                    {
                        user_id = item[type]["user_id"].ToString();
                    }
                    string text = item[type]["text"].ToString();
                    string access_key = "nil";
                    if (item[type]["access_key"] != null)
                    {
                        access_key = item[type]["access_key"].ToString();
                    }
                    try
                    {
                        db.closePeerAddAttachments(targetId, Vk.m_from_id,
                        access_key, long.Parse(media_id), long.Parse(album_id), long.Parse(owner_id), long.Parse(user_id), text);
                    }
                    catch
                    {
                        Vk.MessagesSend("Произошла ошибка прикрепления фотографии к беседе #2. Попробуйте позже.");
                        return;
                    }



                    //attachmesnts.Append(type + owner_id + "_" + media_id);
                }

                var system_text = "";


                foreach (var item in Vk.m_fwd_messages)
                {
                    var from_id = long.Parse(item["from_id"].ToString());
                    var date = long.Parse(item["date"].ToString());
                    var text = item["text"].ToString();

                    if (text == "")
                    {
                        continue;
                    }

                    if (peerInfo["sys_mention_date"] != "")
                    {
                        if (date < db.timeGetForMysql(peerInfo["sys_mention_date"]).ToUnixTimeSeconds())
                        {
                            Vk.MessagesSend("В тексте присутствуют сообщения, отправленные раньше, чем вы взяли рассматривать эту беседу (" +
                                "начните с " + peerInfo["sys_mention_date"] + ").");
                            return;
                        }
                    }

                    if (from_id != Vk.m_from_id && from_id != long.Parse(peerInfo["owner"]) && from_id != long.Parse(peerInfo["inviter"]))
                    {
                        Vk.MessagesSend("В диалоге не должно присутствовать никаких лиц, кроме владельца, вас, и/или пригласившего в беседу человека.");
                        return;
                    }

                    system_text += (from_id == Vk.m_from_id) ? "админ" : (from_id == long.Parse(peerInfo["owner"])) ? "владелец беседы" : "пригласивший бота";
                    system_text += ": " + text + "<br>";
                }

                db.closePeerAddAttachments(targetId, Vk.m_from_id, "", 0, 0, 0, 0, "nil", system_text, "text");

                db.peersSetMentionType(targetId, comm);
                Vk.MessagesSend("Беседа закрыта. Можете взять новую — /quest. Обратите внимание, за поддельные скриншоты следует наказание в виде " +
                       "блокировки возможности использовать бота на 30 дней по пункту 5.6 публичной оферты.");
                Cache.Delete("target_getquest_" + Vk.m_from_id);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_infoquest()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getquest", 3))
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend("Использование: /questinfo [ID беседы]");
                    return;
                }

                Dictionary<string, string> peerInfo = null;

                try
                {
                    peerInfo = db.peersGetPeer(long.Parse(args[0]), false, false);
                    if (peerInfo == null || peerInfo["sys_mention_worker"] == "0")
                    {
                        Vk.MessagesSend("Введён неправильный ID беседы.");
                        return;
                    }
                }
                catch
                {

                }


                var messages = db.ClosePeerDialogGetMessages(long.Parse(args[0]), 10);
                if (messages == null)
                {
                    Vk.MessagesSend("Странно, но в диалоге нет сообщений.");
                    return;
                }
                var urlsOwner = await Vk.UserGetNameUrls(new long[] { long.Parse(peerInfo["owner"]),
                    long.Parse(peerInfo["inviter"]), long.Parse(peerInfo["sys_mention_worker"]) });

                var owner = (peerInfo["owner"] == "0") ? "—" : urlsOwner[peerInfo["owner"]];
                var inviter = (peerInfo["inviter"] == "0") ? "—" : urlsOwner[peerInfo["inviter"]];
                var admin = (peerInfo["sys_mention_worker"] == "0") ? "—" : urlsOwner[peerInfo["sys_mention_worker"]];
                string status = (peerInfo["sys_mention_non_active"] == "0") ? "на рассмотрении" : reasonsDeactivate[int.Parse(peerInfo["sys_mention_non_active"])];
                string text = "#" + args[0] + "<br>" +
                    $"Владелец: {owner}<br>" +
                    $"Пригласивший: {inviter}<br>" +
                    $"Рассматривающий: {admin}<br>" +
                    $"Статус: {status}<br>" +
                    $"Комментарий: {peerInfo["sys_mention_comment"]}";
                text += "<br><br>Показаны последние 10 сообщений.<br><br>";
                string link_photo = "";
                long i_photo = 0;
                List<long> UsersForGet = new();
                foreach (var item in messages)
                {
                    if (!UsersForGet.Contains(long.Parse(item["from_id"])))
                    {
                        UsersForGet.Add(long.Parse(item["from_id"]));
                    }
                }
                var urls = await Vk.UserGetNameUrls(UsersForGet.ToArray());

                foreach (var item in messages)
                {

                    if (item["type"] == "photo")
                    {
                        i_photo++;

                        link_photo = link_photo + "," + item["type"] + item["photo_owner_id"] + "_" + item["photo_id"] + "_" + item["access_key"];

                    }


                    string sender = urls[item["from_id"]];
                    string att = (item["type"] == "photo") ? "(🌅 " + i_photo + ")" : "";
                    if (item["text"] != "nil")
                    {
                        text = text + item["text"] + " " + att + "<br>";
                    }
                    else
                    {
                        text = text + "" + sender + ": " + att + "<br>";
                    }
                }

                if (link_photo != "")
                {
                    Vk.MessagesSend(text, 1, 0, "", true, link_photo);
                }
                else
                {
                    Vk.MessagesSend(text, 1, 0, "");
                }

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getinvite()
        {
            //
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_givevip == 0)
                {
                    return;
                }

                long targetId = 0;
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать ID конференции.");
                    return;
                }
                else
                {
                    try
                    {
                        targetId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }

                if (targetId == 0 || !settings.isPeer(targetId))
                {
                    if (targetId == 0)
                    {
                        Vk.MessagesSend("Необходимо указать ID беседы, про которую идёт речь.");
                        return;
                    }
                    else
                    {
                        targetId = settings.PEERS_CHATID + targetId;
                    }

                }

                var peerInfo = db.peersGetPeer(targetId, false, false);
                if (peerInfo == null)
                {
                    Vk.MessagesSend("Такой беседы не существует.");
                    return;
                }

                if (peerInfo["active"] == "0")
                {
                    Vk.MessagesSend("Эта беседа неактивна.");
                    return;
                }

                Dictionary<string, string> parames = new()
                {
                    { "peer_id", targetId.ToString() },
                    { "reset", "0" }
                };
                var res = await Vk.VkAPI("messages.getInviteLink", parames);
                if (res.ContainsKey("error") || !res.ContainsKey("response"))
                {
                    Vk.MessagesSend("error.");
                    return;
                }
                else
                {
                    Vk.MessagesSend(res["response"]["link"].ToString());
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_reports()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_reports == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "reports", 3))
                {
                    return;
                }

                var reportsInfo = db.reportsGetAllOpenned(0, 15);
                if (reportsInfo == null || reportsInfo.Count <= 0)
                {
                    Vk.MessagesSend("На данный момент нет открытых тикетов.");
                    return;
                }
                else
                {
                    string text = "Открытые тикеты:<br><br>";
                    long count_reports = reportsInfo.Count;

                    long[] uses_for_get = new long[count_reports];
                    long i = 0;
                    foreach (var item in reportsInfo)
                    {
                        uses_for_get[i] = long.Parse(item["from_id"]);
                        i++;
                    }
                    var vkInfo = await Vk.UsersGetName(uses_for_get);
                    foreach (var item in reportsInfo)
                    {
                        string userName = "[id" + item["from_id"] + "|Пользователь]";
                        if (vkInfo.ContainsKey("id" + item["from_id"]))
                        {
                            userName = "[id" + item["from_id"] + "|" + vkInfo["id" + item["from_id"]].first_name + " " + vkInfo["id" + item["from_id"]].last_name + "]";
                        }
                        else
                        {
                            if (long.Parse(item["from_id"]) < 0)
                            {
                                userName = "[club" + item["from_id"].Substring(1) + "|Сообщество]";
                            }
                        }
                        text = text + "#" + item["id"] + ". " + userName + " | Последняя активность: " + item["last_activity"] + "<br>";
                    }

                    text = text + "<br>Для подробного просмотра тикета используйте команду /getreport";

                    Vk.MessagesSend(text);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getreport()
        {
            try
            {
                // reportGet
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getreport", 10))
                {
                    return;
                }

                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    var reportInsfo = db.reportGet(Vk.m_from_id, Vk.m_peer_id, false);
                    if (reportInsfo == null)
                    {
                        Vk.MessagesSend("У Вас нет открытого тикета.");
                        return;
                    }
                    else
                    {
                        string text = "Информация о тикете #" + reportInsfo["id"] + ":<br><br>";

                        var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(reportInsfo["from_id"]) });
                        string name_url = "[id" + reportInsfo["from_id"] + "|Пользователь]";
                        if (vkInfo.ContainsKey("id" + reportInsfo["from_id"]))
                        {
                            name_url = "[id" + reportInsfo["from_id"] + "|" + vkInfo["id" + reportInsfo["from_id"]].first_name + " " +
                                vkInfo["id" + reportInsfo["from_id"]].last_name + "]";
                        }
                        else
                        {
                            if (long.Parse(reportInsfo["from_id"]) < 0)
                            {
                                name_url = "[club" + reportInsfo["from_id"].Substring(1) + "|Сообщество]";
                            }
                        }

                        string closed = (reportInsfo["closed"] == "1") ? "да" : "нет";

                        string admin_url = "ожидает рассмотрения.";
                        if (reportInsfo.ContainsKey("worker") && reportInsfo["worker"] != "0")
                        {
                            if (settings.OWNER_IDS.ContainsKey(long.Parse(reportInsfo["worker"])))
                            {
                                admin_url = "Администратор #" + settings.OWNER_IDS[long.Parse(reportInsfo["worker"])].id;
                            }
                            else
                            {
                                admin_url = "Модератор";
                            }
                        }


                        text = text + "Отправитель: " + name_url + "<br>" +
                            "Конференция: " + (reportInsfo.ContainsKey("peer_id") ? reportInsfo["peer_id"] : "—") + "<br>" +
                            "Закрыт? - " + closed + "<br>" +
                            "Рассматривает: " + admin_url + "<br>" +
                            "Последняя активность: " + (reportInsfo.ContainsKey("last_activity") ? reportInsfo["last_activity"] : "—");

                        Vk.MessagesSend(text);
                    }
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (settings.OWNER_IDS[Vk.m_from_id].access_reports == 0)
                {
                    return;
                }

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getreport"]);
                    return;
                }

                var reportInfo = db.reportGet(long.Parse(args[0]), false);
                if (reportInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID тикета.");
                    return;
                }
                else
                {
                    if (reportInfo["closed"] == "1")
                    {
                        if (settings.OWNER_IDS[Vk.m_from_id].access_closed == 0)
                        {
                            Vk.MessagesSend("У вас нет доступа для просмотра закрытых тикетов.");
                            return;
                        }
                    }

                    string text = "Информация о тикете #" + reportInfo["id"] + ":<br><br>";

                    var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(reportInfo["from_id"]) });
                    string name_url = "[id" + reportInfo["from_id"] + "|Пользователь]";
                    if (vkInfo.ContainsKey("id" + reportInfo["from_id"]))
                    {
                        name_url = "[id" + reportInfo["from_id"] + "|" + vkInfo["id" + reportInfo["from_id"]].first_name + " " +
                            vkInfo["id" + reportInfo["from_id"]].last_name + "]";
                    }
                    else
                    {
                        if (long.Parse(reportInfo["from_id"]) < 0)
                        {
                            name_url = "[club" + reportInfo["from_id"].Substring(1) + "|Сообщество]";
                        }
                    }

                    string closed = (reportInfo["closed"] == "1") ? "да" : "нет";

                    string admin_url = "ожидает рассмотрения.";
                    if (reportInfo.ContainsKey("worker") && reportInfo["worker"] != "0")
                    {
                        if (settings.OWNER_IDS.ContainsKey(long.Parse(reportInfo["worker"])))
                        {
                            admin_url = "Администратор #" + settings.OWNER_IDS[long.Parse(reportInfo["worker"])].id;
                        }
                    }

                    string buttons = Vk.GenerateKeyboard(new string[] { "Взять на рассмотрение", "Диалог", "Закрыть", "Заблокировать" },
                        new string[] { "open " + reportInfo["id"], "getdialog " + reportInfo["id"], "close " + reportInfo["id"], "banreport " + name_url },
                        new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_RED }, new int[] { 0, 1, 2, 3 });

                    var time_close = "—";

                    if (reportInfo.ContainsKey("close_time") && reportInfo["close_time"] != "")
                    {
                        time_close = db.timeGetForMysql(reportInfo["close_time"]).ToString("g");
                    }

                    string close_id = reportInfo.ContainsKey("close_id") ? reportInfo["close_id"] : "—";
                    string last_activity = reportInfo.ContainsKey("last_activity") ? reportInfo["last_activity"] : "—";

                    text = text + "Отправитель: " + name_url + " (ID: " + reportInfo["from_id"] + ")" + "<br>" +
                        "Конференция: " + (reportInfo.ContainsKey("peer_id") ? reportInfo["peer_id"] : "—") + "<br>" +
                        "Закрыт? - " + closed + "<br>" +
                        "Закрыл - @id" + close_id + " в " + time_close + "<br>" +
                        "Рассматривает: " + admin_url + "<br>" +
                        "Последняя активность: " + last_activity + "<br><br>Посмотреть диалог: /getdialog " + reportInfo["id"];

                    Vk.MessagesSend(text, 1, 0, buttons);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getdialog()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_reports == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getdialog", 3))
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getdialog"]);
                    return;
                }

                var reportInfo = db.reportGet(long.Parse(args[0]), false);
                if (reportInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID тикета.");
                    return;
                }

                if (reportInfo["closed"] == "1")
                {
                    if (settings.OWNER_IDS[Vk.m_from_id].access_closed == 0)
                    {
                        Vk.MessagesSend("У вас нет доступа для просмотра закрытых тикетов.");
                        return;
                    }
                }

                var messages = db.reportMessagesGet(long.Parse(args[0]), 10);
                if (messages == null || messages.Count == 0)
                {
                    Vk.MessagesSend("В тикете нет сообщений.");
                    return;
                }
                string text = "Показаны последние " + messages.Count + " сообщений.<br><br>";
                string link_photo = "";
                long i_photo = 0;
                foreach (var item in messages)
                {

                    if (item["attachments"] == "1")
                    {
                        i_photo++;
                        var attachment = db.reportGetAttachmentMessId(long.Parse(args[0]), long.Parse(item["id"]));
                        if (attachment != null)
                        {

                            link_photo = link_photo + "," + attachment["type"] + attachment["photo_owner_id"] + "_" + attachment["photo_id"] + "_" + attachment["access_key"];
                        }
                    }
                    string sender = (item["is_worker"] == "1") ? "Админ" : "Клиент";
                    string att = (item["attachments"] == "1") ? "(🌅 " + i_photo + ")" : "";
                    text = text + item["date_created"] + " | " + sender + ": " + item["message"] + " " + att + "<br>";
                }
                text = text + "<br>Для отправки сообщения вам необходимо ввести команду /answer " + args[0] + ", либо нажать на кнопку ниже.";
                string buttons = Vk.GenerateKeyboard(new string[] { "Ответить", "Информация", "Закрыть", "Заблокировать" },
                        new string[] { "answer " + reportInfo["id"], "getreport " + reportInfo["id"], "close " + reportInfo["id"], "banreport id" + reportInfo["from_id"] },
                        new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_RED });
                if (link_photo != "")
                {
                    Vk.MessagesSend(text, 1, 0, buttons, true, link_photo);
                }
                else
                {
                    Vk.MessagesSend(text, 1, 0, buttons);
                }

                Cache.Set("report_target_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id, reportInfo, 20);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_closereport()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_answer == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "closereport", 3))
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["closereport"]);
                    return;
                }

                var reportInfo = db.reportGet(long.Parse(args[0]), false);
                if (reportInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID тикета.");
                    return;
                }

                if (reportInfo["closed"] != "0")
                {
                    MenuList menu = new(Cache);
                    if (menu.getMenuSelect(Vk.m_from_id) == (int)MenuList.ListMenu.ADMIN_ANSWER_REPORT)
                    {
                        menu.setMenuSelect(Vk.m_from_id, 0);
                        Vk.MessagesSend("Тикет уже закрыт.<br><br>Вы в диалоге с ботом. Сообщения больше не отправляются в тикет.");
                    }
                    else
                    {
                        Vk.MessagesSend("Тикет уже закрыт.");
                    }
                    return;
                }


                MenuList menut = new(Cache);
                if (menut.getMenuSelect(Vk.m_from_id) == (int)MenuList.ListMenu.ADMIN_ANSWER_REPORT)
                {
                    menut.setMenuSelect(Vk.m_from_id, 0);
                    Vk.MessagesSend("Тикет #" + reportInfo["id"] + " был закрыт.<br><br>Вы в диалоге с ботом. Сообщения больше не отправляются в тикет.");
                }
                else
                {
                    Vk.MessagesSend("Тикет #" + reportInfo["id"] + " был закрыт.");
                }
                long reportPeerId = reportInfo.ContainsKey("peer_id") ? long.Parse(reportInfo["peer_id"]) : 0;
                db.reportSetClose(long.Parse(reportInfo["id"]), 1, long.Parse(reportInfo["from_id"]), reportPeerId, Vk.m_from_id);


                //db.reportSetWorker(long.Parse(reportInfo["id"]), Vk.m_from_id);

                var buttons = Vk.GenerateKeyboard(new string[] { "1", "2", "3", "4", "5" },
                    new string[] { $"markrep {reportInfo["id"]} 1",
                    $"markrep {reportInfo["id"]} 2", $"markrep {reportInfo["id"]} 3", $"markrep {reportInfo["id"]} 4",
                    $"markrep {reportInfo["id"]} 5" }, new string[]
                    {
                        Vk.BUTTON_RED, Vk.BUTTON_RED, Vk.BUTTON_WHITE, Vk.BUTTON_BLUE, Vk.BUTTON_GREEN
                    }, new int[] { 0, 0, 1, 1, 1 }, false, true, true);

                if (reportPeerId != 0)
                {
                    Vk.MessagesSend("[id" + reportInfo["from_id"] + "|Ваш] тикет #" + reportInfo["id"] + " был закрыт Администратором.<br><br>Если у вас остались вопросы — " +
                        "откройте новый тикет командой '/report'.<br><br>Оцените ответ " +
                        "администратора от 1 до 5.", 0, reportPeerId, buttons, false);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_markrep()
        {
            try
            {


                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "markrep", 5))
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int", "int" });

                if (args[0] == "" || args[0] == null || args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend("Поставьте оценку.");
                    return;
                }

                var reportInfo = db.reportGet(long.Parse(args[0]), false);
                if (reportInfo == null)
                {
                    //Vk.MessagesSend("Введён неправильный ID тикета.");
                    return;
                }

                if (reportInfo["closed"] != "1" || reportInfo["from_id"] != Vk.m_from_id.ToString())
                {
                    if (reportInfo["from_id"] == Vk.m_from_id.ToString())
                    {
                        Vk.MessagesSend("Тикет ещё не закрыт.");
                    }
                    //Vk.MessagesSend("Тикет ещё не закрыт.");
                    return;
                }

                if (reportInfo.ContainsKey("mark") && reportInfo["mark"] != "-1")
                {
                    Vk.MessagesSend("Тикет уже оценён.");
                    return;
                }
                int mark = -1;
                try
                {
                    mark = int.Parse(args[1]);
                    if (mark >= 6)
                    {
                        mark = 5;
                    }
                    if (mark <= 0)
                    {
                        mark = 1;
                    }
                }
                catch
                {
                    Vk.MessagesSend("Укажите оценку.");
                    return;
                }

                db.reportSetMark(long.Parse(reportInfo["id"]), mark);
                if (reportInfo.ContainsKey("worker"))
                {
                    db.adminsAddMarkTicket(long.Parse(reportInfo["worker"]), mark);
                    Vk.MessagesSend("[id" + reportInfo["from_id"] + "|Пользователь] оценили тикет #" + reportInfo["id"] + $" на {mark}.", 0, long.Parse(reportInfo["worker"]));
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_openreport()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_answer == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "openreport", 3))
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["openreport"]);
                    return;
                }

                var reportInfo = db.reportGet(long.Parse(args[0]), false);
                if (reportInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID тикета.");
                    return;
                }

                if (reportInfo["closed"] == "1" && settings.OWNER_IDS[Vk.m_from_id].access_closed == 0)
                {
                    Vk.MessagesSend("Данный тикет уже закрыт.");
                    return;
                }

                if (reportInfo.ContainsKey("worker") && reportInfo["worker"] != "0" && settings.OWNER_IDS[Vk.m_from_id].access_closed == 0)
                {
                    Vk.MessagesSend("Данный тикет уже рассматривает Администратор №" + settings.OWNER_IDS[long.Parse(reportInfo["worker"])].id);
                    return;
                }

                db.reportSetClose(long.Parse(reportInfo["id"]), 0, long.Parse(reportInfo["from_id"]), Vk.m_peer_id, Vk.m_from_id);

                db.reportSetWorker(long.Parse(reportInfo["id"]), Vk.m_from_id, Vk.m_peer_id, long.Parse(reportInfo["from_id"]));
                db.adminsAddAnswer(Vk.m_from_id);

                reportInfo = db.reportGet(long.Parse(args[0]), false);
                if (reportInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID тикета.");
                    return;
                }

                Vk.MessagesSend("Тикет #" + reportInfo["id"] + $" был взят на рассмотрение.<br>Для получения диалога используйте /getdialog " + reportInfo["id"]);
                if (reportInfo.ContainsKey("peer_id"))
                {
                    Vk.MessagesSend("[id" + reportInfo["from_id"] + "|Ваш] тикет #" + reportInfo["id"] + " был взят на рассмотрение Администратором №"
                        + settings.OWNER_IDS[Vk.m_from_id].id + ".<br><br>" +
                        "Ответ на тикет придёт в эту беседу как только Администратор ответит на него.", 0, long.Parse(reportInfo["peer_id"]), "", false);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void send_answer()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_answer == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "answer_system", 2))
                {
                    return;
                }

                if (Vk.m_text == "")
                {
                    MenuList menu = new(Cache);
                    menu.setMenuSelect(Vk.m_from_id, 0);
                    Vk.MessagesSend("Вы вернулись обратно в диалог с ботом. Сообщения больше не отправляются в тикет. Не забудьте закрыть его (/close)");
                    return;
                }

                var reportInfo = Cache.Get<Dictionary<string, string>>("report_target_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id);

                if (reportInfo == null || reportInfo["id"] == "")
                {
                    MenuList menu = new(Cache);
                    menu.setMenuSelect(Vk.m_from_id, 0);
                    Vk.MessagesSend("Вы вернулись обратно в диалог с ботом. Сообщения больше не отправляются в тикет. Не забудьте закрыть его (/close)");
                    return;
                }
                var lower = Vk.m_text.ToLower();
                if (lower == "exit" || lower == "/exit" || lower == "/answer" || lower == "answer")
                {
                    MenuList menu = new(Cache);
                    menu.setMenuSelect(Vk.m_from_id, 0);
                    Vk.MessagesSend("Вы вернулись обратно в диалог с ботом. Сообщения больше не отправляются в тикет. Не забудьте закрыть его (/close)");
                    return;
                }

                if (reportInfo["closed"] != "0" && settings.OWNER_IDS[Vk.m_from_id].access_closed == 0)
                {
                    MenuList menu = new(Cache);
                    menu.setMenuSelect(Vk.m_from_id, 0);
                    Vk.MessagesSend("Данный тикет уже закрыт." +
                        "<br><br>Вы вернулись обратно в диалог с ботом. Сообщения больше не отправляются в тикет. Не забудьте закрыть его (/close)");
                    return;
                }

                string text = "";
                string worker = reportInfo.ContainsKey("worker") ? reportInfo["worker"] : "0";
                if (worker == "0" && reportInfo["closed"] == "0")
                {
                    // взят на рассмотрение
                    db.reportSetWorker(long.Parse(reportInfo["id"]), Vk.m_from_id, Vk.m_peer_id, long.Parse(reportInfo["from_id"]));
                    text = "Вы взяли данный тикет на рассмотрение.<br><br>";
                    //db.adminsSetFieldSettings(Vk.m_from_id, "answers", "answers + 1");
                    db.adminsAddAnswer(Vk.m_from_id);
                }

                else if (worker != "0" && reportInfo["closed"] != "0" && settings.OWNER_IDS[Vk.m_from_id].access_closed == 0 && worker != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Данный тикет уже рассматривает Администратор №" + settings.OWNER_IDS[long.Parse(worker)].id);
                    return;
                }
                if (worker != "0" && settings.OWNER_IDS[Vk.m_from_id].access_closed == 0 && worker != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Данный тикет уже рассматривает Администратор №" + settings.OWNER_IDS[long.Parse(worker)].id);
                    return;
                }

                string buttons = Vk.GenerateKeyboard(new string[] { "Выйти", "Закрыть" },
                        new string[] { "answer", "close " + reportInfo["id"] },
                        new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_GREEN });
                Vk.MessagesSend(text + "Тикет #" + reportInfo["id"] + $" был обновлён, сообщение было отправлено.<br>" +
                    "Вы ещё находитесь в диалоге с пользователем. Все сообщения будут отправлены в тикет.<br><br>" +
                    "Для выхода используйте /answer или /exit", 1, 0, buttons);

                string admin_url;
                if (settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    admin_url = "Администратора #" + settings.OWNER_IDS[Vk.m_from_id].id;
                }
                else
                {
                    admin_url = "Модератора";
                }

                if (reportInfo.ContainsKey("peer_id"))
                {
                    Vk.MessagesSend("———————————————<br>" +
                        "[id" + reportInfo["from_id"] + "|Ваш] тикет #" + reportInfo["id"] + " был обновлен.<br><br>" +
                        "💭 Сообщение " + admin_url + ":<br>" + Vk.m_text + "<br><br>" +
                        "Ваш тикет всё ещё открыт. Если вы хотите отправить сообщение — используйте команду /report<br>" +
                        "———————————————", 0, long.Parse(reportInfo["peer_id"]), "", false);
                }

                db.reportAddMessage(long.Parse(reportInfo["id"]), Vk.m_from_id, 0, Vk.m_text, true);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_answer()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_answer == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "answer", 5))
                {
                    return;
                }

                MenuList menu = new(Cache);
                if (menu.getMenuSelect(Vk.m_from_id) == (int)MenuList.ListMenu.ADMIN_ANSWER_REPORT)
                {
                    menu.setMenuSelect(Vk.m_from_id, 0);
                    var reportInfoTarget = Cache.Get<Dictionary<string, string>>("report_target_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id);
                    if (reportInfoTarget == null)
                    {
                        Vk.MessagesSend("Вы вернулись обратно в диалог с ботом. Сообщения больше не отправляются в тикет. Не забудьте закрыть его (/close)");
                        return;
                    }
                    else
                    {
                        string buttonstwo = Vk.GenerateKeyboard(new string[] { "Закрыть" },
                        new string[] { "close " + reportInfoTarget["id"] },
                        new string[] { Vk.BUTTON_GREEN });
                        Vk.MessagesSend("Вы вернулись обратно в диалог с ботом. Сообщения больше не отправляются в тикет. Не забудьте закрыть его (/close)", 1, 0, buttonstwo);
                        return;
                    }
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["answer"]);
                    return;
                }

                var reportInfo = db.reportGet(long.Parse(args[0]), false);
                if (reportInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID тикета.");
                    return;
                }

                string worker = reportInfo.ContainsKey("worker") ? reportInfo["worker"] : "0";
                if (worker != "0" && reportInfo["closed"] == "1" && settings.OWNER_IDS[Vk.m_from_id].access_closed == 0 && worker != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Данный тикет уже рассматривает Администратор №" + settings.OWNER_IDS[long.Parse(worker)].id);
                    return;
                }
                if (worker != "0" && settings.OWNER_IDS[Vk.m_from_id].access_closed == 0 && worker != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Данный тикет уже рассматривает Администратор №" + settings.OWNER_IDS[long.Parse(worker)].id);
                    return;
                }

                Cache.Set("report_target_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id, reportInfo, 20);

                string buttons = Vk.GenerateKeyboard(new string[] { "Выйти" },
                        new string[] { "answer" },
                        new string[] { Vk.BUTTON_GREEN });

                Vk.MessagesSend("Вы перемещены в диалог с пользователем. Все последующие ваши сообщения будут отправлены в диалог тикета." +
                    "<br><br>Для отмены вам необходимо либо нажать на кнопку, либо ввести команду /exit", 1, 0, buttons);
                menu.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.ADMIN_ANSWER_REPORT);
                //Vk.MessagesSend("Тикет #" + reportInfo["id"] + " был обновлён, сообщение было отправлено.");
                /*
                string admin_url;
                if (settings.OWNER_IDS.ContainsKey(long.Parse(reportInfo["worker"])))
                {
                    admin_url = "Администратора #" + settings.OWNER_IDS[long.Parse(reportInfo["worker"])];
                }
                else
                {
                    admin_url = "Модератора";
                }
                Vk.MessagesSend("[id" + reportInfo["from_id"] + "|Ваш] тикет #" + reportInfo["id"] + " был обновлён.<br><br>" +
                    "Сообщение " + admin_url + ":<br>" + args[1], 0, long.Parse(reportInfo["peer_id"]), "", false);

                db.reportAddMessage(long.Parse(reportInfo["id"]), Vk.m_from_id, 0, args[1], true);*/
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }


        public async void command_banreport()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_banreport == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "banreport", 3))
                {
                    return;
                }

                Dictionary<string, string> reasons = new Dictionary<string, string>()
                {
                    { "1", "Оффтоп (сообщения не по теме)" },
                    { "2", "Оскорбление модерации / бота" },
                    { "3", "Обман (заведомо ложное сообщение)" },
                    { "4", "Оскорбление / упоминание родных" }
                };

                string textReasons = "";
                foreach (var item in reasons)
                {
                    textReasons += item.Key + " — " + item.Value + "<br>";
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "int" });

                if (args[0] == "" || args[0] == null)//|| args[0] == "553227510"
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["banreport"] + "<br><br>Причины блокировок:<br>" + textReasons);
                    return;
                }



                var userInfo = db.usersGetUser(long.Parse(args[0]));
                if (userInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID пользователя.");
                    return;
                }

                var targetBan = db.BanreportsGetBan(long.Parse(args[0]));
                if (targetBan != null)
                {
                    var NickAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(targetBan["admin_id"]) });
                    string textBan = $"Заблокировал: {NickAdmin[targetBan["admin_id"]]}<br>" +
                        $"Блокировка до: {targetBan["date_unban"]}<br>" +
                        $"Причина: {targetBan["reason"]}<br>" +
                        $"Всего блокировок у пользователя: {db.BanreportsGetAllBansCount(long.Parse(args[0]))}<br>" +
                        $"<br>Блокировка выдана {targetBan["date_created"]}.";
                    Vk.MessagesSend("Указанный пользователь уже имеет блокировку репорта.<br><br>" + textBan);
                    return;
                }

                if (args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["banreport"] + "<br><br>Причины блокировок:<br>" + textReasons);
                    return;
                }


                if (!reasons.ContainsKey(args[1]))
                {
                    Vk.MessagesSend("Указанной причины не существует. Укажите ID причины.<br><br>Список причин:<br>" + textReasons);
                    return;
                }

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });
                string name_url = "[id" + args[0] + "|Пользователь]";
                if (vkInfo.ContainsKey("id" + args[0]))
                {
                    name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                        vkInfo["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }

                int backBans = db.BanreportsGetAllBansCount(long.Parse(args[0]));

                DateTimeOffset currentBanTime = DateTimeOffset.Now;
                DateTimeOffset nextBanTime = DateTimeOffset.Now;

                if (backBans == 0)
                {
                    currentBanTime = DateTimeOffset.Now.AddHours(12);
                    nextBanTime = DateTimeOffset.Now.AddHours(24);
                }
                else if (backBans == 1)
                {
                    currentBanTime = DateTimeOffset.Now.AddHours(24);
                    nextBanTime = DateTimeOffset.Now.AddDays(2);
                }
                else if (backBans == 2)
                {
                    currentBanTime = DateTimeOffset.Now.AddDays(2);
                    nextBanTime = DateTimeOffset.Now.AddDays(5);
                }
                else if (backBans == 3)
                {
                    currentBanTime = DateTimeOffset.Now.AddDays(5);
                    nextBanTime = DateTimeOffset.Now.AddDays(7);
                }
                else if (backBans == 4)
                {
                    currentBanTime = DateTimeOffset.Now.AddDays(7);
                    nextBanTime = DateTimeOffset.Now.AddDays(14);
                }
                else if (backBans >= 5)
                {
                    currentBanTime = DateTimeOffset.Now.AddDays(14);
                    nextBanTime = DateTimeOffset.Now.AddDays(28);
                }

                long adm_id = Vk.m_from_id;

                string buttons = Vk.GenerateKeyboard(new string[] { "Отмена" },
                        new string[] { "unbanreport " + name_url },
                        new string[] { Vk.BUTTON_GREEN });

                string targetTextSend = $"{name_url} больше не сможет отправлять тикеты.<br>" +
                    $"Блокировка выдана до: {currentBanTime.ToString("g")}<br>" +
                    $"Указанная причина: {args[1]} - {reasons[args[1]]}<br><br>" +
                    $"Следующая блокировка будет до: {nextBanTime.ToString("g")}." +
                    $"<br><br>Всего блокировок репорта: {db.BanreportsGetAllBansCount(long.Parse(args[0]))}.";

                Vk.MessagesSend(targetTextSend,
                    1, 0, buttons);

                var NickAdmin1 = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                string textBan1 = $"Вы получили блокировку отправки тикетов.<br><br>" +
                    $"Заблокировал: {NickAdmin1[Vk.m_from_id.ToString()]}<br>" +
                    $"Блокировка до: {currentBanTime.ToString("g")}<br>" +
                    $"Причина: {args[1]} - {reasons[args[1]]}<br>" +
                    $"Следующая блокировка будет до: {nextBanTime.ToString("g")}<br>" +
                    $"<br>Блокировка выдана {DateTimeOffset.Now.ToString("g")}." +
                    $"<br>Если вы не согласны с наказанием - обжалуйте в обсуждениях нашей группы.";
                Vk.MessagesSend(textBan1, 0, long.Parse(args[0]));

                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_BANREPORT, Vk.m_from_id, long.Parse(args[0]), "заблокировал репорт");
                //db.usersSetBanReport(long.Parse(args[0]), adm_id);

                db.BanreportsAddBan(long.Parse(args[0]), Vk.m_from_id, $"{args[1]} - {reasons[args[1]]}", db.timeGetForString(currentBanTime));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_unbanreport()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_unbanreport == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "unbanreport", 3))
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["unbanreport"]);
                    return;
                }

                var userInfo = db.usersGetUser(long.Parse(args[0]));
                if (userInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID пользователя.");
                    return;
                }

                var banInfo = db.BanreportsGetBan(long.Parse(args[0]));
                if (banInfo == null)
                {
                    Vk.MessagesSend("Указанный пользователь не заблокирован.");
                    return;
                }



                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });
                string name_url = "[id" + args[0] + "|Пользователь]";
                if (vkInfo.ContainsKey("id" + args[0]))
                {
                    name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                        vkInfo["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }

                string buttons = Vk.GenerateKeyboard(new string[] { "Отмена" },
                        new string[] { "banreport " + name_url },
                        new string[] { Vk.BUTTON_RED });

                Vk.MessagesSend(name_url + " теперь сможет отправлять тикеты.", 1, 0, buttons);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_UNBANREPORT, Vk.m_from_id, long.Parse(args[0]), "разблокировал репорт");
                db.BanreportsSetBanNonActive(long.Parse(args[0]));
                db.BanreportsGetBan(long.Parse(args[0]), true);

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        /*public async void command_banreports()
        {
            //

            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_banreport == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "banreports", 3))
                {
                    return;
                }

                var bans = db.reportBansGetAll();

                var userInfo = db.usersGetUser(long.Parse(args[0]));
                if (userInfo == null)
                {
                    Vk.MessagesSend("Введён неправильный ID пользователя.");
                    return;
                }

                if (userInfo["ban_report"] == "0")
                {
                    Vk.MessagesSend($"Пользователь уже может отправить репорты.");
                    return;
                }

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });
                string name_url = "[id" + args[0] + "|Пользователь]";
                if (vkInfo.ContainsKey("id" + args[0]))
                {
                    name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                        vkInfo["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }

                string buttons = Vk.GenerateKeyboard(new string[] { "Отмена" },
                        new string[] { "banreport " + name_url },
                        new string[] { Vk.BUTTON_RED });

                Vk.MessagesSend(name_url + " теперь сможет отправлять тикеты.", 1, 0, buttons);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_UNBANREPORT, Vk.m_from_id, long.Parse(args[0]), "разблокировал репорт");
                db.usersSetBanReport(long.Parse(args[0]), 0);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
        */
        public async void command_getstats()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getbotstats == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getbotstats", 300))
                {
                    return;
                }
                List<string>? list_for_sync = Cache.Get<List<string>>("list_stats");
                if (list_for_sync == null || list_for_sync.Count <= 0)
                {
                    Vk.MessagesSend("За текущий период не было активных конференций.");
                    return;
                }
                //Console.WriteLine("SEND STAT");
                string key_sync = "";
                for (int i = 0; i < list_for_sync.Count; i++)
                {
                    key_sync = list_for_sync[i];
                    Dictionary<string, Dictionary<string, long>>? result = Cache.Get<Dictionary<string, Dictionary<string, long>>>(key_sync);

                    if (result == null || result.Count() <= 0)
                    {
                        continue;
                    }

                    await Parallel.ForEachAsync(result, async (res, token) =>
                    {
                        try
                        {
                            Database dbh = new(Cache);
                            Dictionary<string, long>? result_db = null;
                            var split_key = key_sync.Split("_");
                            if (split_key.Length == 3 && split_key[2] != null)
                            {
                                result_db = dbh.statsGetStatForBDDay(long.Parse(res.Value["peer_id"].ToString()), res.Key, long.Parse(split_key[2]));
                            }
                            else
                            {
                                result_db = dbh.statsGetStatForBDDay(long.Parse(res.Value["peer_id"].ToString()), res.Key);
                            }
                            if (res.Value["user_id"] == null || res.Value["user_id"] == 0)
                            {
                                res.Value["user_id"] = -1;
                            }
                            if (result_db != null)
                            {
                                res.Value["messages"] += result_db["messages"];
                                res.Value["commands"] += result_db["commands"];
                                res.Value["words"] += result_db["words"];
                                res.Value["obscen_words"] += result_db["obscen_words"];
                                res.Value["symbols"] += result_db["symbols"];
                                res.Value["voices"] += result_db["voices"];
                                res.Value["photos"] += result_db["photos"];
                                res.Value["videos"] += result_db["videos"];
                                res.Value["audios"] += result_db["audios"];
                                res.Value["posts"] += result_db["posts"];
                                res.Value["stickers"] += result_db["stickers"];
                                res.Value["smiles"] += result_db["smiles"];
                                dbh.statsUpdateDb(long.Parse(res.Value["peer_id"].ToString()), res.Key,
                                    res.Value["messages"].ToString(), res.Value["words"].ToString(), res.Value["obscen_words"].ToString(), res.Value["symbols"].ToString(),
                                    res.Value["voices"].ToString(), res.Value["photos"].ToString(), res.Value["videos"].ToString(), res.Value["audios"].ToString(),
                                    res.Value["posts"].ToString(), res.Value["stickers"].ToString(), res.Value["smiles"].ToString(), res.Value["commands"].ToString(),
                                    res.Value["user_id"].ToString());
                            }
                            else
                            {
                                dbh.statsInsert(long.Parse(res.Value["peer_id"].ToString()), res.Key,
                                    res.Value["messages"].ToString(), res.Value["words"].ToString(), res.Value["obscen_words"].ToString(), res.Value["symbols"].ToString(),
                                    res.Value["voices"].ToString(), res.Value["photos"].ToString(), res.Value["videos"].ToString(), res.Value["audios"].ToString(),
                                    res.Value["posts"].ToString(), res.Value["stickers"].ToString(), res.Value["smiles"].ToString(), res.Value["commands"].ToString(),
                                    res.Value["user_id"].ToString());
                            }
                            //Thread.Sleep(10);
                        }
                        catch
                        {
                            Console.WriteLine("error for update cache statistics");
                        }
                    });

                    Cache.Delete(key_sync);
                }
                list_for_sync.Clear();
                Cache.Delete("list_stats");
                DateTimeOffset current_time = DateTimeOffset.Now;
                string key_day = current_time.Year.ToString() + "_" + current_time.Month.ToString() + "_" + current_time.Day.ToString();
                var result_day = db.statsGetActualStatBd(key_day);
                string text = "Информация за " + current_time.ToString("g") + "<br><br>";
                long all_conferences = 0;
                long messages = 0;
                long commands = 0;
                long symbols = 0;
                long words = 0;
                long obscen_words = 0;
                long voices = 0;
                long photos = 0;
                long videos = 0;
                long audios = 0;
                long posts = 0;
                long stickers = 0;
                long smiles = 0;
                long max_peer = 0;
                long max_messages = 0;
                List<long> sendIds = new();
                foreach (var item in settings.OWNER_IDS)
                {
                    sendIds.Add(item.Key);
                }
                if (result_day == null)
                {
                    Vk.MessagesSend(text + "За текущий период не было активных конференций.");
                    return;
                }

                all_conferences = result_day.Count();
                foreach (var item in result_day)
                {
                    messages += item["messages"];
                    if (item["messages"] > max_messages)
                    {
                        max_messages = item["messages"];
                        max_peer = item["peer_id"];
                    }
                    commands += item["commands"];
                    words += item["words"];
                    obscen_words += item["obscen_words"];
                    voices += item["voices"];
                    photos += item["photos"];
                    videos += item["videos"];
                    audios += item["audios"];
                    posts += item["posts"];
                    stickers += item["stickers"];
                    smiles += item["smiles"];
                    symbols += item["symbols"];
                }
                bool result_dbu = await Commands.syncOnePeer(max_peer);
                var max_peer_info = db.peersGetPeer(max_peer);

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(max_peer_info["owner"]) });
                string name_url = "[id" + max_peer_info["owner"] + "|Пользователь]";
                if (vkInfo.ContainsKey("id" + max_peer_info["owner"]))
                {
                    name_url = "[id" + max_peer_info["owner"] + "|" + vkInfo["id" + max_peer_info["owner"]].first_name + " " +
                        vkInfo["id" + max_peer_info["owner"]].last_name + "]";
                }
                else
                {
                    if (long.Parse(max_peer_info["owner"]) < 0)
                    {
                        name_url = "[club" + max_peer_info["owner"].Substring(1) + "|Сообщество]";
                    }
                }

                long peer_count = db.peersGetCount();

                var percent_smiles = (smiles > 0 && symbols > 0) ? $"{Math.Round(decimal.Parse(smiles.ToString()) / decimal.Parse(symbols.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_nosmile = (smiles > 0 && symbols > 0) ? $"{Math.Round(decimal.Parse((symbols - smiles).ToString()) / decimal.Parse(symbols.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_words = (words > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(words.ToString()) / decimal.Parse(messages.ToString()), 1)}"
                    : "—";
                var percent_wordssymbols = (symbols > 0 && messages > 0) ? $"{Math.Round(decimal.Parse((symbols - smiles).ToString()) / decimal.Parse(words.ToString()), 1)}"
                    : "—";

                var percent_obwords = (obscen_words > 0 && words > 0) ? $"{Math.Round(decimal.Parse(obscen_words.ToString()) / decimal.Parse(words.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_cmds = (commands > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(commands.ToString()) / decimal.Parse(messages.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_voices = (voices > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(voices.ToString()) / decimal.Parse(messages.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_photos = (photos > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(photos.ToString()) / decimal.Parse(messages.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_videos = (videos > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(videos.ToString()) / decimal.Parse(messages.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_audios = (audios > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(audios.ToString()) / decimal.Parse(messages.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_posts = (posts > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(posts.ToString()) / decimal.Parse(messages.ToString()) * 100m, 2)}%"
                    : "—";
                var percent_stickers = (stickers > 0 && messages > 0) ? $"{Math.Round(decimal.Parse(stickers.ToString()) / decimal.Parse(messages.ToString()) * 100m, 2)}%"
                    : "—";


                text = text + "Всего сообщений было обработано: " + messages + "<br>" +
                    $"Всего символов: " + symbols + "<br>" +
                    $"Из них смайлов: " + smiles +
                    $" ({percent_smiles})<br>" +
                    $"Без смайлов: " + (symbols - smiles).ToString() +
                    $" ({percent_nosmile})<br><br>" +

                    "Всего слов: " + words + "<br>" +
                    $"(по '{percent_words}' слова в сообщении," +
                    $" каждое по '{percent_wordssymbols}' символов)<br><br>" +

                    "Нецензурных слов: " + obscen_words +
                    $" ({percent_obwords})<br>" +
                    "Команд: " + commands +
                    $" ({percent_cmds})<br>" +
                    "Голосовых сообщений: " + voices +
                    $" ({percent_voices})<br>" +
                    "Фотографий: " + photos +
                    $" ({percent_photos})<br>" +
                    "Видео: " + videos +
                    $" ({percent_videos})<br>" +
                    "Аудизаписей: " + audios +
                    $" ({percent_audios})<br>" +
                    "Постов: " + posts +
                    $" ({percent_posts})<br>" +
                    "Стикеров: " + stickers +
                    $" ({percent_stickers})<br>" +

                    "Бесед было активно: " + all_conferences + "<br><br>" +
                    "Самая активная конференция:<br>" +
                    "#" + max_peer + " | " + max_messages + " сообщений.<br>" +
                    "'" + max_peer_info["title"] + "' | Владелец: " + name_url + "<br>" +
                    "<br>Максимальное кол-во запросов в секунду: " + AdminInfo.rps_max + "<br>" +
                    "Max RPS было: " + AdminInfo.rps_max_date + "<br><br>" +
                    "Всего конференций зарегистрировано: " + peer_count;

                Vk.MessagesSend(text);
                /*List<long> datas = new()
                {
                    commands, words, obscen_words, voices, photos, videos, audios, posts, stickers, smiles
                };*/
                /*Chart qc = new Chart();

                qc.Width = 1280;
                qc.Height = 720;
                List<string> labels = new();
                List<long> datas = new();
                if (commands >= 1)
                {
                    labels.Add("Команды");
                    datas.Add(commands);
                }
                if (words >= 1)
                {
                    //labels.Add("Слова");
                    //datas.Add(words);
                }
                if (obscen_words >= 1)
                {
                    labels.Add("Нецензурная лексика");
                    datas.Add(obscen_words);
                }
                if (photos >= 1)
                {
                    labels.Add("Фотографии");
                    datas.Add(photos);
                }
                if (videos >= 1)
                {
                    labels.Add("Видеозаписи");
                    datas.Add(videos);
                }
                if (audios >= 1)
                {
                    labels.Add("Аудиозаписи");
                    datas.Add(audios);
                }
                if (posts >= 1)
                {
                    labels.Add("Посты");
                    datas.Add(posts);
                }
                if (stickers >= 1)
                {
                    labels.Add("Стикеры");
                    datas.Add(stickers);
                }
                if (smiles >= 1)
                {
                    labels.Add("Эмодзи");
                    datas.Add(smiles);
                }
                qc.Config = @"{
    type:'doughnut',
    data: {
            labels:" + JsonConvert.SerializeObject(labels) + @",
            datasets: [{
                data: " + JsonConvert.SerializeObject(datas) + @"
            }] },
    options: {
        plugins: {
            doughnutlabel: {
                labels: [{text:'" + messages + @" сообщений',font:{size:40}},{text:'всего'}]
            }
        }
    }
}";
                qc.ToFile("result_sync.png");*/
                var Series = new List<LiveChartsCore.ISeries>();
                if (commands >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { commands },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        // for more information about available positions see:
                        // https://lvcharts.com/api/2.0.0-beta.300/LiveChartsCore.Measure.PolarLabelsPosition
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " команд"
                    });
                }
                if (words >= 1)
                {
                    //labels.Add("Слова");
                    //datas.Add(words);
                }
                if (voices >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { voices },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " голосовых"
                    });
                }
                if (obscen_words >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { obscen_words },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " нецензурных слов"
                    });
                }
                if (photos >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { photos },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " фотографий"
                    });
                }
                if (videos >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { videos },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " видеозаписей"
                    });
                }
                if (audios >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { audios },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " аудиозаписей"
                    });
                }
                if (posts >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { posts },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " постов"
                    });
                }
                if (stickers >= 1)
                {
                    Series.Add(new PieSeries<long>
                    {
                        Values = new List<long> { stickers },
                        DataLabelsPaint = new SolidColorPaint(SKColors.Black),
                        DataLabelsSize = 50,
                        DataLabelsPosition = LiveChartsCore.Measure.PolarLabelsPosition.Middle,
                        DataLabelsFormatter = point => point.PrimaryValue.ToString("N2") + " стикеров"
                    });
                }
                if (smiles >= 1)
                {
                    //labels.Add("Эмодзи");
                    //datas.Add(smiles);
                }
                var pieChart = new SKPieChart
                {

                    Width = 1920,
                    Height = 1280,
                    Series = Series
                };

                pieChart.SaveImage("result_sync.png");
                var result_photo = await Vk.PostPhotoForPeer(Vk.m_peer_id, "result_sync.png", "result_sync.png");
                string att = "";
                if (result_photo != null)
                {
                    att = "photo" + result_photo["owner_id"] + "_" + result_photo["id"] + "_" + result_photo["access_key"];
                    Vk.MessagesSend("Инфографическая схема", 0, 0, "", true, att);
                }
                //Commands.syncAllPeers(db);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_async()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_getbotstats == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "async", 3))
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["async"]);
                    return;
                }

                if (args[0] == "-1")
                {
                    Vk.MessagesSend("Синхронизация началась.. Пожалуйста, подождите..");
                    //Commands com = new(Vk, db, settings, Cache);
                    await Commands.syncAllPeers(db, Vk.m_peer_id);
                    Vk.MessagesSend("Синхронизация успешно закончилась.");
                    return;
                }
                else
                {
                    Vk.MessagesSend("Синхронизация началась.. Пожалуйста, подождите..");
                    //Commands com = new(Vk, db, settings, Cache);
                    await Commands.syncOnePeer(long.Parse(args[0]));
                    var peerInfo = db.peersGetPeer(long.Parse(args[0]), true);
                    var activation = (peerInfo["active"] == "0") ? "не активна" : "активна";

                    var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(peerInfo["owner"]) });
                    string name_url = "[id" + peerInfo["owner"] + "|Пользователь]";
                    if (vkInfo.ContainsKey("id" + peerInfo["owner"]))
                    {
                        name_url = "[id" + peerInfo["owner"] + "|" + vkInfo["id" + peerInfo["owner"]].first_name + " " +
                            vkInfo["id" + peerInfo["owner"]].last_name + "]";
                    }
                    else
                    {
                        if (long.Parse(peerInfo["owner"]) < 0)
                        {
                            name_url = "[club" + peerInfo["owner"].Substring(1) + "|Сообщество]";
                        }
                    }

                    Vk.MessagesSend($"Беседа '{peerInfo["title"]}' была успешно синхронизирована. Владелец: " + name_url +
                        $" | Участников: {peerInfo["current_members"]} | Статус: {activation}");
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sysrole()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_sysrole == 0)
                {
                    return;
                }

                if (settings.isUserChat(Vk.m_peer_id))
                {
                    Vk.MessagesSend("Данную команду можно использовать только в конференциях.");
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "sysrole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[1] != "" && args[1] != "")
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysrole"]);
                    return;
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nickname;
                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }


                string[] args_role = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "int" });
                int target_role_priority = -1;
                if (args_role[0] == null || args_role[0] == "")
                {
                    string[] args_roletext = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "text" });
                    if (args_roletext[0] == null || args_roletext[0] == "")
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["sysrole"]);
                        return;
                    }
                    var roles = db.peerGetRoles(Vk.m_peer_id);
                    args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                    foreach (var item in roles)
                    {
                        var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (args_roletext[0] == name_role)
                        {
                            target_role_priority = item.Value.priority;
                            break;
                        }
                    }
                    if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                    {
                        target_role_priority = 20;
                    }
                    else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                    {
                        target_role_priority = 40;
                    }
                    else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                    {
                        target_role_priority = 60;
                    }
                    else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                        args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                        args_roletext[0] == "spec" || args_roletext[0] == "lead")
                    {
                        target_role_priority = 80;
                    }
                    else if (args_roletext[0] == "owner" || args_roletext[0] == "владелец")
                    {
                        target_role_priority = 100;
                    }
                }
                else
                {
                    if (long.Parse(args_role[0]) > 100 || long.Parse(args_role[0]) <= -1)
                    {
                        Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                        return;
                    }
                    target_role_priority = int.Parse(args_role[0]);
                }

                if (target_role_priority <= -1)
                {

                    Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                    return;
                }
                string text;
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    if (long.Parse(Target_User["priority"]) == target_role_priority)
                    {
                        Vk.MessagesSend(nickname + " уже имеет данную роль.");
                        return;
                    }
                    var old_name = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                    text = nickname + " получил новую роль." + "<br><br>" +
                    "Название: " + db.rolesGetName(Vk.m_peer_id, target_role_priority.ToString()) + "<br>" +
                    "Выдал: Системный Администратор<br>" +
                    "Предыдущая роль: " + old_name;
                }
                else
                {
                    text = nickname + " получил новую роль." + "<br>" +
                    "Название: " + db.rolesGetName(Vk.m_peer_id, target_role_priority.ToString()) + "<br>" +
                    "Выдал: Системный Администратор";
                }

                Vk.MessagesSend(text);
                db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), target_role_priority);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sysban()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_sysban == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "sysban", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[1] != null && args[1] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysban"]);
                    return;
                }

                if (Target_User == null || args[0] == "721663584" || args[0] == "553227510")
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                var banInfo = db.BotBansGetBan(long.Parse(args[0]));
                if (banInfo != null && banInfo["user_id"] != null)
                {
                    Vk.MessagesSend("Данный пользователь уже заблокирован.");
                    return;
                }

                long days = 0;
                string reason = "не указана.";

                long type = 1;

                string[] sas_argse = await cmdChecker.getArguments("/ban " + args[1], new string[] { "int", "text" });
                // тип, дни-причина
                if (sas_argse[0] != null && long.Parse(sas_argse[0]) >= 1)
                {
                    type = long.Parse(sas_argse[0]);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysban"]);
                    return;
                }


                string[] sas_args = await cmdChecker.getArguments("/ban " + sas_argse[1], new string[] { "int", "text" });



                if (sas_args[0] != null && sas_args[0] != "")
                {
                    //дни
                    string ss = sas_args[0];
                    if (Char.IsNumber(ss, 0) || sas_args[0] == "-1")
                    {
                        days = long.Parse(sas_args[0]);
                        if (days >= 365 || days <= 0)
                        {
                            days = 0;
                        }

                        if (sas_args[1] != null && sas_args[1] != "")
                        {
                            reason = sas_args[1];
                        }
                    }
                    else
                    {
                        reason = sas_args[0];
                    }
                }
                else
                {
                    string[] sas_args22 = await cmdChecker.getArguments("/ban " + sas_argse[1], new string[] { "text" });
                    if (sas_args22[0] != null && sas_args22[0] != "")
                    {
                        reason = sas_args22[0];
                    }
                }


                string ban_time = null;
                string ban_text = "перманентно";
                if (days != 0)
                {
                    ban_time = db.timeGetForString(DateTimeOffset.Now.AddDays(days));
                    ban_text = "до " + DateTimeOffset.Now.AddDays(days).ToString("g");
                }

                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                string name_two = await Vk.GetUrlName(long.Parse(args[0]), "gen");

                var buttons = Vk.GenerateKeyboard(new string[] { "Разблокировать" }, new string[] { "sysunban id" + args[0] }, new string[] { Vk.BUTTON_GREEN });

                if (type == 4)
                {
                    Vk.MessagesSend(name_one + " пометил " + name_two + " как страничного бота.<br><br>" +
                    "Теперь он не сможет использовать некоторые команды.", 1, 0, buttons);
                }
                else if (type == 5)
                {
                    Vk.MessagesSend(name_one + " пометил " + name_two + " как сливера бесед.<br><br>" +
                    "Теперь он не сможет использовать команды /ban /warn и /kick.", 1, 0, buttons);
                }
                else
                {
                    Vk.MessagesSend(name_one + " заблокировал доступ к боту " + name_two + "<br><br>" +
                    "Теперь он не сможет взаимодействовать с ботом.", 1, 0, buttons);
                }



                db.BotBansAddBan(long.Parse(args[0]), type, Vk.m_from_id, reason, ban_time);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_SYSBAN, Vk.m_from_id, long.Parse(args[0]), "заблокировал", reason, ban_text);

                long target_id = long.Parse(args[0]);


                var ids = db.peerGetPeersWhereMembers(target_id);
                name_one = await Vk.GetUrlName(target_id, "nom");
                if (ids != null && ids.Count >= 1)
                {
                    foreach (var item in ids)
                    {
                        if (type == 1)
                        {
                            var member = db.peersGetMember(item, target_id, false, false);
                            if (member != null)
                            {
                                if (member["leave_peer"] == "0")
                                {
                                    Vk.MessagesSend(name_one + " находится в чёрном списке бота, он(а) исключен(а) из соображений безопасности.<br><br>" +
                                "Обратите внимание, обратное добавление этого пользователя в беседу будет расценено как подозрительное действие," +
                                " приглашающий участник будет исключен.", 0, item);
                                    Vk.KickUser(item, target_id);
                                    db.peersDeleteMember(item, target_id);
                                }
                            }
                        }
                        else if (type == 2)
                        {
                            var member = db.peersGetMember(item, target_id, false, false);
                            if (member != null)
                            {
                                if (member["leave_peer"] == "0")
                                {
                                    Vk.MessagesSend(name_one + " находится в чёрном списке бота.<br><br>" +
                                    "Обратите внимание, при дальнейшем нахождении этого пользователя в конференции — вы подвергаете свою беседу опасности, " +
                                    "а бот не будет реагировать на команды данного пользователя.", 0, item);
                                    Vk.KickUser(item, target_id);
                                    db.peersDeleteMember(item, target_id);
                                }
                            }

                        }
                        else if (type == 3)
                        {
                            //Vk.MessagesSend(name_one + " находится в чёрном списке бота.<br><br>" +
                            //"Обратите внимание, при дальнейшем нахождении этого пользователя в конференции — вы подвергаете свою беседу опасности, " +
                            //"а бот не будет реагировать на команды данного пользователя.", 0, item);
                        }
                        Thread.Sleep(500);
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sysunban()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_sysunban == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "sysunban", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != null && args[0] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysunban"]);
                    return;
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                var banInfo = db.BotBansGetBan(long.Parse(args[0]));
                if (banInfo == null || banInfo["user_id"] == null)
                {
                    Vk.MessagesSend("Данный пользователь не находится в блокировке.");
                    return;
                }

                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                string name_two = await Vk.GetUrlName(long.Parse(args[0]), "dat");

                Vk.MessagesSend(name_one + " разблокировал доступ к боту " + name_two + "<br><br>" +
                    "Теперь он сможет взаимодействовать с ботом.");
                db.BotBansDeleteBan(long.Parse(args[0]));
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_SYSUNBAN, Vk.m_from_id, long.Parse(args[0]), "разблокировал");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sysinfo()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_sysinfo == 0)
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysinfo"]);
                    return;
                }



                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                Cache Cache = new Cache();
                var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id);

                var helpText = "1 — информация о блокировках<br>" +
                    "2 — беседы, в которых пользователь является владельцем<br>" +
                    "3 — беседы, в которых пользователь есть на данный момент<br>" +
                    "4 — беседы, в которых пользователь был ранее<br>" +
                    "5 — все беседы, в которых когда-либо был или есть пользователь<br>" +
                    "6 — последние действия с пользователем (логи)";
                var targetId = "id" + args[0];
                if (long.Parse(args[0]) <= 0)
                {
                    targetId = "club" + args[0].Substring(1);
                }
                var buttons = Vk.GenerateKeyboard(new string[] { "1", "2", "3", "4", "5", "6" },
                    new string[] { $"sysinfo {targetId} 1", $"sysinfo {targetId} 2", $"sysinfo {targetId} 3",
                    $"sysinfo {targetId} 4", $"sysinfo {targetId} 5", $"sysinfo {targetId} 6" },
                    new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_BLUE, Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_RED },
                    new int[] { 0, 0, 0, 1, 1, 1 },
                    false, true, true);

                var buttons__tab1 = Vk.GenerateKeyboard(new string[] { "1", "2", "3", "4", "5", "6", "CHECKBAN" },
                    new string[] { $"sysinfo {targetId} 1", $"sysinfo {targetId} 2", $"sysinfo {targetId} 3",
                    $"sysinfo {targetId} 4", $"sysinfo {targetId} 5", $"sysinfo {targetId} 6", $"sysinfo {targetId} 7" },
                    new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_BLUE, Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_RED, Vk.BUTTON_GREEN },
                    new int[] { 0, 0, 0, 1, 1, 1, 2 },
                    false, true, true);

                var buttons__tab6 = Vk.GenerateKeyboard(new string[] { "1", "2", "3", "4", "5", "6", "FULLLOG" },
                    new string[] { $"sysinfo {targetId} 1", $"sysinfo {targetId} 2", $"sysinfo {targetId} 3",
                    $"sysinfo {targetId} 4", $"sysinfo {targetId} 5", $"sysinfo {targetId} 6", $"sysinfo {targetId} 8" },
                    new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_BLUE, Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_RED, Vk.BUTTON_RED },
                    new int[] { 0, 0, 0, 1, 1, 1, 2 },
                    false, true, true);

                if (args[1] == null || args[1] == "")
                {
                    long idmes = await Vk.MessagesSendMassive("Используйте тип.<br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                    Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    return;
                }
                /*else
                {
                    Cache Cache = new Cache();
                    var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id);
                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons2, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons2);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                }
                */

                var nameUserVk = await Vk.UserGetNameUrls(new long[] { long.Parse(args[0]) });
                var nameUser = nameUserVk[args[0]] + " (" + targetId + ")";


                if (args[1] != null && args[1] == "1")
                {
                    var banInfo = db.BotBansGetBan(long.Parse(args[0]));
                    string sysban_text = "не заблокирован.";
                    if (banInfo != null && banInfo["user_id"] != null)
                    {
                        string nick_adm = "модератором.";
                        if (settings.OWNER_IDS.ContainsKey(long.Parse(banInfo["banned_by"])))
                        {
                            nick_adm = "Администратором #" + settings.OWNER_IDS[long.Parse(banInfo["banned_by"])].id + ".";
                        }
                        string time_ban = "перманентно";
                        if (banInfo["date_unban"] != "")
                        {
                            time_ban = db.timeGetForMysql(banInfo["date_unban"]).ToString("G");
                        }
                        sysban_text = "заблокирован " + nick_adm + "<br>Окончание блокировки: " +
                            time_ban + "<br>Комментарий: " + banInfo["reason"] + "<br>";

                        sysban_text += "TypeBan: " + banInfo["type_ban"];
                        //Vk.MessagesSend("Данный пользователь уже заблокирован.");
                        //return;
                    }

                    string text = nameUser + ".<br><br>Информация о блокировке бота:<br>" + sysban_text + "<br>" +
                        "";

                    var data = db.bansGetBansForUser(long.Parse(args[0]));
                    if (data == null || data.Count <= 0)
                    {
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit(text + " Указанный пользователь не заблокирован ни в одной из бесед." + "<br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive(text + " Указанный пользователь не заблокирован ни в одной из бесед." + "<br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                        return;
                    }


                    text += "<br><br>Запросите список заблокированных бесед по кнопке ниже.<br>";// +
                                                                                                 //"Название беседы (ID)⠀⠀⠀⠀⠀| Срок блокировки⠀⠀⠀⠀| Причина<br><br>";
                    int i = 0;
                    foreach (var item in data)
                    {
                        i++;
                        long peerid = 0;
                        try
                        {
                            peerid = long.Parse(item["peer_id"]);
                            var peerInfo = db.peersGetPeer(peerid);
                            if (peerInfo["active"] == "0")
                            {
                                //i--;
                                //continue;
                            }
                        }
                        catch
                        {
                            continue;
                        }
                    }
                    text += "📝 Указанный пользователь заблокирован в '" + i + "' беседах." + "<br><br>" + helpText;


                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons__tab1, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons__tab1);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }

                    return;
                }

                if (args[1] != null && args[1] == "2")
                {
                    string text = nameUser + ".<br>";

                    string peerCount = "0";

                    var peersList = db.peersGetForOwner(long.Parse(args[0]));
                    if (peersList != null && peersList.Count >= 1)
                    {
                        peerCount = peersList.Count.ToString();
                    }
                    else
                    {
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit("Указанный пользователь не является создателем бесед.<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive("Указанный пользователь не является создателем бесед.<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                        return;
                    }

                    int idPeer = 0;
                    foreach (var item in peersList)
                    {
                        var peerInfo = db.peersGetPeer(item, false, false);
                        if (peerInfo != null)
                        {
                            idPeer++;
                            var activeText = (peerInfo["active"] == "0") ? "неактивна" : "активна";
                            text += $"{idPeer}. '{peerInfo["title"]}' — {activeText} ({peerInfo["current_members"]} участников).<br>";
                        }

                    }

                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text + "<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                    return;
                }


                if (args[1] != null && args[1] == "3")
                {
                    string text = nameUser + ".<br>";

                    string peerCount = "0";

                    var peersList = db.peerGetPeersWhereMembers(long.Parse(args[0]));
                    if (peersList != null && peersList.Count >= 1)
                    {
                        peerCount = peersList.Count.ToString();
                    }
                    else
                    {
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit(nameUser + ". Указанный пользователь не состоит ни в одной беседе.<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive(nameUser + ". Указанный пользователь не состоит ни в одной беседе.<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                        return;
                    }

                    int idPeer = 0;
                    foreach (var item in peersList)
                    {
                        try
                        {
                            var peerInfo = db.peersGetPeer(item, false, false);
                            if (peerInfo != null)
                            {
                                var target_member = db.peersGetMember(item, long.Parse(args[0]), false, false);
                                if (target_member == null)
                                {
                                    continue;
                                }

                                if (target_member["leave_peer"] == "1")
                                {
                                    continue;
                                }
                                idPeer++;
                                var activeText = (peerInfo["active"] == "0") ? "неактивна" : "активна";

                                string target_owner = "—";
                                if (peerInfo["owner"] != "0")
                                {
                                    var target_urls = await Vk.UserGetNameUrls(new long[] { long.Parse(peerInfo["owner"]) });
                                    if (target_urls.ContainsKey(peerInfo["owner"]))
                                    {
                                        target_owner = target_urls[peerInfo["owner"]];
                                    }
                                }

                                text += $"{idPeer}. '{peerInfo["title"]}' — {activeText} ({peerInfo["current_members"]} участников). Владелец: {target_owner}<br>";
                            }
                        }
                        catch
                        {
                            text += $"{item} — ошибка при выполнении итерации.<br>";
                        }
                    }

                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text + "<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                    return;
                }

                if (args[1] != null && args[1] == "4")
                {
                    string text = nameUser + ".<br>";

                    string peerCount = "0";

                    var peersList = db.peerGetPeersWhereMembers(long.Parse(args[0]));
                    if (peersList != null && peersList.Count >= 1)
                    {
                        peerCount = peersList.Count.ToString();
                    }
                    else
                    {
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit(text + "Указанный пользователь не состоит ни в одной беседе." + "<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive(text + "Указанный пользователь не состоит ни в одной беседе." + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                        return;
                    }

                    int idPeer = 0;
                    foreach (var item in peersList)
                    {
                        try
                        {
                            var peerInfo = db.peersGetPeer(item, false, false);
                            if (peerInfo != null)
                            {
                                var target_member = db.peersGetMember(item, long.Parse(args[0]), false, false);
                                if (target_member == null)
                                {
                                    continue;
                                }

                                if (target_member["leave_peer"] == "0")
                                {
                                    continue;
                                }
                                idPeer++;
                                var activeText = (peerInfo["active"] == "0") ? "неактивна" : "активна";

                                string target_owner = "—";
                                if (peerInfo["owner"] != "0")
                                {
                                    var target_urls = await Vk.UserGetNameUrls(new long[] { long.Parse(peerInfo["owner"]) });
                                    if (target_urls.ContainsKey(peerInfo["owner"]))
                                    {
                                        target_owner = target_urls[peerInfo["owner"]];
                                    }
                                }

                                text += $"{idPeer}. '{peerInfo["title"]}' — {activeText} ({peerInfo["current_members"]} участников). Владелец: {target_owner}<br>";
                            }
                        }
                        catch
                        {
                            text += $"{item} — ошибка выполнения итерации.";
                        }
                    }

                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text + "<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                    return;
                }

                if (args[1] != null && args[1] == "5")
                {
                    string text = nameUser + ".<br>";

                    string peerCount = "0";

                    var peersList = db.peerGetPeersWhereMembers(long.Parse(args[0]));
                    if (peersList != null && peersList.Count >= 1)
                    {
                        peerCount = peersList.Count.ToString();
                    }
                    else
                    {
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit("Указанный пользователь не состоит ни в одной беседе." + "<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive("Указанный пользователь не состоит ни в одной беседе." + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                        return;
                    }

                    int idPeer = 0;
                    foreach (var item in peersList)
                    {
                        try
                        {
                            var peerInfo = db.peersGetPeer(item, false, false);
                            if (peerInfo != null)
                            {
                                var target_member = db.peersGetMember(item, long.Parse(args[0]), false, false);
                                if (target_member == null)
                                {
                                    continue;
                                }
                                idPeer++;
                                var activeText = (peerInfo["active"] == "0") ? "неактивна" : "активна";
                                //
                                var leaveText = (target_member["leave_peer"] == "1") ? " Не в беседе." : "";
                                string target_owner = "—";
                                if (peerInfo["owner"] != "0")
                                {
                                    var target_urls = await Vk.UserGetNameUrls(new long[] { long.Parse(peerInfo["owner"]) });
                                    if (target_urls.ContainsKey(peerInfo["owner"]))
                                    {
                                        target_owner = target_urls[peerInfo["owner"]];
                                    }
                                }

                                text += $"{idPeer}. '{peerInfo["title"]}' — {activeText} ({peerInfo["current_members"]} участников).{leaveText} Владелец: {target_owner}<br>";
                            }
                        }
                        catch
                        {
                            text += $"{item} — ошибка выполнения итерации!<br>";
                        }


                    }

                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text + "<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                    return;
                }

                if (args[1] != null && args[1] == "6")
                {
                    string text = nameUser + ".<br>";

                    var logs = db.getAllLogsUser(long.Parse(args[0]));
                    if (logs == null || logs.Count <= 0)
                    {
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit(text + "К сожалению, нет последних действий пользователя." + "<br><br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive(text + "К сожалению, нет последних действий пользователя." + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                        return;
                    }



                    List<long> userget = new();
                    long iters = 0;
                    string my_id = args[0];
                    foreach (var item in logs)
                    {
                        try
                        {
                            iters++;
                            if (item["user_id"] == my_id)
                            {
                                userget.Add(long.Parse(item["target_id"]));
                            }
                            else
                            {
                                userget.Add(long.Parse(item["user_id"]));
                            }
                        }
                        catch
                        {

                        }

                    }
                    userget.Add(long.Parse(my_id));

                    var users_names_vk = await Vk.UsersGetVkInfo(userget.ToArray());
                    //if (all_list == 0)
                    //{

                    //}

                    text = "Список последних действий пользователя: <br><br>";
                    int i = 1;
                    foreach (var item in logs)
                    {
                        try
                        {
                            if (users_names_vk.ContainsKey("id" + item["user_id"]))
                            {
                                if (long.Parse(item["user_id"]) < 0)
                                {
                                    text = text + i + ". [club" + item["user_id"].Substring(1) + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                        users_names_vk["id" + item["user_id"]].last_name + "] ";
                                }
                                else
                                {
                                    text = text + i + ". [id" + item["user_id"] + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                        users_names_vk["id" + item["user_id"]].last_name + "] ";
                                }
                            }
                            else
                            {
                                if (long.Parse(item["user_id"]) < 0)
                                {
                                    text = text + i + ". [club" + item["user_id"].Substring(1) + "|Сообщество] ";
                                }
                                else
                                {
                                    text = text + i + ". [id" + item["user_id"] + "|Пользователь] ";
                                }
                            }
                            if (item["type"] == "2")
                            {
                                text += " активировал конференцию";
                            }
                            else
                            {
                                text = text + item["text"] + " ";
                            }

                            if (item["target_id"] != "0")
                            {
                                if (users_names_vk.ContainsKey("id" + item["target_id"]))
                                {
                                    if (long.Parse(item["target_id"]) < 0)
                                    {
                                        text = text + "[club" + item["target_id"].Substring(1) + "|" + users_names_vk["id" + item["target_id"]].first_name + " " +
                                            users_names_vk["id" + item["target_id"]].last_name + "]<br>";
                                    }
                                    else
                                    {
                                        text = text + "[id" + item["target_id"] + "|" + users_names_vk["id" + item["target_id"]].first_name + " " +
                                            users_names_vk["id" + item["target_id"]].last_name + "]<br>";
                                    }
                                }
                                else
                                {
                                    if (long.Parse(item["target_id"]) < 0)
                                    {
                                        text = text + "[club" + item["target_id"].Substring(1) + "|Сообщество]<br>";
                                    }
                                    else
                                    {
                                        text = text + "[id" + item["target_id"] + "|Пользователь]<br>";
                                    }
                                }
                            }
                            else
                            {
                                text = text + "<br>";
                            }


                            //Vk.MessagesSend("");
                            i++;
                        }
                        catch
                        {
                            text += " ! ошибка при выполнении итерации<br>";
                        }

                    }

                    text += "<br>Вы можете запросить лог последних 250-и действий с полной информацией по кнопке ниже.<br><br>";

                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text + "<br><br>" + helpText, Vk.m_peer_id, buttons__tab6, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text + "<br><br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons__tab6);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                    return;
                }

                if (args[1] != null && args[1] == "7")
                {
                    string text = "";

                    var data = db.bansGetBansForUser(long.Parse(args[0]), true);
                    if (data == null || data.Count <= 0)
                    {
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit(nameUser + ". " + text + " Указанный пользователь не заблокирован ни в одной из бесед." + "<br>" + helpText, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive(nameUser + ". " + text + " Указанный пользователь не заблокирован ни в одной из бесед." + "<br>" + helpText, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                        return;
                    }


                    text += nameUser + ".<br>Список бесед, в которых имеется блокировка:<br><br>";// +
                                                                                                  //"Название беседы (ID)⠀⠀⠀⠀⠀| Срок блокировки⠀⠀⠀⠀| Причина<br><br>";
                    int i = 0;
                    foreach (var item in data)
                    {
                        i++;
                        long peerid = 0;
                        try
                        {
                            peerid = long.Parse(item["peer_id"]);
                            var peerInfo = db.peersGetPeer(peerid);
                            var activeText = "да";
                            if (peerInfo["active"] == "0")
                            {
                                activeText = "нет";
                                //i--;
                                //continue;
                            }

                            var peerName = "—";
                            if (peerInfo["title"] != "0")
                            {
                                peerName = peerInfo["title"];
                            }

                            var peerIdText = long.Parse(peerInfo["peer_id"]) - settings.PEERS_CHATID;

                            string ownerText = "—";
                            if (peerInfo["owner"] != "0")
                            {
                                var ownerVk = await Vk.UserGetNameUrls(new long[] { long.Parse(peerInfo["owner"]) });
                                if (ownerVk.ContainsKey(peerInfo["owner"]))
                                {
                                    ownerText = ownerVk[peerInfo["owner"]];
                                }
                            }

                            string bannerText = "—";
                            if (item["admin_id"] != "0")
                            {
                                var ownerVk = await Vk.UserGetNameUrls(new long[] { long.Parse(item["admin_id"]) });
                                if (ownerVk.ContainsKey(item["admin_id"]))
                                {
                                    bannerText = ownerVk[item["admin_id"]];
                                }
                            }

                            string dateText = "перманентно";

                            if (item["date_unban"] != "")
                            {
                                dateText = "до " + db.timeGetForMysql(item["date_unban"]).ToString("g");
                            }

                            string reasonText = "—";

                            if (item["reason"] != "")
                            {
                                reasonText = item["reason"];
                            }

                            text += $"{peerIdText}. Название: '{peerName}'. Владелец: {ownerText}. Активна: {activeText}. Заблокировал: {bannerText}. Срок: {dateText}. Причина: {reasonText}<br><br>";
                        }
                        catch
                        {
                            continue;
                        }
                    }
                    text += "<br>📝 Указанный пользователь заблокирован в '" + i + "' беседах." + "<br>" + helpText;


                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }

                    return;
                }

                if (args[1] != null && args[1] == "8")
                {
                    try
                    {
                        var namesOne = await Vk.UsersGetName(new long[] { Vk.m_from_id }, false, "gen");

                        string nameAdmin = "—";
                        if (namesOne.ContainsKey($"id{Vk.m_from_id}"))
                        {
                            nameAdmin = namesOne[$"id{Vk.m_from_id}"].first_name + " " + namesOne[$"id{Vk.m_from_id}"].last_name + $" (ID {Vk.m_from_id})";
                        }

                        var targetIdParsed = long.Parse(args[0]);
                        var namesAbl = await Vk.UsersGetName(new long[] { targetIdParsed }, false, "abl");
                        string TargetNameUser = "—";
                        if (namesAbl.ContainsKey($"id{targetIdParsed}"))
                        {
                            TargetNameUser = namesAbl[$"id{targetIdParsed}"].first_name + " " + namesAbl[$"id{targetIdParsed}"].last_name + $" (ID {targetIdParsed})";
                        }

                        string text = $"Полный отчёт для {nameAdmin} о {TargetNameUser} за {DateTimeOffset.Now.ToString("G")}.\n\n";


                        var logs = db.getAllLogsUser(long.Parse(args[0]), 0, 250);
                        if (logs == null || logs.Count <= 0)
                        {
                            text += "Последние 250 событий не найдены.";
                        }


                        List<long> userget = new();
                        long iters = 0;
                        string my_id = args[0];
                        foreach (var item in logs)
                        {
                            try
                            {
                                iters++;
                                if (item["user_id"] == my_id)
                                {
                                    userget.Add(long.Parse(item["target_id"]));
                                }
                                else
                                {
                                    userget.Add(long.Parse(item["user_id"]));
                                }
                            }
                            catch
                            {

                            }

                        }
                        userget.Add(long.Parse(my_id));

                        var users_names_vk = await Vk.UsersGetVkInfo(userget.ToArray());
                        //if (all_list == 0)
                        //{

                        //}

                        text += "Список последних действий пользователя: \n\n";
                        string i = "DATE";
                        foreach (var item in logs)
                        {
                            try
                            {
                                i = item["date_created"];
                                if (i != "")
                                {
                                    i = db.timeGetForMysql(i).ToString("g");
                                }

                                string userOne = "—";
                                string userTwo = "—";
                                string typeName = "—";
                                string dop1 = "—";
                                string dop2 = "—";
                                string dop3 = "—";
                                string dateSob = i;
                                string kfId = (long.Parse(item["peer_id"]) > settings.PEERS_CHATID) ? (long.Parse(item["peer_id"]) - settings.PEERS_CHATID).ToString() : item["peer_id"];



                                if (users_names_vk.ContainsKey("id" + item["user_id"]))
                                {
                                    if (long.Parse(item["user_id"]) < 0)
                                    {
                                        userOne = $"Сообщество (ID {item["user_id"].Substring(1)})";
                                    }
                                    else
                                    {
                                        userOne = $"{users_names_vk["id" + item["user_id"]].first_name} {users_names_vk["id" + item["user_id"]].last_name} (ID {item["user_id"]})";
                                    }
                                }
                                else
                                {
                                    if (long.Parse(item["user_id"]) < 0)
                                    {
                                        userOne = $"Сообщество (ID {item["user_id"].Substring(1)})";
                                    }
                                    else
                                    {
                                        userOne = $"Пользователь (ID {item["user_id"]})";
                                    }
                                }

                                if (item["type"] == "2")
                                {
                                    typeName = " активировал конференцию";
                                }
                                else
                                {
                                    typeName = item["text"];
                                }

                                if (item["target_id"] != "0")
                                {
                                    if (users_names_vk.ContainsKey("id" + item["target_id"]))
                                    {
                                        if (long.Parse(item["target_id"]) < 0)
                                        {
                                            userTwo = $"Сообщество (ID {item["target_id"].Substring(1)})";
                                        }
                                        else
                                        {
                                            userTwo = $"{users_names_vk["id" + item["target_id"]].first_name} {users_names_vk["id" + item["target_id"]].last_name} (ID {item["target_id"]})";
                                        }
                                    }
                                    else
                                    {
                                        if (long.Parse(item["target_id"]) < 0)
                                        {
                                            userTwo = $"Сообщество (ID {item["target_id"].Substring(1)})";
                                        }
                                        else
                                        {
                                            userTwo = $"Пользователь (ID {item["target_id"]})";
                                        }
                                    }
                                }

                                if (item["data1"] != "")
                                {
                                    dop1 = item["data1"];
                                }

                                if (item["data2"] != "")
                                {
                                    dop2 = item["data2"];
                                }

                                text += $"Событие {dateSob}:\n" +
                                    $"\t\tПользователь: {userOne}\n" +
                                    $"\t\tПрименил к: {userTwo}\n" +
                                    $"\t\tТип: {typeName}\n" +
                                    $"\t\tИнформация 1: {dop1}\n" +
                                    $"\t\tИнформация 2: {dop2}\n" +
                                    $"\t\tID беседы: {kfId}\n\n";
                            }
                            catch
                            {
                                text += " ! ошибка при выполнении итерации\n";
                            }

                        }

                        text += "\n\n\nОтправка любой информации из этого отчёта, либо отправка ссылки на этот отчёт — влечёт наказание в виде блокировки бота (sysban с типом 1).";

                        Vk.MessagesSend("Подготовка отчета может занять некоторое время. В личные сообщения от бота Вам придет ссылка на результат.", 0);
                        try
                        {
                            Random rand = new();

                            var randName = rand.NextInt64(300000, 900000000);
                            string nameFull = $"log{Vk.m_from_id}-{randName}.txt";


                            string path = $"logs/{nameFull}";

                            if (!Program.is_beta)
                            {
                                path = $"/var/www/html/logs/{nameFull}";
                            }

                            //byte[] bytes = Encoding.Default.GetBytes(text);
                            //var myString = Encoding.ASCII.GetString(bytes);

                            var myString = text;
                            // полная перезапись файла StreamWriter w = new StreamWriter(PathWithName, false, Encoding.GetEncoding("Windows-1251"));

                            using (StreamWriter writer = new StreamWriter(path, false, Encoding.GetEncoding("Windows-1251")))
                            {
                                await writer.WriteLineAsync(myString);
                            }

                            string linkUrl = "";

                            if (Program.is_beta)
                            {
                                linkUrl = nameFull;
                            }
                            else
                            {
                                linkUrl = $"https://grandmanager.ru/logs/{nameFull}";
                            }

                            db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_GETSYSLOGFULL, Vk.m_from_id, targetIdParsed, "запросил полный лог действий");

                            Vk.MessagesSend("Отчёт был подготовлен и сейчас доступен по ссылке: " + linkUrl, 0, Vk.m_from_id);

                        }
                        catch
                        {
                            Vk.MessagesSend("Ошибка непосредственной записи отчета на диск.", 0);
                        }


                        return;
                    }
                    catch (Exception ex)
                    {
                        Vk.MessagesSend("Возникла непредвиденная ошибка. Text: " + ex.Message, 0);
                    }
                    catch
                    {
                        Vk.MessagesSend("Возникла непредвиденная ошибка.", 0);
                    }

                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }


        public async void command_allquests()
        {
            try
            {
                //questsGetAllQuests
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    return;
                }

                string text = $"Всего квестов рассмотрено: {db.questsGetAllQuests()}<br>" +
                    $"Квестов на рассмотрении сейчас: {db.questsGetAllQuestsInWork()}<br>" +
                    $"Активные беседы ПОСЛЕ прохождения квеста: {db.questsGetAllQuestsActiveAfterWork()}<br>" +
                    $"Осталось квестов: {db.questsGetAllQuestsNewer()}";

                Vk.MessagesSend(text);

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
        public async void command_getquests()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }



                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                DateTimeOffset today = DateTimeOffset.Now.Date;
                var ress = db.getQuestsWhereDay(long.Parse(args[0]), db.timeGetForString(today));
                if (ress != null)
                {
                    if (ress.Count >= 1)
                    {
                        string text_send = "Квесты за день:<br> 'ID' - TYPE - комментарий агента<br>";

                        foreach (var item in ress)
                        {
                            string typee = (item["sys_mention_non_active"] == "0") ? "на рассмотрении" : reasonsDeactivate[int.Parse(item["sys_mention_non_active"])];
                            text_send += $"'{item["peer_id"]}' - {item["sys_mention_non_active"]} ({typee}) - {item["sys_mention_comment"]}<br><br>";
                        }
                        Vk.MessagesSend(text_send);
                    }
                    else
                    {
                        Vk.MessagesSend("Нет квестов за сегодняшний день.");
                    }
                }
                else
                {
                    Vk.MessagesSend("Нет квестов за сегодняшний день.");
                }

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sysmoney()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 0 && settings.OWNER_IDS[Vk.m_from_id].access_givemoney == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "givemoney", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["givemoney"]);
                    return;

                }
                else
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                var target_money = getUlongMoney(Target_User["rubs"]);
                var give_money = getUlongMoney(args[1]);
                var ABSgive_money = getUlongMoney(args[1].Replace("-", ""));
                if (give_money == 0)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["givemoney"]);
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_give == 0 && settings.OWNER_IDS[Vk.m_from_id].access_givemoney == 1)
                {
                    var resultCacheLimit = Cache.Get<string>("limit_giverub_" + Vk.m_from_id);
                    if (resultCacheLimit != null)
                    {
                        if (getUlongMoney(resultCacheLimit) > 5000000)
                        {
                            Vk.MessagesSend("К сожалению, ваш лимит на выдачу денег за последние 6 часов потрачен.");
                            return;
                        }

                        if (getUlongMoney(resultCacheLimit) + ABSgive_money > 5000000)
                        {
                            Vk.MessagesSend("Вы не можете выдать больше, чем установленный лимит за последние 6 часов.<br>" +
                                "Уже выдано: " + getRubsMoney(resultCacheLimit) + "<br>Ваш лимит: " + getRubsMoney("5000000") + "<br>" +
                                "Осталось выдать: " + getRubsMoney((5000000 - getUlongMoney(resultCacheLimit)).ToString()));
                            return;
                        }
                        Cache.Set("limit_giverub_" + Vk.m_from_id, (getUlongMoney(resultCacheLimit) + ABSgive_money).ToString(), 60 * 60 * 6);
                    }
                    else
                    {
                        if (ABSgive_money > 5000000)
                        {
                            Vk.MessagesSend("Вы не можете выдать больше, чем установленный лимит за последние 6 часов.<br>" +
                                "Уже выдано: " + getRubsMoney("0") + "<br>Ваш лимит: " + getRubsMoney("5000000") + "<br>" +
                                "Осталось выдать: " + getRubsMoney("5000000"));
                            return;
                        }

                        Cache.Set("limit_giverub_" + Vk.m_from_id, ABSgive_money.ToString(), 60 * 60 * 6);
                    }
                    //Target_User = db.usersGetUser(Vk.m_from_id);
                }


                var result_money = target_money + give_money;
                var result_money_text = getRubsMoney(result_money.ToString());

                string name_two = await Vk.GetUrlName(long.Parse(args[0]));

                string text = "";

                text = name_two + $" — новый баланс: «{result_money_text}».<br><br>Предыдущий баланс: «{getRubsMoney(Target_User["rubs"])}»";
                Vk.MessagesSend(text);

                if (settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 1 && settings.OWNER_IDS[Vk.m_from_id].access_givemoney == 0)
                {
                    return;
                }

                db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_GIVERUB, Vk.m_from_id, long.Parse(args[0]), "установил рубли на аккаунт", args[1]);
                db.gameSetUserRub(long.Parse(args[0]), result_money.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_syseuro()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_givemoney == 0 && settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "givemoney", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["givemoney"]);
                    return;
                }
                else
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_give == 0 && settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 0)
                {
                    Vk.MessagesSend("К сожалению, у вас нет доступа.");
                    return;
                    //Target_User = db.usersGetUser(Vk.m_from_id);
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                var target_money = getUlongMoney(Target_User["euros"]);
                var give_money = getUlongMoney(args[1]);
                if (give_money == 0)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["givemoney"]);
                    return;
                }
                var result_money = target_money + give_money;
                var result_money_text = getEuroMoney(result_money.ToString());

                string name_two = await Vk.GetUrlName(long.Parse(args[0]));

                string text = "";

                text = name_two + $" — новый баланс: «{result_money_text}».<br><br>Предыдущий баланс: «{getEuroMoney(Target_User["euros"])}»";
                Vk.MessagesSend(text);

                if (settings.OWNER_IDS[Vk.m_from_id].access_givemoney == 0)
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 1 && settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    return;
                }
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_GIVERUB, Vk.m_from_id, long.Parse(args[0]), "установил евро на аккаунт", args[1]);
                db.gameSetUserEuros(long.Parse(args[0]), result_money.ToString());
                //db.timeGetForString();
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_agent()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysagent"]);
                    return;
                }

                var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id + "_" + args[0]);

                if (args[1] == null || args[1] == "" || args[1] == "info")
                {

                }
                long target = long.Parse(args[0]);

                if (args[1] == null || args[1] == "" || args[1] == "info")
                {
                    if (!settings.OWNER_IDS.ContainsKey(long.Parse(args[0])))
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                    List<string> colors = new();

                    string append_color = Vk.BUTTON_GREEN;
                    string reports = (settings.OWNER_IDS[target].access_reports == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_reports == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string sysinfo = (settings.OWNER_IDS[target].access_sysinfo == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_sysinfo == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string closed = (settings.OWNER_IDS[target].access_closed == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_closed == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string answer = (settings.OWNER_IDS[target].access_answer == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_answer == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string banreport = (settings.OWNER_IDS[target].access_banreport == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_banreport == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string unbanreport = (settings.OWNER_IDS[target].access_unbanreport == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_unbanreport == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string sysban = (settings.OWNER_IDS[target].access_sysban == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_sysban == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string sysunban = (settings.OWNER_IDS[target].access_sysunban == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_sysunban == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string sysrole = (settings.OWNER_IDS[target].access_sysrole == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_sysrole == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string givevip = (settings.OWNER_IDS[target].access_givevip == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_givevip == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string givemoney = (settings.OWNER_IDS[target].access_givemoney == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_givemoney == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string fakecmd = (settings.OWNER_IDS[target].access_fakecmd == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_fakecmd == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string getbotstats = (settings.OWNER_IDS[target].access_getbotstats == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_getbotstats == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string spam = (settings.OWNER_IDS[target].access_spam == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_spam == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string give = (settings.OWNER_IDS[target].access_give == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_give == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);

                    string getquest = (settings.OWNER_IDS[target].access_getquest == 0) ? "❌" : "✅";
                    append_color = (settings.OWNER_IDS[target].access_getquest == 0) ? Vk.BUTTON_RED : Vk.BUTTON_GREEN;
                    colors.Add(append_color);


                    var buttons2 = Vk.GenerateKeyboard(new string[] { "reports", "sysinfo", "closed", "answer", "banreport", "unbanreport",
                "sysban", "sysunban", "sysrole", "givevip", "givemoney", "fakecmd", "getbotstats", "spam", "give", "getquest" },
                    new string[] { $"sys_give id{target} reports",
                $"sys_give id{target} sysinfo",
                $"sys_give id{target} closed",
                $"sys_give id{target} answer",
                $"sys_give id{target} banreport",
                $"sys_give id{target} unbanreport",
                $"sys_give id{target} sysban",
                $"sys_give id{target} sysunban",
                $"sys_give id{target} sysrole",
                $"sys_give id{target} givevip",
                $"sys_give id{target} givemoney",
                $"sys_give id{target} fakecmd",
                $"sys_give id{target} getbotstats",
                $"sys_give id{target} spam",
                $"sys_give id{target} give",
                    $"sys_give id{target} getquest" },
                    colors.ToArray(), new int[] { 0, 0, 1, 1, 2, 2, 3, 3, 4, 4, 5, 5, 5, 6, 6, 6 }, false, false, true);

                    string text = $"ID: {settings.OWNER_IDS[target].id}<br>VK: {settings.OWNER_IDS[target].user_id}" +
                        $"<br>Доступ:<br><br>" +
                        $"!тикеты — {reports}<br>" +
                        $"!sysinfo — {sysinfo}<br>" +
                        $"Закрытые тикеты — {closed}<br>" +
                        $"!answer — {answer}<br>" +
                        $"!banreport — {banreport}<br>" +
                        $"!unbanreport — {unbanreport}<br>" +
                        $"!sysban — {sysban}<br>" +
                        $"!sysunban — {sysunban}<br>" +
                        $"!sysrole — {sysrole}<br>" +
                        $"!givevip — {givevip}<br>" +
                        $"!givemoney — {givemoney}<br>" +
                        $"Фейковые команды — {fakecmd}<br>" +
                        $"!getbotstats — {getbotstats}<br>" +
                        $"!рассылка — {spam}<br>" +
                        $"!quest — {getquest}<br>" +
                        $"<br>!agent — {give}";
                    if (settings.OWNER_IDS[Vk.m_from_id].access_give == 1)
                    {
                        if (last_message != null)
                        {
                            if (args[1] == "info")
                            {
                                buttons2 = "";
                            }
                            Cache.Set("last_message_for_" + Vk.m_peer_id + "_" + args[0], last_message.ToString());
                            Vk.MessagesEdit(text, Vk.m_peer_id, buttons2, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            if (args[1] == "info")
                            {
                                buttons2 = "";
                            }
                            long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons2);
                            Cache.Set("last_message_for_" + Vk.m_peer_id + "_" + args[0], idmes.ToString());
                        }

                    }
                    return;
                }
                if (args[1] == "add")
                {
                    if (settings.OWNER_IDS.ContainsKey(long.Parse(args[0])))
                    {
                        Vk.MessagesSend("Данный пользователь уже является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                    db.adminsAdd(target, Vk.m_from_id);
                    Vk.MessagesSend("Пользователь был добавлен в список агентов.");
                    return;
                }

                if (args[1] == "del" || args[1] == "remove" || args[1] == "delete")
                {
                    if (!settings.OWNER_IDS.ContainsKey(long.Parse(args[0])))
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                    if (args[0] == "721663584" || args[0] == "553227510")
                    {
                        Vk.MessagesSend("Данный пользователь — генеральный директор команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                    db.adminsRemove(target);
                    Vk.MessagesSend("Пользователь был лишен прав агента.");
                    return;
                }

                Vk.MessagesSend(CommandsList.CommandsHelp["sysagent"]);
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_addlox()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 0)
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend("Используйте: !addlox [ID/ссылка].");
                    return;
                }

                long target = long.Parse(args[0]);

                var targetUserNick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id, target });

                Vk.MessagesSend(targetUserNick[target.ToString()] + " получил новую роль.<br>Название: лох<br>Выдал: " + targetUserNick[Vk.m_from_id.ToString()]);
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_givevip()
        {
            try
            {

                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_givevip == 0)
                {
                    return;
                }


                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["givevip"]);
                    return;
                }

                long target_days = -1;
                if (args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["givevip"]);
                    return;
                }

                try
                {
                    target_days = long.Parse(args[1]);
                }
                catch
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["givevip"]);
                    return;
                }

                string time_text = "перманентно";
                string status_text = "0";
                long target_vip = 1;
                if (db.UserIsVip(long.Parse(args[0])))
                {
                    //status_text =
                    if (long.Parse(Target_User["vip_type"]) >= 20)
                    {
                        target_vip = long.Parse(Target_User["vip_type"]);
                    }
                    else
                    {
                        target_vip = long.Parse(Target_User["vip_type"]) + 1;
                    }

                }

                if (target_days == 0)
                {
                    db.usersSetVipTime(long.Parse(args[0]), null);
                    db.usersSetVipType(long.Parse(args[0]), 0);
                }
                else if (target_days >= 600 || target_days == -1)
                {
                    db.usersSetVipTime(long.Parse(args[0]), null);
                    db.usersSetVipType(long.Parse(args[0]), target_vip);
                    status_text = target_vip.ToString();
                }
                else
                {
                    var time_next = DateTimeOffset.Now.AddDays(target_days);
                    db.usersSetVipTime(long.Parse(args[0]), db.timeGetForString(time_next));
                    db.usersSetVipType(long.Parse(args[0]), target_vip);
                    time_text = time_next.ToString("g");
                    status_text = target_vip.ToString();
                }

                var nick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id, long.Parse(args[0]) });
                Vk.MessagesSend($"{nick[args[0]]} получил VIP статус '{status_text}' уровня. Дата окончания: {time_text}<br>" +
                    $"<br>Выдал: {nick[Vk.m_from_id.ToString()]}");
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_GIVEVIP, Vk.m_from_id, long.Parse(args[0]), "установил VIP статус", status_text, time_text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sys_give()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_give == 0)
                {
                    return;
                }


                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "")
                {
                    Target_User = db.usersGetUser(long.Parse(args[0]));
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysagent"]);
                    return;
                }

                if (args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysagent"]);
                    return;
                }
                long target = long.Parse(args[0]);

                if (args[1] == "reports")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_reports == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_reports", toggle);
                        settings.OWNER_IDS[target].access_reports = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "sysinfo")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_sysinfo == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_sysinfo", toggle);
                        settings.OWNER_IDS[target].access_sysinfo = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "closed")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_closed == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_closed", toggle);
                        settings.OWNER_IDS[target].access_closed = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "answer")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_answer == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_answer", toggle);
                        settings.OWNER_IDS[target].access_answer = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "banreport")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_banreport == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_banreport", toggle);
                        settings.OWNER_IDS[target].access_banreport = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "unbanreport")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_unbanreport == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_unbanreport", toggle);
                        settings.OWNER_IDS[target].access_unbanreport = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "sysban")
                {
                    Console.WriteLine($"[ROLE DEBUG] sysban toggle by from_id={Vk.m_from_id}, target={target}");
                    if (Vk.m_from_id != 721663584 && Vk.m_from_id != 553227510)
                    {
                        Console.WriteLine($"[ROLE DEBUG] sysban BLOCKED — from_id not in allowed list");
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_sysban == 1) ? 0 : 1;
                        Console.WriteLine($"[ROLE DEBUG] sysban toggle={toggle}, current={settings.OWNER_IDS[target].access_sysban}");
                        db.adminsSetFieldSettings(target, "access_sysban", toggle);
                        settings.OWNER_IDS[target].access_sysban = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "sysunban")
                {
                    if (Vk.m_from_id != 721663584 && Vk.m_from_id != 553227510)
                    {
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_sysunban == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_sysunban", toggle);
                        settings.OWNER_IDS[target].access_sysunban = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "sysrole")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_sysrole == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_sysrole", toggle);
                        settings.OWNER_IDS[target].access_sysrole = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "givevip")
                {
                    Console.WriteLine($"[ROLE DEBUG] givevip toggle by from_id={Vk.m_from_id}, target={target}");
                    if (Vk.m_from_id != 721663584 && Vk.m_from_id != 553227510)
                    {
                        Console.WriteLine($"[ROLE DEBUG] givevip BLOCKED — from_id not in allowed list");
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_givevip == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_givevip", toggle);
                        settings.OWNER_IDS[target].access_givevip = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "getbotstats")
                {
                    Console.WriteLine($"[ROLE DEBUG] getbotstats toggle by from_id={Vk.m_from_id}, target={target}");
                    if (Vk.m_from_id != 721663584 && Vk.m_from_id != 553227510)
                    {
                        Console.WriteLine($"[ROLE DEBUG] getbotstats BLOCKED — from_id not in allowed list");
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_getbotstats == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_getbotstats", toggle);
                        settings.OWNER_IDS[target].access_getbotstats = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "spam")
                {
                    Console.WriteLine($"[ROLE DEBUG] spam toggle by from_id={Vk.m_from_id}, target={target}");
                    if (Vk.m_from_id != 721663584 && Vk.m_from_id != 553227510)
                    {
                        Console.WriteLine($"[ROLE DEBUG] spam BLOCKED — from_id not in allowed list");
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_spam == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_spam", toggle);
                        settings.OWNER_IDS[target].access_spam = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "give")
                {
                    if (Vk.m_from_id != 721663584)
                    {
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_give == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_give", toggle);
                        settings.OWNER_IDS[target].access_give = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else if (args[1] == "givemoney")
                {
                    Console.WriteLine($"[ROLE DEBUG] givemoney toggle by from_id={Vk.m_from_id}, target={target}");
                    if (Vk.m_from_id != 721663584 && Vk.m_from_id != 553227510)
                    {
                        Console.WriteLine($"[ROLE DEBUG] givemoney BLOCKED — from_id not in allowed list");
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_givemoney == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_givemoney", toggle);
                        settings.OWNER_IDS[target].access_givemoney = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }//
                }
                else if (args[1] == "fakecmd")
                {
                    Console.WriteLine($"[ROLE DEBUG] fakecmd toggle by from_id={Vk.m_from_id}, target={target}");
                    if (Vk.m_from_id != 553227510 && Vk.m_from_id != 721663584)
                    {
                        Console.WriteLine($"[ROLE DEBUG] fakecmd BLOCKED — from_id not in allowed list");
                        return;
                    }
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_fakecmd == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_fakecmd", toggle);
                        settings.OWNER_IDS[target].access_fakecmd = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }//
                }
                else if (args[1] == "getquest")
                {
                    if (settings.OWNER_IDS.ContainsKey(target))
                    {
                        var toggle = (settings.OWNER_IDS[target].access_getquest == 1) ? 0 : 1;
                        db.adminsSetFieldSettings(target, "access_getquest", toggle);
                        settings.OWNER_IDS[target].access_getquest = toggle;
                    }
                    else
                    {
                        Vk.MessagesSend("Данный пользователь не является частью команды 𝐆𝐑𝐀𝐍𝐃.");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["sysagent"]);
                    return;
                }

                Vk.m_text = "!agent id" + args[0];
                this.command_agent();
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_spam()
        {
            try
            {
                //peersGetAllIdsForSendMass
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_spam == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "sysspam", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Укажите текст для рассылки.");
                    return;
                }
                var peerIds = db.peersGetAllIdsForSendMass();

                long count = peerIds.Count;

                long global_current_count = 0;
                /*
                List<List<long>> for_data = new();

                long current_list1 = 0;

                // for (int i = 0; i == 0 || i % (count / 100) == 0; i++)
                while (global_current_count < count)
                {
                    if (for_data.Count <= 0 || for_data.Count < current_list1)
                    {
                        for_data.Add(new List<long>());
                    }
                    long max = (current_list1 + 1) * 10;
                    long min = max - 10;

                    var listf_peers = db.peersGetAllIdsForSendMass(min, max);
                    //for_data[current_list1].Add();
                    if (listf_peers.Count <= 0)
                    {
                        break;
                    }
                    for_data[current_list1] = listf_peers;
                    if (listf_peers.Count > 10)
                    {
                        current_list1++;
                        for_data.Add(new List<long>());
                    }
                    global_current_count += 10;
                    //i += 100;
                }

                string text = args[0] + "<br><br>" +
                    "Отключить подобные оповещения можно командой: /mentions";

                var buttons = Vk.GenerateKeyboard(new string[] { "Отключить уведомления" }, new string[] { "mentions" }, new string[] { Vk.BUTTON_RED });
                foreach (var item in for_data)
                {

                    List<long> sendIds = new();
                    foreach (var itemd in item)
                    {
                        sendIds.Add(itemd);
                    }
                    Vk.MessagesSendMassive(text, sendIds, buttons, true, "");
                    Thread.Sleep(5000);
                }*/
                string text = args[0] + "<br><br>" +
                    "Отключить подобные оповещения можно командой: /mentions";

                var buttons = Vk.GenerateKeyboard(new string[] { "Отключить уведомления" }, new string[] { "mentions" }, new string[] { Vk.BUTTON_RED });
                int i = 0;
                foreach (var item in peerIds)
                {
                    i++;
                    Vk.MessagesSend(text, 0, item, buttons, true, "");
                    Thread.Sleep(100);

                    if ((i % 500) == 0)
                    {
                        Vk.MessagesSend("Проходка беседы №" + item + $", ({i} из {peerIds.Count})");
                    }
                }

                Vk.MessagesSend($"Оповещения были успешно отправлены во все беседы.<br>Всего отправлено в '{count}' бесед");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_checkuser()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_reports == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "syscheckusers", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Укажите ID пользователя.");
                    return;
                }

                var target_ids = Cache.Get<Dictionary<string, Dictionary<string, string>>>("users_online_check");
                /*var back_status = item.Value["status"];
                                var item_id = item.Value["id"];
                                var peer_id = item.Value["peer_id"];*/
                var templane_user = new Dictionary<string, string>() {
                { "id", args[0] },  { "status", "5" }, { "peer_id", Vk.m_peer_id.ToString() }
            };
                var templane = new Dictionary<string, Dictionary<string, string>>() { { args[0], templane_user } };

                if (target_ids == null)
                {
                    Cache.Set("users_online_check", templane, 600);
                    Vk.MessagesSend("Пользователь был добавлен в список.");
                    return;
                }
                else
                {
                    if (target_ids.ContainsKey(args[0]))
                    {
                        Vk.MessagesSend("Пользователь уже находится в списке.");
                        return;
                    }
                    else
                    {
                        target_ids.Add(args[0], templane_user);
                        Cache.Set("users_online_check", target_ids, 600);
                        Vk.MessagesSend("Пользователь был добавлен в список.");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }

        }

        public async void command_delcheckuser()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_reports == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "syscheckusers", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Укажите ID пользователя.");
                    return;
                }

                var target_ids = Cache.Get<Dictionary<string, Dictionary<string, string>>>("users_online_check");

                if (target_ids == null)
                {
                    Vk.MessagesSend("Пользователь не находится в списке.");
                    return;
                }
                else
                {
                    if (target_ids.ContainsKey(args[0]))
                    {
                        target_ids.Remove(args[0]);
                        Cache.Set("users_online_check", target_ids, 600);
                        Vk.MessagesSend("Пользователь был убран из списка.");
                        return;
                    }
                    else
                    {
                        Vk.MessagesSend("Пользователь не находится в списке.");
                        return;
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_botadmins()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_reports == 0 && settings.OWNER_IDS[Vk.m_from_id].access_getquest == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "botadmins", 3))
                {
                    return;
                }

                if (settings.OWNER_IDS.Count <= 0)
                {
                    Vk.MessagesSend("Администраторов бота не существует.");
                    return;
                }
                List<long> userIds = new();
                foreach (var item in settings.OWNER_IDS)
                {
                    userIds.Add(item.Value.user_id);
                }
                var nick = await Vk.UserGetNameUrls(userIds.ToArray());
                string text = "🤡 Список агентов поддержки:<br><br>";

                foreach (var item in settings.OWNER_IDS)
                {
                    if (item.Value.admin == 1)
                    {
                        continue;
                    }

                    var nickAdmin = await Vk.UserGetNameUrls(new long[] { item.Value.admin });

                    var quests = db.agentGetQuests(item.Value.user_id);//;
                    text += $"№{item.Value.id} — {nick[item.Value.user_id.ToString()]} | Назначил: {nickAdmin[item.Value.admin.ToString()]} | Т: {item.Value.answers} Q: {quests}<br>";
                }
                text += "<br>Для отображения спонсоров введите: /sponsors.";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sponsors()
        {
            try
            {
                // reportGet
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_reports == 0)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "sponsors", 3))
                {
                    return;
                }

                if (settings.OWNER_IDS.Count <= 0)
                {
                    Vk.MessagesSend("Спонсоров бота не существует.");
                    return;
                }
                List<long> userIds = new();
                foreach (var item in settings.OWNER_IDS)
                {
                    userIds.Add(item.Value.user_id);
                }
                var nick = await Vk.UserGetNameUrls(userIds.ToArray());
                string text = "🤡 Список Спонсоров:<br><br>";

                foreach (var item in settings.OWNER_IDS)
                {
                    if (item.Value.admin != 1)
                    {
                        continue;
                    }

                    var timeD = "перманентно";
                    if (item.Value.expire != null)
                    {
                        timeD = "до " + item.Value.expire.ToString();
                    }
                    var quests = db.agentGetQuests(item.Value.user_id);//;
                    text += $"№{item.Value.id} — {nick[item.Value.user_id.ToString()]} | {timeD}<br>";
                }
                text += "<br>Для отображения агентов поддержки введите: /botadmins.";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_settoken()
        {
            try
            {
                if (Vk.m_peer_id > 2e9 && Vk.m_peer_id < 2e9 + 1e8)
                {
                    Vk.MessagesSend("В целях безопасности, эту команду можно использовать только в личных сообщениях с ботом.");
                    return;
                }
                Dictionary<string, string>? UserInfo = db.usersGetUser(Vk.m_from_id);

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать токен привязки. Получить его можно по следующей ссылке: https://vk.cc/cpOa8O");
                    return;
                }

                var method = "account.getInfo";
                var parames = new Dictionary<string, string>() { { "access_token", args[0] } };
                var result = await Vk.VkAPIs(method, parames);

                if (result.ContainsKey("error"))
                {
                    Vk.MessagesSend("Токен введен неверно.");
                    return;
                }

                db.usersSetAccessToken(Vk.m_from_id, args[0]);

                Vk.MessagesSend("Токен доступа успешно установлен. Для привязки его к определенной беседе используйте команду !peertoken");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_stickers()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.usersGetUser(Vk.m_from_id);

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "stickers", 10))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == null || args[0] == "" || !settings.isUserChat(long.Parse(args[0])))
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }

                Cache cach = new();
                var resultCache = cach.Get<JToken?>("store_cache_" + args[0]);

                if (resultCache == null)
                {
                    var method = "gifts.getCatalog";
                    var parames = new Dictionary<string, string>() { { "access_token", settings.TOKEN_USER } ,
                    { "user_id", args[0] },
                    { "type", "stickers" } };
                    //{ "filters", "promoted,purchased" } };
                    //{ "extended", "1" } };
                    //var result = await Vk.VkAPIs(method, parames);
                    //store.getProducts 
                    //var method = "store.getProducts";
                    //var parames = new Dictionary<string, string>() { { "access_token", settings.TOKEN_USER } ,
                    //    { "user_id", args[0] },
                    //   { "type", "stickers" },
                    //{ "filters", "purchased,active" }, { "extended", "0" } };
                    var result = await Vk.VkAPIs(method, parames);
                    if (result.ContainsKey("error") || !result.ContainsKey("response"))
                    {
                        Vk.MessagesSend("Ошибка обработки запроса. Попробуйте позднее.");
                        return;
                    }

                    var resp = result["response"];
                    if (resp[1] == null)
                    {
                        Vk.MessagesSend("Ошибка обработки запроса. Попробуйте позднее.");
                        return;
                    }
                    if (resp[1]["items"] == null)
                    {
                        Vk.MessagesSend("Ошибка обработки запроса. Попробуйте позднее.");
                        return;
                    }
                    var stickers = resp[1]["items"];
                    //cach.Set("store_cache_" + args[0], stickers, 600);
                    resultCache = stickers;
                }
                //result = null;
                //resp = null;
                var priceCache = cach.Get<JToken?>("pricestore_cache");

                if (priceCache == null)
                {
                    var method = "gifts.getCatalog";
                    var parames = new Dictionary<string, string>() { { "access_token", settings.TOKEN_USER } ,
                    { "user_id", settings.TOKEN_USER_ID.ToString() },
                    { "type", "stickers" } };
                    //{ "filters", "promoted,purchased" } };
                    //{ "extended", "1" } };
                    //var result = await Vk.VkAPIs(method, parames);
                    //store.getProducts 
                    //var method = "store.getProducts";
                    //var parames = new Dictionary<string, string>() { { "access_token", settings.TOKEN_USER } ,
                    //    { "user_id", args[0] },
                    //   { "type", "stickers" },
                    //{ "filters", "purchased,active" }, { "extended", "0" } };
                    var resultC = await Vk.VkAPIs(method, parames);
                    if (resultC.ContainsKey("error") || !resultC.ContainsKey("response"))
                    {
                        Vk.MessagesSend("Ошибка обработки запроса. Попробуйте позднее.");
                        return;
                    }

                    var resp1 = resultC["response"];
                    if (resp1[1] == null)
                    {
                        Vk.MessagesSend("Ошибка обработки запроса. Попробуйте позднее.");
                        return;
                    }
                    if (resp1[1]["items"] == null)
                    {
                        Vk.MessagesSend("Ошибка обработки запроса. Попробуйте позднее.");
                        return;
                    }
                    var stickersPrice = resp1[1]["items"];
                    //cach.Set("pricestore_cache", stickersPrice, 1200);
                    priceCache = stickersPrice;
                }

                var nick = await Vk.UserGetNameUrls(new long[] { long.Parse(args[0]) });
                string stickerss = "";
                int price = 0;
                int sticker_count = 0;

                if (resultCache.Count() >= 1500)
                {
                    Vk.MessagesSend("Слишком большое количество стикер-паков для бота 😱😱" + resultCache.Count());
                    return;
                }

                try
                {
                    for (int i = 2; i < resultCache.Count(); i++)
                    {
                        if (resultCache[i]["disabled"] != null)
                        {
                            //Console.WriteLine(resultCache[i].ToString());
                            price += int.Parse(priceCache[i]["price"].ToString());
                            stickerss += resultCache[i]["sticker_pack"]["title"] + ", ";
                            sticker_count++;
                        }
                        else
                        {

                            continue;
                        }
                    }
                }
                catch (Exception ex)
                {
                    Vk.MessagesSend("Ошибка 05.1 : " + ex.Message + " 😱😱" + resultCache.Count());
                    return;
                }

                if (stickerss.Length > 4)
                {
                    stickerss = stickerss.Remove(stickerss.Length - 2);
                }
                string text = "😏 " + nick[args[0]] + $" имеет '{sticker_count}' платных стикер-паков. Это примерно '{price}' голосов, '{price * 7}' рублей.<br><br>✍ {stickerss}" +
                    $"<br>";
                resultCache = null;
                Vk.MessagesSend(text);
                //Console.WriteLine(result.ToString());
                //Vk.MessagesSend(result.ToString());

                //List<string> namesStickers = new();
                //foreach (var item in resp)
                //{
                //idsStickers.Add(int.Parse(item["id"].ToString()));
                //namesStickers.Add(item["title"].ToString());
                //}
                //Console.WriteLine("1");
                //Vk.MessagesSend(result.ToString());

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_checkban()
        {
            try
            {
                if (settings.isPeer(Vk.m_peer_id))
                {
                    Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 0, "checkban"))
                    {
                        return;
                    }
                }

                //CommandsCheck
                if (!db.UserIsVip(Vk.m_from_id))
                {
                    //return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "checkban", 15))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                //Console.WriteLine(args);
                if (args[0] == null || args[0] == "")
                {
                    //Vk.MessagesSend(CommandsList.CommandsHelp["checkban"]);
                    //return;
                    args[0] = Vk.m_from_id.ToString();
                }
                if (args[0] == "0")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["checkban"]);
                    return;
                }

                if (args[0] != Vk.m_from_id.ToString() && !settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    Vk.MessagesSend("Использовать данную команду на других людях запрещено в целях сохранения и защиты персональных данных.");
                    return;
                }

                var data = db.bansGetBansForUser(long.Parse(args[0]));
                if (data == null || data.Count <= 0)
                {
                    Vk.MessagesSend("Указанный пользователь не заблокирован ни в одной из бесед.");
                    return;
                }
                string text = "📝 Указанный пользователь заблокирован в '" + data.Count + "' беседах.<br><br>" +
                    "Название беседы⠀⠀⠀⠀⠀| Срок блокировки⠀⠀⠀⠀| Причина<br><br>";
                int i = 0;
                bool skipped = false;
                foreach (var item in data)
                {
                    if (i >= 15)
                    {
                        i++;
                        skipped = true;
                        continue;
                    }
                    i++;
                    long peerid = 0;
                    try
                    {
                        peerid = long.Parse(item["peer_id"]);
                        string peerName = "—";
                        var peerInfo = db.peersGetPeer(peerid);
                        if (peerInfo["active"] == "0")
                        {
                            i--;
                            continue;
                        }
                        if (peerInfo["title"] != "0")
                        {
                            peerName = peerInfo["title"];
                        }
                        string dateUnban = "перманентно";
                        if (item["date_unban"] != "")
                        {
                            dateUnban = db.timeGetForMysql(item["date_unban"]).ToString("g");
                        }
                        text += $"⠀{i}. '{peerName}'\t| {dateUnban}\t| {item["reason"]}<br>";
                    }
                    catch
                    {
                        continue;
                    }
                }
                if (skipped)
                {
                    text += "<br>Обратите внимание, часть блокировок была пропущена, поскольку их слишком много.";
                }
                Vk.MessagesSend(text);
            }
            catch (Exception e)
            {
                Console.WriteLine(e.ToString());
            }
        }


        // -------------------------------------------------------- ИГРОВЫЕ КОМАНДЫ --------------------------------------------------------
        public async void command_ng()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_ng", 10))
                {
                    return;
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                string text;

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (userInfo["opros"] == "0")
                {
                    var targetUser = userInfo;
                    if (args[0] != null && args[0] != "")
                    {
                        targetUser = db.usersGetUser(long.Parse(args[0]));
                        var userEurosTarget = getUlongMoney(targetUser["euros"]) + 10000;
                        string we = (long.Parse(args[0]) < 0) ? $"[club{args[0].Substring(1)}|сообществу]" : $"[id{args[0]}|пользователю]";
                        text = $"Вы успешно подарили подарок за прохождение опроса {we} — " + getEuroMoney("10000") + ".<br>Новый баланс: " + getEuroMoney(userEurosTarget.ToString());
                        db.gameSetUserEuros(long.Parse(args[0]), userEurosTarget.ToString());
                        db.gameSetUserNG31(Vk.m_from_id, 1);
                        Vk.MessagesSend(text);
                        return;
                    }

                    var userEuros = getUlongMoney(targetUser["euros"]) + 10000;

                    text = "Вы успешно получили подарок за прохождение опроса — " + getEuroMoney("10000") + ".<br>Новый баланс: " + getEuroMoney(userEuros.ToString());
                    db.gameSetUserEuros(Vk.m_from_id, userEuros.ToString());
                    db.gameSetUserNG31(Vk.m_from_id, 1);
                    Vk.MessagesSend(text);
                    return;
                }
                else
                {
                    text = "К сожалению, вы уже получили/подарили бонус за прохождение опроса.";
                    Vk.MessagesSend(text);
                }

                /*if (DateTimeOffset.Now.Day == 7)
                {
                    if (userInfo["7march"] == "0")
                    {
                        var targetUser = userInfo;
                        if (args[0] != null && args[0] != "")
                        {
                            targetUser = db.usersGetUser(long.Parse(args[0]));
                            var userEurosTarget = getUlongMoney(targetUser["euros"]) + 888;
                            string we = (long.Parse(args[0]) < 0) ? $"[club{args[0].Substring(1)}|сообществу]" : $"[id{args[0]}|пользователю]";
                            text =  $"Вы успешно подарили подарок на 8 марта {we} — " + getEuroMoney("888") + ".<br>Новый баланс: " + getEuroMoney(userEurosTarget.ToString());
                            db.gameSetUserEuros(long.Parse(args[0]), userEurosTarget.ToString());
                            db.gameSetUserNG31(Vk.m_from_id, 1);
                            Vk.MessagesSend(text);
                            return;
                        }

                        var userEuros = getUlongMoney(targetUser["euros"]) + 888;

                        text = "Вы успешно получили подарок на 8 марта — " + getEuroMoney("888") + ".<br>Новый баланс: " + getEuroMoney(userEuros.ToString());
                        db.gameSetUserEuros(Vk.m_from_id, userEuros.ToString());
                        db.gameSetUserNG31(Vk.m_from_id, 1);
                        Vk.MessagesSend(text);
                        return;
                    }
                    else
                    {
                        text = "К сожалению, вы уже получили/подарили бонус 7 марта. Следующий будет доступен 8 марта.";
                        Vk.MessagesSend(text);
                    }
                    
                }
                else
                {
                    if (DateTimeOffset.Now.Day == 8)
                    {
                        if (userInfo["8march"] == "0")
                        {
                            var targetUser = userInfo;
                            if (args[0] != null && args[0] != "")
                            {
                                targetUser = db.usersGetUser(long.Parse(args[0]));
                                var userEurosTarget = getUlongMoney(targetUser["euros"]) + 888;
                                string we = (long.Parse(args[0]) < 0) ? $"[club{args[0].Substring(1)}|сообществу]" : $"[id{args[0]}|пользователю]";
                                text = $"С Новым, 2024 годом!<br><br>Вы успешно подарили подарок на 8 марта {we} — " + getEuroMoney("888") + ".<br>Новый баланс: " + getEuroMoney(userEurosTarget.ToString());
                                db.gameSetUserEuros(long.Parse(args[0]), userEurosTarget.ToString());
                                Vk.MessagesSend(text);
                                db.gameSetUserNG01(Vk.m_from_id, 1);
                                return;
                            }

                            var userEuros = getUlongMoney(targetUser["euros"]) + 888;

                            text = "С 8 марта!<br><br>Вы успешно получили подарок на 8 марта — " + getEuroMoney("888") + ".<br>Новый баланс: " + getEuroMoney(userEuros.ToString());
                            db.gameSetUserEuros(Vk.m_from_id, userEuros.ToString());
                            Vk.MessagesSend(text);
                            db.gameSetUserNG01(Vk.m_from_id, 1);
                            return;
                        }
                        else
                        {
                            text = "К сожалению, вы уже получили/подарили бонус 8 марта.";
                            Vk.MessagesSend(text);
                        }
                    }
                    else
                    {
                        text = "Подарок будет доступен 7 и 8 марта.";
                        Vk.MessagesSend(text);
                    }
                }*/

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_profile()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_profile", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                long targetId = Vk.m_from_id;
                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        targetId = long.Parse(args[0]);
                        if (targetId == 0 || targetId < 0)
                        {
                            targetId = Vk.m_from_id;
                        }
                    }
                    catch { }
                }
                var userInfo = db.usersGetUser(targetId);
                if (userInfo == null)
                {
                    Vk.MessagesSend("❌ Пользователь не найден в базе.");
                    return;
                }

                var country_text = "без гражданства";
                if (userInfo["country"] != "0")
                {
                    var countryInfo = db.CountriesGetCountry(long.Parse(userInfo["country"]));
                    if (countryInfo != null) country_text = countryInfo["name"];
                }

                string dop_text = "";
                if (targetId > 0)
                {
                    var slaveAccount = db.slavesGetSlave(targetId);
                    var slaves = db.slavesGetAllForOwner(targetId);

                    if (slaveAccount != null)
                        dop_text = "👹 Цепей для рабов: " + slaveAccount["armours"] + "<br>";
                    if (slaves != null)
                        dop_text += "👽 Рабов: " + slaves.Count() + "<br>";
                }


                string text = "💫 ID: " + targetId + "<br>" +
                    "🌍 Страна: " + country_text + "<br>" +
                    "💴 Рублей: " + getRubsMoney(userInfo["rubs"]) + "<br>" +
                    "💵 Долларов: " + getDollMoney(userInfo["dollars"]) + "<br>" +
                    "💷 Евро: " + getEuroMoney(userInfo["euros"]) + "<br>" +
                    "💉 Энергия: " + userInfo["energy"] + "/10" + "<br>" +
                    "👑 Рейтинг: " + userInfo["rating"] + "<br>" +
                    "💠 Уровень: " + userInfo["level"] + "<br>" + dop_text;

                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_balance()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_balance", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                string text = "На ваших счетах:<br>" +
                    "💴 Рублей: " + getRubsMoney(userInfo["rubs"]) + "<br>" +
                    "💵 Долларов: " + getDollMoney(userInfo["dollars"]) + "<br>" +
                    "💷 Евро: " + getEuroMoney(userInfo["euros"]) + "<br>" +
                    "👑 Рейтинг: " + userInfo["rating"] + "<br>";

                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_country()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_country", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var country_text = "без гражданства";
                if (userInfo["country"] == "0")
                {
                    Vk.MessagesSend("Вы не имеете гражданства. Для его получения воспользуйтесь командой !гражданство<br><br>" +
                        "Просмотр списка доступных стран: !страны");
                    return;
                }
                var countryInfo = db.CountriesGetCountry(long.Parse(userInfo["country"]));

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(countryInfo["owner"]) });
                string name_url = "[id" + countryInfo["owner"] + "|Пользователь]";
                if (vkInfo.ContainsKey("id" + countryInfo["owner"]))
                {
                    name_url = "[id" + countryInfo["owner"] + "|" + vkInfo["id" + countryInfo["owner"]].first_name + " " +
                        vkInfo["id" + countryInfo["owner"]].last_name + "]";
                }
                else
                {
                    if (long.Parse(countryInfo["owner"]) < 0)
                    {
                        name_url = "[club" + countryInfo["owner"].Substring(1) + "|Сообщество]";
                    }
                }

                string text = "💫 ID страны: " + countryInfo["id"] + "<br>" +
                    "🌍 Полное название: " + countryInfo["name"] + "<br>" +
                    "💭 Короткое название: " + countryInfo["short_name"] + "<br>" +
                    "💴 Казна (рубли): " + getRubsMoney(countryInfo["rubles"]) + "<br>" +
                    "💵 Казна (доллары): " + getDollMoney(countryInfo["dollars"]) + "<br>" +
                    "💷 Казна (евро): " + getEuroMoney(countryInfo["euros"]) + "<br>" +
                    "🔱 Президент: " + name_url + "<br>" +
                    "🐩 Численность: " + countryInfo["members"] + "<br>" +
                    "🌏 Площадь: " + countryInfo["area"] + " км²<br>" +
                    "💸 Подоходный налог: " + countryInfo["tax_income"] + "%" + "<br>" +
                    "💸 Налог на добавленную стоимость: " + countryInfo["tax_vat"] + "%<br>" +
                    "💸 Имущественный налог: " + countryInfo["tax_services"] + "%<br>" +
                    "💸 Налог на казино: " + countryInfo["tax_kazino"] + "%";

                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_mycountry()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_country", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                Cache cach = new();

                string buttons = Vk.GenerateKeyboard(new string[] { "Собрать налоги", "Инфраструктура", "Территория", "Налоги", "Армия" },
                        new string[] { "mycountry take", "mycountry infr", "mycountry terr", "mycountry tax", "mycountry army" },
                        new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_RED },
                        new int[] { 0, 1, 2, 3, 4 }, false, true, true);

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var vkInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });


                var country_text = "без гражданства";
                if (userInfo["country"] == "0")
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы не имеете гражданства. Для его получения воспользуйтесь командой !гражданство<br><br>" +
                        "Просмотр списка доступных стран: !страны<br><br>" +
                        "Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()]);
                        return;
                    }
                    Vk.MessagesSend("Вы не имеете гражданства. Для его получения воспользуйтесь командой !гражданство<br><br>" +
                        "Просмотр списка доступных стран: !страны");
                    return;
                }
                var countryInfo = db.CountriesGetCountry(long.Parse(userInfo["country"]));
                if (countryInfo["owner"] != Vk.m_from_id.ToString())
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы не являетесь президентом страны.<br><br>" +
                        "Вы можете принять участие в выборах: !баллотироваться<br><br>" +
                        "Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()]);
                        return;
                    }
                    Vk.MessagesSend("Вы не являетесь президентом страны.<br><br>" +
                        "Вы можете принять участие в выборах: !баллотироваться");
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "" || args[0] == "main")
                {

                    string text = "💫 " + countryInfo["id"] + " " +
                        countryInfo["name"] + "<br>" +
                        "💴 Казна (рубли): " + getRubsMoney(countryInfo["rubles"]) + "<br>" +
                        "💵 Казна (доллары): " + getDollMoney(countryInfo["dollars"]) + "<br>" +
                        "💷 Казна (евро): " + getEuroMoney(countryInfo["euros"]) + "<br>" +
                        "🔱 Президент: " + vkInfo[Vk.m_from_id.ToString()] + "<br>" +
                        "🐩 Численность: " + countryInfo["members"] + "<br>" +
                        "🌏 Площадь: " + countryInfo["area"] + " км²<br>" +
                        "💸 Подоходный налог: " + countryInfo["tax_income"] + "%" + "<br>" +
                        "💸 Налог на добавленную стоимость: " + countryInfo["tax_vat"] + "%<br>" +
                        "💸 Имущественный налог: " + countryInfo["tax_services"] + "%<br>" +
                        "💸 Налог на казино: " + countryInfo["tax_kazino"] + "%<br><br>Выберите действие";


                    //Vk.MessagesSend(text, 1, 0, buttons);
                    if (args[0] != null && args[0] == "main")
                    {
                        var last_mess = cach.Get<string>("last_message_" + Vk.m_peer_id.ToString());
                        if (last_mess == null || last_mess == "")
                        {
                            var idmes2 = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                            cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes2.ToString());
                        }
                        else
                        {
                            Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_mess));
                            cach.Set("last_message_" + Vk.m_peer_id.ToString(), last_mess);
                        }
                    }
                    else
                    {
                        var idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    }
                    return;
                }
                else
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "Назад", "Собрать налоги", "Инфраструктура", "Территория", "Налоги", "Армия" },
                        new string[] { "mycountry main", "mycountry take", "mycountry infr", "mycountry terr", "mycountry tax", "mycountry army" },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_RED },
                        new int[] { 0, 1, 2, 3, 4, 5 }, false, true, true);
                    var last_mess = cach.Get<string>("last_message_" + Vk.m_peer_id.ToString());
                    string text = "";
                    //Собрать налоги
                    if (args[0] == "take")
                    {
                        if (countryInfo["date_tax"] != null || countryInfo["date_tax"] != "")
                        {
                            var date_tax = db.timeGetForMysql(countryInfo["date_tax"]);
                            if (DateTimeOffset.Now.ToUnixTimeSeconds() >= date_tax.AddDays(1).ToUnixTimeSeconds())
                            {
                                var target_seconds = DateTimeOffset.Now.ToUnixTimeSeconds() - date_tax.ToUnixTimeSeconds();

                                long target_days = target_seconds / 60 / 24;
                                if (target_days > 31)
                                {
                                    target_days = 31;
                                }
                                var tax = Math.Round((decimal.Parse(countryInfo["average_zp"]) / (decimal)100) * decimal.Parse(countryInfo["tax_income"])
                                     * decimal.Parse(countryInfo["members"]) * (decimal)target_days * (decimal)0.3);
                                var new_balance = getUlongMoney(countryInfo["rubles"]) + getUlongMoney(tax.ToString());
                                db.CountriesSetRub(long.Parse(countryInfo["id"]), new_balance.ToString());
                                db.CountriesSetTaxLast(long.Parse(countryInfo["id"]), db.timeGetForString(DateTimeOffset.Now));
                                text = "💳 Вы собрали налоги за '" + target_days + "' дней в казну.<br>💰 В казну прибыло: " + getRubsMoney(tax.ToString()) + "<br><br>" +
                                    "💶 Рублей в казне: " + getRubsMoney(new_balance.ToString()) + "<br>" +
                                    "💸 Налоги можно будет собрать: " + DateTimeOffset.Now.AddDays(1).ToString("g");
                            }
                            else
                            {
                                text = "💸 Налоги можно будет собрать: " + date_tax.AddDays(1).ToString("g");
                            }
                        }
                        else
                        {
                            text = "";
                        }

                        //date_tax

                    }
                    //Инфраструктура
                    else if (args[0] == "infr")
                    {
                        //общественный транспорт, медицина, заводы, образование
                        text = "Выберите подкатегорию:<br>" +
                            "⠀🚎 — общественный транспорт<br>" +
                            "⠀⚕ — медицина<br>" +
                            "⠀🏗 — заводы<br>" +
                            "⠀🎓 — образование";
                        buttons = Vk.GenerateKeyboard(new string[] { "Назад", "🚎", "⚕", "🏗", "🎓" },
                        new string[] { "mycountry main", "m_country buses", "m_country med", "m_country zav", "m_country obr", },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE },
                        new int[] { 0, 1, 2, 3, 4 }, false, true, true);
                    }
                    //Территория
                    else if (args[0] == "terr")
                    {


                    }
                    //Налоги
                    else if (args[0] == "tax")
                    {


                    }
                    //Армия
                    else if (args[0] == "army")
                    {


                    }

                    if (last_mess == null || last_mess == "")
                    {
                        if (Vk.is_callbackButton)
                        {
                            text += "<br><br>Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()];
                        }
                        var idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    }
                    else
                    {
                        if (Vk.is_callbackButton)
                        {
                            text += "<br><br>Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()];
                        }
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_mess));
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), last_mess);
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_mcountry()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_country", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var country_text = "без гражданства";
                if (userInfo["country"] == "0")
                {
                    Vk.MessagesSend("Вы не имеете гражданства. Для его получения воспользуйтесь командой !гражданство<br><br>" +
                        "Просмотр списка доступных стран: !страны");
                    return;
                }
                var countryInfo = db.CountriesGetCountry(long.Parse(userInfo["country"]));

                if (countryInfo["owner"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Вы не являетесь президентом данной страны.<br><br>" +
                        "Вы можете принять участие в выборах: !баллотироваться");
                    return;
                }

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(countryInfo["owner"]) });
                string name_url = "[id" + countryInfo["owner"] + "|Пользователь]";
                if (vkInfo.ContainsKey("id" + countryInfo["owner"]))
                {
                    name_url = "[id" + countryInfo["owner"] + "|" + vkInfo["id" + countryInfo["owner"]].first_name + " " +
                        vkInfo["id" + countryInfo["owner"]].last_name + "]";
                }
                else
                {
                    if (long.Parse(countryInfo["owner"]) < 0)
                    {
                        name_url = "[club" + countryInfo["owner"].Substring(1) + "|Сообщество]";
                    }
                }

                string text = "💫 " + countryInfo["id"] + " " +
                    countryInfo["name"] + "<br>" +
                    "💴 Казна (рубли): " + getRubsMoney(countryInfo["rubles"]) + "<br>" +
                    "💵 Казна (доллары): " + getDollMoney(countryInfo["dollars"]) + "<br>" +
                    "💷 Казна (евро): " + getEuroMoney(countryInfo["euros"]) + "<br>" +
                    "🔱 Президент: " + name_url + "<br>" +
                    "🐩 Численность: " + countryInfo["members"] + "<br>" +
                    "🌏 Площадь: " + countryInfo["area"] + " км²<br>" +
                    "💸 Подоходный налог: " + countryInfo["tax_income"] + "%" + "<br>" +
                    "💸 Налог на добавленную стоимость: " + countryInfo["tax_vat"] + "%<br>" +
                    "💸 Имущественный налог: " + countryInfo["tax_services"] + "%<br>" +
                    "💸 Налог на казино: " + countryInfo["tax_kazino"] + "%<br><br>Выберите действие";

                string buttons = Vk.GenerateKeyboard(new string[] { "Собрать налоги", "Инфраструктура", "Территория", "Налоги", "Армия" },
                    new string[] { "mcountry take", "mcountry infr", "mcountry terr", "mcountry tax", "mcountry army" },
                    new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_GREEN, Vk.BUTTON_BLUE, Vk.BUTTON_RED },
                    new int[] { 0, 1, 2, 3, 4 }, false, true, true);

                Vk.MessagesSend(text, 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_m_countrytwo()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_country", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                Cache cach = new();


                string buttons = Vk.GenerateKeyboard(new string[] { "Назад", "🚎", "⚕", "🏗", "🎓" },
                new string[] { "mycountry main", "m_country buses", "m_country med", "m_country zav", "m_country obr", },
                new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE },
                new int[] { 0, 1, 2, 3, 4 }, false, true, true);

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var vkInfo = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });


                var country_text = "без гражданства";
                if (userInfo["country"] == "0")
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы не имеете гражданства. Для его получения воспользуйтесь командой !гражданство<br><br>" +
                        "Просмотр списка доступных стран: !страны<br><br>" +
                        "Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()]);
                        return;
                    }
                    Vk.MessagesSend("Вы не имеете гражданства. Для его получения воспользуйтесь командой !гражданство<br><br>" +
                        "Просмотр списка доступных стран: !страны");
                    return;
                }
                var countryInfo = db.CountriesGetCountry(long.Parse(userInfo["country"]));
                if (countryInfo["owner"] != Vk.m_from_id.ToString())
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы не являетесь президентом страны.<br><br>" +
                        "Вы можете принять участие в выборах: !баллотироваться<br><br>" +
                        "Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()]);
                        return;
                    }
                    Vk.MessagesSend("Вы не являетесь президентом страны.<br><br>" +
                        "Вы можете принять участие в выборах: !баллотироваться");
                    return;
                }

                string text = "";

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "" || args[0] == "main")
                {

                    text = "Выберите подкатегорию:<br>" +
                            "⠀🚎 — общественный транспорт<br>" +
                            "⠀⚕ — медицина<br>" +
                            "⠀🏗 — заводы<br>" +
                            "⠀🎓 — образование";

                    //Vk.MessagesSend(text, 1, 0, buttons);
                    if (args[0] != null && args[0] == "main")
                    {
                        var last_mess = cach.Get<string>("last_message_" + Vk.m_peer_id.ToString());
                        if (last_mess == null || last_mess == "")
                        {
                            var idmes2 = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                            cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes2.ToString());
                        }
                        else
                        {
                            Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_mess));
                            cach.Set("last_message_" + Vk.m_peer_id.ToString(), last_mess);
                        }
                    }
                    else
                    {
                        var idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    }
                    return;
                }
                else
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "Назад", "🚎", "⚕", "🏗", "🎓" },
                        new string[] { "mycountry main", "m_country buses", "m_country med", "m_country zav", "m_country obr", },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE },
                        new int[] { 0, 1, 2, 3, 4 }, false, true, true);
                    var last_mess = cach.Get<string>("last_message_" + Vk.m_peer_id.ToString());

                    //Общественный транспорта
                    if (args[0] == "buses")
                    {
                        var minibuses = countryInfo["transport_minibuses"];
                        var buses = countryInfo["transport_buses"];
                        var trolleybuses = countryInfo["transport_trolleybuses"];
                        var trans = countryInfo["transport_trans"];
                        var metro = countryInfo["transport_metro"];

                        int plus_minibuses = int.Parse(minibuses) * 1;
                        int plus_buses = int.Parse(buses) * 2;
                        int plus_trolleybuses = int.Parse(trolleybuses) * 3;
                        int plus_trans = int.Parse(trans) * 4;
                        int plus_metro = int.Parse(metro) * 5;
                        //date_tax

                    }
                    //Медицина
                    else if (args[0] == "med")
                    {

                    }
                    //Заводы
                    else if (args[0] == "zav")
                    {


                    }
                    //Образование
                    else if (args[0] == "obr")
                    {


                    }

                    if (last_mess == null || last_mess == "")
                    {
                        if (Vk.is_callbackButton)
                        {
                            text += "<br><br>Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()];
                        }
                        var idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    }
                    else
                    {
                        if (Vk.is_callbackButton)
                        {
                            text += "<br><br>Команду выполнил: " + vkInfo[Vk.m_from_id.ToString()];
                        }
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_mess));
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), last_mess);
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }


        public async void game_cmd_getcountries()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_getcountries", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });
                long list = 1;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        list = long.Parse(args[0]);
                    }
                    catch
                    {
                        Vk.MessagesSend("Указанная страница не найдена.<br>Используйте: !страны [страница]");
                        return;
                    }
                    if (list <= 0)
                    {
                        Vk.MessagesSend("Указанная страница не найдена.<br>Используйте: !страны [страница]");
                        return;
                    }
                }

                long max = list * 25;
                long min = max - 24;

                var countries = db.CountriesGetList();


                if (countries.Count <= 0)
                {
                    Vk.MessagesSend("К сожалению, список стран не найден.");
                    return;
                }

                long all_list = countries.Count / 25;

                all_list++;

                if (countries.Count < min)
                {
                    Vk.MessagesSend("Указанная страница не найдена. Всего страниц: " + all_list);
                    return;
                }

                long iters = 0;
                string text = "Список доступных стран:<br><br>";
                foreach (var item in countries)
                {
                    iters++;
                    if (iters < min || iters > max)
                    {
                        continue;
                    }
                    text = text + "№ " + item["id"] + ". " + item["name"] + " | " + item["members"] + " участников.<br>";
                }

                string buttons = "";
                if (list == 1)
                {
                    if (all_list != 1)
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "—>" },
                        new string[] { "countries 2" },
                        new string[] { Vk.BUTTON_WHITE });
                    }
                }
                else if (list == all_list && list != 1)
                {
                    var previus = list - 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—" },
                        new string[] { "countries " + previus },
                        new string[] { Vk.BUTTON_WHITE });
                }
                else
                {
                    var previus = list - 1;
                    var next = list + 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—", "—>" },
                        new string[] { "countries " + previus, "countries " + next },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                }

                text = text + "<br>Страница: " + list + "<br>" +
                    "Всего страниц: " + all_list;
                Vk.MessagesSend(text, 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_setcountry()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_setcountry", 20))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }
                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать название страны, либо её ID.");
                    return;
                }
                long target_country = 0;
                Dictionary<string, string> countryInfo = new();

                try
                {
                    target_country = long.Parse(args[0]);
                    countryInfo = db.CountriesGetCountry(target_country);
                    if (countryInfo == null || countryInfo.Count <= 0)
                    {
                        Vk.MessagesSend("Страны с таким названием/ID не существует. Используйте !страны для просмотра списка доступных.");
                        return;
                    }
                }
                catch
                {
                    var countries = db.CountriesGetList();
                    string target_name = args[0].ToLower().Replace(" ", "");
                    foreach (var item in countries)
                    {
                        try
                        {
                            string target_item_name = item["name"].ToLower().Replace(" ", "");
                            string target_item_shortname = item["short_name"].ToLower().Replace(" ", "");

                            if (target_item_name == target_name || target_item_shortname == target_name)
                            {
                                target_country = long.Parse(item["id"]);
                                countryInfo = item;
                                break;
                            }
                        }
                        catch
                        {

                        }
                    }
                }

                if (target_country == 0)
                {
                    Vk.MessagesSend("Страны с таким названием/ID не существует. Используйте !страны для просмотра списка доступных.");
                    return;
                }



                var userInfo = db.usersGetUser(Vk.m_from_id);

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(countryInfo["owner"]) });
                string name_url = "[id" + countryInfo["owner"] + "|Пользователь]";
                if (vkInfo.ContainsKey("id" + countryInfo["owner"]))
                {
                    name_url = "[id" + countryInfo["owner"] + "|" + vkInfo["id" + countryInfo["owner"]].first_name + " " +
                        vkInfo["id" + countryInfo["owner"]].last_name + "]";
                }
                else
                {
                    if (long.Parse(countryInfo["owner"]) < 0)
                    {
                        name_url = "[club" + countryInfo["owner"].Substring(1) + "|Сообщество]";
                    }
                }
                db.CountriesAddMember(target_country);
                countryInfo = db.CountriesGetCountry(target_country);

                string text = "🌍 Вы получили гражданство '" + countryInfo["name"] + "'. В предыдущей стране Вас лишили гражданства.<br>" +
                    "🔱 Президент: " + name_url + "<br>" +
                    "🐩 Численность: " + countryInfo["members"] + "<br>";

                Vk.MessagesSend(text);
                db.userSetCountry(Vk.m_from_id, target_country);
                db.CountriesRemoveMember(long.Parse(userInfo["country"]));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_kazino()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_kazino", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать сумму ставки.<br><br>" +
                        "Пример: !казино 5к или !казино все");
                    return;
                }

                var stavka = cmdChecker.getArgumentMoney(args[0]);
                args[0] = args[0].ToLower();
                if (stavka <= 0 && args[0] != "все" && args[0] != "всё")
                {
                    Vk.MessagesSend("Ставка не может быть меньше или равна нулю.<br><br>" +
                        "Пример: !казино 5к или !казино все");
                    return;
                }

                if (args[0] == "все" || args[0] == "всё")
                {
                    stavka = getUlongMoney(userInfo["rubs"]);
                    if (stavka <= 0)
                    {
                        Vk.MessagesSend("Вы не можете играть в казино, у Вас 0 рублей на аккаунте. ");
                        return;
                    }
                }

                if (stavka <= 0)
                {
                    Vk.MessagesSend("Ставка не может быть меньше или равна нулю.<br><br>" +
                        "Пример: !казино 5к или !казино все");
                    return;
                }

                var money_user = getUlongMoney(userInfo["rubs"]);
                if (stavka > money_user)
                {
                    if (money_user == 0)
                    {
                        Vk.MessagesSend("Вы не можете играть в казино, у Вас 0 рублей на аккаунте. ");
                        return;
                    }
                    Vk.MessagesSend("Упс! На Вашем счету с рублями недостаточно средств!<br><br>" +
                        "💴 Рублей на счету: " + getRubsMoney(userInfo["rubs"]));
                    return;
                }

                //money_user = money_user - stavka;

                Random Rand = new();
                long ran = Rand.Next(1, 10);

                long chanse_x5 = long.Parse(userInfo["chanse_kazino"]);
                long ran_chanse = Rand.Next(1, 100);

                System.Numerics.BigInteger result_win = 0;
                string text = "Ваша ставка: " + getRubsMoney(stavka.ToString()) + "<br>";

                System.Numerics.BigInteger getPrize(long chanse_x5s, long chanse, System.Numerics.BigInteger stavkar)
                {
                    try
                    {
                        if (chanse < chanse_x5s)
                        {
                            System.Numerics.BigInteger result_temp = stavka * 5;
                            //result_win = System.Numerics.BigInteger.Parse(Math.Round(result_temp).ToString());
                            result_win = result_temp;
                            text = text + "💪 Вы сорвали КУШ! " + getRubsMoney((result_win).ToString()) + " (x5)!";
                            return result_win;
                        }

                        if (chanse >= 80)
                        {
                            System.Numerics.BigInteger result_temp = stavka / 2;
                            result_win = System.Numerics.BigInteger.Abs(result_temp) * -1;
                            text = text + "😕 Вы проиграли " + getRubsMoney((System.Numerics.BigInteger.Abs(result_win)).ToString()) + " (x0.5)!";
                            return result_win;
                        }

                        if (chanse >= 70)
                        {
                            System.Numerics.BigInteger result_temp = stavka / 3;
                            result_win = System.Numerics.BigInteger.Abs(result_temp) * -1;
                            text = text + "😕 Вы проиграли " + getRubsMoney((System.Numerics.BigInteger.Abs(result_win)).ToString()) + " (x0.33)!";
                            return result_win;
                        }

                        if (chanse >= 55)
                        {
                            result_win = 0;

                            text = text + "🤭 Вы остались при своем! (x1)!";
                            return result_win;
                        }

                        if (chanse >= 40)
                        {
                            System.Numerics.BigInteger result_temp = stavka / 3;
                            result_win = System.Numerics.BigInteger.Abs(result_temp);
                            text = text + "💥 Вы выиграли " + getRubsMoney((result_win).ToString()) + " (x1.33)!";
                            return result_win;
                        }

                        if (chanse >= 25)
                        {
                            System.Numerics.BigInteger result_temp = stavka / 5;
                            result_win = System.Numerics.BigInteger.Abs(result_temp);
                            text = text + "💥 Вы выиграли " + getRubsMoney((result_win).ToString()) + " (x1.2)!";
                            return result_win;
                        }
                        else
                        {
                            result_win = stavka * -1;

                            text = text + "😫 Вы проиграли " + getRubsMoney((System.Numerics.BigInteger.Abs(result_win)).ToString()) + " (x0)!";
                            return result_win;
                        }
                        return 0;
                    }
                    catch (Exception ex)
                    {
                        text = "Указанная сумма слишком большая.<br>" + ex.Message;
                        Vk.MessagesSend(text);
                        return 0;
                    }
                }
                result_win = getPrize(chanse_x5, ran_chanse, stavka);
                /*else if (ran == 7)
                {
                    double result_temp = double.Parse(stavka.ToString()) * 5;
                    result_win = long.Parse(Math.Round(result_temp).ToString());
                    text = text + "💪 Вы сорвали КУШ! " + getRubsMoney((result_win).ToString()) + " (x5)";
                }*/

                //string stavka_1 = (Math.Round(decimal.Parse(stavka.ToString()) * 1.5m)).ToString();

                //var f1 = NumFraction(1.5m);
                //var f2 = NumFraction(0.5m);
                //string stavka_1 = (stavka * f1.numerator).ToString();
                string stavka_1 = (stavka / 10 * 15).ToString();
                //string stavka_2 = (stavka * f2.denominator).ToString();
                string stavka_2 = (stavka / 2).ToString();

                //string stavka_2 = (Math.Round(decimal.Parse(stavka.ToString()) * 0.5m)).ToString();

                string buttons = "";
                try
                {
                    money_user = money_user + result_win;
                    userInfo["rubs"] = money_user.ToString();
                    if (decimal.Parse(stavka_1) >= 1m && System.Numerics.BigInteger.Parse(stavka_1) <= money_user)
                    {
                        if (decimal.Parse(stavka_2) >= 1m && System.Numerics.BigInteger.Parse(stavka_2) <= money_user)
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить", "Ставка x1.5",
                                                                "Ставка x0.5",
                                                                "Поставить ВСЁ" },
                            new string[] { "казино " + stavka, "казино " + stavka_1, "казино " + stavka_2, "казино все" },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }
                        else
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить", "Ставка x1.5",
                                                                "Поставить ВСЁ" },
                            new string[] { "казино " + stavka, "казино " + stavka_1, "казино все" },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }

                    }
                    else
                    {
                        if (decimal.Parse(stavka_2) >= 1m && System.Numerics.BigInteger.Parse(stavka_2) <= money_user)
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить",
                                                                "Ставка x0.5",
                                                                "Поставить ВСЁ" },
                            new string[] { "казино " + stavka, "казино " + stavka_2, "казино все" },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }
                        else
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить",
                                                                "Поставить ВСЁ" },
                            new string[] { "казино " + stavka, "казино все" },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }
                    }
                }
                catch (Exception ex)
                {
                    //text = "Указанная сумма слишком большая.<br>" + ex.Message;
                    //Vk.MessagesSend(text);
                    //return;
                }

                text = text + "<br>💴 Рублей на счету: " + getRubsMoney(userInfo["rubs"]);
                Vk.MessagesSend(text, 1, 0, buttons);

                db.gameSetUserRub(Vk.m_from_id, userInfo["rubs"]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_roulette()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_rulette", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "" || !args[0].Contains(" "))
                {
                    Vk.MessagesSend("Необходимо указать все параметры.<br><br>" +
                        "Пример: !рулетка 5к красный или !рулетка все черный");
                    return;
                }

                var args2 = args[0].Split(" ");
                if (args2 == null || args2.Length <= 1)
                {
                    Vk.MessagesSend("Необходимо указать все параметры.<br><br>" +
                        "Пример: !рулетка 5к красный или !рулетка все черный");
                    return;
                }

                var stavka = cmdChecker.getArgumentMoney(args2[0]);
                args2[0] = args2[0].ToLower();
                if (stavka <= 0 && args2[0] != "все" && args2[0] != "всё")
                {
                    Vk.MessagesSend("Ставка не может быть меньше или равна нулю.<br><br>" +
                        "Пример: !рулетка 5к красный или !рулетка все черный");
                    return;
                }

                if (args2[0] == "все" || args2[0] == "всё")
                {
                    stavka = getUlongMoney(userInfo["rubs"]);
                    if (stavka <= 0)
                    {
                        Vk.MessagesSend("На вашем счету 0 рублей.<br><br>" +
                        "Вы можете попробовать использовать !bonus.");
                        return;
                    }
                }

                if (stavka <= 0)
                {
                    Vk.MessagesSend("Ставка не может быть меньше или равна нулю.<br><br>" +
                        "Пример: !рулетка 5к красный или !рулетка все черный");
                    return;
                }

                var money_user = getUlongMoney(userInfo["rubs"]);
                if (stavka > money_user)
                {
                    if (money_user == 0)
                    {
                        Vk.MessagesSend("Вы не можете играть в казино, у Вас 0 рублей на аккаунте. ");
                        return;
                    }
                    Vk.MessagesSend("Упс! На Вашем счету с рублями недостаточно средств!<br><br>" +
                        "💴 Рублей на счету: " + getRubsMoney(userInfo["rubs"]));
                    return;
                }

                var targetStavka = args2[1].ToLower();
                if (targetStavka != "красный" && targetStavka != "красная" && targetStavka != "красное" && targetStavka != "red" && targetStavka != "черный" && targetStavka != "чёрный" && targetStavka != "черная" && targetStavka != "чёрная" && targetStavka != "black"
                    && targetStavka != "черное" && targetStavka != "чёрное")
                {
                    Vk.MessagesSend("Необходимо указать все параметры.<br><br>" +
                        "Пример: !рулетка 5к красный или !рулетка все черный");
                    return;
                }
                int Stav = 0;
                if (targetStavka == "красный" || targetStavka == "красная" || targetStavka == "red" || targetStavka == "красное")
                {
                    Stav = 1;
                }
                else
                {
                    Stav = 2;
                }
                //money_user = money_user - stavka;
                string text = "Ваша ставка: " + getRubsMoney(stavka.ToString()) + " - " + args2[1] + "<br>";
                System.Numerics.BigInteger result_win = 0;

                Random Rand = new();
                int targetStavkaRandom = Rand.Next(1, 3);
                if (targetStavkaRandom != Stav)
                {
                    try
                    {
                        result_win = stavka * -1;
                        var color = (targetStavkaRandom == 1) ? "красный" : "чёрный";
                        text = text + "😫 Вы проиграли " + getRubsMoney((System.Numerics.BigInteger.Abs(result_win)).ToString()) + " (x0 - " + color + ")!";
                        //return result_win;
                    }
                    catch
                    {

                    }
                }
                else
                {
                    try
                    {
                        long ran = Rand.Next(1, 10);
                        long chanse_x5 = long.Parse(userInfo["chanse_kazino"]);
                        long ran_chanse = Rand.Next(1, 100);
                        if (ran_chanse < chanse_x5)
                        {
                            System.Numerics.BigInteger result_temp = stavka * 5;
                            //result_win = System.Numerics.BigInteger.Parse(Math.Round(result_temp).ToString());
                            result_win = result_temp;
                            text = text + "💪 Вы сорвали КУШ! " + getRubsMoney((result_win).ToString()) + " (x5)!";
                        }
                        else
                        {
                            if (ran_chanse >= 55)
                            {
                                result_win = 0;

                                text = text + "🤭 Вы остались при своем! (x1)!";
                            }
                            else if (ran_chanse >= 30)
                            {
                                System.Numerics.BigInteger result_temp = stavka / 3;
                                result_win = System.Numerics.BigInteger.Abs(result_temp);
                                text = text + "💥 Вы выиграли " + getRubsMoney((result_win).ToString()) + " (x1.33)!";
                            }
                            else if (ran_chanse >= 15)
                            {
                                System.Numerics.BigInteger result_temp = stavka / 5;
                                result_win = System.Numerics.BigInteger.Abs(result_temp);
                                text = text + "💥 Вы выиграли " + getRubsMoney((result_win).ToString()) + " (x1.2)!";
                            }
                            else
                            {
                                System.Numerics.BigInteger result_temp = stavka * 2;
                                result_win = System.Numerics.BigInteger.Abs(result_temp);
                                text = text + "💥 Вы выиграли " + getRubsMoney((result_win).ToString()) + " (x2)!";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        text = "Указанная сумма слишком большая.<br>" + ex.Message;
                        Vk.MessagesSend(text);
                        return;
                    }
                }


                //string stavka_1 = (Math.Round(decimal.Parse(stavka.ToString()) * 1.5m)).ToString();

                var f1 = NumFraction(1.5m);
                var f2 = NumFraction(0.5m);
                string stavka_1 = (stavka * f1.numerator).ToString();
                string stavka_2 = (stavka * f2.denominator).ToString();

                //string stavka_2 = (Math.Round(decimal.Parse(stavka.ToString()) * 0.5m)).ToString();

                string buttons = "";
                try
                {
                    money_user = money_user + result_win;
                    userInfo["rubs"] = money_user.ToString();
                    if (decimal.Parse(stavka_1) >= 1m && System.Numerics.BigInteger.Parse(stavka_1) <= money_user)
                    {
                        if (decimal.Parse(stavka_2) >= 1m && System.Numerics.BigInteger.Parse(stavka_2) <= money_user)
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить", "Ставка x1.5",
                                                                "Ставка x0.5",
                                                                "Поставить ВСЁ" },
                            new string[] { "рулетка " + stavka + args2[1], "рулетка " + stavka_1 + args2[1], "рулетка " + stavka_2 + args2[1], "рулетка все " + args2[1] },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }
                        else
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить", "Ставка x1.5",
                                                                "Поставить ВСЁ" },
                            new string[] { "рулетка " + stavka + args2[1], "рулетка " + stavka_1 + args2[1], "рулетка все " + args2[1] },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }

                    }
                    else
                    {
                        if (decimal.Parse(stavka_2) >= 1m && System.Numerics.BigInteger.Parse(stavka_2) <= money_user)
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить",
                                                                "Ставка x0.5",
                                                                "Поставить ВСЁ" },
                            new string[] { "рулетка " + stavka + args2[1], "рулетка " + stavka_2 + args2[1], "рулетка все " + args2[1] },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }
                        else
                        {
                            buttons = Vk.GenerateKeyboard(new string[] { "Повторить",
                                                                "Поставить ВСЁ" },
                            new string[] { "рулетка " + stavka + args2[1], "рулетка все " + args2[1] },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                        }
                    }
                }
                catch (Exception ex)
                {
                    //text = "Указанная сумма слишком большая.<br>" + ex.Message;
                    //Vk.MessagesSend(text);
                    //return;
                }

                text = text + "<br>💴 Рублей на счету: " + getRubsMoney(userInfo["rubs"]);
                Vk.MessagesSend(text, 1, 0, buttons);

                db.gameSetUserRub(Vk.m_from_id, userInfo["rubs"]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_bonus()
        {
            try
            {
                //date_bonus_last
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_bonus", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                if (userInfo["date_bonus_last"] != "")
                {
                    var time_last = db.timeGetForMysql(userInfo["date_bonus_last"]);
                    if (DateTimeOffset.Now.ToUnixTimeSeconds() < time_last.AddDays(1).ToUnixTimeSeconds())
                    {
                        Vk.MessagesSend("Вы уже получали бонус. Следующий будет доступен " + time_last.AddDays(1).ToString("g"));
                        return;
                    }
                }

                int mnoj = 0;
                if (db.UserIsVip(Vk.m_from_id))
                {
                    try
                    {
                        if (int.Parse(userInfo["vip_type"]) >= 20)
                        {
                            mnoj = 20;
                        }
                        else
                        {
                            mnoj = int.Parse(userInfo["vip_type"]) + 1;
                        }
                    }
                    catch
                    {

                    }
                }

                Random rand = new();
                System.Numerics.BigInteger rand_money;
                if (mnoj == 0)
                {
                    rand_money = System.Numerics.BigInteger.Parse(rand.Next(10000, 30000).ToString());
                    var money_user = getUlongMoney(userInfo["rubs"]);
                    Vk.MessagesSend("Вы получили бонус в размере " + getRubsMoney(rand_money.ToString())
                        + ".<br>Следующий будет доступен " + DateTimeOffset.Now.AddDays(1).ToString("g"));
                    db.gameSetUserRub(Vk.m_from_id, (money_user + rand_money).ToString());
                    db.gameSetLastBonus(Vk.m_from_id, db.timeGetForString(DateTimeOffset.Now));
                }
                else
                {
                    rand_money = System.Numerics.BigInteger.Parse(rand.Next(10000 * mnoj, 30000 * mnoj).ToString());
                    var money_user = getUlongMoney(userInfo["rubs"]);
                    Vk.MessagesSend("Вы получили увеличенный бонус (для VIP) в размере " + getRubsMoney(rand_money.ToString())
                        + ".<br>Следующий будет доступен " + DateTimeOffset.Now.AddDays(1).ToString("g"));
                    db.gameSetUserRub(Vk.m_from_id, (money_user + rand_money).ToString());
                    db.gameSetLastBonus(Vk.m_from_id, db.timeGetForString(DateTimeOffset.Now));
                }


            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_pay()
        {
            try
            {
                //date_bonus_last
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_pay", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });

                if (args[0] == null || args[0] == "" || args[1] == null || args[1] == "" || args[0] == Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Для передачи денег необходимо указать ID пользователя. Используйте: /pay [ID] [деньги]");
                    return;
                }

                var TargetInfo = db.usersGetUser(long.Parse(args[0]));
                if (TargetInfo == null || long.Parse(args[0]) <= 0)
                {
                    Vk.MessagesSend("Введён неправильный ID пользователя.");
                    return;
                }

                var userMoney = getUlongMoney(userInfo["rubs"]);

                var TargetMoney = cmdChecker.getArgumentMoney(args[1]);

                if (userMoney < TargetMoney)
                {
                    Vk.MessagesSend("У Вас недостаточно средств для проведения данной операции.<br><br>" +
                        "💴 Рублей на счету: " + getRubsMoney(userInfo["rubs"]));
                    return;
                }

                if (TargetMoney <= 0 && args[1].ToLower() != "все" && args[1].ToLower() != "всё")
                {
                    Vk.MessagesSend("Вы не можете передавать валюту, значение которой меньше или равно нулю.");
                    return;
                }

                if (args[1].ToLower() == "все" || args[1].ToLower() == "всё")
                {
                    TargetMoney = userMoney;
                }

                var targetUserMoney = getUlongMoney(TargetInfo["rubs"]);
                System.Numerics.BigInteger AllMoney = targetUserMoney;

                try
                {
                    AllMoney += TargetMoney;
                }
                catch
                {
                    Vk.MessagesSend("У пользователя превышен лимит средств на счету с рублями.");
                    return;
                }

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) }, false, "dat");
                string name_url = "[id" + args[0] + "|Пользователю]";

                if (vkInfo.ContainsKey("id" + args[0]))
                {
                    name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                        vkInfo["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url = "[club" + args[0].Substring(1) + "|Сообществу]";
                    }
                }

                userInfo["rubs"] = (userMoney - TargetMoney).ToString();

                Vk.MessagesSend("Вы перевели " + name_url + " " + getRubsMoney(TargetMoney.ToString()) + "<br><br>" +
                    "💴 Рублей на счету: " + getRubsMoney(userInfo["rubs"]));
                db.gameSetUserRub(long.Parse(args[0]), AllMoney.ToString());

                db.gameSetUserRub(Vk.m_from_id, (userMoney - TargetMoney).ToString());

                db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_GIVERUB, Vk.m_from_id, long.Parse(args[0]),
                    $"перевел {getRubsMoney(TargetMoney.ToString())}", TargetMoney.ToString(), AllMoney.ToString());

                if (settings.isUserChat(Vk.m_peer_id))
                {
                    Vk.MessagesSend("[id" + Vk.m_from_id + "|Пользователь] перевёл Вам " + getRubsMoney(TargetMoney.ToString()), 0, long.Parse(args[0]));
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_transfer()
        {
            try
            {
                //date_bonus_last
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_transfer", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Для обмена валюты необходимо указать сколько ЕВРО вы меняете на рубли.<br>Пример: /transfer 100");
                    return;
                }

                var userMoneyRubs = getUlongMoney(userInfo["rubs"]);
                var userMoneyEuros = getUlongMoney(userInfo["euros"]);


                var TargetMoney = cmdChecker.getArgumentMoney(args[0]);

                if (userMoneyEuros < TargetMoney)
                {
                    Vk.MessagesSend("У Вас недостаточно средств для проведения данной операции.<br><br>" +
                        "💴 Евро на счету: " + getEuroMoney(userInfo["euros"]));
                    return;
                }

                if (TargetMoney <= 0 && args[0].ToLower() != "все" && args[0].ToLower() != "всё")
                {
                    Vk.MessagesSend("Вы не можете обменять валюту, значение которой меньше или равно нулю.");
                    return;
                }

                if (args[0].ToLower() == "все" || args[0].ToLower() == "всё")
                {
                    TargetMoney = userMoneyEuros;
                }

                if (TargetMoney < 50)
                {
                    Vk.MessagesSend("Минимальная сумма для перевода - 50 евро.");
                    return;
                }

                System.Numerics.BigInteger AllMoney = userMoneyRubs;

                try
                {
                    AllMoney += (int)(double.Parse(TargetMoney.ToString()) * settings.euro_course);
                }
                catch
                {
                    Vk.MessagesSend("У пользователя превышен лимит средств на счету с рублями.");
                    return;
                }

                //userInfo["rubs"] = AllMoney.ToString();

                var buttons = Vk.GenerateKeyboard(new string[] { "обменять" }, new string[] { "transfertwo " + args[0] }, new string[] { Vk.BUTTON_RED });
                Vk.MessagesSend($"Текущий курс: €1 = {settings.euro_course}₽<br><br>" +
                    "💴 Станет рублей на вашем счету: " + getRubsMoney(AllMoney.ToString()), 1, 0, buttons);
                //db.gameSetUserRub(long.Parse(args[0]), AllMoney.ToString());

                //db.gameSetUserRub(Vk.m_from_id, AllMoney.ToString());

                //if (settings.isUserChat(Vk.m_peer_id))
                //{
                // Vk.MessagesSend("[id" + Vk.m_from_id + "|Пользователь] перевёл Вам " + getRubsMoney(TargetMoney.ToString()), 0, long.Parse(args[0]));
                //}
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_transfertwo()
        {
            try
            {
                //date_bonus_last
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_transfertwo", 40))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Для обмена валюты необходимо указать сколько ЕВРО вы меняете на рубли.<br>Пример: /transfer 100");
                    return;
                }

                var userMoneyRubs = getUlongMoney(userInfo["rubs"]);
                var userMoneyEuros = getUlongMoney(userInfo["euros"]);


                var TargetMoney = cmdChecker.getArgumentMoney(args[0]);

                if (userMoneyEuros < TargetMoney)
                {
                    Vk.MessagesSend("У Вас недостаточно средств для проведения данной операции.<br><br>" +
                        "💴 Евро на счету: " + getEuroMoney(userInfo["euros"]));
                    return;
                }

                if (TargetMoney <= 0 && args[0].ToLower() != "все" && args[0].ToLower() != "всё")
                {
                    Vk.MessagesSend("Вы не можете обменять валюту, значение которой меньше или равно нулю.");
                    return;
                }

                if (args[0].ToLower() == "все" || args[0].ToLower() == "всё")
                {
                    TargetMoney = userMoneyEuros;
                }

                System.Numerics.BigInteger AllMoney = userMoneyRubs;

                if (TargetMoney <= 0)
                {
                    Vk.MessagesSend("Вы не можете обменять валюту, значение которой меньше или равно нулю.");
                    return;
                }

                string text = "";

                if (settings.euro_course < 50)
                {
                    settings.euro_course = 50;
                    text += "Евро достиг своей минимальной цены, курс евро стал 50.<br>";
                }
                else
                {
                    if (settings.euro_course >= 501)
                    {
                        settings.euro_course = 500;
                    }
                    else
                    {
                        if (settings.euro_tranferDate.AddHours(1).ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                        {
                            text += "Евро никто не покупал на протяжении 1 часов, курс возрос на 35%!<br>";
                            settings.euro_course = settings.euro_course * 1.35;

                        }
                        if (settings.euro_tranferDate.AddMinutes(30).ToUnixTimeSeconds() >= DateTimeOffset.Now.ToUnixTimeSeconds())
                        {
                            text += "Евро покупали за последние 10 минут, курс упал на 3%!<br>";
                            settings.euro_course = settings.euro_course * 0.97;
                        }
                    }
                }


                try
                {
                    AllMoney += (int)(double.Parse(TargetMoney.ToString()) * settings.euro_course);
                }
                catch
                {
                    Vk.MessagesSend("У пользователя превышен лимит средств на счету с рублями.");
                    return;
                }

                userInfo["rubs"] = AllMoney.ToString();


                var buttons = Vk.GenerateKeyboard(new string[] { "обменять" }, new string[] { "transfertwo " + args[0] }, new string[] { Vk.BUTTON_RED });
                Vk.MessagesSend(text + $"Вы потратили {getEuroMoney(TargetMoney.ToString())} по курсу €1 = {settings.euro_course}₽<br>" +
                    $"Приобритено {(int)(double.Parse(TargetMoney.ToString()) * settings.euro_course)} рублей.<br><br>" +
                    "💴 На вашем счету с рублями: " + getRubsMoney(AllMoney.ToString()));
                db.gameSetUserRub(Vk.m_from_id, AllMoney.ToString());
                db.gameSetUserEuros(Vk.m_from_id, (userMoneyEuros - TargetMoney).ToString());
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ADMIN_GIVERUB, Vk.m_from_id, 0, $"обменял {getEuroMoney(TargetMoney.ToString())} на {(int)(double.Parse(TargetMoney.ToString()) * settings.euro_course)}" +
                    $" рублей по курсу €1 = {settings.euro_course}₽", TargetMoney.ToString(), ((int)(double.Parse(TargetMoney.ToString()) * settings.euro_course)).ToString());

                try
                {
                    settings.euro_tranferDate = DateTimeOffset.Now;
                }
                catch
                {

                }


                //db.gameSetUserRub(Vk.m_from_id, AllMoney.ToString());

                //if (settings.isUserChat(Vk.m_peer_id))
                //{
                // Vk.MessagesSend("[id" + Vk.m_from_id + "|Пользователь] перевёл Вам " + getRubsMoney(TargetMoney.ToString()), 0, long.Parse(args[0]));
                //}
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_toprub()
        {
            try
            {
                //gameTopGetRubs
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_toprub", 10))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var nick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                var topInfo = db.gameTopGetRubs();
                if (topInfo == null || topInfo.Count <= 1)
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Информация о лучших игроках не найдена." +
                            "<br><br>Команду выполнил: " + nick[Vk.m_from_id.ToString()]);
                        return;
                    }
                    Vk.MessagesSend("Информация о лучших игроках не найдена.");
                    return;
                }

                long[] uses_for_get = new long[topInfo.Count];
                long i = 0;
                foreach (var item in topInfo)
                {
                    uses_for_get[i] = item.Key;
                    i++;
                }

                var vkInfo = await Vk.UsersGetName(uses_for_get);

                string text = "💎 Список лучших игроков по рублям:<br><br>";

                i = 0;
                foreach (var item in topInfo)
                {
                    if (item.Key <= 0 || settings.OWNER_IDS.ContainsKey(item.Key))
                    {
                        continue;
                    }
                    i++;
                    string userName = "[id" + item.Key + "|Пользователь]";
                    if (vkInfo.ContainsKey("id" + item.Key))
                    {
                        userName = "[id" + item.Key + "|" + vkInfo["id" + item.Key].first_name + " " + vkInfo["id" + item.Key].last_name + "]";
                    }
                    else
                    {
                        if (item.Key < 0)
                        {
                            userName = "[club" + item.Key.ToString().Substring(1) + "|Сообщество]";
                        }
                    }
                    text = text + i + ". " + userName + " — " + getRubsMoney(item.Value.ToString()) + "<br>";
                }

                if (Vk.is_callbackButton)
                {
                    text += "<br><br>Команду выполнил: " + nick[Vk.m_from_id.ToString()];
                }
                var buttons2 = Vk.GenerateKeyboard(new string[] { "рейтинг" },
                    new string[] { "top 1" },
                    new string[] { Vk.BUTTON_GREEN }, null, false, true, true);
                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Cache Cache = new Cache();

                    long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons2);
                    Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    return;
                }
                else
                {
                    Cache Cache = new Cache();
                    var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id);
                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons2, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons2);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                }

                //Vk.MessagesSend(text, 1, 0, buttons2);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_toprating()
        {
            try
            {
                //gameTopGetRubs
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_toprating", 10))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var nick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                var topInfo = db.gameTopGetRatings();
                if (topInfo == null || topInfo.Count <= 1)
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Информация о лучших игроках не найдена." +
                            "<br><br>Команду выполнил: " + nick[Vk.m_from_id.ToString()]);
                        return;
                    }
                    Vk.MessagesSend("Информация о лучших игроках не найдена.");
                    return;
                }

                long[] uses_for_get = new long[topInfo.Count];
                long i = 0;
                foreach (var item in topInfo)
                {
                    uses_for_get[i] = item.Key;
                    i++;
                }

                var vkInfo = await Vk.UsersGetName(uses_for_get);

                string text = "👑 Список лучших игроков по рейтингу:<br><br>";

                i = 0;
                foreach (var item in topInfo)
                {
                    if (item.Key <= 0 || item.Value <= 0)
                    {
                        continue;
                    }
                    i++;
                    string userName = "[id" + item.Key + "|Пользователь]";
                    if (vkInfo.ContainsKey("id" + item.Key))
                    {
                        userName = "[id" + item.Key + "|" + vkInfo["id" + item.Key].first_name + " " + vkInfo["id" + item.Key].last_name + "]";
                    }
                    else
                    {
                        if (item.Key < 0)
                        {
                            userName = "[club" + item.Key.ToString().Substring(1) + "|Сообщество]";
                        }
                    }
                    text = text + i + ". " + userName + " — " + item.Value.ToString() + " ⚖<br>";
                }

                if (Vk.is_callbackButton)
                {
                    text += "<br><br>Команду выполнил: " + nick[Vk.m_from_id.ToString()];
                }

                var buttons2 = Vk.GenerateKeyboard(new string[] { "рубли" },
                    new string[] { "toprub 1" },
                    new string[] { Vk.BUTTON_GREEN }, null, false, true, true);

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Cache Cache = new Cache();

                    long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons2);
                    Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    return;
                }
                else
                {
                    Cache Cache = new Cache();
                    var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id);
                    if (last_message != null)
                    {
                        Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons2, true, "", long.Parse(last_message));
                    }
                    else
                    {
                        long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons2);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_property()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_property", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);
                var property = db.propertyGetUser(Vk.m_from_id);
                if (property == null || property.Count < 1)
                {
                    Vk.MessagesSend("К сожалению, у вас нет никакого имущества. Вы можете купить его — !магазин");
                    return;
                }

                string text;

                string house = (houses.list.ContainsKey(long.Parse(property["house"]))) ? houses.list[long.Parse(property["house"])]["name"] : "нет";

                string car = (houses.list.ContainsKey(long.Parse(property["car"]))) ? cars.list[long.Parse(property["car"])]["name"] : "нет";

                string boat = (boats.list.ContainsKey(long.Parse(property["boat"]))) ? boats.list[long.Parse(property["boat"])]["name"] : "нет";

                string airplane = (airplanes.list.ContainsKey(long.Parse(property["airplane"]))) ? airplanes.list[long.Parse(property["airplane"])]["name"] : "нет";

                string helicopter = (helicopters.list.ContainsKey(long.Parse(property["helicopter"]))) ? helicopters.list[long.Parse(property["helicopter"])]["name"] : "нет";

                string smartphone = (smartphones.list.ContainsKey(long.Parse(property["smartphone"]))) ? smartphones.list[long.Parse(property["smartphone"])]["name"] : "нет";

                string computer = (computers.list.ContainsKey(long.Parse(property["computer"]))) ? computers.list[long.Parse(property["computer"])]["name"] : "нет";

                text = $"🚀 Ваше имущество:<br><br>" +
                    $"🏠 Дом — {house}<br>" +
                    $"🚗 Машина — {car}<br>" +
                    $"🛥 Яхта — {boat}<br>" +
                    $"🛩 Самолет — {airplane}<br>" +
                    $"🚁 Вертолет — {helicopter}<br>" +
                    $"📱 Телефон — {smartphone}<br>" +
                    $"🖥 Компьютер — {computer}";
                Vk.MessagesSend(text);
                /*string text = "💫 ID: " + Vk.m_from_id + "<br>" +
                    "🌍 Страна: " + country_text + "<br>" +
                    "💴 Рублей: " + getRubsMoney(userInfo["rubs"]) + "<br>" +
                    "💵 Долларов: " + getDollMoney(userInfo["dollars"]) + "<br>" +
                    "💷 Евро: " + getEuroMoney(userInfo["euros"]) + "<br>" +
                    "💉 Энергия: " + userInfo["energy"] + "/10" + "<br>" +
                    "👑 Рейтинг: " + userInfo["rating"] + "<br>" +
                    "💠 Уровень: " + userInfo["level"];*/

                //Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        private string listOfShop = "🛒 Категории:<br><br>" +
            "🚘 Транспорт:<br>" +
            "⠀— 🚗 автомобили<br>" + //1
            "⠀— 🚁 вертолеты<br>" + //2
            "⠀— ✈ самолеты<br>" + //3
            "⠀— 🛥 яхты<br><br>" + //4
            "" + //5 самокаты
            "🏢 Недвижимость:<br>" +
            "⠀— 🏡 дома<br><br>" + //6
            "📌 Остальное:<br>" + //7
            "⠀— 📱 телефоны<br>" + //8
            "⠀— 💻 компьютеры<br>" + //9
            "⠀— 🎖 рейтинг [кол-во]<br><br>" +

            "📥 Для покупки используйте \"[категория] [номер]\".<br>⠀ ⠀ ❗ Например: \"!машина 1\"";

        public async void game_cmd_shop(long category = 0)
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_shop", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        Vk.MessagesSend("🎮 Игры отключены в этой беседе.\nВключите в настройках: !настройка → Игры", 0, Vk.m_peer_id);
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);

                if (category == 0)
                {
                    Vk.MessagesSend(listOfShop);
                    return;
                }
                else if (category == 1) // МАШИНЫ
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                    var items = properties.cars.list;

                    if (args[0] == null || args[0] == "")
                    {


                        string text = "🧳 Список автомобилей:<br><br>";
                        foreach (KeyValuePair<long, Dictionary<string, string>> item in items)
                        {
                            text = text + $"🚗 {item.Key}. {item.Value["name"]} ({getRubsMoney(item.Value["price"])})<br>";
                        }

                        Vk.MessagesSend(text);
                        return;
                    }

                    long target_item = 0;

                    try
                    {
                        target_item = long.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item == 0)
                    {
                        string low_arg = args[0].ToLower();
                        foreach (var item in items)
                        {
                            if (low_arg == item.Value["name"].ToLower())
                            {
                                target_item = long.Parse(item.Value["id"]);
                                break;
                            }
                        }
                    }

                    if (target_item == 0)
                    {
                        Vk.MessagesSend("Указанный автомобиль не найден. Используйте: '!машины' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    if (!items.ContainsKey(target_item))
                    {
                        Vk.MessagesSend("Указанный автомобиль не найден. Используйте: '!машины' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    var itemMoney = getUlongMoney(items[target_item]["price"]);

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("Ошибка. На вашем счету недостаточно рублей.<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]));
                        return;
                    }

                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("🚀 Вы успешно купили '" + items[target_item]["name"] + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()));
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.propertyAddItemUser(Vk.m_from_id, "car", target_item);
                    if (userInfo["level"] == "1")
                    {
                        db.gameSetLevel(Vk.m_from_id, 2);
                    }
                    return;
                }
                else if (category == 2) // ЯХТЫ
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                    var items = properties.boats.list;

                    if (args[0] == null || args[0] == "")
                    {


                        string text = "🧳 Список яхт:<br><br>";
                        foreach (KeyValuePair<long, Dictionary<string, string>> item in items)
                        {
                            text = text + $"🛥 {item.Key}. {item.Value["name"]} ({getRubsMoney(item.Value["price"])})<br>";
                        }

                        Vk.MessagesSend(text);
                        return;
                    }

                    long target_item = 0;

                    try
                    {
                        target_item = long.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item == 0)
                    {
                        string low_arg = args[0].ToLower();
                        foreach (var item in items)
                        {
                            if (low_arg == item.Value["name"].ToLower())
                            {
                                target_item = long.Parse(item.Value["id"]);
                                break;
                            }
                        }
                    }

                    if (target_item == 0)
                    {
                        Vk.MessagesSend("Указанная яхта не найдена. Используйте: '!яхты' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    if (!items.ContainsKey(target_item))
                    {
                        Vk.MessagesSend("Указанная яхта не найдена. Используйте: '!яхты' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    var itemMoney = getUlongMoney(items[target_item]["price"]);

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("Ошибка. На вашем счету недостаточно рублей.<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]));
                        return;
                    }

                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("🚀 Вы успешно купили '" + items[target_item]["name"] + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()));
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.propertyAddItemUser(Vk.m_from_id, "boat", target_item);
                    return;
                }
                else if (category == 3) // САМОЛЕТЫ
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                    var items = properties.airplanes.list;

                    if (args[0] == null || args[0] == "")
                    {


                        string text = "🧳 Список самолетов:<br><br>";
                        foreach (KeyValuePair<long, Dictionary<string, string>> item in items)
                        {
                            text = text + $"✈ {item.Key}. {item.Value["name"]} ({getRubsMoney(item.Value["price"])})<br>";
                        }

                        Vk.MessagesSend(text);
                        return;
                    }

                    long target_item = 0;

                    try
                    {
                        target_item = long.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item == 0)
                    {
                        string low_arg = args[0].ToLower();
                        foreach (var item in items)
                        {
                            if (low_arg == item.Value["name"].ToLower())
                            {
                                target_item = long.Parse(item.Value["id"]);
                                break;
                            }
                        }
                    }

                    if (target_item == 0)
                    {
                        Vk.MessagesSend("Указанный самолет не найден. Используйте: '!самолеты' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    if (!items.ContainsKey(target_item))
                    {
                        Vk.MessagesSend("Указанный самолет не найден. Используйте: '!самолеты' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    var itemMoney = getUlongMoney(items[target_item]["price"]);

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("Ошибка. На вашем счету недостаточно рублей.<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]));
                        return;
                    }

                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("🚀 Вы успешно купили '" + items[target_item]["name"] + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()));
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.propertyAddItemUser(Vk.m_from_id, "airplane", target_item);
                    return;
                }
                else if (category == 4) // ВЕРТОЛЕТЫ
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                    var items = properties.helicopters.list;

                    if (args[0] == null || args[0] == "")
                    {


                        string text = "🧳 Список вертолетов:<br><br>";
                        foreach (KeyValuePair<long, Dictionary<string, string>> item in items)
                        {
                            text = text + $"🚁 {item.Key}. {item.Value["name"]} ({getRubsMoney(item.Value["price"])})<br>";
                        }

                        Vk.MessagesSend(text);
                        return;
                    }

                    long target_item = 0;

                    try
                    {
                        target_item = long.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item == 0)
                    {
                        string low_arg = args[0].ToLower();
                        foreach (var item in items)
                        {
                            if (low_arg == item.Value["name"].ToLower())
                            {
                                target_item = long.Parse(item.Value["id"]);
                                break;
                            }
                        }
                    }

                    if (target_item == 0)
                    {
                        Vk.MessagesSend("🚁 Указанный вертолет не найден. Используйте: '!вертолеты' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    if (!items.ContainsKey(target_item))
                    {
                        Vk.MessagesSend("🚁 Указанный вертолет не найден. Используйте: '!вертолеты' (без ковычек) для просмотра списка доступных.");
                        return;
                    }
                    var itemMoney = getUlongMoney(items[target_item]["price"]);

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("🚁 Ошибка. На вашем счету недостаточно рублей.<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]));
                        return;
                    }

                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("🚁 Вы успешно купили '" + items[target_item]["name"] + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()));
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.propertyAddItemUser(Vk.m_from_id, "helicopter", target_item);
                    return;
                }
                else if (category == 6) // ДОМА
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                    var items = properties.houses.list;

                    if (args[0] == null || args[0] == "")
                    {


                        string text = "🚧 Список домов:<br><br>";
                        foreach (KeyValuePair<long, Dictionary<string, string>> item in items)
                        {
                            text = text + $"🏘 {item.Key}. {item.Value["name"]} ({getRubsMoney(item.Value["price"])})<br>";
                        }

                        Vk.MessagesSend(text);
                        return;
                    }

                    long target_item = 0;

                    try
                    {
                        target_item = long.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item == 0)
                    {
                        string low_arg = args[0].ToLower();
                        foreach (var item in items)
                        {
                            if (low_arg == item.Value["name"].ToLower())
                            {
                                target_item = long.Parse(item.Value["id"]);
                                break;
                            }
                        }
                    }

                    if (target_item == 0)
                    {
                        Vk.MessagesSend("Указанный дом не найден. Используйте: '!дома' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    if (!items.ContainsKey(target_item))
                    {
                        Vk.MessagesSend("Указанный дом не найден. Используйте: '!дома' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    var itemMoney = getUlongMoney(items[target_item]["price"]);

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("Ошибка. На вашем счету недостаточно рублей.<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]));
                        return;
                    }

                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("🚀 Вы успешно купили '" + items[target_item]["name"] + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()));
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.propertyAddItemUser(Vk.m_from_id, "house", target_item);
                    return;
                }
                else if (category == 8) // ТЕЛЕФОНЫ
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                    var items = properties.smartphones.list;

                    if (args[0] == null || args[0] == "")
                    {


                        string text = "🖨 Список телефонов:<br><br>";
                        foreach (KeyValuePair<long, Dictionary<string, string>> item in items)
                        {
                            text = text + $"📱 {item.Key}. {item.Value["name"]} ({getRubsMoney(item.Value["price"])})<br>";
                        }

                        Vk.MessagesSend(text);
                        return;
                    }

                    long target_item = 0;

                    try
                    {
                        target_item = long.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item == 0)
                    {
                        string low_arg = args[0].ToLower();
                        foreach (var item in items)
                        {
                            if (low_arg == item.Value["name"].ToLower())
                            {
                                target_item = long.Parse(item.Value["id"]);
                                break;
                            }
                        }
                    }

                    if (target_item == 0)
                    {
                        Vk.MessagesSend("📱 Указанный телефон не найден. Используйте: '!телефоны' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    if (!items.ContainsKey(target_item))
                    {
                        Vk.MessagesSend("📱 Указанный телефон не найден. Используйте: '!телефоны' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    var itemMoney = getUlongMoney(items[target_item]["price"]);

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("📱 Ошибка. На вашем счету недостаточно рублей.<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]));
                        return;
                    }

                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("☎ Вы успешно купили '" + items[target_item]["name"] + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()));
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.propertyAddItemUser(Vk.m_from_id, "smartphone", target_item);
                    return;
                }
                else if (category == 9) // КОМПЬЮТЕРЫ
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                    var items = properties.computers.list;

                    if (args[0] == null || args[0] == "")
                    {


                        string text = "🖨 Список компьютеров:<br><br>";
                        foreach (KeyValuePair<long, Dictionary<string, string>> item in items)
                        {
                            text = text + $"💻 {item.Key}. {item.Value["name"]} ({getRubsMoney(item.Value["price"])})<br>";
                        }

                        Vk.MessagesSend(text);
                        return;
                    }

                    long target_item = 0;

                    try
                    {
                        target_item = long.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item == 0)
                    {
                        string low_arg = args[0].ToLower();
                        foreach (var item in items)
                        {
                            if (low_arg == item.Value["name"].ToLower())
                            {
                                target_item = long.Parse(item.Value["id"]);
                                break;
                            }
                        }
                    }

                    if (target_item == 0)
                    {
                        Vk.MessagesSend("💻 Указанный компьютер не найден. Используйте: '!компьютеры' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    if (!items.ContainsKey(target_item))
                    {
                        Vk.MessagesSend("💻 Указанный компьютер не найден. Используйте: '!компьютеры' (без ковычек) для просмотра списка доступных.");
                        return;
                    }

                    var itemMoney = getUlongMoney(items[target_item]["price"]);

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("🖥 Ошибка. На вашем счету недостаточно рублей.<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]));
                        return;
                    }

                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("🖥 Вы успешно купили '" + items[target_item]["name"] + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()));
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.propertyAddItemUser(Vk.m_from_id, "computer", target_item);
                    return;
                }
                else if (category == 10) // рейтинг
                {
                    var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                    string rate = "<br>Текущий курс: 1 рейтинг = " + getRubsMoney(settings.rate_rating.ToString()) + "<br>";
                    if (args[0] == null || args[0] == "")
                    {


                        string text = "Используйте !рейтинг [кол-во] для покупки рейтинга.<br><br>" + rate;
                        Vk.MessagesSend(text);
                        return;
                    }

                    System.Numerics.BigInteger target_item = 0;

                    try
                    {
                        target_item = System.Numerics.BigInteger.Parse(args[0]);
                    }
                    catch
                    {
                        target_item = 0;
                    }

                    if (target_item <= 0)
                    {
                        string text = "Используйте !рейтинг [кол-во] для покупки рейтинга.<br><br>" + rate;
                        Vk.MessagesSend(text);
                        return;
                    }

                    var itemMoney = getUlongMoney((settings.rate_rating * target_item).ToString());

                    var userMoney = getUlongMoney(userInfo["rubs"]);

                    if (userMoney < itemMoney)
                    {
                        Vk.MessagesSend("Ошибка. На вашем счету недостаточно рублей.<br>Требуется: "
                            + getRubsMoney(itemMoney.ToString()) + "<br><br>💰 Баланс: " + getRubsMoney(userInfo["rubs"]) + rate);
                        return;
                    }
                    var target_ratings = getUlongMoney(userInfo["rating"]) + target_item;
                    var resultMoney = userMoney - itemMoney;
                    Vk.MessagesSend("🚀 Вы успешно купили рейтинг в количестве '" + target_item + "'.<br><br>" +
                        "💰 Ваш новый баланс: " + getRubsMoney(resultMoney.ToString()) + rate);
                    db.gameSetUserRub(Vk.m_from_id, resultMoney.ToString());
                    db.gameSetUserRating(Vk.m_from_id, target_ratings.ToString());
                    return;
                }
                else
                {
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_marry()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_marry", 4))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }
                var marryInfo = db.MarriagesGetUser(Vk.m_peer_id, Vk.m_from_id);
                if (marryInfo != null)
                {
                    if (marryInfo.Count >= 2)
                    {
                        var buttons2 = Vk.GenerateKeyboard(new string[] { "РАЗВОД" },
                            new string[] { "divorce" },
                            new string[] { Vk.BUTTON_RED });
                        Vk.MessagesSend("Вы уже состоите в браке. Используйте !развестись для развода, либо нажмите на кнопку ниже.", 1, 0, buttons2);
                        return;
                    }
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "" || args[0] == Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Используйте: !брак [ID/ссылка]" +
                        "<br>Вместо ID или ссылки вы можете переслать сообщение пользователя, к которому хотите применить команду.");
                    return;
                }

                var targetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false);

                if (targetUser == null)
                {
                    Vk.MessagesSend("К сожалению, указанный пользователь не найден.");
                    return;
                }

                var marryInfotwo = db.MarriagesGetUser(Vk.m_peer_id, long.Parse(args[0]));
                if (marryInfotwo != null)
                {
                    Vk.MessagesSend("Пользователь уже состоит в браке.");
                    return;
                }

                if (long.Parse(args[0]) <= 0)
                {
                    Vk.MessagesSend("Заключить брак с сообществом нельзя.");
                    return;
                }

                Cache.Set("targetid_marry_" + Vk.m_from_id, args[0], 5);

                var buttons = Vk.GenerateKeyboard(new string[] { "ПРИНЯТЬ", "ОТКАЗАТЬ" },
                    new string[] { "acceptmarry id" + Vk.m_from_id, "delmarry id" + Vk.m_from_id },
                    new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED });


                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });
                string name_url = "[id" + args[0] + "|Пользователь]";

                if (vkInfo.ContainsKey("id" + args[0]))
                {
                    name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                        vkInfo["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }

                var vkInfo2 = await Vk.UsersGetName(new long[] { Vk.m_from_id }, false, "ins");
                string name_url2 = "[id" + Vk.m_from_id + "|Пользователем]";

                if (vkInfo2.ContainsKey("id" + Vk.m_from_id))
                {
                    name_url2 = "[id" + Vk.m_from_id + "|" + vkInfo2["id" + Vk.m_from_id].first_name + " " +
                        vkInfo2["id" + Vk.m_from_id].last_name + "]";
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        name_url2 = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообществом]";
                    }
                }

                Vk.MessagesSend(name_url + ", согласны ли Вы вступить в брак с " + name_url2 + "?<br><br>" +
                    "💞 Если да, то просто нажмите на зелёную кнопку. Если нет — на красную.", 1, 0, buttons, false);
                return;
                //MenuList menu = new(Cache);
                //menu.getMenuSelect(Vk.m_from_id);
                //menu.setMenuSelect(Vk.m_from_id, 0);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_acceptmarry()
        {
            try
            {
                //acceptmarry id" + Vk.m_from_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_acceptmarry", 4))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }
                var marryInfo = db.MarriagesGetUser(Vk.m_peer_id, Vk.m_from_id);
                if (marryInfo != null)
                {
                    var buttons2 = Vk.GenerateKeyboard(new string[] { "РАЗВОД" },
                    new string[] { "divorce" },
                    new string[] { Vk.BUTTON_RED });
                    Vk.MessagesSend("Вы уже состоите в браке. Используйте !развестись для развода, либо нажмите на кнопку ниже.", 1, 0, buttons2);
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Используйте: !брак [ID/ссылка]" +
                        "<br>Вместо ID или ссылки вы можете переслать сообщение пользователя, к которому хотите применить команду.");
                    return;
                }

                var targetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false);

                if (targetUser == null)
                {
                    Vk.MessagesSend("К сожалению, указанный пользователь не найден.");
                    return;
                }

                var marryInfotwo = db.MarriagesGetUser(Vk.m_peer_id, long.Parse(args[0]));
                if (marryInfotwo != null)
                {
                    Vk.MessagesSend("Пользователь уже состоит в браке.");
                    return;
                }

                if (long.Parse(args[0]) <= 0)
                {
                    Vk.MessagesSend("Заключить брак с сообществом нельзя.");
                    return;
                }
                var result = Cache.Get<string>("targetid_marry_" + args[0]);
                if (result == null)
                {
                    Vk.MessagesSend("Этот пользователь не предлагал вам вступить в брак, либо прошло более пяти минут.");
                    return;
                }

                if (result != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Этот пользователь не предлагал вам вступить в брак, либо прошло более пяти минут.");
                    return;
                }

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });
                string name_url = "[id" + args[0] + "|Пользователь]";

                if (vkInfo.ContainsKey("id" + args[0]))
                {
                    name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                        vkInfo["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }

                var vkInfo2 = await Vk.UsersGetName(new long[] { Vk.m_from_id });
                string name_url2 = "[id" + Vk.m_from_id + "|Пользователь]";

                if (vkInfo2.ContainsKey("id" + Vk.m_from_id))
                {
                    name_url2 = "[id" + Vk.m_from_id + "|" + vkInfo2["id" + Vk.m_from_id].first_name + " " +
                        vkInfo2["id" + Vk.m_from_id].last_name + "]";
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        name_url2 = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }

                Vk.MessagesSend("💘 " + name_url + " и " + name_url2 + " заключили брачный союз! 💘");

                db.MarriagesAddMarrie(Vk.m_peer_id, long.Parse(args[0]), Vk.m_from_id);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_decmarry()
        {
            try
            {
                //acceptmarry id" + Vk.m_from_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_decmarry", 4))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var marryInfo = db.MarriagesGetUser(Vk.m_peer_id, Vk.m_from_id);
                if (marryInfo != null && marryInfo.Count >= 2)
                {
                    Vk.MessagesSend("Вы уже состоите в браке.");
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "" || args[0] == Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Используйте: !брак [ID/ссылка]" +
                        "<br>Вместо ID или ссылки вы можете переслать сообщение пользователя, к которому хотите применить команду.");
                    return;
                }

                var targetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false);

                if (targetUser == null)
                {
                    Vk.MessagesSend("К сожалению, указанный пользователь не найден.");
                    return;
                }

                var result = Cache.Get<string>("targetid_marry_" + args[0]);
                if (result == null || result != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Этот пользователь не предлагал вам вступить в брак, либо прошло более пяти минут.");
                    return;
                }

                var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });
                string name_url = "[id" + args[0] + "|Пользователь]";

                if (vkInfo.ContainsKey("id" + args[0]))
                {
                    name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                        vkInfo["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }

                var vkInfo2 = await Vk.UsersGetName(new long[] { Vk.m_from_id });
                string name_url2 = "[id" + Vk.m_from_id + "|Пользователь]";

                if (vkInfo2.ContainsKey("id" + Vk.m_from_id))
                {
                    name_url2 = "[id" + Vk.m_from_id + "|" + vkInfo2["id" + Vk.m_from_id].first_name + " " +
                        vkInfo2["id" + Vk.m_from_id].last_name + "]";
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        name_url2 = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }

                Vk.MessagesSend("💔 " + name_url + ", " + name_url2 + " отказался(ась) вступать в брачный союз..");

                Cache.Delete("targetid_marry_" + args[0]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_mafia()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_mafia", 15))
                {
                    return;
                }

                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "mafia"))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + Vk.m_peer_id);

                if (target_mafia != null)
                {
                    Vk.MessagesSend("🔪 Игра в мафию уже запущена");
                    return;
                }

                var urlTarget = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });

                var buttons = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);

                Vk.MessagesSend("🔪 " + urlTarget[Vk.m_from_id.ToString()] + " предложил начать игру в мафию.<br><br>" +
                    "👥 Игроков: 0<br>⌛Начало через: 2 минуты.", 0, 0, buttons);

                Cache.Set("mafia_" + Vk.m_peer_id, "start", 3);
                Cache.Set("mafiaplayers_" + Vk.m_peer_id, new Dictionary<long, Dictionary<string, string>>(), 10);

                // vk.mafios
                /*peer_id
                status (start - набор, run)
                date_create
                date_start*/

                // mafiaplayers_ peerid
                /* role = not

                 */

                var tempDict = new Dictionary<string, string>()
            {
                { "peer_id", Vk.m_peer_id.ToString() },
                { "status", "start" },
                { "date_create", db.timeGetForString(DateTimeOffset.Now) },
                { "date_start", db.timeGetForString(DateTimeOffset.Now.AddMinutes(2)) }
            };
                vk.mafios.TryAdd(Vk.m_peer_id.ToString(), tempDict);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        //----------------------------------------------------------------------------------- МАФИЯ

        public async void game_cmd_invitemafia()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_invitemafia", 0))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + Vk.m_peer_id);

                if (target_mafia == null || target_mafia != "start")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо уже началась.");
                    return;
                }

                var userInfoGlobal = db.usersGetUser(Vk.m_from_id);
                var urlTarget = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });

                if (userInfoGlobal["accept_ls"] != "1")
                {
                    var buttonss = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);

                    Vk.MessagesSend(urlTarget[Vk.m_from_id.ToString()] + ", я не могу писать вам личные сообщения.<br>" +
                        "🌐 Перейдите ко мне на страницу, напишите мне в личные сообщения и попробуйте ещё раз.", 1, 0, buttonss);
                    return;
                }

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia != null && targetUserMafia != "")
                {
                    var buttonss = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);

                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы уже принимаете участие в другой игре.<br><br>Команду выполнил: " + urlTarget[Vk.m_from_id.ToString()], 1, 0, buttonss);
                    }
                    else
                    {
                        Vk.MessagesSend("Вы уже принимаете участие в другой игре.", 1, 0, buttonss);
                    }

                    return;
                }

                var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + Vk.m_peer_id.ToString());
                if (targetUsers != null && targetUsers.Count >= 25)
                {
                    var buttonssq = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);

                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("К сожалению, играть в мафию можно максимум 25 людям.<br><br>Команду выполнил: " + urlTarget[Vk.m_from_id.ToString()], 1, 0, buttonssq);
                    }
                    else
                    {
                        Vk.MessagesSend("К сожалению, играть в мафию можно максимум 25 людям.", 1, 0, buttonssq);
                    }
                    return;
                }

                if (targetUsers != null && targetUsers.ContainsKey(Vk.m_from_id))
                {
                    var buttonsds = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы уже являетесь участником игры.<br><br>Команду выполнил: " + urlTarget[Vk.m_from_id.ToString()], 1, 0, buttonsds);
                    }
                    else
                    {
                        Vk.MessagesSend("Вы уже являетесь участником игры.", 1, 0, buttonsds);
                    }
                    return;
                }

                var res = await Vk.MessagesSendOneGame("🔪 Вы присоединились к игре мафия.", 0, Vk.m_from_id);

                if (res.ContainsKey("response") && res["response"].ToString().ToLower() == "false")
                {

                    var buttonss = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);
                    Vk.MessagesSend(urlTarget[Vk.m_from_id.ToString()] + ", я не могу писать вам личные сообщения.<br>" +
                        "🌐 Перейдите ко мне на страницу, напишите мне в личные сообщения и попробуйте ещё раз.", 1, 0, buttonss);
                    db.gameSetAcceptLs(Vk.m_from_id, 0);
                    return;
                }


                long countUser = 0;
                if (targetUsers == null)
                {
                    countUser = 1;
                    Cache.Set("mafiaplayers_" + Vk.m_peer_id.ToString(), new Dictionary<long, Dictionary<string, string>>()
                { { Vk.m_from_id, new Dictionary<string, string>() { { "role", "not" } } } }, 20);
                }
                else
                {
                    targetUsers.Add(Vk.m_from_id, new Dictionary<string, string>() { { "role", "not" } });
                    countUser = targetUsers.Count();
                    Cache.Set("mafiaplayers_" + Vk.m_peer_id.ToString(), targetUsers, 20);
                }

                Cache.Set("mafiauser_" + Vk.m_from_id.ToString(), Vk.m_peer_id.ToString(), 20);

                string time_tostart = "2 минуты";

                if (vk.mafios.ContainsKey(Vk.m_peer_id.ToString()))
                {
                    DateTimeOffset date_start = db.timeGetForMysql(vk.mafios[Vk.m_peer_id.ToString()]["date_start"]);
                    time_tostart = Case(DateTimeOffset.Now.ToUnixTimeSeconds() - date_start.ToUnixTimeSeconds());


                }

                //var buttons = Vk.GenerateKeyboard(new string[] { "Присоединиться" }, new string[] { "invitemaf" },
                //new string[] { Vk.BUTTON_WHITE }, null, false, false);
                var buttons = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);

                Vk.MessagesSend("🚀 " + urlTarget[Vk.m_from_id.ToString()] + " присоединился к игре в мафию.<br><br>" +
                    $"👥 Игроков: {countUser}<br>⌛Начало через: {time_tostart}.", 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_addmafia()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_addmafia", 0))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + Vk.m_peer_id);

                var urlTarget = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });

                if (target_mafia == null || target_mafia != "start")
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("🔪 Игра в мафию не запущена, либо уже началась.<br><br>Команду выполнил: " + urlTarget[Vk.m_from_id.ToString()]);
                    }
                    else
                    {
                        Vk.MessagesSend("🔪 Игра в мафию не запущена, либо уже началась.");
                    }
                    return;
                }


                var buttons = Vk.GenerateKeyboard(new string[] { "Присоединиться", "Начать игру", "Добавить время" }, new string[] { "invitemaf", "startmafia", "addmafia" },
                    new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_RED, Vk.BUTTON_WHITE }, null, false, false, true);

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia == null || targetUserMafia == "")
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы не играете в мафию. <br><br>Команду выполнил: " + urlTarget[Vk.m_from_id.ToString()], 1, 0, buttons);
                    }
                    else
                    {
                        Vk.MessagesSend("Вы не играете в мафию.", 1, 0, buttons);
                    }

                    return;
                }

                string time_tostart = "2 минуты";

                if (vk.mafios.ContainsKey(Vk.m_peer_id.ToString()))
                {
                    DateTimeOffset date_start = db.timeGetForMysql(vk.mafios[Vk.m_peer_id.ToString()]["date_start"]).AddMinutes(1);
                    time_tostart = Case(DateTimeOffset.Now.ToUnixTimeSeconds() - date_start.ToUnixTimeSeconds());
                    vk.mafios[Vk.m_peer_id.ToString()]["date_start"] = db.timeGetForString(date_start);

                }

                //var buttons = Vk.GenerateKeyboard(new string[] { "Присоединиться" }, new string[] { "invitemaf" },
                //new string[] { Vk.BUTTON_WHITE }, null, false, false);


                Vk.MessagesSend("🚀 " + urlTarget[Vk.m_from_id.ToString()] + $" продлил время ожидания на одну минуту.<br>⌛Начало через: {time_tostart}.", 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_mafiadon()
        {
            try
            {

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_mafiadon", 5))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia == null || targetUserMafia == "")
                {
                    Vk.MessagesSend("Вы не играете в мафию.");
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + targetUserMafia);

                if (target_mafia == null || target_mafia != "night")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо ночь ещё не наступила.");
                    return;
                }

                var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + targetUserMafia);
                if (targetUsers.ContainsKey(Vk.m_from_id))
                {
                    if (targetUsers[Vk.m_from_id]["role"] != "done")
                    {
                        Vk.MessagesSend("🔪 Вы не дон мафии.");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend("🔪 Вы не дон мафии.");
                    return;
                }

                var target_selected_mafia = Cache.Get<string>("mafia_don_selected_" + targetUserMafia);
                if (target_selected_mafia != null)
                {
                    if (long.Parse(target_selected_mafia) >= 1)
                    {
                        Vk.MessagesSend("❗ Вы уже сделали выбор.");
                        return;
                    }
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("❗ Не указан ID необходимого человека.");
                    return;
                }

                long target_id = 0;
                try
                {
                    target_id = long.Parse(args[0]);
                }
                catch
                {
                    target_id = 0;
                }

                if (target_id == 0)
                {
                    Vk.MessagesSend("❗ ID человека введён неверно.");
                    return;
                }

                var targetUserMafia2 = Cache.Get<string>("mafiauser_" + target_id.ToString());
                if (targetUserMafia2 == null || targetUserMafia2 == "" || targetUserMafia != targetUserMafia2 || target_id == Vk.m_from_id)
                {
                    Vk.MessagesSend("Данный человек не играет с вами в мафию.");
                    return;
                }

                Cache.Set("mafia_don_selected_" + targetUserMafia, target_id.ToString(), 5);

                Vk.MessagesSend("🔪 Выбор сделан.");
                Vk.MessagesSend("🔪 Мафия выбрала жертву.", 0, long.Parse(targetUserMafia));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_komissarmaf()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_komissarmaf", 5))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia == null || targetUserMafia == "")
                {
                    Vk.MessagesSend("Вы не играете в мафию.");
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + targetUserMafia);

                if (target_mafia == null || target_mafia != "night")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо ночь ещё не наступила.");
                    return;
                }

                var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + targetUserMafia);
                if (targetUsers.ContainsKey(Vk.m_from_id))
                {
                    if (targetUsers[Vk.m_from_id]["role"] != "komissar")
                    {
                        Vk.MessagesSend("🔪 Вы не комиссар.");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend("🔪 Вы не комиссар.");
                    return;
                }

                var target_selected_mafia = Cache.Get<string>("komissar_maf_selected_" + targetUserMafia);
                if (target_selected_mafia != null)
                {
                    if (long.Parse(target_selected_mafia) >= 1)
                    {
                        Vk.MessagesSend("❗ Вы уже сделали выбор.");
                        return;
                    }
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("❗ Не указан ID необходимого человека.");
                    return;
                }

                long target_id = 0;
                try
                {
                    target_id = long.Parse(args[0]);
                }
                catch
                {
                    target_id = 0;
                }

                if (target_id == 0)
                {
                    Vk.MessagesSend("❗ ID человека введён неверно.");
                    return;
                }

                var targetUserMafia2 = Cache.Get<string>("mafiauser_" + target_id.ToString());
                if (targetUserMafia2 == null || targetUserMafia2 == "" || targetUserMafia != targetUserMafia2 || target_id == Vk.m_from_id)
                {
                    Vk.MessagesSend("Данный человек не играет с вами в мафию.");
                    return;
                }

                Cache.Set("komissar_maf_selected_" + targetUserMafia, target_id.ToString(), 5);
                string buttons = Vk.GenerateKeyboard(new string[] { "Проверить", "Ликвидировать" }, new string[] { "mafia_check id" + target_id, "maf_kilkom id" + target_id }, new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED }, null, true, false);
                Vk.MessagesSend("☠ Вы можете либо проверить человека (узнать его роль), либо ликвидировать.", 1, 0, buttons);
                Vk.MessagesSend("☠ Комиссар выбрал подозреваемого.", 0, long.Parse(targetUserMafia));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_komissarcheck()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_komissarcheck", 5))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia == null || targetUserMafia == "")
                {
                    Vk.MessagesSend("Вы не играете в мафию.");
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + targetUserMafia);

                if (target_mafia == null || target_mafia != "night")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо ночь ещё не наступила.");
                    return;
                }

                var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + targetUserMafia);
                if (targetUsers.ContainsKey(Vk.m_from_id))
                {
                    if (targetUsers[Vk.m_from_id]["role"] != "komissar")
                    {
                        Vk.MessagesSend("🔪 Вы не комиссар.");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend("🔪 Вы не комиссар.");
                    return;
                }

                var target_selected_mafia = Cache.Get<string>("komissar_maf_selected_" + targetUserMafia);


                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "" || args[0] != target_selected_mafia)
                {
                    Vk.MessagesSend("❗ Не указан ID необходимого человека.");
                    return;
                }

                long target_id = 0;
                try
                {
                    target_id = long.Parse(args[0]);
                }
                catch
                {
                    target_id = 0;
                }

                if (target_id == 0)
                {
                    Vk.MessagesSend("❗ ID человека введён неверно.");
                    return;
                }

                var targetUserMafia2 = Cache.Get<string>("mafiauser_" + target_id.ToString());
                if (targetUserMafia2 == null || targetUserMafia2 == "" || targetUserMafia != targetUserMafia2 || target_id == Vk.m_from_id)
                {
                    Vk.MessagesSend("Данный человек не играет с вами в мафию.");
                    return;
                }

                string target_role = "мирный житель.";


                if (targetUsers.ContainsKey(target_id))
                {
                    if (targetUsers[target_id]["role"] == "dead")
                    {
                        target_role = "умер.";
                    }
                    else if (targetUsers[target_id]["role"] == "people")
                    {
                        target_role = "мирный житель.";
                    }
                    else if (targetUsers[target_id]["role"] == "done")
                    {
                        target_role = "дон мафии.";
                    }
                    else if (targetUsers[target_id]["role"] == "doctor")
                    {
                        target_role = "доктор.";
                    }
                    else if (targetUsers[target_id]["role"] == "mafia")
                    {
                        target_role = "мафиози.";
                    }
                    else if (targetUsers[target_id]["role"] == "komissar")
                    {
                        target_role = "комиссар.";
                    }
                }

                var target_nick = await Vk.UserGetNameUrls(new long[] { target_id });
                Vk.MessagesSend(target_nick[target_id.ToString()] + " — " + target_role);
                Cache.Set("komissarCheck_maf_selected_" + targetUserMafia, target_id.ToString(), 5);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_komissarkill()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_komissarkill", 5))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia == null || targetUserMafia == "")
                {
                    Vk.MessagesSend("Вы не играете в мафию.");
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + targetUserMafia);

                if (target_mafia == null || target_mafia != "night")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо ночь ещё не наступила.");
                    return;
                }

                var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + targetUserMafia);
                if (targetUsers.ContainsKey(Vk.m_from_id))
                {
                    if (targetUsers[Vk.m_from_id]["role"] != "komissar")
                    {
                        Vk.MessagesSend("🔪 Вы не комиссар.");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend("🔪 Вы не комиссар.");
                    return;
                }

                var target_selected_mafia = Cache.Get<string>("komissar_maf_selected_" + targetUserMafia);


                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "" || args[0] != target_selected_mafia)
                {
                    Vk.MessagesSend("❗ Не указан ID необходимого человека.");
                    return;
                }

                long target_id = 0;
                try
                {
                    target_id = long.Parse(args[0]);
                }
                catch
                {
                    target_id = 0;
                }

                if (target_id == 0)
                {
                    Vk.MessagesSend("❗ ID человека введён неверно.");
                    return;
                }

                var targetUserMafia2 = Cache.Get<string>("mafiauser_" + target_id.ToString());
                if (targetUserMafia2 == null || targetUserMafia2 == "" || targetUserMafia != targetUserMafia2 || target_id == Vk.m_from_id)
                {
                    Vk.MessagesSend("Данный человек не играет с вами в мафию.");
                    return;
                }

                var target_nick = await Vk.UserGetNameUrls(new long[] { target_id });
                Vk.MessagesSend(target_nick[target_id.ToString()] + " будет ликвидирован.");
                Cache.Delete("komissarCheck_maf_selected_" + targetUserMafia);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_doctormaf()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_doctormaf", 5))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia == null || targetUserMafia == "")
                {
                    Vk.MessagesSend("Вы не играете в мафию.");
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + targetUserMafia);

                if (target_mafia == null || target_mafia != "night")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо ночь ещё не наступила.");
                    return;
                }

                var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + targetUserMafia);
                if (targetUsers.ContainsKey(Vk.m_from_id))
                {
                    if (targetUsers[Vk.m_from_id]["role"] != "doctor")
                    {
                        Vk.MessagesSend("🔪 Вы не доктор.");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend("🔪 Вы не доктор.");
                    return;
                }

                var target_selected_mafia = Cache.Get<string>("doctor_don_selected_" + targetUserMafia);
                if (target_selected_mafia != null)
                {
                    if (long.Parse(target_selected_mafia) >= 1)
                    {
                        Vk.MessagesSend("❗ Вы уже сделали выбор.");
                        return;
                    }
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("❗ Не указан ID необходимого человека.");
                    return;
                }

                long target_id = 0;
                try
                {
                    target_id = long.Parse(args[0]);
                }
                catch
                {
                    target_id = 0;
                }

                if (target_id == 0)
                {
                    Vk.MessagesSend("❗ ID человека введён неверно.");
                    return;
                }

                var targetUserMafia2 = Cache.Get<string>("mafiauser_" + target_id.ToString());
                if (targetUserMafia2 == null || targetUserMafia2 == "" || targetUserMafia != targetUserMafia2 || target_id == Vk.m_from_id)
                {
                    Vk.MessagesSend("Данный человек не играет с вами в мафию.");
                    return;
                }

                Cache.Set("doctor_don_selected_" + targetUserMafia, target_id.ToString(), 5);

                Vk.MessagesSend("💊 Выбор сделан.");
                Vk.MessagesSend("💊 Доктор вышел на ночное дежурство.", 0, long.Parse(targetUserMafia));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_peoplemaf()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_peoplemaf", 5))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var targetUserMafia = Cache.Get<string>("mafiauser_" + Vk.m_from_id.ToString());
                if (targetUserMafia == null || targetUserMafia == "")
                {
                    Vk.MessagesSend("Вы не играете в мафию.");
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + targetUserMafia);

                if (target_mafia == null || target_mafia != "day2")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо день ещё не наступил.");
                    return;
                }

                var targetUsers = Cache.Get<Dictionary<long, Dictionary<string, string>>>("mafiaplayers_" + targetUserMafia);
                if (targetUsers.ContainsKey(Vk.m_from_id))
                {
                    if (targetUsers[Vk.m_from_id]["role"] == "died")
                    {
                        Vk.MessagesSend("🔪 Вы уже умерли..");
                        return;
                    }
                }
                else
                {
                    Vk.MessagesSend("🔪 Вы не мирный житель.");
                    return;
                }

                var target_selected_mafia = Cache.Get<Dictionary<long, List<long>>>("peoples_mafia_selected_" + targetUserMafia);
                if (target_selected_mafia != null && target_selected_mafia.Count >= 1)
                {
                    foreach (var item in target_selected_mafia)
                    {
                        if (item.Value.Contains(Vk.m_from_id))
                        {
                            Vk.MessagesSend("❗ Вы уже сделали выбор.");
                            return;
                        }
                    }
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("❗ Не указан ID необходимого человека.");
                    return;
                }

                long target_id = 0;
                try
                {
                    target_id = long.Parse(args[0]);
                }
                catch
                {
                    target_id = 0;
                }

                if (target_id == 0)
                {
                    Vk.MessagesSend("❗ ID человека введён неверно.");
                    return;
                }

                var targetUserMafia2 = Cache.Get<string>("mafiauser_" + target_id.ToString());
                if (targetUserMafia2 == null || targetUserMafia2 == "" || targetUserMafia != targetUserMafia2 || target_id == Vk.m_from_id)
                {
                    Vk.MessagesSend("Данный человек не играет с вами в мафию.");
                    return;
                }


                if (target_selected_mafia == null)
                {
                    target_selected_mafia = new Dictionary<long, List<long>>();
                }

                if (target_selected_mafia.ContainsKey(target_id))
                {
                    target_selected_mafia[target_id].Add(Vk.m_from_id);
                }
                else
                {
                    target_selected_mafia.Add(target_id, new List<long> { Vk.m_from_id });
                }
                Cache.Set("peoples_mafia_selected_" + targetUserMafia, target_selected_mafia, 5);

                Vk.MessagesSend("💊 Выбор сделан.");
                var nick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                Vk.MessagesSend("📝 " + nick[Vk.m_from_id.ToString()] + " проголосовал(а).", 0, long.Parse(targetUserMafia));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_startmafia()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_invitemafia", 0))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var target_mafia = Cache.Get<string>("mafia_" + Vk.m_peer_id);

                if (target_mafia == null || target_mafia != "start")
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо уже началась.");
                    return;
                }

                var userInfoGlobal = db.usersGetUser(Vk.m_from_id);

                if (vk.mafios.ContainsKey(Vk.m_peer_id.ToString()))
                {
                    vk.mafios[Vk.m_peer_id.ToString()]["date_start"] = db.timeGetForString(DateTimeOffset.Now.AddSeconds(-2));
                }
                else
                {
                    Vk.MessagesSend("🔪 Игра в мафию не запущена, либо уже началась.");
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        // ---------------------- РАБОТА

        public async void game_cmd_job()
        {
            if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_job", 4))
            {
                return;
            }

            if (Vk.m_peer_id <= settings.PEERS_CHATID)
            {
                return;
            }

            var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
            if (PeerInfo != null && PeerInfo["set_games"] != "1")
            {
                return;
            }

            if (Vk.m_from_id <= 0)
            {
                return;
            }
            var targetUser = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);

            if (targetUser == null)
            {
                Vk.MessagesSend("К сожалению, указанный пользователь не найден.");
                return;
            }

            if (targetUser["job"] == "0")
            {
                Vk.MessagesSend("Вы нигде не работаете. Просмотреть список доступных работ: !работы");
                return;
            }

            var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

            var buttons = Vk.GenerateKeyboard(new string[] { "зарплата", "уволиться" },
                new string[] { "job зарплата", "job уволиться" },
                new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED });

            if (args[0] == null || args[0] == "")
            {
                //INFO
                Vk.MessagesSend("Используйте: !брак [ID/ссылка]" +
                    "<br>Вместо ID или ссылки вы можете переслать сообщение пользователя, к которому хотите применить команду.");
                return;
            }


            return;
        }


        // ----------------------- РАБЫ

        public async void game_cmd_slavepay()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slavepay", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                long ownerId = Vk.m_from_id;

                if (ownerId <= 0)
                {
                    return;
                }

                var account = db.usersGetUser(Vk.m_from_id);

                var userSlave = db.slavesGetSlave(ownerId);

                var dateSlave = db.timeGetForMysql(userSlave["date_last_zp"]);
                if (dateSlave.ToUnixTimeSeconds() > DateTimeOffset.Now.AddHours(-1).ToUnixTimeSeconds())
                {
                    Vk.MessagesSend("Вы уже собирали прибыль. Следующий раз будет доступен: " + dateSlave.AddHours(1).ToString("g"));
                    return;
                }

                string text = "";

                var slaves = db.slavesGetAllForOwner(ownerId);
                if (slaves == null || slaves.Count <= 0)
                {
                    Vk.MessagesSend(text + "Вы не имеете своих рабов.<br>Купите рабов: /купитьраба (/buyslave)");
                    return;
                }



                var money = new System.Numerics.BigInteger();

                foreach (var slaveId in slaves)
                {
                    money += long.Parse(slaveId["job_pay"]);
                }
                var userMoney = getUlongMoney(account["rubs"]);
                db.gameSetUserRub(Vk.m_from_id, (userMoney + money).ToString());
                Vk.MessagesSend($"Вы успешно получили {getRubsMoney(money.ToString())}.<br>" +
                    $"Следующий раз доступен " + DateTimeOffset.Now.AddHours(1).ToString("g"));
                db.slaveSetLastJobZP(Vk.m_from_id, db.timeGetForString(DateTimeOffset.Now));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_slaves()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slaves", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                long ownerId = Vk.m_from_id;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        ownerId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }
                if (ownerId <= 0)
                {
                    return;
                }


                List<long> usersForGet = new() { ownerId };

                var userSlave = db.slavesGetSlave(ownerId);
                if (userSlave["owner"] != "0")
                {
                    usersForGet.Add(long.Parse(userSlave["owner"]));
                }

                string buttons = "";
                if (ownerId != Vk.m_from_id)
                {
                    if (userSlave["owner"] == Vk.m_from_id.ToString())
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "Прокачать", "Продать", "Цепи" }, new string[] { $"upslave id{args[0]}", $"sellslave id{args[0]}", $"armourslave id{args[0]}" },
                            new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED, Vk.BUTTON_RED });
                    }
                    else
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "Купить" }, new string[] { $"buyslave id{args[0]}" }, new string[] { Vk.BUTTON_RED });
                    }
                }
                else
                {
                    if (userSlave["owner"] != "0")
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "Выкупиться", "Собрать прибыль" }, new string[] { "slaveexit", $"slavepay" }, new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED });
                    }
                    else
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "Собрать прибыль" }, new string[] { $"slavepay" }, new string[] { Vk.BUTTON_RED });

                    }
                }


                string text = "";

                var usersVk = await Vk.UserGetNameUrls(usersForGet.ToArray());

                if (userSlave["owner"] != "0")
                {
                    text = "Владелец пользователя: " + usersVk[userSlave["owner"]] + "<br>";
                }
                else
                {
                    if (ownerId != Vk.m_from_id)
                    {
                        text = "Пользователь свободен.<br>";
                    }
                    else
                    {
                        text = "Вы свободны.<br>";
                    }

                }

                text += $"Стоимость: {getRubsMoney(userSlave["cost"])}<br><br>";

                var slaves = db.slavesGetAllForOwner(ownerId);
                if (slaves == null || slaves.Count <= 0)
                {
                    if (ownerId != Vk.m_from_id)
                    {
                        Vk.MessagesSend(text + "Пользователь не имеет своих рабов.", 1, 0, buttons);
                        return;
                    }
                    Vk.MessagesSend(text + "Вы не имеете своих рабов.<br>Купите рабов: /купитьраба (/buyslave)", 1, 0, buttons);
                    return;
                }


                foreach (var slaveId in slaves)
                {
                    if (!usersForGet.Contains(long.Parse(slaveId["user_id"])))
                    {
                        usersForGet.Add(long.Parse(slaveId["user_id"]));
                    }

                }

                var usersVkSlaves = await Vk.UserGetNameUrls(usersForGet.ToArray());



                if (ownerId != Vk.m_from_id)
                {
                    text += "У пользователя в рабстве '" + slaves.Count + "' человек:<br><br>";
                }
                else
                {
                    text += "У вас в рабстве '" + slaves.Count + "' человек:<br><br>";
                }


                int i = 0;
                foreach (var slaveId in slaves)
                {
                    i++;

                    string armour = (slaveId["armour"] != "") ? (db.timeGetForMysql(slaveId["armour"]) > DateTimeOffset.Now) ? "Нельзя купить до " + db.timeGetForMysql(slaveId["armour"]).ToString("g") + "." : "" : "";

                    text += $"{i}. {usersVkSlaves[slaveId["user_id"]]} — {slaveId["job"]} ({getRubsMoney(slaveId["job_pay"])} в час). Стоимость: {getRubsMoney(slaveId["cost"])}. {armour}<br>";
                }


                Vk.MessagesSend(text + "<br><br>Купите рабов: /купитьраба (/buyslave)<br>Продайте рабов: /продатьраба (/sellslave)<br>Назначьте работу: /датьработу<br>Прокачайте раба: /прокачатьраба<br>" +
                    "Накиньте цепи на раба: /цепи", 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_sellslave()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slave", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var args1 = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args1[0] == null || args1[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать пользователя.");
                    return;
                }

                var split_args = args1[0].Split(" ");

                var args = await cmdChecker.getArguments("/me " + split_args[0], new string[] { "id" });



                long ownerId = 0;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        ownerId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }
                else
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }
                if (ownerId <= 0 || Vk.m_from_id <= 0)
                {
                    return;
                }

                var account = db.usersGetUser(Vk.m_from_id);

                var userSlave = db.slavesGetSlave(ownerId);
                if (userSlave["owner"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend($"[id{Vk.m_from_id}|Вы] не владеете указанным пользователем.");
                    return;
                }

                var userMoney = getUlongMoney(account["rubs"]);
                var costUser = getUlongMoney(userSlave["cost"]) / 2;

                if (split_args.Length <= 1)
                {
                    var keyb = Vk.GenerateKeyboard(new string[] { "Продать" }, new string[] { $"sellslave id{args[0]} 1" }, new string[] { Vk.BUTTON_RED });
                    Vk.MessagesSend($"Вы можете продать указанного раба за {getRubsMoney(costUser.ToString())}.<br>Вы уверены, что хотите это сделать?",
                        1, 0, keyb);
                    return;
                }
                else
                {
                    if (split_args[1] == "1")
                    {
                        var usersVk = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id, long.Parse(args[0]) });
                        Vk.MessagesSend($"{usersVk[Vk.m_from_id.ToString()]} продал {usersVk[args[0]]}.");
                        db.slavesSetOwner(long.Parse(args[0]), 0);
                        db.gameSetUserRub(Vk.m_from_id, (userMoney + costUser).ToString());
                        db.slavesGetAllForOwner(Vk.m_from_id, true);
                        db.slaveSetArmour(long.Parse(args[0]), db.timeGetForString(DateTimeOffset.Now));
                    }
                    else
                    {
                        return;
                    }
                }

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_buyslave()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slave", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                long ownerId = 0;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        ownerId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }
                else
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }

                if (ownerId <= 0 || ownerId == Vk.m_from_id)
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }

                List<long> usersForGet = new();

                var userSlave = db.slavesGetSlave(ownerId);


                var account = db.usersGetUser(Vk.m_from_id);


                var userMoneys = getUlongMoney(account["rubs"]);
                var targetMoney = getUlongMoney(userSlave["cost"]);

                if (userMoneys < targetMoney)
                {
                    Vk.MessagesSend("К сожалению, у вас недостаточно рублей для покупки.<br>Необходимо для покупки: " +
                        $"{getRubsMoney(userSlave["cost"])}<br>" +
                        $"На вашем счету: {getRubsMoney(account["rubs"])}");
                    return;
                }

                if (account["accept_ls"] != "1")
                {
                    Vk.MessagesSend("Я не могу писать вам личные сообщения.<br>" +
                        "🌐 Перейдите ко мне на страницу, напишите мне в личные сообщения и попробуйте ещё раз.", 1, 0);
                    return;
                }

                if (userSlave["armour"] != "")
                {
                    var timeArmour = db.timeGetForMysql(userSlave["armour"]);
                    if (timeArmour > DateTimeOffset.Now)
                    {
                        Vk.MessagesSend("Вы не можете купить пользователя, поскольку он имеет цепи до " + timeArmour.ToString("g") + ".");
                        return;
                    }
                }

                if (settings.OWNER_IDS.ContainsKey(ownerId))
                {
                    Vk.MessagesSend("Нельзя покупать спонсоров FINK!");
                    return;
                }

                db.gameSetUserRub(Vk.m_from_id, (userMoneys - targetMoney).ToString());
                db.slavesSetOwner(ownerId, Vk.m_from_id);

                List<long> user = new() { Vk.m_from_id, ownerId };
                if (userSlave["owner"] != "0")
                {
                    db.slavesGetAllForOwner(long.Parse(userSlave["owner"]), true);
                }

                var usersVk = await Vk.UserGetNameUrls(user.ToArray());

                float dig = 1.3f;
                //long digitCost = Convert.ToInt64(dig * long.Parse(userSlave["cost"]));
                //if (targetMoney > (BigInteger)999999999999)
                var digitCost = targetMoney + (targetMoney / 10 * 3);

                //long digitJobPay = Convert.ToInt64(1.2f * long.Parse(userSlave["job_pay"]));
                db.slavesSetCost(ownerId, digitCost.ToString());
                db.slavesGetAllForOwner(Vk.m_from_id, true);
                //db.slavesSetJobPay(ownerId, digitJobPay);

                Vk.MessagesSend(usersVk[ownerId.ToString()] + " получил нового владельца.<br>" +
                    "Новый владелец: " + usersVk[Vk.m_from_id.ToString()], 1, 0);

                if (userSlave["owner"] != "0")
                {
                    Vk.MessagesSend(usersVk[Vk.m_from_id.ToString()] + " выкупил у вас " + usersVk[ownerId.ToString()] + ".", 0, long.Parse(userSlave["owner"]));
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_jobslave()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slavejob", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });

                long ownerId = 0;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        ownerId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }
                else
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }

                if (args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend("Необходимо указать название работы.");
                    return;
                }

                if (ownerId <= 0 || ownerId == Vk.m_from_id)
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }

                List<long> usersForGet = new() { Vk.m_from_id, ownerId };

                var usersVk = await Vk.UserGetNameUrls(usersForGet.ToArray());

                var userSlave = db.slavesGetSlave(ownerId);


                var account = db.usersGetUser(Vk.m_from_id);

                if (userSlave["owner"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Вы не владеете данным пользователем.");
                    return;
                }

                if (account["accept_ls"] != "1")
                {
                    Vk.MessagesSend("Я не могу писать вам личные сообщения.<br>" +
                        "🌐 Перейдите ко мне на страницу, напишите мне в личные сообщения и попробуйте ещё раз.", 1, 0);
                    return;
                }

                db.slavesSetJob(ownerId, args[1]);
                db.slavesGetAllForOwner(Vk.m_from_id, true);


                Vk.MessagesSend(usersVk[ownerId.ToString()] + " получил новую работу");

                if (userSlave["owner"] != "0")
                {
                    Vk.MessagesSend(usersVk[Vk.m_from_id.ToString()] + " назначил вам работу '" + args[1] + "'.", 0, long.Parse(args[0]));
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_slaveexit()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slave", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }


                var account = db.usersGetUser(Vk.m_from_id);

                var userSlave = db.slavesGetSlave(Vk.m_from_id);
                if (userSlave["owner"] == "0")
                {
                    Vk.MessagesSend($"[id{Vk.m_from_id}|Вы] уже свободны.");
                    return;
                }

                if (userSlave["armour"] != "")
                {
                    var timeArmour = db.timeGetForMysql(userSlave["armour"]);
                    if (timeArmour > DateTimeOffset.Now)
                    {
                        Vk.MessagesSend("Вы не можете выкупиться, поскольку вы имеете цепи до " + timeArmour.ToString("g") + ".");
                        return;
                    }
                }

                var userMoney = getUlongMoney(account["rubs"]);
                var costUser = getUlongMoney(userSlave["cost"]);

                if (userMoney < costUser)
                {
                    Vk.MessagesSend("На вашем счету недостаточно средств. Необходимо для выкупа: " + getRubsMoney(costUser.ToString()));
                    return;
                }

                var usersVk = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id, long.Parse(userSlave["owner"]) });
                Vk.MessagesSend($"{usersVk[Vk.m_from_id.ToString()]} больше не раб {usersVk[userSlave["owner"]]}.");
                db.slavesSetOwner(Vk.m_from_id, 0);
                db.gameSetUserRub(Vk.m_from_id, (userMoney - costUser).ToString());
                db.slavesGetAllForOwner(Vk.m_from_id, true);
                db.slavesGetAllForOwner(long.Parse(userSlave["owner"]), true);
                if (userSlave["owner"] != "0")
                {
                    Vk.MessagesSend(usersVk[Vk.m_from_id.ToString()] + " выкупился.", 0, long.Parse(userSlave["owner"]));
                }

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_upslave()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slave", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                long ownerId = 0;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        ownerId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }
                else
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }

                if (ownerId <= 0 || ownerId == Vk.m_from_id)
                {
                    return;
                }

                List<long> usersForGet = new();

                var userSlave = db.slavesGetSlave(ownerId);
                if (userSlave["owner"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Вы не владеете данным пользователем.");
                    return;
                }

                var account = db.usersGetUser(Vk.m_from_id);


                var userMoneys = getUlongMoney(account["rubs"]);
                var jobPAy = getUlongMoney(userSlave["job_pay"]);


                //float dig = 1.3f;
                //long digitCost = Convert.ToInt64(dig * long.Parse(userSlave["cost"]));
                var targetMoney = getUlongMoney(userSlave["cost"]);

                var digitCost = targetMoney + (targetMoney / 10 * 3);
                var maxJob = BigInteger.Parse("10000000");
                //long digitJobPay = Convert.ToInt64(1.2f * long.Parse(userSlave["job_pay"]));
                var digitJobPay = new BigInteger(0);
                if (jobPAy >= maxJob)
                {
                    digitJobPay = jobPAy + (jobPAy / 1000);
                }
                else
                {
                    digitJobPay = jobPAy + (jobPAy / 10 * 2);
                }


                if (userMoneys < digitCost)
                {
                    Vk.MessagesSend("К сожалению, у вас недостаточно рублей для покупки.<br>Необходимо для повышения: " +
                        $"{getRubsMoney(digitCost.ToString())}<br>" +
                        $"На вашем счету: {getRubsMoney(account["rubs"])}");
                    return;
                }

                if (account["accept_ls"] != "1")
                {
                    Vk.MessagesSend("Я не могу писать вам личные сообщения.<br>" +
                        "🌐 Перейдите ко мне на страницу, напишите мне в личные сообщения и попробуйте ещё раз.", 1, 0);
                    return;
                }

                db.gameSetUserRub(Vk.m_from_id, (userMoneys - digitCost).ToString());

                db.slavesSetCost(ownerId, digitCost.ToString());
                db.slavesSetJobPay(ownerId, digitJobPay.ToString());
                db.slavesGetAllForOwner(Vk.m_from_id, true);

                Vk.MessagesSend("Теперь ваш раб будет работать больше и приносить больше денег.");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_armourslave()
        {
            try
            {
                // cache key - "mafia_" + Vk.m_peer_id


                if (Vk.m_peer_id >= settings.PEERS_CHATID)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_slave", 15))
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                long ownerId = 0;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        ownerId = long.Parse(args[0]);
                    }
                    catch
                    {

                    }
                }
                else
                {
                    Vk.MessagesSend("Необходимо указать ID пользователя.");
                    return;
                }

                if (ownerId <= 0 || ownerId == Vk.m_from_id)
                {
                    return;
                }

                List<long> usersForGet = new();

                var userSlave = db.slavesGetSlave(ownerId);
                if (userSlave["owner"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Вы не владеете данным пользователем.");
                    return;
                }

                var account = db.usersGetUser(Vk.m_from_id);


                var userMoneys = getUlongMoney(account["rubs"]);
                var jobPAy = getUlongMoney(userSlave["job_pay"]);

                if (userSlave["armour"] != "")
                {
                    var timeArmour = db.timeGetForMysql(userSlave["armour"]);
                    if (timeArmour > DateTimeOffset.Now)
                    {
                        Vk.MessagesSend("Пользователь уже имеет цепи до " + timeArmour.ToString("g") + ".");
                        return;
                    }
                }
                //float dig = 1.3f;
                //long digitCost = Convert.ToInt64(dig * long.Parse(userSlave["cost"]));
                var ownerSLAVEAccount = db.slavesGetSlave(Vk.m_from_id);
                if (int.Parse(ownerSLAVEAccount["armours"]) < 1)
                {
                    Vk.MessagesSend("Вы не имеете цепей. Их можно получить прокручивая рулетку в комментариях под любым постом группы, где не раздаются другие призы.<br>" +
                        "Просто напишите 'Рулетка' без кавычек.");
                    return;
                }

                //var targetMoney = jobPAy + (jobPAy / 2);


                //if (userMoneys < targetMoney)
                //{
                //Vk.MessagesSend("К сожалению, у вас недостаточно рублей для покупки цепей.<br>Необходимо для повышения: " +
                //$"{getRubsMoney(digitCost.ToString())}<br>" +
                //$"На вашем счету: {getRubsMoney(account["rubs"])}");
                //return;
                //}

                if (account["accept_ls"] != "1")
                {
                    Vk.MessagesSend("Я не могу писать вам личные сообщения.<br>" +
                        "🌐 Перейдите ко мне на страницу, напишите мне в личные сообщения и попробуйте ещё раз.", 1, 0);
                    return;
                }

                //db.gameSetUserRub(Vk.m_from_id, (userMoneys - digitCost).ToString());

                //db.slavesSetCost(ownerId, digitCost.ToString());
                db.slaveSetArmour(ownerId, db.timeGetForString(DateTimeOffset.Now.AddHours(12)));
                db.slavesSetArmours(Vk.m_from_id, int.Parse(ownerSLAVEAccount["armours"]) - 1);
                db.slavesGetAllForOwner(Vk.m_from_id, true);

                Vk.MessagesSend("Теперь ваш раб будет под защитой 12 часов.");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        // ---------------------- ВЫБОРЫ

        public async void game_cmd_golosovat()
        {
            try
            {
                //GetCandidatesCountry
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_candidates", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);
                if (userInfo["country"] == "0")
                {
                    Vk.MessagesSend("❗ У вас нет государства. Используйте '!гражданство' для вступления в страну.");
                    return;
                }

                var date = DateTimeOffset.Now;
                if (date.Day != 11 || (date.Hour >= 23))
                {
                    //Vk.MessagesSend("❗ К сожалению, сейчас нет выборов. Выборы в президенты проводятся 11 числа каждого месяца с 00:00 до 22:59 включительно.");
                    //return;
                }

                var candidates = db.GetCandidatesCountry(long.Parse(userInfo["country"]));
                if (candidates == null || candidates.Count() <= 0)
                {
                    Vk.MessagesSend("🤖 В вашей стране нет кандидатов на пост президента.<br><br>Вы можете попробовать себя в роли президента — '!баллотироваться'");
                    return;
                }
                var niks = new List<long>();
                foreach (var item in candidates)
                {
                    niks.Add(item.id);
                }
                var names = await Vk.UserGetNameUrls(niks.ToArray());
                string text = "🤵 Кандидаты на пост президента страны:<br><br>";
                long i = 1;
                List<string> names_buttons = new();
                List<string> commands_buttons = new();
                List<string> colors_buttons = new();
                foreach (var item in candidates)
                {
                    text = text + $"{i}. {names[item.id.ToString()]} — {item.voices} голосов.<br>";
                    names_buttons.Add(i.ToString());
                    commands_buttons.Add("vibor [id" + item.id.ToString() + "|пользователь]");
                    colors_buttons.Add(Vk.BUTTON_WHITE);
                    i++;
                }
                text = text + "<br>Чтобы просмотреть предвыборную кампанию — выберите одну из кнопок ниже (текст кнопок - соответствует номеру кандидата).";

                var buttons = Vk.GenerateKeyboard(names_buttons.ToArray(), commands_buttons.ToArray(), colors_buttons.ToArray());
                Vk.MessagesSend(text, 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_getpresident()
        {
            try
            {
                //GetCandidatesCountry
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_getpresident", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);
                if (userInfo["country"] == "0")
                {
                    Vk.MessagesSend("❗ У вас нет государства. Используйте '!гражданство' для вступления в страну.");
                    return;
                }

                var date = DateTimeOffset.Now;
                if (date.Day != 11 || (date.Hour >= 23))
                {
                    //Vk.MessagesSend("❗ К сожалению, сейчас нет выборов. Выборы в президенты проводятся 11 числа каждого месяца с 00:00 до 22:59 включительно.");
                    //return;
                }

                var candidates = db.GetCandidatesCountry(long.Parse(userInfo["country"]));
                if (candidates == null || candidates.Count() <= 0)
                {
                    Vk.MessagesSend("🤖 В вашей стране нет кандидатов на пост президента.<br><br>Вы можете попробовать себя в роли президента — '!баллотироваться'");
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("❗ Не указан ID кандидата в президенты.");
                    return;
                }

                var country = db.CountriesGetCountry(long.Parse(userInfo["country"]));

                bool finded_candidate = false;
                long target_id = long.Parse(args[0]);
                string text = "❗ Выбранный вами кандидат не найден";
                foreach (var item in candidates)
                {
                    if (item.id == target_id)
                    {
                        finded_candidate = true;
                        var niks_target = await Vk.UserGetNameUrls(new long[] { target_id });
                        text = "🤴 " + niks_target[target_id.ToString()] + " — кандидат в президенты страны '" + country["name"] + "'.<br><br>" +
                            "👀 За него отдали голосов: " + item.voices + " людей.<br>" +
                            "💭 Предвыборная кампания: " + item.text_comp;
                        var buttons = Vk.GenerateKeyboard(new string[] { "голосовать" }, new string[] { "golos id" + target_id }, new string[] { Vk.BUTTON_BLUE });
                        text = text + "<br>Вы также можете попробовать себя в роли президента — '!баллотироваться'";
                        Vk.MessagesSend(text, 1, 0, buttons);
                        return;
                    }
                }
                text = text + "<br>Вы также можете попробовать себя в роли президента — '!баллотироваться'";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_golos_pres()
        {
            try
            {
                //GetCandidatesCountry
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_golos_prez", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);
                if (userInfo["country"] == "0")
                {
                    Vk.MessagesSend("❗ У вас нет государства. Используйте '!гражданство' для вступления в страну.");
                    return;
                }

                var date = DateTimeOffset.Now;
                if (date.Day != 11 || (date.Hour >= 23))
                {
                    //Vk.MessagesSend("❗ К сожалению, сейчас нет выборов. Выборы в президенты проводятся 11 числа каждого месяца с 00:00 до 22:59 включительно.");
                    //return;
                }

                var candidates = db.GetCandidatesCountry(long.Parse(userInfo["country"]));
                if (candidates == null || candidates.Count() <= 0)
                {
                    Vk.MessagesSend("🤖 В вашей стране нет кандидатов на пост президента.<br><br>Вы можете попробовать себя в роли президента — '!баллотироваться'");
                    return;
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("❗ Не указан ID кандидата в президенты.");
                    return;
                }

                var country = db.CountriesGetCountry(long.Parse(userInfo["country"]));

                long target_id = long.Parse(args[0]);
                string text = "❗ Выбранный вами кандидат не найден";
                foreach (var item in candidates)
                {
                    if (item.id == target_id)
                    {
                        string? result = Cache.Get<string>("golos_user_" + Vk.m_from_id.ToString());

                        if (result != null || result == "otdan")
                        {
                            Vk.MessagesSend("Вы уже принимали участие в голосовании!");
                            return;
                        }
                        else
                        {
                            result = "otdan";
                        }
                        Cache.Set("golos_user_" + Vk.m_from_id.ToString(), result, 1440);
                        var niks_target = await Vk.UserGetNameUrls(new long[] { target_id });
                        item.voices += 1;
                        text = "🤴 Вы отдали свой голос за " + niks_target[target_id.ToString()] + " — '" + country["name"] + "'.<br><br>" +
                            "👀 За него отдали голосов: " + item.voices + " людей.<br>" +
                            "💭 Предвыборная кампания: " + item.text_comp;

                        text = text + "<br>Вы также можете попробовать себя в роли президента — '!баллотироваться'";
                        Vk.MessagesSend(text);
                        return;
                    }
                }
                text = text + "<br>Вы также можете попробовать себя в роли президента — '!баллотироваться'";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_ballotyri()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_ballotyri", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);
                if (userInfo["country"] == "0")
                {
                    Vk.MessagesSend("❗ У вас нет государства. Используйте '!гражданство' для вступления в страну.");
                    return;
                }

                var date = DateTimeOffset.Now;
                if (date.Day != 11 || (date.Hour >= 23))
                {
                    //Vk.MessagesSend("❗ К сожалению, сейчас нет выборов. Выборы в президенты проводятся 11 числа каждого месяца с 00:00 до 22:59 включительно.");
                    //return;
                }

                var candidates = db.GetCandidatesCountry(long.Parse(userInfo["country"]));
                if (candidates != null && candidates.Count() >= 0)
                {
                    foreach (var item in candidates)
                    {
                        if (item.id == Vk.m_from_id)
                        {
                            Vk.MessagesSend("🤖 Вы уже находитесь в списке кандидатов.");
                            return;
                        }
                    }
                }

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("❗ Укажите свою предвыборную кампанию (описание), !баллотироваться [ТЕКСТ]");
                    return;
                }

                var moneyuser = getUlongMoney(userInfo["rubs"]);
                if (moneyuser < 25000000)
                {
                    Vk.MessagesSend("❗ Стоимость участия в выборах — 25 миллионов рублей. Однако, на вашем счету недостаточно средств.");
                    return;
                }


                if (userInfo["accept_ls"] != "1")
                {
                    var urlTarget = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });

                    Vk.MessagesSend(urlTarget[Vk.m_from_id.ToString()] + ", я не могу писать вам личные сообщения.<br>" +
                        "🌐 Перейдите ко мне на страницу, напишите мне в личные сообщения и попробуйте ещё раз.", 1, 0);
                    return;
                }


                Cache cach = new Cache();
                var candidate = new Database.candidatePresident()
                { id = Vk.m_from_id, id_country = long.Parse(userInfo["country"]), text_comp = args[0], voices = 0 };
                cach.Set("predvibor_" + Vk.m_from_id.ToString(), candidate);

                var buttons = Vk.GenerateKeyboard(new string[] { "ДА" }, new string[] { "ball_two" }, new string[] { Vk.BUTTON_RED });
                Vk.MessagesSend("🤴 Обратите внимание, стоимость участия в выборах — 25 миллионов рублей.<br><br>" +
                    "Если вы полностью согласны, нажмите на кнопку ниже.", 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_ballotyri2()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_ballotyri2", 4))
                {
                    return;
                }

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                var userInfo = db.usersGetUser(Vk.m_from_id);
                if (userInfo["country"] == "0")
                {
                    Vk.MessagesSend("❗ У вас нет государства. Используйте '!гражданство' для вступления в страну.");
                    return;
                }

                var date = DateTimeOffset.Now;
                if (date.Day != 11 || (date.Hour >= 23))
                {
                    //Vk.MessagesSend("❗ К сожалению, сейчас нет выборов. Выборы в президенты проводятся 11 числа каждого месяца с 00:00 до 22:59 включительно.");
                    //return;
                }

                var candidates = db.GetCandidatesCountry(long.Parse(userInfo["country"]));
                if (candidates != null && candidates.Count() >= 0)
                {
                    foreach (var item in candidates)
                    {
                        if (item.id == Vk.m_from_id)
                        {
                            Vk.MessagesSend("🤖 Вы уже находитесь в списке кандидатов.");
                            return;
                        }
                    }
                }
                Cache cach = new();
                var result = cach.Get<Database.candidatePresident>("predvibor_" + Vk.m_from_id.ToString());
                if (result == null || result.id != Vk.m_from_id)
                {
                    Vk.MessagesSend("🤖 Время подтверждения истекло, заполните заявку заново и подтвердите в течение 5 минут.");
                    return;
                }

                var moneyuser = getUlongMoney(userInfo["rubs"]);
                if (moneyuser < 25000000)
                {
                    Vk.MessagesSend("❗ Стоимость участия в выборах — 25 миллионов рублей. Однако, на вашем счету недостаточно средств.");
                    return;
                }

                moneyuser -= 25000000;

                Vk.MessagesSend("📜 Вы успешно записаны в кандидаты на пост президента.");

                db.CandidatesAddCountry(long.Parse(userInfo["country"]), result);
                db.gameSetUserRub(Vk.m_from_id, moneyuser.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async Task system_vibory_start()
        {
            try
            {

                var countries = db.CandidatesGetCountries();
                if (countries == null || countries.Count <= 0)
                {
                    return;
                }

                foreach (var item in countries)
                {
                    var candidates = db.GetCandidatesCountry(item);
                    if (candidates == null || candidates.Count <= 0)
                    {
                        Cache.Delete("candidates_country_" + item);
                        continue;
                    }

                    long max = 0;
                    long max_id = 0;
                    long min = 0;

                    foreach (var candidate in candidates)
                    {
                        if (candidate.voices > max)
                        {
                            max = candidate.voices;
                            max_id = candidate.id;
                        }
                    }
                    min = max;

                    foreach (var candidate in candidates)
                    {
                        if (candidate.voices < min)
                        {
                            min = candidate.voices;
                        }
                    }
                    var country = db.CountriesGetCountry(item);
                    await Vk.MessagesSend($"🔥 Вас выбрали главой государства '{country["name"]}'! Вы набрали '{max}' голосов. Поздравляем!" +
                        $"<br><br>Управления страной: !моястрана", 0, max_id);
                    db.CountriesSetOwner(max_id, item);
                    Cache.Delete("candidates_country_" + item);
                    Thread.Sleep(2000);
                }
                db.CandidatesCountriesClear();
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
        // ---------------------- ВЫБОРЫ

        public async void system_togglelog()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }
                if (settings.ENABLE_MESSAGES_LOG)
                {
                    settings.ENABLE_MESSAGES_LOG = false;
                    Vk.MessagesSend("Логгирование выключено.");
                }
                else
                {
                    settings.ENABLE_MESSAGES_LOG = true;
                    Vk.MessagesSend("Логгирование включено.");
                }
                //ENABLE_MESSAGES_LOG
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }


        private string Case(long seconds)
        {
            long result = (seconds % 100 > 20) ? seconds % 10 : seconds % 20;
            //Console.WriteLine("Результат: ");
            switch (result)
            {
                case 1: return Math.Abs(seconds) + " " + "секунду";
                case 2:
                case 3:
                case 4: return Math.Abs(seconds) + " " + "секунды";
                default: return Math.Abs(seconds) + " " + "секунд";

            }
        }

        public async void game_cmd_divorce()
        {
            try
            {
                //acceptmarry id" + Vk.m_from_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_divorce", 4))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var marryInfo = db.MarriagesGetUser(Vk.m_peer_id, Vk.m_from_id);
                if (marryInfo == null)
                {
                    Vk.MessagesSend("Вы не находитесь в браке.");
                    return;
                }

                long targetId = 0;
                if (marryInfo["husband"] == Vk.m_from_id.ToString())
                {
                    targetId = long.Parse(marryInfo["wife"]);
                }
                else
                {
                    targetId = long.Parse(marryInfo["husband"]);
                }

                var vkInfo = await Vk.UsersGetName(new long[] { targetId });
                string name_url = "[id" + targetId + "|Пользователь]";

                if (vkInfo.ContainsKey("id" + targetId))
                {
                    name_url = "[id" + targetId + "|" + vkInfo["id" + targetId].first_name + " " +
                        vkInfo["id" + targetId].last_name + "]";
                }
                else
                {
                    if (targetId < 0)
                    {
                        name_url = "[club" + targetId.ToString().Substring(1) + "|Сообщество]";
                    }
                }

                var vkInfo2 = await Vk.UsersGetName(new long[] { Vk.m_from_id });
                string name_url2 = "[id" + Vk.m_from_id + "|Пользователь]";

                if (vkInfo2.ContainsKey("id" + Vk.m_from_id))
                {
                    name_url2 = "[id" + Vk.m_from_id + "|" + vkInfo2["id" + Vk.m_from_id].first_name + " " +
                        vkInfo2["id" + Vk.m_from_id].last_name + "]";
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        name_url2 = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }

                Vk.MessagesSend("💔 " + name_url + " и " + name_url2 + " развелись.. 💔");
                db.MarriagesDelMarrie(Vk.m_peer_id, long.Parse(marryInfo["husband"]), long.Parse(marryInfo["wife"]));
                //db.Marr(Vk.m_peer_id, long.Parse(args[0]), Vk.m_from_id);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void game_cmd_marrylist()
        {
            try
            {

                //acceptmarry id" + Vk.m_from_id

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "game_marrylist", 4))
                {
                    return;
                }

                if (Vk.m_peer_id <= settings.PEERS_CHATID)
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo != null && PeerInfo["set_games"] != "1")
                {
                    return;
                }

                if (Vk.m_from_id <= 0)
                {
                    return;
                }

                var marryList = db.MarriagesGetMarries(Vk.m_peer_id);

                if (marryList == null || (marryList.GetType().Equals(typeof(Dictionary<string, string>)) && marryList.Count <= 0))
                {
                    Vk.MessagesSend("💔 В данной беседе нет зарегистрированных браков 💔");
                    return;
                }


                long list = 0;

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (args[0] == null || args[0] == "")
                {
                    list = 1;
                }
                else
                {
                    long target_list = long.Parse(args[0]);
                    if (target_list <= 0)
                    {
                        list = 1;
                    }
                    else
                    {
                        list = target_list;
                    }
                }

                long max_count = list * 25;
                long min_count = max_count - 25;

                long all_list = (int)Math.Round(double.Parse(marryList.Count.ToString()) / double.Parse("25"));

                all_list++;

                if (list != 1 && marryList.Count <= min_count)
                {
                    Vk.MessagesSend("Указанная страница не найдена.<br><br>" +
                        "Страница: " + list + "<br>" +
                        "Всего страниц: " + all_list);
                    return;
                }

                long target_marry_count = 0;

                List<long> userget = new();
                long iters = 0;
                foreach (var item in marryList)
                {

                    if (target_marry_count >= max_count || target_marry_count < min_count)
                    {
                        target_marry_count++;
                        continue;
                    }
                    target_marry_count++;
                    if (!userget.Contains(long.Parse(item["husband"])))
                    {
                        userget.Add(long.Parse(item["husband"]));
                    }
                    if (!userget.Contains(long.Parse(item["wife"])))
                    {
                        userget.Add(long.Parse(item["wife"]));
                    }
                }

                long[] userids = new long[userget.Count()];
                long iss = 0;
                foreach (var item in userget)
                {
                    userids[iss] = item;
                    iss++;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(userids);
                //if (all_list == 0)
                //{

                //}

                string text = "Список зарегистрированных браков в этой беседе:<br><br>";
                long i = min_count + 1;
                target_marry_count = 0;
                foreach (var item in marryList)
                {

                    if (target_marry_count >= max_count || target_marry_count < min_count)
                    {
                        target_marry_count++;
                        continue;
                    }
                    target_marry_count++;

                    if (users_names_vk.ContainsKey("id" + item["husband"]))
                    {
                        if (long.Parse(item["husband"]) < 0)
                        {
                            text = text + "💞 " + i + ". [club" + item["husband"].Substring(1) + "|" + users_names_vk["id" + item["husband"]].first_name + " " +
                                users_names_vk["id" + item["husband"]].last_name + "] ❤ ";
                        }
                        else
                        {
                            text = text + "💞 " + i + ". [id" + item["husband"] + "|" + users_names_vk["id" + item["husband"]].first_name + " " +
                                users_names_vk["id" + item["husband"]].last_name + "] ❤ ";
                        }
                    }
                    else
                    {
                        if (long.Parse(item["husband"]) < 0)
                        {
                            text = text + "💞 " + i + ". [club" + item["husband"].Substring(1) + "|Сообщество] ❤ ";
                        }
                        else
                        {
                            text = text + "💞 " + i + ". [id" + item["husband"] + "|Пользователь] ❤ ";
                        }
                    }


                    // ЖЕНА

                    if (users_names_vk.ContainsKey("id" + item["wife"]))
                    {
                        if (long.Parse(item["wife"]) < 0)
                        {
                            text = text + "[club" + item["wife"].Substring(1) + "|" + users_names_vk["id" + item["wife"]].first_name + " " +
                                users_names_vk["id" + item["wife"]].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + "[id" + item["wife"] + "|" + users_names_vk["id" + item["wife"]].first_name + " " +
                                users_names_vk["id" + item["wife"]].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        if (long.Parse(item["wife"]) < 0)
                        {
                            text = text + "[club" + item["wife"].Substring(1) + "|Сообщество]<br>";
                        }
                        else
                        {
                            text = text + "[id" + item["wife"] + "|Пользователь]<br>";
                        }
                    }

                    //Vk.MessagesSend("");
                    i++;
                }
                string buttons = "";
                if (list == 1 && all_list > 1)
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "—>" }, new string[] { "браки 2" }, new string[] { Vk.BUTTON_WHITE });
                }
                else if (list != 1 && all_list > list)
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "<—", "—>" }, new string[] { "браки " + (list-1).ToString(),
                    "браки " + (list+1).ToString() }, new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE }, new int[] { 0, 0 });
                }
                else if (list != 1 && all_list == list)
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "<—" }, new string[] { "браки " + (list - 1).ToString(), }, new string[] { Vk.BUTTON_WHITE },
                        new int[] { 0, 0 });
                }
                text = text + "<br>Страница: " + list + "<br>Всего страниц: " + all_list;
                Vk.MessagesSend(text, 1, 0, buttons);
                //db.Marr(Vk.m_peer_id, long.Parse(args[0]), Vk.m_from_id);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        (System.Numerics.BigInteger numerator, System.Numerics.BigInteger denominator) NumFraction(decimal d)
        {
            int[] bits = decimal.GetBits(d);
            System.Numerics.BigInteger numerator = (1 - ((bits[3] >> 30) & 2)) *
                                   unchecked(((System.Numerics.BigInteger)(uint)bits[2] << 64) |
                                             ((System.Numerics.BigInteger)(uint)bits[1] << 32) |
                                              (System.Numerics.BigInteger)(uint)bits[0]);
            System.Numerics.BigInteger denominator = System.Numerics.BigInteger.Pow(10, (bits[3] >> 16) & 0xff);
            return (numerator, denominator);
        }

        public async void SendAdmMessage(string text, string keyboard = "", bool disable_mentions = true, string attchs = "")
        {
            string? last_time = Cache.Get<string>("last_adm_info");
            if (last_time == null || last_time == "")
            {
                last_time = DateTimeOffset.Now.ToUnixTimeSeconds().ToString();
                Cache.Set("last_adm_info", last_time);
            }
            else
            {
                var time = long.Parse(last_time);
                if (time > DateTimeOffset.Now.AddMinutes(-10).ToUnixTimeSeconds())
                {
                    //return;
                }
                time = DateTimeOffset.Now.ToUnixTimeSeconds();
                Cache.Set("last_adm_info", last_time);
            }
            List<long> sendIds = new();
            foreach (var item in settings.OWNER_IDS)
            {
                if (item.Value.access_answer == 1)
                {
                    sendIds.Add(item.Key);
                }

            }
            Vk.MessagesSendMassive(text, sendIds, keyboard, disable_mentions, attchs);

            if (settings.REPORT_CHAT_PEER_ID != 0)
            {
                Vk.MessagesSend(text, 0, settings.REPORT_CHAT_PEER_ID, keyboard, disable_mentions, attchs);
            }

            return;
        }


        public string getRubsMoney(string money)
        {
            return getKKsMoney(money, "en-U") + "₽";
        }

        public string getDollMoney(string money)
        {
            return getKKsMoney(money, "en-US") + "$";
        }

        public string getEuroMoney(string money)
        {
            return getKKsMoney(money, "en-U") + "€";
        }
        /*
         * ru-RU - рубли
         * en-US - доллары
         * fr-FR - евро
         */
        public string getKKsMoney(string money, string country = "ru-RU")
        {
            System.Numerics.BigInteger temp = 0;
            try
            {
                temp = System.Numerics.BigInteger.Parse(money);
            }
            catch
            {

            }
            var counti = CultureInfo.CreateSpecificCulture(country);
            return temp.ToString("N0", counti);//temp.ToString("C2", counti);
        }

        public System.Numerics.BigInteger getUlongMoney(string money)
        {
            //decimal temp = 0;
            System.Numerics.BigInteger temp = 0;
            try
            {
                temp = System.Numerics.BigInteger.Parse(money);
            }
            catch
            {

            }
            return temp;
        }

        public async void command_setreportchat()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].admin == 0)
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                if (args[0] == "" || args[0] == null)
                {
                    if (settings.REPORT_CHAT_PEER_ID == 0)
                    {
                        Vk.MessagesSend("Чат репортов не установлен.\nИспользование: !setreportchat [peer_id]");
                    }
                    else
                    {
                        Vk.MessagesSend("Текущий чат репортов: " + settings.REPORT_CHAT_PEER_ID + "\nДля сброса: !setreportchat 0");
                    }
                    return;
                }

                if (args[0] == "0" || args[0] == "сброс" || args[0] == "reset")
                {
                    settings.REPORT_CHAT_PEER_ID = 0;
                    Vk.MessagesSend("Чат репортов сброшен. Репорты будут отправляться администраторам в ЛС.");
                    return;
                }

                long peerId = long.Parse(args[0]);
                settings.REPORT_CHAT_PEER_ID = peerId;
                Vk.MessagesSend("Чат репортов установлен: " + peerId + "\nВсе уведомления о тикетах будут приходить сюда.");
                Vk.MessagesSend("✅ Чат репортов активирован.", 0, peerId);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
    }
}
