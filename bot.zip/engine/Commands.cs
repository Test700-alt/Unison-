﻿using Google.Protobuf.Collections;
using Google.Protobuf;
using Google.Protobuf.WellKnownTypes;
using GrandManager.engine.DataBaseClass;
using Microsoft.Extensions.DependencyInjection;
using MySqlX.XDevAPI.Common;
using Newtonsoft.Json.Linq;
using Org.BouncyCastle.Pkix;
using Org.BouncyCastle.Utilities;
using StackExchange.Redis;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Runtime.InteropServices;
using System.Security.AccessControl;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using static System.Net.Mime.MediaTypeNames;
using Newtonsoft.Json;
using QuickChart;
using static GrandManager.engine.MenuList;
using K4os.Compression.LZ4.Encoders;
using System.Text.Json.Serialization.Metadata;
using System.Globalization;
using System.Xml;
using System.Security.Policy;
using GrandManager.engine.cmds;
using GrandManager.engine.xenforo;
using System.Linq.Expressions;
using System.Drawing;
using static GrandManager.engine.Database;
using GrandManager.engine.properties;
using System.Diagnostics;
using Org.BouncyCastle.Pkcs;
using Org.BouncyCastle.Utilities.Encoders;
//using GrandManager.engine.SiteEngine;
using K4os.Compression.LZ4.Streams;
using Microsoft.Extensions.Logging.Abstractions;
using Universe.CpuUsage;
using System.Threading.Tasks.Dataflow;
using Org.BouncyCastle.Asn1.X509;
//using NsfwSpyNS;

namespace GrandManager.engine
{
    internal class Commands
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private Cache Cache;

        public Commands(vk vks, Database dbs, settings set, Cache cache)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            Cache = cache;
        }
        
        public async Task inviteConversation()
        {
            long inviter = Vk.m_from_id;
            long member_id = Vk.m_action.member_id;

            //var BanInfo = db.bansGetBan(Vk.m_peer_id, member_id);

            var userBotBan2 = db.BotBansGetBan(inviter);
            if (userBotBan2 != null)
            {
                if (userBotBan2["type_ban"] == "1")
                {

                    var kick = await Vk.KickUser(Vk.m_peer_id, inviter);
                    if (kick == null || kick["error"] != null)
                    {
                        string? result_data = Cache.Get<string>("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + inviter);
                        Cache.Set("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + inviter, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                        if (result_data != null && result_data != "")
                        {
                            long timed = 0;
                            try
                            {
                                timed = long.Parse(result_data);
                            }
                            catch
                            {

                            }
                            if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                            {
                                return;
                            }
                        }
                        string name_one = await Vk.GetUrlName(inviter, "nom");
                        Vk.MessagesSend(name_one + " находится в чёрном списке бота, но он имеет права администратора в самой конференции.<br><br>" +
                                "Обратите внимание, бот перевел эту беседу в статус 'не активирована'. Удали участника и активируйте беседу заново — /start.", 0);
                        db.peerDeactivate(Vk.m_peer_id);
                        return;
                    }
                    else
                    {
                        string? result_data = Cache.Get<string>("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + inviter);
                        Cache.Set("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + inviter, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                        if (result_data != null && result_data != "")
                        {
                            long timed = 0;
                            try
                            {
                                timed = long.Parse(result_data);
                            }
                            catch
                            {

                            }
                            if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                            {
                                return;
                            }
                        }
                        string name_one = await Vk.GetUrlName(inviter, "nom");
                        Vk.MessagesSend(name_one + " находится в чёрном списке бота, он(а) исключен(а) из соображений безопасности.<br><br>" +
                            "Обратите внимание, обратное добавление этого пользователя в беседу будет расценено как подозрительное действие," +
                            " приглашающий участник будет исключен.", 0);
                        return;
                    }
                }
            }

            if (member_id == -settings.GROUP_ID)
            {
                string keyb = Vk.GenerateKeyboard(new string[] { "НАЧАТЬ" }, new string[] { "start" }, new string[] { Vk.BUTTON_GREEN });
                string text = "Для активации необходимо выдать права администратора боту, затем нажать на зелёную кнопку 'Начать' или ввести команду '/старт' без ковычек.<br><br>" +
                    "Список команд: vk.com/@fink_manager-aktualnye-komandy<br>" +
                    "Как начать работу: vk.com/@fink_manager-aktualnye-komandy";

                Vk.MessagesSend(text, 0, 0, keyb);
                db.peersSetInviter(Vk.m_peer_id, inviter);
            }
            else
            {
                
                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);

                var BanInfo = db.bansGetBan(Vk.m_peer_id, member_id);

                var userBotBan = db.BotBansGetBan(member_id);
                if (userBotBan != null)
                {
                    if (userBotBan["type_ban"] == "1")
                    {

                        var kick = await Vk.KickUser(Vk.m_peer_id, member_id);
                        if (kick == null || kick["error"] != null)
                        {
                            string? result_data = Cache.Get<string>("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id);
                            Cache.Set("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                            if (result_data != null && result_data != "")
                            {
                                long timed = 0;
                                try
                                {
                                    timed = long.Parse(result_data);
                                }
                                catch
                                {

                                }
                                if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                                {
                                    return;
                                }
                            }
                            string name_one = await Vk.GetUrlName(member_id, "nom");
                            Vk.MessagesSend(name_one + " находится в чёрном списке бота, но он имеет права администратора в самой конференции.<br><br>" +
                                    "Обратите внимание, бот перевел эту беседу в статус 'не активирована'. Удали участника и активируйте беседу заново — /start.", 0);
                            db.peerDeactivate(Vk.m_peer_id);
                            return;
                        }
                        else
                        {
                            string? result_data = Cache.Get<string>("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id);
                            Cache.Set("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                            if (result_data != null && result_data != "")
                            {
                                long timed = 0;
                                try
                                {
                                    timed = long.Parse(result_data);
                                }
                                catch
                                {

                                }
                                if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                                {
                                    return;
                                }
                            }
                            string name_one = await Vk.GetUrlName(member_id, "nom");
                            Vk.MessagesSend(name_one + " находится в чёрном списке бота, он(а) исключен(а) из соображений безопасности.<br><br>" +
                                "Обратите внимание, обратное добавление этого пользователя в беседу будет расценено как подозрительное действие," +
                                " приглашающий участник будет исключен.", 0);
                            return;
                        }
                    }
                    else if (userBotBan["type_ban"] == "2" || userBotBan["type_ban"] == "3")
                    {
                        string? result_data = Cache.Get<string>("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id);
                        Cache.Set("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                        if (result_data != null && result_data != "")
                        {
                            long timed = 0;
                            try
                            {
                                timed = long.Parse(result_data);
                            }
                            catch
                            {

                            }
                            if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                            {
                                return;
                            }
                        }
                        string name_one = await Vk.GetUrlName(member_id, "nom");

                        Vk.MessagesSend(name_one + " находится в чёрном списке бота.<br><br>" +
                            "Обратите внимание, при дальнейшем нахождении этого пользователя в конференции — вы подвергаете свою беседу опасности, " +
                            "а бот не будет реагировать на команды данного пользователя.", 0);
                    }
                    else if (userBotBan["type_ban"] == "5")
                    {
                        string? result_data = Cache.Get<string>("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id);
                        Cache.Set("peer_invitefailbotban_" + Vk.m_peer_id.ToString() + "_" + member_id, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                        if (result_data != null && result_data != "")
                        {
                            long timed = 0;
                            try
                            {
                                timed = long.Parse(result_data);
                            }
                            catch
                            {

                            }
                            if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                            {
                                return;
                            }
                        }
                        string name_one = await Vk.GetUrlName(member_id, "nom");

                        Vk.MessagesSend(name_one + " находится в стоп-листе бота.<br><br>" +
                            "Указанный пользователь помечен как сливщик бесед.<br><br>Обратите внимание, при дальнейшем нахождении этого пользователя " +
                            "в конференции — вы подвергаете свою беседу опасности.<br><br>" +
                            "В целях предотвращения слива беседы у Пользователя ограничены некоторые команды.", 0);
                    }
                }


                if (BanInfo != null)
                {
                    var nick_user = db.peersGetNickUrl(Vk.m_peer_id, member_id);
                    string time_ban = "перманентно";
                    if (BanInfo["date_unban"] != "")
                    {
                        var ban_time = db.timeGetForMysql(BanInfo["date_unban"]);
                        time_ban = "до " + ban_time.ToString("g");
                        var time = db.timeGetForMysql(BanInfo["date_unban"]);
                        if (time.ToUnixTimeSeconds() <= DateTimeOffset.Now.ToUnixTimeSeconds())
                        {
                            db.bansDeleteBan(Vk.m_peer_id, member_id);
                            //return;
                            time_ban = "окончена " + ban_time.ToString("g");
                        }
                    }

                    string time_giveban = "неизвестно";
                    if (BanInfo["date_ban"] != "")
                    {
                        var ban_times = db.timeGetForMysql(BanInfo["date_ban"]);
                        time_giveban = ban_times.ToString("g");
                    }

                    var AdminNick = await Vk.GetUrlName(long.Parse(BanInfo["admin_id"]));
                    if (long.Parse(BanInfo["admin_id"]) < 0)
                    {
                        AdminNick = "[club" + BanInfo["admin_id"].Substring(1) + "|Сообщество]";
                    }

                    Vk.KickUser(Vk.m_peer_id, member_id);
                    string? result_data = Cache.Get<string>("peer_invitefailpeer_ban_" + Vk.m_peer_id.ToString());
                    Cache.Set("peer_invitefailpeer_ban_" + Vk.m_peer_id.ToString(), DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                    if (result_data != null && result_data != "")
                    {
                        long timed = 0;
                        try
                        {
                            timed = long.Parse(result_data);
                        }
                        catch
                        {

                        }
                        if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                        {
                            return;
                        }
                    }
                    string text = nick_user + " находится в списке заблокированных.<br><br>" +
                        "⚠ Заблокировал: " + AdminNick + "<br>" +
                        "🚫 Дата блокировки: " + time_giveban + "<br>" +
                        "🚫 Срок блокировки: " + time_ban + "<br>" +
                        "💬 Причина: " + BanInfo["reason"];
                    string targetIdText = (member_id <= 0) ? "club" + member_id.ToString().Substring(1) : $"id{member_id}";
                    var buttonsunban = Vk.GenerateKeyboard(new string[] { "Разблокировать" }, new string[] { "unban " + targetIdText }, new string[] { Vk.BUTTON_RED });
                    Vk.MessagesSend(text, 0, 0, buttonsunban);
                }

                if (PeerInfo["set_kickinviter"] != "0")
                {
                    var inviterData = db.peersGetMember(Vk.m_peer_id, inviter);
                    if (long.Parse(PeerInfo["set_inviterrole"]) > long.Parse(inviterData["priority"]))
                    {
                        Vk.KickUser(Vk.m_peer_id, member_id);
                        Vk.KickUser(Vk.m_peer_id, inviter);
                        string text = "У пригласившего пользователя недостаточно полномочий для добавления участников в беседу. Для настройки используйте /settings.";
                        Vk.MessagesSend(text, 0);
                        return;
                    }
                }
                if (PeerInfo.ContainsKey("group") && PeerInfo["group"] != "0")
                {
                    string method = "groups.isMember";
                    Dictionary<string, string> prams = new() { { "group_id", PeerInfo["group"] }, { "user_id", member_id.ToString() } };
                    var result = await Vk.VkAPI(method, prams);
                    if (result == null || result.ContainsKey("error") || !result.ContainsKey("response") || result["response"].ToString() == "0")
                    {
                        string? result_data = Cache.Get<string>("peer_invite_checkgroup_" + Vk.m_peer_id.ToString());
                        Cache.Set("peer_invite_checkgroup_" + Vk.m_peer_id.ToString(), DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                        if (result_data != null && result_data != "")
                        {
                            long timed = 0;
                            try
                            {
                                timed = long.Parse(result_data);
                            }
                            catch
                            {

                            }
                            if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                            {
                                return;
                            }
                        }
                        Vk.MessagesSend($"Приглашенный пользователь не состоит в [club{PeerInfo["group"]}|сообществе].", 0);
                        if (member_id > 0)
                        {
                            Vk.KickUser(Vk.m_peer_id, member_id);
                        }
                        return;
                    }
                }

                var memberInfo = db.peersGetMember(Vk.m_peer_id, member_id, true, true);

                if (memberInfo["leave_peer"] == "1")
                {
                    db.peersMemberSetLeavePeer(Vk.m_peer_id, member_id, "0");
                }

                if (memberInfo["invited_by"] != inviter.ToString())
                {
                    db.peersMemberSetInviter(Vk.m_peer_id, member_id, inviter);
                }


                if (PeerInfo["welcome_text"] != "0" && BanInfo == null)
                {
                    string? result_data = Cache.Get<string>("peer_invite_" + Vk.m_peer_id.ToString());
                    Cache.Set("peer_invite_" + Vk.m_peer_id.ToString(), DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                    if (result_data != null && result_data != "")
                    {
                        long timed = 0;
                        try
                        {
                            timed = long.Parse(result_data);
                        }
                        catch
                        {

                        }
                        if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                        {
                            return;
                        }
                    }

                    var resPlainFormat = TextFormatter.FromMarkdown("⚠ Приветствие, установленное администратором беседы ⚠<br><br>" + PeerInfo["welcome_text"]);
                    if (resPlainFormat == null)
                    {
                        Vk.MessagesSend("⚠ Приветствие, установленное администратором беседы ⚠<br><br>" + PeerInfo["welcome_text"], 0);
                        return;
                    }
                    else
                    {
                        Vk.MessagesSend(resPlainFormat.PlainText, 0, 0,"", true, "", resPlainFormat.FormatData.ToString());
                        return;
                    }
                    
                }


            }
            return;
        }

        public async Task kickConversation()
        {
            long admin = Vk.m_from_id;
            long member_id = Vk.m_action.member_id;
            if (member_id == -settings.GROUP_ID)
            {
                //string keyb = Vk.GenerateKeyboard(new string[] { "НАЧАТЬ" }, new string[] { "start" }, new string[] { Vk.BUTTON_GREEN });
                //Console.WriteLine(keyb);
                //Vk.MessagesSend("Для активации необходимо выдать права администратора боту, затем нажать на зелёную кнопку 'Начать' или ввести команду '/старт' без ковычек", 0, 0, keyb);
            }

            //peersMemberSetLeavePeer
            var Target_User = db.peersGetMember(Vk.m_peer_id, member_id);
            try
            {
                if (Target_User["leave_peer"] == "0")
                {
                    db.peersMemberSetLeavePeer(Vk.m_peer_id, member_id, "1");
                }
            }
            catch
            {

            }
            

            try
            {
                var warns_database = db.peerGetWarnsList(Vk.m_peer_id, member_id, false, 3);
                if (warns_database != null)
                {
                    foreach (var item in warns_database)
                    {
                        if (item.deleted != 1)
                        {
                            db.peerWarnsDeleteWarn((int)item.id);
                        }

                    }
                    db.peerMembersSetWarns(Vk.m_peer_id, member_id, 0);
                }
            }
            catch
            {

            }
            

            var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
            try
            {
                if (PeerInfo["group"] != "0" && PeerInfo["set_kickexitgroup"] != "0" && PeerInfo["access_token"] != "")
                {
                    var method = "groups.removeUser";
                    var parames = new Dictionary<string, string>();
                    parames.Add("group_id", PeerInfo["group"]);
                    parames.Add("user_id", member_id.ToString());
                    parames.Add("access_token", SysUtils.DecryptString(PeerInfo["access_token"]));
                    var JObject = await Vk.VkAPIs(method, parames);
                    if (!JObject.ContainsKey("response") || JObject.ContainsKey("error"))
                    {
                        if (JObject.ContainsKey("error"))
                        {
                            if (JObject["error"]["error_code"] != null)
                            {
                                var code = JObject["error"]["error_code"];
                                if (code.ToString() == "5")
                                {
                                    Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен, " +
                                        "поэтому он был отвязан от беседы.");
                                }
                            }
                        }
                        db.peersSetAccessToken(Vk.m_peer_id, "");
                    }
                }
            }
            catch
            {

            }

            string text = "";
            if (member_id == Vk.m_from_id)
            {
                string nickname = "Пользователь";

                if (Target_User != null)
                {
                    nickname = db.peersGetNickUrl(Vk.m_peer_id, member_id);
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = $"[public{Vk.m_from_id.ToString().Substring(1)}|Сообщество]";
                    }
                    else
                    {
                        nickname = $"[id{Vk.m_from_id}|Пользователь]";
                    }
                }

                text = text + nickname + " вышел из конференции.";
                Vk.MessagesSend(text, 0);

                
                if (PeerInfo["owner"] != member_id.ToString())
                {
                    try
                    {
                        if (PeerInfo["set_kickexit"] != "0" || PeerInfo["set_kickexitrole"] != "0")
                        {
                            var memberData = db.peersGetMember(Vk.m_peer_id, member_id);
                            long priority = long.Parse(memberData["priority"]);
                            if (priority != 0)
                            {
                                if (PeerInfo["set_kickexitrole"] != "0")
                                {
                                    Vk.KickUser(Vk.m_peer_id, member_id);
                                    if (priority != 100)
                                    {
                                        db.peersMemberSetPriority(Vk.m_peer_id, member_id, 0);
                                    }
                                    
                                    if (PeerInfo["set_exitremovenick"] == "1")
                                    {
                                        db.peersMemberSetNickName(Vk.m_peer_id, member_id, null);
                                    }
                                    
                                    //return;
                                }
                            }
                            else
                            {
                                if (PeerInfo["set_kickexit"] != "0")
                                {
                                    Vk.KickUser(Vk.m_peer_id, member_id);
                                    if (PeerInfo["set_exitremovenick"] == "1")
                                    {
                                        db.peersMemberSetNickName(Vk.m_peer_id, member_id, null);
                                    }
                                    //return;
                                }
                            }
                        }
                    }
                    catch
                    {

                    }
                    
                    try
                    {
                        
                        if (Target_User != null && Target_User["mute"] != "")
                        {
                            db.peersMemberSetMute(Vk.m_peer_id, member_id, "");
                            text = "⚠ У " + nickname + " была блокировка чата, она автоматически снята.<br><br>";
                            Vk.MessagesSend(text, 0);
                        }
                        
                    }
                    catch
                    {

                    }

                    
                    //return;
                }

                //db.peersMemberSetNickName(Vk.m_peer_id, member_id, null);


            }
            return;
        }

        public bool systemMute(Dictionary<string, string> user_info)
        {
            if (user_info == null || !user_info.ContainsKey("mute"))
            {
                return false;
            }
            if (user_info["mute"] != "" && user_info["mute"] != null)
            {
                if (long.Parse(user_info["priority"]) >= 100)
                {
                    return false;
                }
                var muteDate = db.timeGetForMysql(user_info["mute"]).ToUnixTimeSeconds();
                var current_time = DateTimeOffset.Now.ToUnixTimeSeconds();//DateTime.Now.ToUniversalTime();
                if (muteDate > current_time)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo.ContainsKey("set_typemute") && PeerInfo["set_typemute"] == "1")
                    {
                        Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                    }
                    else
                    {
                        vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                    }
                    return true;
                    //cmd.systemMute();
                }
                else
                {
                    db.peersMemberSetMute(Vk.m_peer_id, Vk.m_from_id, "");
                    return false;
                }
            }
            return false;
        }

        public async Task<bool> handler_menu(long menu)
        {
            Vk.m_text = Vk.m_text.Replace("'", "");
            Vk.m_text = Vk.m_text.Replace("\"", "");

            botban banms = new(Vk, db, settings);

            var target = await banms.checkBotBan();
            if (target)
            {
                return false;
            }

            if (settings.isUserChat(Vk.m_peer_id))
            {
                ls_cmds checked_user = new ls_cmds(Vk, db, settings, Cache);
                return checked_user.handler_menu(menu);
            }

            Vk.m_text = Vk.m_text.Replace("\n", " ");
            Vk.m_text = Vk.m_text.Replace("\r", " ");
            Vk.m_text = Vk.m_text.Replace("<br>", " ");

            owner_cmds owner_cmds = new owner_cmds(Vk, db, settings, Cache);
            switch (menu)
            {
                case (int)MenuList.ListMenu.SETUP_MAIN:
                    owner_cmds.command_setup(menu);
                    return true;
                    break;
                case (int)MenuList.ListMenu.SETUP_STEP2:
                    owner_cmds.command_settings_set(menu);
                    return true;
                case (int)MenuList.ListMenu.SETUP_STEP3:
                    owner_cmds.command_settings_set(menu);
                    return true;
                case (int)MenuList.ListMenu.MENU_EDITUNITY_SETNAME:
                    owner_cmds.command_editunity_name(menu);
                    return true;
                case (int)MenuList.ListMenu.MENU_EDITUNITY_SETDESCRIPTION:
                    owner_cmds.command_editunity_desc(menu);
                    return true;
                case (int)ListMenu.MENU_EDITCMD:
                    owner_cmds.command_editcmd(menu);
                    return true;
                case (int)ListMenu.MENU_GEDITCMD:
                    owner_cmds.command_geditcmd(menu);
                    return true;
                default:
                    return false;
                    break;
            }

            return true;
        }

        public async Task<bool> handler_command()
        {
            try
            {
                Vk.m_text = Vk.m_text.Replace("'", "");
                Vk.m_text = Vk.m_text.Replace("\"", "");

                Vk.m_text_origin = Vk.m_text;
                Vk.m_text = Vk.m_text.Replace("<br>", " ");

                string? text = Vk.m_text;
                string lowercase = "";

                string[] parames;

                string[] parames_low;

                string command = "";
                if (text != "")
                {
                    lowercase = text.ToLower();
                    parames = text.Split(" ");
                    parames_low = lowercase.Split(" ");
                    if (parames_low.Length >= 1 && parames_low.Count() >= 1)
                    {
                        if (parames_low[0].Length >= 1)
                        {
                            command = parames_low[0].Substring(1);
                        }
                        else
                        {
                            command = parames_low[0];
                        }
                    }
                    else
                    {
                        command = lowercase;
                    }
                    // yesyse
                }

                if(!Program.is_pot && Vk.m_from_id != 251372816 && Vk.m_from_id != 549678497)
                {
                    return false;
                }

                var userInfoGlobal = db.usersGetUser(Vk.m_from_id);

                /*if ((Vk.m_peer_id >= 1 && Vk.m_peer_id < 1.9e9) || (Vk.m_peer_id >= 200e9 && Vk.m_peer_id < 100e10))
                {
                    if (userInfoGlobal["accept_ls"] != "1")
                    {
                        db.gameSetAcceptLs(Vk.m_from_id, 1);
                    }
                    ls_cmds checked_userr = new ls_cmds(Vk, db, settings, Cache);
                    return checked_userr.CheckCmd(text);
                }*/

                if (settings.isUserChat(Vk.m_peer_id))
                {
                    if (userInfoGlobal["accept_ls"] != "1")
                    {
                        db.gameSetAcceptLs(Vk.m_from_id, 1);
                    }
                    ls_cmds checked_userr = new ls_cmds(Vk, db, settings, Cache);
                    return await checked_userr.CheckCmd(text);
                }

                
                Vk.m_text = Vk.m_text.Replace("\n", " ");
                Vk.m_text = Vk.m_text.Replace("\r", " ");

                Dictionary<string, string>? peer_info = db.peersGetPeer(Vk.m_peer_id);
                

                user_cmds user_commands = new user_cmds(Vk, db, settings);

                //Console.WriteLine($"[cmd] {command} — attachments: " + Vk.m_attachments.Count());

                if (command == "start" || command == "старт" || command == "начать" || command == "запустить")
                {
                    // АКТИВАЦИЯ КФ
                    user_commands.command_start();
                    return true;
                }

                if (command == "ping" || command == "пинг" || command == "статус" || command == "status" || command == "test" || command == "тест")
                {
                    user_commands.command_ping();
                    return true;
                }

                if (peer_info["active"] is not null and "0")
                {
                    return false;
                }
                Dictionary<string, string>? member_info = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (peer_info["silence"] != "0" && member_info["priority"] == "0")
                {
                    if (peer_info["silence"] == "1")
                    {
                        Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                    }
                    else
                    {
                        vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                    }
                }

                if (!await check_filters(peer_info, text, member_info))
                {
                    return false;
                }
                
                if (text == "")
                {
                    return false;
                }
                //EmojiCount
                if (lowercase.Length <= 0)
                {
                    return false;
                }

                // Обработка активных сессий настройки БД (без необходимости префикса)
                if (DbSetupCmds.HasActiveSession(Vk.m_from_id))
                {
                    // Убираем префикс если есть (/, !, +, -)
                    string sessionText = text;
                    if (lowercase.Length > 0 && (lowercase[0] == '!' || lowercase[0] == '/' || lowercase[0] == '+' || lowercase[0] == '-'))
                        sessionText = text.Length > 1 ? text.Substring(1) : "";

                    bool handled = await DbSetupCmds.HandleDbSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id, sessionText);
                    if (handled) return true;
                    handled = await DbSetupCmds.HandleMappingSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id, sessionText);
                    if (handled) return true;
                    handled = await DbSetupCmds.HandleCommandSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id, sessionText);
                    if (handled) return true;
                }

                // Обработка активных сессий настройки форума (XenForo)
                if (ForumCmds.HasActiveSession(Vk.m_from_id))
                {
                    string sessionText = text;
                    if (lowercase.Length > 0 && (lowercase[0] == '!' || lowercase[0] == '/' || lowercase[0] == '+' || lowercase[0] == '-'))
                        sessionText = text.Length > 1 ? text.Substring(1) : "";

                    var handled = await ForumCmds.HandleForumSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id, sessionText);
                    if (handled) return true;
                }

                if (lowercase[0] != '!' && lowercase[0] != '/' && lowercase[0] != '+' && lowercase[0] != '-')
                {
                    return false;
                }
                owner_cmds owner_cmds = new owner_cmds(Vk, db, settings, Cache);
                helper_cmds helper_cmds = new helper_cmds(Vk, db, settings);
                moder_cmds moder_cmds = new moder_cmds(Vk, db, settings);
                admin_cmds admin_cmds = new admin_cmds(Vk, db, settings);
                gladmin_cmds gladmin_cmds = new gladmin_cmds(Vk, db, settings);
                ls_cmds checked_user = new ls_cmds(Vk, db, settings, Cache);
                var vips_cmds = new vips_cmds(Vk, db, settings);
                // -------------------------- ОБРАБОТЧИК КОМАНД ПОЛЬЗОВАТЕЛЯ
                switch (command)
                {
                    case "zudilov":
                        user_commands.command_test();
                        //syncAllPeers(db);
                        return true;
                    case "quit":
                    case "q":
                    case "выйти":
                        user_commands.command_quit();
                        return true;
                    case "ping":
                    case "пинг":
                    case "статус":
                    case "status":
                    case "test":
                    case "тест":
                    case "joke":
                        user_commands.command_ping();
                        return true;
                    case "gc":
                        user_commands.command_gc();
                        return true;
                    case "cmds":
                    case "help":
                    case "команды":
                    case "помощь":
                    case "хелп":
                    case "рудз":
                    case "gjvjom":
                        user_commands.command_help();
                        return true;
                    case "try":
                    case "попытка":
                        user_commands.command_try();
                        return true;
                    case "kiss":
                    case "поцелуй":
                    case "поцеловать":
                        user_commands.command_kiss();
                        return true;
                    case "админы":
                    case "admins":
                    case "staff":
                    case "стаф":
                    case "стафф":
                        user_commands.command_staff();
                        return true;
                    // РП КОМАНДЫ
                    case "обнять":
                        user_commands.command_obnyat();
                        return true;
                    case "погладить":
                        return true;
                    case "убить":
                        return true;
                    case "изнасиловать":
                    case "надругаться":
                    case "трахнуть":
                    case "трах":
                    case "iznas":
                        user_commands.command_iznas();
                        return true;
                    case "минет":
                    case "миньет":
                    case "отсос":
                    case "minet":
                    case "отсосать":
                        user_commands.command_minet();
                        return true;
                    case "mtop":
                    case "мтоп":
                    case "топсообщений":
                        user_commands.command_mtop();
                        return true;
                    case "online":
                    case "онлайн":
                        user_commands.command_online();
                        return true;
                    case "правила":
                    case "rules":
                        user_commands.command_rules();
                        return true;
                        // VIP команды пользователей
                    case "скажи":
                    case "voice":
                        user_commands.command_voice();
                        return true;
                    case "sban":
                    case "сбан":
                        user_commands.command_sban();
                        return true;

                    // ===== КОМАНДЫ БД =====
                    case "подключить":
                    case "подкл":
                    case "dbconnect":
                    case "connect":
                    case "dbsetup":
                        DbSetupCmds.StartDbSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id);
                        return true;
                    case "dbsetup_cancel":
                        DbSetupCmds.CancelDbSetup(Vk, Vk.m_peer_id, Vk.m_from_id);
                        return true;
                    case "маппинг":
                    case "таблица":
                    case "mapping":
                    case "dbmap":
                    case "table":
                        DbSetupCmds.StartMappingSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id);
                        return true;
                    case "создать":
                    case "новаякоманда":
                    case "createcmd":
                    case "newcommand":
                        DbSetupCmds.StartCommandSetup(Vk, db, Vk.m_peer_id, Vk.m_from_id);
                        return true;
                    case "dbстатус":
                    case "dbstatus":
                    case "dbстата":
                        DbSetupCmds.ShowDbStatus(Vk, db, Vk.m_peer_id);
                        return true;
                    case "dbкоманды":
                    case "dbcommands":
                    case "dbсписок":
                        DbSetupCmds.ShowCommandsList(Vk, db, Vk.m_peer_id);
                        return true;
                    case "dbпомощь":
                    case "dbhelp":
                    case "dbхелп":
                    case "dbсправка":
                        DbSetupCmds.ShowDbHelp(Vk, Vk.m_peer_id);
                        return true;
                    case "удалить_кмд":
                    case "удалитькмд":
                    case "delcmd":
                    case "deletecmd":
                        {
                            string[] delParts = text.Split(" ");
                            string cmdName = delParts.Length > 1 ? delParts[1].ToLower() : "";
                            if (string.IsNullOrEmpty(cmdName))
                            {
                                Vk.MessagesSend("⚠️ Использование: !удалить_кмд [имя]", 0, Vk.m_peer_id);
                                return true;
                            }
                            DbSetupCmds.DeleteCommand(Vk, db, Vk.m_peer_id, Vk.m_from_id, cmdName);
                            return true;
                        }

                    // === XENFORO COMMANDS ===
                    case "xfsetup":
                    case "форумнастроить":
                    case "forums":
                        ForumCmds.StartSetup(Vk, Vk.m_peer_id, Vk.m_from_id);
                        return true;

                    default:
                        //return false;
                        break;
                }

                // === CHECK FORUM COMMANDS (after switch) ===
                if (settings.isPeer(Vk.m_peer_id))
                {
                    var memberInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                    bool isAdmin = memberInfo != null && memberInfo["priority"] != "0";

                    var forumHandled = await ForumCmds.HandleForumCommand(
                        Vk, db, Vk.m_peer_id, Vk.m_from_id, text, isAdmin);
                    if (forumHandled) return true;
                }

                user_commands = null;
                // -------------------------- ОБРАБОТЧИК КОМАНД ПОМОЩНИКА
                

                switch (command)
                {
                    //стата/статистика/stats/statistic
                    case "стата":
                    case "статистика":
                    case "stats":
                    case "statistic":
                    case "getstats":
                    case "getstat":
                        helper_cmds.command_stats();
                        return true;
                    case "mute":
                    case "мут":
                    case "заткнуть":
                    case "затычка":
                        helper_cmds.command_mute();
                        return true;
                    //унмут/разоткнуть/unmute
                    case "унмут":
                    case "разоткнуть":
                    case "unmute":
                        helper_cmds.command_unmute();
                        return true;
                    case "kick":
                    case "лшсл":
                    case "кик":
                    case "kic":
                    case "исключить":
                        helper_cmds.command_kick();
                        return true;
                    case "пред":
                    case "предупредить":
                    case "предупреждение":
                    case "варн":
                    case "warn":
                    case "ghtl":
                    case "цфкт":
                    case "dfhy":
                        helper_cmds.command_warn();
                        return true;
                    case "снятьпред":
                    case "унварн":
                    case "unwarn":
                        helper_cmds.command_unwarn();
                        return true;
                    case "предупреждения":
                    case "getwarns":
                    case "getwarn":
                    case "warns":
                        //case "warnhistory":
                        helper_cmds.command_getwarn();
                        return true;
                    case "историяварнов":
                    case "warnhistory":
                    case "historywarn":
                        helper_cmds.command_warnhistory();
                        return true;
                    case "listwarn":
                    case "listwarns":
                    case "warnlist":
                    case "warnslist":
                    case "warnmans":
                    case "преды":
                    case "предупрждения":
                        helper_cmds.command_warnlist();
                        return true;
                    case "чатинфо":
                    case "очате":
                    case "инфо":
                    case "chatinfo":
                    case "info":
                        helper_cmds.command_chatinfo();
                        return true;
                    case "getban":
                    case "гетбан":
                    case "baninfo":
                        helper_cmds.command_getban();
                        return true;
                    case "ник":
                    case "гник":
                    case "gnick":
                    case "getnick":
                        helper_cmds.command_getnick();
                        return true;
                    case "сник":
                    case "snick":
                    case "setnick":
                        helper_cmds.command_setnick();
                        return true;
                    case "рник":
                    case "rnick":
                    case "removenick":
                        helper_cmds.command_removenick();
                        return true;
                    case "нлист":
                    case "nlist":
                    case "nicklist":
                    case "nicknames":
                        helper_cmds.command_nicknames();
                        return true;
                    case "безников":
                    case "nonames":
                        helper_cmds.command_nonames();
                        return true;
                    case "checknicks":
                    case "checknick":
                    case "syncnicks":
                    case "syncnick":
                        helper_cmds.command_checknicks();
                        return true;
                    case "вызов":
                    case "зов":
                    case "zov":
                        helper_cmds.command_zov();
                        return true;
                    case "reg":
                    case "datereg":
                    case "created":
                    case "register":
                    case "рег":
                        helper_cmds.command_reg();
                        return true;
                    case "logs":
                    case "логи":
                    case "история":
                        helper_cmds.command_logs();
                        return true;
                    case "упоминать":
                    case "неупоминать":
                    case "nomention":
                    case "mention":
                        helper_cmds.command_notmentions();
                        return true;
                    default:
                        break;
                }

                helper_cmds = null;
                // -------------------------- ОБРАБОТЧИК КОМАНД МОДЕРАТОРА
                
                switch (command)
                {
                    case "бан":
                    case "блок":
                    case "ban":
                    case "ифт":
                    case "заблокировать":
                    case "блокировать":
                        moder_cmds.command_ban();
                        return true;
                    case "унбан":
                    case "разбан":
                    case "унблок":
                    case "unban":
                    case "гтифт":
                    case "разблокировать":
                        moder_cmds.command_unban();
                        return true;
                    case "помощник":
                    case "хелпер":
                    case "addhelper":
                    case "helper":
                        moder_cmds.command_addhelper();
                        return true;
                    case "role":
                    case "роль":
                    case "giverole":
                    case "setrole":
                        moder_cmds.command_setrole();
                        return true;
                    case "removerole":
                    case "rr":
                    case "снять":
                    case "снятьроль":
                        moder_cmds.command_removerole();
                        return true;
                    case "roles":
                    case "роли":
                    case "rolelist":
                    case "listrole":
                        moder_cmds.command_roles();
                        return true;
                    case "тишина":
                    case "silence":
                        moder_cmds.command_silence();
                        return true;
                    case "gremoverole":
                    case "grr":
                        moder_cmds.command_gremoverole();
                        return true;
                    case "banlist":
                    case "bans":
                    case "listban":
                        moder_cmds.command_banlist();
                        return true;
                    case "понику":
                    case "getbynick":
                        moder_cmds.command_getbynick();
                        return true;
                    case "gzov":
                    case "гзов":
                    case "гвызов":
                        moder_cmds.command_gzov();
                        return true;
                    case "gzovu":
                        moder_cmds.command_gzovu();
                        return true;
                    case "gkick":
                    case "гкик":
                        moder_cmds.command_gkick();
                        return true;
                    case "checkpublic":
                        moder_cmds.command_checkpublic();
                        return true;
                    case "gsnick":
                    case "гсник":
                    case "gsetnick":
                        moder_cmds.command_gsetnick();
                        return true;
                    case "grnick":
                    case "грник":
                    case "gremovenick":
                        moder_cmds.command_gremovenick();
                        return true;
                    default:
                        break;
                }

                moder_cmds = null;
                // -------------------------- ОБРАБОТЧИК КОМАНД АДМИНИСТРАТОРА
                
                switch (command)
                {
                    case "gsysrole":
                    case "гсусроль":
                        admin_cmds.command_gsyssetrole();
                        return true;
                    //grole/гроль/ggiverole/gsetrole
                    case "grole":
                    case "гроль":
                    case "ggiverole":
                    case "gsetrole":
                        admin_cmds.command_gsetrole();
                        return true;
                    // !гпомощник/гхелпер/ghelper/gaddhelper
                    case "гпомощник":
                    case "гхелпер":
                    case "ghelper":
                    case "gaddhelper":
                        admin_cmds.command_ghelper();
                        return true;
                    case "гмодер":
                    case "гмодератор":
                    case "gmoder":
                        admin_cmds.command_gmoder();
                        return true;
                    // !модер/модератор/moder
                    case "модер":
                    case "модератор":
                    case "moder":
                    case "addmoder":
                        admin_cmds.command_moder();
                        return true;
                    // !gban/gblock/гбан
                    case "gban":
                    case "globalban":
                    case "гбан":
                    case "gblock":
                        admin_cmds.command_gban();
                        return true;
                    //!gunban/gunblock/гунбан
                    case "gunban":
                    case "gunblock":
                    case "гунбан":
                        admin_cmds.command_gunban();
                        return true;
                    case "del":
                    case "delete":
                    case "удалить":
                        admin_cmds.command_delete();
                        return true;
                    case "gm":
                    case "rgm":
                    case "removegm":
                    case "delgm":
                    case "ungm":
                    case "гм":
                    case "gamemode":
                    case "неуязвимость":
                    case "иммунитет":
                        admin_cmds.command_gm();
                        return true;
                    //!gms/gamemodes/гмс/иммунитеты/неуязвимости
                    case "gms":
                    case "gamemodes":
                    case "гмс":
                    case "иммунитеты":
                    case "неуязвимости":
                        admin_cmds.command_gms();
                        return true;
                    case "filter":
                    case "filters":
                    case "фильтр":
                    case "фильтры":
                        admin_cmds.command_filters();
                        return true;
                    case "filteradd":
                    case "фильтрдобавить":
                        admin_cmds.command_filteradd();
                        return true;
                    case "filterdel":
                    case "фильтрудалить":
                        admin_cmds.command_filterdel();
                        return true;
                    case "filteredit":
                    case "фильтрредактировать":
                        admin_cmds.command_filteredit();
                        return true;
                    default:
                        break;
                }

                admin_cmds = null;
                // -------------------------- ОБРАБОТЧИК КОМАНД ГЛАВНОГО АДМИНИСТРАТОРА
                
                switch (command)
                {
                    
                    case "inactive":
                    case "неактив":
                        gladmin_cmds.command_inactive();
                        return true;
                    case "pin":
                    case "закрепить":
                        gladmin_cmds.command_pin();
                        return true;
                    case "unpin":
                    case "открепить":
                        gladmin_cmds.command_unpin();
                        return true;
                    //!admin/админ/addadmin
                    case "admin":
                    case "админ":
                    case "addadmin":
                        gladmin_cmds.command_addadmin();
                        return true;
                    case "gadmin":
                    case "gaddadmin":
                    case "гадмин":
                        gladmin_cmds.command_gadmin();
                        return true;
                    case "newrole":
                        gladmin_cmds.command_newrole();
                        return true;
                    case "gnewrole":
                        gladmin_cmds.command_gnewrole();
                        return true;
                    case "deleterole":
                    case "delrole":
                    case "drole":
                        gladmin_cmds.command_deleterole();
                        return true;
                    case "gdeleterole":
                    case "gdelrole":
                    case "gdrole":
                        gladmin_cmds.command_gdeleterole();
                        return true;
                    case "welcome":
                    case "приветствие":
                        gladmin_cmds.command_welcome();
                        return true;
                    case "group":
                    case "setgroup":
                    case "setpublic":
                    case "public":
                        gladmin_cmds.command_setpublic();
                        return true;
                    case "kickgroup":
                        gladmin_cmds.command_kickgroup();
                        return true;
                    case "setrules":
                    case "srules":
                    case "установитьправила":
                        gladmin_cmds.command_setrules();
                        return true;
                    default:
                        break;
                }

                gladmin_cmds = null;
                // -------------------------- ОБРАБОТЧИК КОМАНД ВЛАДЕЛЬЦА
                

                switch (command)
                {
                    case "setup":
                        owner_cmds.command_setup();
                        return true;
                    case "настройки":
                    case "settings":
                        owner_cmds.command_settings();
                        return true;
                    case "settingsinvite":
                        owner_cmds.command_settings_invite();
                        return true;
                    case "setsettings":
                        owner_cmds.command_settings_set();
                        return true;
                    case "sync":
                    case "синхронизировать":
                    case "resync":
                        owner_cmds.command_sync();
                        return true;
                    case "unity":
                    case "unityinfo":
                    case "infounity":
                        owner_cmds.command_unity();
                        return true;
                    case "unites":
                    case "unitylist":
                    case "listunity":
                        owner_cmds.command_unites();
                        return true;
                    case "addunity":
                    case "pool":
                    case "addpool":
                    case "poll":
                    case "pull":
                    case "addpull":
                        owner_cmds.command_addunity();
                        return true;
                    case "removeunity":
                    case "runity":
                        owner_cmds.command_removeunity();
                        return true;
                    case "createunity":
                        owner_cmds.command_createunity();
                        return true;
                    case "editunity":
                        owner_cmds.command_editunity();
                        return true;
                    case "deleteunity":
                    case "delunity":
                        owner_cmds.command_deleteunity();
                        return true;
                    case "spec":
                    case "glav":
                    case "gladmin":
                    case "glavadmin":
                    case "гладмин":
                    case "глав":
                    case "спец":
                    case "addspec":
                    case "addglav":
                    case "addglavadmin":
                    case "lead":
                    case "addlead":
                        owner_cmds.command_addspec();
                        return true;
                    case "gspec":
                    case "gaddspec":
                    case "gglav":
                    case "ggladmin":
                    case "gglavadmin":
                    case "гглав":
                    case "ггадмин":
                    case "glead":
                    case "gaddlead":
                        owner_cmds.command_gaddspec();
                        return true;
                    //wipe/вайп [warns/bans/roles]
                    case "wipe":
                    case "вайп":
                    case "очистить":
                        owner_cmds.command_wipe();
                        return true;
                    case "migration":
                    case "миграция":
                        owner_cmds.command_migration();
                        return true;
                    case "games":
                    case "игры":
                        owner_cmds.command_games();
                        return true;
                    case "editcmd":
                    case "ecmd":
                        owner_cmds.command_editcmd();
                        return true;
                    case "geditcmd":
                    case "gecmd":
                        owner_cmds.command_geditcmd();
                        return true;
                    case "уведы":
                    case "уведомления":
                    case "mentions":
                        owner_cmds.command_mentions();
                        return true;
                    case "owner":
                    case "владелец":
                        owner_cmds.command_owner();
                        return true;
                    case "addowner":
                        owner_cmds.command_addowner();
                        return true;
                    case "whitelinks":
                    case "whitelistlinks":
                    case "whitelink":
                        owner_cmds.command_whitelistlinks();
                        return true;
                    case "addlink":
                    case "createlink":
                        owner_cmds.command_addlink();
                        return true;
                    case "removelink":
                    case "dellink":
                    case "deletelink":
                        owner_cmds.command_removelink();
                        return true;
                    // СИСТЕМНЫЕ
                    case "editunityname":
                        owner_cmds.command_editunity_name(0);
                        return true;
                    case "editunitydesc":
                        owner_cmds.command_editunity_desc(0);
                        return true;
                    case "settingsfilter":
                        owner_cmds.command_settings_filter();
                        return true;
                    case "setroleinviter":
                        owner_cmds.command_setroleinviter();
                        return true;
                    case "peertoken":
                        owner_cmds.command_peertoken();
                        return true;
                    default:
                        break;
                }

                owner_cmds = null;
                // -------------------------- ОБРАБОТЧИК КОМАНД VIP

                switch (command)
                {
                    //эмодзи/emoji
                    case "эмодзи":
                    case "emoji":
                        vips_cmds.command_emoji();
                        return true;
                    case "рольэмодзи":
                    case "erole":

                        return true;
                    case "никэмодзи":
                    case "enick":
                        vips_cmds.command_enick();
                        return true;
                    default:
                        break;
                }

                // Проверка пользовательских команд БД (перед последним fallback)
                if (settings.isPeer(Vk.m_peer_id))
                {
                    var dbCmd = DbSetupCmds.FindCommand(db, Vk.m_peer_id, command);
                    if (dbCmd != null)
                    {
                        string[] parames_cmd = text.Split(" ");
                        string nick = parames_cmd.Length > 1 ? parames_cmd[1] : "";
                        string val = parames_cmd.Length > 2 ? string.Join(" ", parames_cmd, 2, parames_cmd.Length - 2) : "";

                        if (string.IsNullOrEmpty(nick))
                        {
                            bool rv = dbCmd["requires_value"]?.ToString() == "1";
                            string usage = rv ? $"!{command} [ник] [значение]" : $"!{command} [ник]";
                            Vk.MessagesSend($"⚠️ Использование: {usage}", 0, Vk.m_peer_id);
                            return true;
                        }

                        var creds = DbSetupCmds.LoadCreds(db, Vk.m_peer_id);
                        if (creds == null)
                        {
                            Vk.MessagesSend("❌ БД не подключена.", 0, Vk.m_peer_id);
                            return true;
                        }

                        try
                        {
                            string tableName = dbCmd["table_name"]?.ToString() ?? "";
                            string searchColumn = dbCmd["search_column"]?.ToString() ?? "";
                            string targetColumn = dbCmd["target_column"]?.ToString() ?? "";
                            bool requiresValue = dbCmd["requires_value"]?.ToString() == "1";

                            string targetValue = requiresValue ? val : targetColumn;
                            int affected = await dbtools.QueryExecutor.ExecuteUpdate(
                                Vk.m_peer_id, creds, tableName, searchColumn, nick, targetColumn, targetValue);

                            if (affected == 0)
                            {
                                Vk.MessagesSend($"⚠️ Игрок «{nick}» не найден.", 0, Vk.m_peer_id);
                                return true;
                            }

                            string msg = requiresValue
                                ? $"✅ {dbCmd["description"]}\n\nИгрок: {nick}\nЗначение: {val}\nЗатронуто: {affected}"
                                : $"✅ {dbCmd["description"]}\n\nИгрок: {nick}\nЗатронуто: {affected}";

                            Vk.MessagesSend(msg, 0, Vk.m_peer_id);

                            // Логирование
                            db.executeQuery(
                                "INSERT INTO command_logs (peer_id, user_id, command_name, search_value, target_value, affected_rows) VALUES (?, ?, ?, ?, ?, ?)",
                                Vk.m_peer_id, Vk.m_from_id, command, nick, val, affected);
                        }
                        catch (Exception ex)
                        {
                            Vk.MessagesSend($"❌ Ошибка: {ex.Message}", 0, Vk.m_peer_id);
                        }
                        return true;
                    }
                }

                return await checked_user.CheckCmd(command);
                //return true;
            }
            catch (Exception ex)
            {
                AdminInfo.AddErrorList("Ошибка обработки команды в COMMANDS", "Дата: " + DateTimeOffset.Now.ToString("G") + "<br>" +
                    "Vk TEXT: " + Vk.m_text + " <br>Error: " + ex.Message + "<br>HelpLink:" + ex.HelpLink + "<br>StackTrace" + ex.StackTrace);
                return true;
            }
        }

        public async Task<bool>check_filters(Dictionary<string, string>peer_info, string text, Dictionary<string, string>member_info)
        {

            /* УДАЛЁННЫЕ ОПАСНЫЕ КОМАНДЫ */

            /*ANTIFLOOD BOT*/
            if (member_info["priority"] == "0")
            {

                Task.Run(async () => {
                    checkAntiFloodBotInPeer(db, new Cache(), Vk, peer_info);
                });
            }

            if (Vk.m_attachments != null && Vk.m_attachments.Count() >= 1 && peer_info["set_kickphotos"] != "0" && member_info["priority"] == "0" && Vk.m_from_id != settings.GROUP_ID * -1)
            {
                var attachments = Vk.m_attachments;

                foreach (var item in attachments)
                {
                    if (item["type"].ToString() == "photo")
                    {
                        if (peer_info["set_kickphotos"] == "2")
                        {
                            Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                            var url = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                            Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " был исключен за отправку фотографий в чат.", 0, 0);
                        }
                        else
                        {
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                        }

                        return false;
                    }
                }
            }


            if (Vk.m_attachments != null && Vk.m_attachments.Count() >= 1 && peer_info["set_kickposts"] != "0" && member_info["priority"] == "0" && Vk.m_from_id != settings.GROUP_ID * -1)
            {
                var attachments = Vk.m_attachments;
                foreach (var item in attachments)
                {
                    if (item["type"].ToString() == "wall")
                    {
                        if (peer_info["set_kickposts"] == "2")
                        {
                            Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                            var url = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                            Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " был исключен за отправку постов в чат.", 0, 0);
                        }
                        else
                        {
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                        }
                        return false;
                    }
                }
            }

            try
            {
                if (Vk.m_attachments != null && Vk.m_attachments.Count() >= 1 && peer_info["set_kicknsfw"] != "0" && member_info["priority"] == "0" && Vk.m_from_id != settings.GROUP_ID * -1)
                {
                    foreach (var item in Vk.m_attachments.ToArray())
                    {
                        if (item["type"] != null && (item["type"].ToString() == "photo" || item["type"].ToString() == "doc"))
                        {

                            if (item["type"].ToString() == "doc" && item["doc"]["ext"] != null && (item["doc"]["ext"].ToString() == "png" || item["doc"]["ext"].ToString() == "jpg" || item["doc"]["ext"].ToString() == "jpeg"))
                            {
                                if (item["doc"]["preview"] != null)
                                {
                                    if (item["doc"]["preview"]["photo"] != null)
                                    {
                                        item["photo"] = item["doc"]["preview"]["photo"];
                                    }
                                }
                            }


                            if (item["photo"] != null)
                            {
                                if (item["photo"]["sizes"] != null)
                                {
                                    int max_size = 0;
                                    string size_type = "";
                                    foreach (var size in item["photo"]["sizes"])
                                    {
                                        int height = (int)size["height"];
                                        int width = (int)size["width"];
                                        int sizer = height + width;
                                        if (sizer > max_size)
                                        {
                                            max_size = sizer;
                                            size_type = size["type"].ToString();
                                        }
                                    }

                                    if (size_type == "")
                                    {
                                        continue;
                                    }

                                    foreach (var size in item["photo"]["sizes"])
                                    {
                                        if (size["type"] != null)
                                        {
                                            if (size["type"].ToString() == size_type)
                                            {
                                                string url = "";
                                                if (size["url"] == null)
                                                {
                                                    if (size["src"] != null)
                                                    {
                                                        url = size["src"].ToString();
                                                    }
                                                }
                                                else
                                                {
                                                    url = size["url"].ToString();
                                                }
                                                

                                                var uri = new Uri(url);
                                                if (settings.nsfwSpyr == null) settings.nsfwSpyr = new NsfwSpyNS.NsfwSpy();
                                                var result = settings.nsfwSpyr.ClassifyImage(uri);
                                                if (result.IsNsfw)
                                                {
                                                     Console.WriteLine("Is nsfw: " + url);
                                                     db.DbInsert(new Dictionary<string, object>() { { "peer_id", Vk.m_peer_id }, { "from_id", Vk.m_from_id }, { "link", url } }, "nsfw");
                                                    var urlr = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                                                    if (peer_info["set_kicknsfw"] == "2")
                                                    {
                                                      Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                                                       vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                                                      Vk.MessagesSend(urlr[Vk.m_from_id.ToString()] + " был исключен за отправку nsfw в чат.", 0, 0);
                                                      return false;
                                                    }
                                                    else
                                                    {
                                                    //     vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                                                         Vk.MessagesSend("Сообщение " + urlr[Vk.m_from_id.ToString()] + " было удалено за отправку nsfw в чат.", 0, 0);
                                                         return false;
                                                     }
                                                 }
                                                //Console.WriteLine(url + " - " + result.Pornography.ToString());
                                                //return true;
                                            }
                                        }
                                        
                                    }
                                }
                                //var photo = "";
                            }
                        }

                    }
                }
            }
            catch
            {

            }
            


            if (text == "" && Vk.m_attachments == null)
            {
                return false;
            }
            string stringForCheckEmoji = Vk.m_text;
            if (Vk.m_fwd_messages != null)
            {
                stringForCheckEmoji += await getAllFwdMesasges(Vk.m_fwd_messages);
            }

            if (Vk.m_attachments != null)
            {
                stringForCheckEmoji += await getAllTextAttachments(Vk.m_attachments);
            }

            if (peer_info["set_kicklinks"] != "0" && member_info["priority"] == "0" && Vk.m_from_id != settings.GROUP_ID * -1)
            {
                text = stringForCheckEmoji;
                //string temp_text = text;
                if (Vk.m_attachments != null)
                {
                    foreach (var item in Vk.m_attachments)
                    {
                        if (item["type"].ToString() == "link")
                        {
                            text = text + " " + item["link"]["url"].ToString() + " ";
                        }
                        else
                        {
                            continue;
                        }
                    }
                }

                if (settings.isMatchUrl(text))
                {
                    var result_cache_fail = Cache.Get<string>("fail_kick_url_" + Vk.m_from_id + "_" + Vk.m_peer_id);
                    if (result_cache_fail != null && result_cache_fail == "failed")
                    {
                        return false;
                    }

                    var buttons = Vk.GenerateKeyboard(new string[] { "Посмотреть" },
                        new string[] { $"getdel {Vk.m_conversation_message_id}" },
                        new string[] { Vk.BUTTON_RED }, null, false, true, true);

                    var links = db.whiteListLinksGet(Vk.m_peer_id);
                    if (links != null && links.Count() >= 1)
                    {
                        var fetchedUrls = settings.urlMatches(text);
                        if (fetchedUrls != null)
                        {
                            foreach (var host in fetchedUrls)
                            {
                                bool finded = false;
                                foreach (var item in links)
                                {
                                    if (item["domain"] == host)
                                    {
                                        finded = true;
                                        break;
                                    }
                                }
                                if (!finded)
                                {
                                    var url = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                                    db.messageDeletedFilterInsert(Vk.m_peer_id, Vk.m_from_id, Vk.m_conversation_message_id, Vk.m_text);
                                    if (peer_info["set_kicklinks"] == "2")
                                    {

                                        var res = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);

                                        if (res.ContainsKey("response") && (res["response"].ToString().ToLower() == "false" || res["response"].ToString().ToLower() == "0"))
                                        {
                                            Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " отправил запрещенную ссылку в чат, " +
                                                "но не был исключен, поскольку имеет права администратора в беседе.<br><br>" +
                                                "Эту настройку можно выключить в !settings - 2 - 3, или добавить ссылку в список разрешенных - /addlink", 0, 0, buttons);

                                            Cache.Set("fail_kick_url_" + Vk.m_from_id + "_" + Vk.m_peer_id, "failed", 30);
                                            return false;
                                        }
                                        vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());

                                        Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " был исключен за отправку ссылок в чат.<br><br>" +
                                            "Эту настройку можно выключить в !settings - 2 - 3, или добавить ссылку в список разрешенных - /addlink", 0, 0, buttons);
                                    }
                                    else
                                    {
                                        vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                                        Vk.MessagesSend("Сообщение " + url[Vk.m_from_id.ToString()] + " было удалено, поскольку в " +
                                            "нем была ссылка на сторонний сайт.<br><br>" +
                                            "Эту настройку можно выключить в !settings - 2 - 3, или добавить ссылку в список разрешенных - /addlink", 0, 0, buttons);
                                    }
                                    return false;
                                }
                                return false;
                            }
                        }
                    }
                    else
                    {
                        var url = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                        if (peer_info["set_kicklinks"] == "2")
                        {

                            var res = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);

                            db.messageDeletedFilterInsert(Vk.m_peer_id, Vk.m_from_id, Vk.m_conversation_message_id, Vk.m_text);

                            if ((res.ContainsKey("response") && (res["response"].ToString().ToLower() == "false" || res["response"].ToString().ToLower() == "0")) || !res.ContainsKey("response"))
                            {
                                Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " отправил запрещенную ссылку в чат, " +
                                    "но не был исключен, поскольку имеет права администратора в беседе.<br><br>" +
                                    "Эту настройку можно выключить в !settings - 2 - 3, или добавить ссылку в список разрешенных - /addlink", 0, 0, buttons);

                                Cache.Set("fail_kick_url_" + Vk.m_from_id + "_" + Vk.m_peer_id, "failed", 30);
                                return false;
                            }
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());

                            Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " был исключен за отправку ссылок в чат.<br><br>" +
                                "Эту настройку можно выключить в !settings - 2 - 3, или добавить ссылку в список разрешенных - /addlink", 0, 0, buttons);
                        }
                        else
                        {
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                            db.messageDeletedFilterInsert(Vk.m_peer_id, Vk.m_from_id, Vk.m_conversation_message_id, Vk.m_text);
                            Vk.MessagesSend("Сообщение " + url[Vk.m_from_id.ToString()] + " было удалено, поскольку в " +
                                "нем была ссылка на сторонний сайт.<br><br>" +
                                "Эту настройку можно выключить в !settings - 2 - 3, или добавить ссылку в список разрешенных - /addlink", 0, 0, buttons);
                        }
                        return false;
                    }
                }
            }

            /*
                Проверка на большое количество эмодзи
             */


            var countEmjo = vk.EmojiCount(stringForCheckEmoji);
            if (countEmjo >= 250 && member_info["priority"] == "0" && Vk.m_from_id != settings.GROUP_ID * -1)
            {
                if (peer_info["set_action_activity"] == "1")
                {

                    var resultCache = Cache.Get<string>("peerActivityFailKick_" + Vk.m_peer_id + "_" + Vk.m_from_id);
                    if (resultCache != null)
                    {
                        var timed = 0;
                        try
                        {
                            long.Parse(resultCache);
                        }
                        catch
                        {

                        }
                        if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                        {
                            return false;
                        }
                    }

                    db.messageDeletedFilterInsert(Vk.m_peer_id, Vk.m_from_id, Vk.m_conversation_message_id, stringForCheckEmoji);

                    var buttons = Vk.GenerateKeyboard(new string[] { "Посмотреть" },
                        new string[] { $"getdel {Vk.m_conversation_message_id}" },
                        new string[] { Vk.BUTTON_RED }, null, false, true, true);

                    vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());

                    var kick = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);

                    if (kick == null || kick["error"] != null)
                    {
                        Cache.Set("peerActivityFailKick_" + Vk.m_peer_id + "_" + Vk.m_from_id, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                        string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                        Vk.MessagesSend(name_one + " должен быть исключен за подозрительную активность (большое количество стикеров), но он имеет права администратора в самой конференции.<br><br>" +
                                "Удалите участника вручную, либо снимите с него права администратора в беседе ВК.", 0, 0, buttons);
                        //db.peerDeactivate(Vk.m_peer_id);
                        return false;
                    }

                    string nick = (Vk.m_from_id <= 0) ? $"[club{Vk.m_from_id.ToString().Substring(1)}|Сообщество] было исключено." :
                    $"[id{Vk.m_from_id}|Пользователь] был исключен.";
                    Vk.MessagesSend($"{nick}<br>Причина: подозрительная активность (большое количество стикеров).<br>" +
                        $"<br><br>Данную настройку в рамках беседы можно настроить в /settings - 2 - 5.", 0, 0, buttons);
                }
                else if (peer_info["set_action_activity"] == "2")
                {
                    db.messageDeletedFilterInsert(Vk.m_peer_id, Vk.m_from_id, Vk.m_conversation_message_id, stringForCheckEmoji);

                    var buttons = Vk.GenerateKeyboard(new string[] { "Посмотреть" },
                        new string[] { $"getdel {Vk.m_conversation_message_id}" },
                        new string[] { Vk.BUTTON_RED }, null, false, true, true);

                    vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());

                    db.peersMemberSetMute(Vk.m_peer_id, Vk.m_from_id, db.timeGetForString(DateTimeOffset.Now.AddHours(1)));
                    string nick = (Vk.m_from_id <= 0) ? $"[club{Vk.m_from_id.ToString().Substring(1)}|Сообщество] получило блокироку чата." :
                    $"[id{Vk.m_from_id}|Пользователь] получил блокировку чата.";
                    Vk.MessagesSend($"{nick}<br>Причина: подозрительная активность (большое количество стикеров).<br>" +
                        $"Окончание блокировки: {DateTimeOffset.Now.AddHours(1).ToString("G")}<br><br>" +
                        $"Данную настройку в рамках беседы можно настроить в /settings - 2 - 5.", 0, 0, buttons);
                }
            }
            /*
                Проверка окончена
            */

            if (text == "")
            {
                return false;
            }

            if (peer_info["set_kickobscen"] != "0" && member_info["priority"] == "0" && Vk.m_from_id != settings.GROUP_ID * -1)
            {
                bool isObscen = false;
                var argsNullSpaced = stringForCheckEmoji.ToLower().Replace(" ", "");
                if (argsNullSpaced.Length >= 1)
                {//MatList

                    foreach (var itemMat in CommandsList.MatList)
                    {
                        if (argsNullSpaced.Contains(itemMat))
                        {
                            isObscen = true;
                        }
                    }
                }

                if (isObscen)
                {
                    db.messageDeletedFilterInsert(Vk.m_peer_id, Vk.m_from_id, Vk.m_conversation_message_id, Vk.m_text);
                    var buttons = Vk.GenerateKeyboard(new string[] { "Посмотреть" },
                        new string[] { $"getdel {Vk.m_conversation_message_id}" },
                        new string[] { Vk.BUTTON_RED }, null, false, true, true);

                    var url = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                    if (peer_info["set_kickobscen"] == "2")
                    {
                        var result_cache_fail = Cache.Get<string>("fail_delete_obscen_" + Vk.m_from_id + "_" + Vk.m_peer_id);
                        if (result_cache_fail == "failed")
                        {
                            return false;
                        }

                        var res = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);

                        if (res.ContainsKey("response") && (res["response"].ToString().ToLower() == "false" || res["response"].ToString().ToLower() == "0"))
                        {
                            Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " отправил нецензурное выражение в чат, " +
                                "но не был исключен, поскольку имеет права администратора в беседе.<br><br>" +
                                "Эту настройку можно выключить в !settings - 2 - 4.", 0, 0, buttons);

                            Cache.Set("fail_delete_obscen_" + Vk.m_from_id + "_" + Vk.m_peer_id, "failed", 30);
                            return false;
                        }
                        vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());

                        Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " был исключен за отправку нецензурной лексики в чат.<br><br>" +
                            "Эту настройку можно выключить в !settings - 2 - 4.", 0, 0, buttons);
                    }
                    else
                    {
                        vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                        var result_cache_fail = Cache.Get<string>("succes_delm_obscen_" + Vk.m_from_id + "_" + Vk.m_peer_id);
                        if (result_cache_fail == "ess")
                        {
                            return false;
                        }
                        Vk.MessagesSend("Сообщение " + url[Vk.m_from_id.ToString()] + " было удалено, поскольку в " +
                            "нем использовалась нецензурная лексика.<br><br>" +
                            "Эту настройку можно выключить в !settings - 2 - 4.", 0, 0, buttons);
                        Cache.Set("succes_delm_obscen_" + Vk.m_from_id + "_" + Vk.m_peer_id, "ess", 5);
                        return false;
                    }
                    return false;
                }

            }
            //Console.WriteLine(lowercase[0]);


            var wordsBlack = db.FilterWordsGetWords(Vk.m_peer_id);
            if (wordsBlack != null && wordsBlack.Count >= 1 && member_info["priority"] == "0" && Vk.m_from_id != settings.GROUP_ID * -1)
            {
                foreach (var word in wordsBlack)
                {
                    if (stringForCheckEmoji.ToLower().Replace(" ", "").Contains(word.Key.ToLower().Replace(" ", "")))
                    {
                        db.messageDeletedFilterInsert(Vk.m_peer_id, Vk.m_from_id, Vk.m_conversation_message_id, Vk.m_text);
                        var buttons = Vk.GenerateKeyboard(new string[] { "Посмотреть" },
                            new string[] { $"getdel {Vk.m_conversation_message_id}" },
                            new string[] { Vk.BUTTON_RED }, null, false, true, true);

                        var url = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });

                        if (word.Value["type"] == "1")
                        { // УДАЛЕНИЕ СООБЩЕНИЯ
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                            var result_cache_fail = Cache.Get<string>("succes_delm_blackword_" + Vk.m_from_id + "_" + Vk.m_peer_id);
                            if (result_cache_fail == "ess")
                            {
                                return false;
                            }
                            Vk.MessagesSend("Сообщение " + url[Vk.m_from_id.ToString()] + " было удалено, поскольку в " +
                                "нем использовались запрещенные Администратором беседы слова.<br><br>" +
                                "Эту настройку можно настроить в !filters.", 0, 0, buttons);
                            Cache.Set("succes_delm_blackword_" + Vk.m_from_id + "_" + Vk.m_peer_id, "ess", 2);
                            return false;
                        }

                        if (word.Value["type"] == "2")
                        { // КИКАТЬ
                            var result_cache_fail = Cache.Get<string>("fail_delete_blackword_" + Vk.m_from_id + "_" + Vk.m_peer_id);
                            if (result_cache_fail == "failed")
                            {
                                return false;
                            }

                            var res = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);

                            if (res.ContainsKey("response") && (res["response"].ToString().ToLower() == "false" || res["response"].ToString().ToLower() == "0"))
                            {
                                Vk.MessagesSend("Пользователь " + url[Vk.m_from_id.ToString()] + " должен был быть исключён, поскольку в его сообщении" +
                                " использовались запрещенные Администратором беседы слова, но имеет права Администратора непосредственно в беседе.<br><br>" +
                                "Эту настройку можно настроить в !filters.", 0, 0, buttons);

                                Cache.Set("fail_delete_blackword_" + Vk.m_from_id + "_" + Vk.m_peer_id, "failed", 30);
                                return false;
                            }
                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());

                            Vk.MessagesSend(url[Vk.m_from_id.ToString()] + " был исключен за отправку запрещенных Администратором слов в чат.<br><br>" +
                                "Эту настройку можно настроить в !filters.", 0, 0, buttons);
                        }

                        if (word.Value["type"] == "3")
                        { // ПРЕДУПРЕЖДАТЬ

                            var Target_User = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);

                            var warns = long.Parse(Target_User["warns"]);

                            vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());

                            //var nick_user = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));
                            var nick_user = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                            text = nick_user + " получил предупреждение за использование запрещенной фразы.";

                            db.peersAddWarn(Vk.m_peer_id, Vk.m_from_id, settings.GROUP_ID * -1, "Использование запрещенной фразы");
                            string reason = "Использование запрещенной фразы";

                            db.peerMembersSetWarns(Vk.m_peer_id, Vk.m_from_id, warns + 1);
                            //string buttons = "";
                            if (warns >= 2)
                            {
                                if (long.Parse(Target_User["priority"]) > 0)
                                {
                                    var role_user = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                                    text = nick_user + " (" + role_user + ") получил предупреждение (3/3) и был лишён роли.<br>Причина: Использование запрещенной фразы";
                                    db.peersMemberSetPriority(Vk.m_peer_id, Vk.m_from_id, 0);
                                    db.peerWarnsClear(Vk.m_peer_id, Vk.m_from_id);
                                }
                                else
                                {
                                    // ИСКЛЮЧЕНИЕ
                                    text = nick_user + " получил предупреждение (3/3) и был исключён из беседы.<br>Причина: " + reason;
                                    db.peerWarnsClear(Vk.m_peer_id, Vk.m_from_id);

                                    JObject result = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                                    if (result.ContainsKey("error"))
                                    {
                                        text = nick_user + " получил предупреждение (3/3), но бот не смог исключить участника из конференции.";
                                    }
                                    else
                                    {
                                        db.peersMemberSetPriority(Vk.m_peer_id, Vk.m_from_id, 0);
                                        db.peersMemberSetNickName(Vk.m_peer_id, Vk.m_from_id, null);

                                        // исключение из группы
                                        var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                                        if (PeerInfo["set_kickexitgroup"] != "0" && PeerInfo["group"] != "0" && PeerInfo["access_token"] != "")
                                        {
                                            var method = "groups.removeUser";
                                            var parames2 = new Dictionary<string, string>();
                                            parames2.Add("group_id", PeerInfo["group"]);
                                            parames2.Add("user_id", Vk.m_from_id.ToString());
                                            parames2.Add("access_token", SysUtils.DecryptString(PeerInfo["access_token"]));
                                            var JObject = await Vk.VkAPIs(method, parames2);
                                            if (!JObject.ContainsKey("response") || JObject.ContainsKey("error"))
                                            {
                                                if (JObject.ContainsKey("error"))
                                                {
                                                    if (JObject["error"]["error_code"] != null)
                                                    {
                                                        var code = JObject["error"]["error_code"];
                                                        if (code.ToString() == "5")
                                                        {
                                                            //db.peersSetAccessToken(Vk.m_peer_id, "");
                                                            Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен.", 0);
                                                        }
                                                    }
                                                }
                                                db.peersSetAccessToken(Vk.m_peer_id, "");
                                            }
                                        }

                                        // --------------------
                                    }
                                }
                            }
                            else
                            {
                                List<string> buttons_names = new List<string>()
                                    {
                                        "Отмена", "Посмотреть"
                                    };
                                List<string> buttons_commands = new List<string>()
                                    {
                                        "unwarn id" + Vk.m_from_id, $"getdel {Vk.m_conversation_message_id}"
                                    };
                                List<string> buttons_colors = new List<string>()
                                    {
                                        Vk.BUTTON_GREEN, Vk.BUTTON_RED
                                    };

                                buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);
                                warns++;
                                text = nick_user + " получил предупреждение (" + warns + "/3).<br>Причина: " + reason + "<br>";
                                //"Выдал: " + nick_admin
                            }
                            Vk.MessagesSend(text, 0, 0, buttons);
                            return false;
                        }


                        return false;
                    }
                }
            }


            return true;
        }

        private async Task<string>getAllFwdMesasges(JToken? data)
        {
            string result = "";
            //var forea = (JObject)data;
            int max = 4;
            int i = 0;
            foreach (var forwardMessage in data.ToArray())
            {
                try
                {
                    if (forwardMessage != null)
                    {
                        var dforwardMessage = (JObject)forwardMessage;
                        if (dforwardMessage != null)
                        {
                            if (dforwardMessage.ContainsKey("text"))
                            {
                                if (dforwardMessage["text"].ToString() != "")
                                {
                                    if (i >= max)
                                    {
                                        break;
                                    }
                                    i++;
                                    result += dforwardMessage["text"] + " ";
                                }
                            }
                        }

                        if (dforwardMessage.ContainsKey("fwd_messages"))
                        {
                            if (i >= max)
                            {
                                break;
                            }
                            i++;
                            result += " (пересланное сообщение) {<br>" + await getAllFwdMesasges(forwardMessage["fwd_messages"].DeepClone()) + "<br>}";
                        }
                    }
                    
                }
                catch
                {
                    try
                    {
                        if (forwardMessage != null)
                        {
                            if (forwardMessage["text"] != null)
                            {
                                if (forwardMessage["text"].ToString() != "")
                                {
                                    if (i >= max)
                                    {
                                        break;
                                    }
                                    i++;
                                    result += forwardMessage["text"] + " ";
                                }
                            }

                            if (forwardMessage["fwd_messages"] != null)
                            {
                                if (i >= max)
                                {
                                    break;
                                }
                                i++;
                                result += " (пересланное сообщение) {<br>" + await getAllFwdMesasges(forwardMessage["fwd_messages"].DeepClone()) + "<br>}";
                            }
                        }
                    }
                    catch (Exception ex)
                    {
                        Console.WriteLine(ex.Message);
                    }
                    
                }
                

                //Console.WriteLine(forwardMessage.ToString());
            }
            return result;
        }

        private async Task<string> getAllTextAttachments(JToken? data)
        {
            string result = "";

            int max = 4;
            int i = 0;

            foreach (var attachment in data.ToArray())
            {
                try
                {
                    if (attachment != null)
                    {
                        if (attachment["type"] != null && attachment["type"].ToString() == "wall")
                        {
                            if (attachment["wall"] != null)
                            {
                                if (attachment["wall"]["text"] != null)
                                {
                                    if (i >= max)
                                    {
                                        break;
                                    }
                                    i++;
                                    result += attachment["wall"]["text"].ToString();
                                }
                            }
                        }
                    }
                    
                }
                catch
                {
                    Console.WriteLine("error attserer");
                }
            }


            return result;
        }

        private async void checkAntiFloodBotInPeer(Database db, Cache cache, vk Vk, Dictionary<string, string>peerInfo)
        {
            try
            {
                var pred_Cache = cache.Get<Dictionary<string, string>>("afBot_" + Vk.m_from_id);
                string text_local = "";
                if (Vk.m_text != null)
                {
                    text_local = Vk.m_text;
                }

                if (Vk.m_attachments != null)
                {
                    foreach (var item in Vk.m_attachments)
                    {
                        if (item["type"] != null)
                        {
                            if (item["type"].ToString() == "sticker")
                            {
                                text_local += "" + item["sticker"]["sticker_id"].ToString();
                                //Console.WriteLine("stickerid = " + text_local);
                            }
                            else if (item["type"].ToString() == "wall" || item["type"].ToString() == "wall_reply" || item["type"].ToString() == "photo")
                            {
                                return;
                            }
                        }
                    }
                }

                var count = 1;
                var time_now = DateTimeOffset.Now;
                var time_now_text = db.timeGetForString(time_now);
                var temp_dic = new Dictionary<string, string>()
                    {
                        { "pred_text", text_local },
                        { "count", "1" },
                        { "date_last", time_now_text }
                    };
                if (pred_Cache != null)
                {
                    if (pred_Cache.ContainsKey("pred_text") && pred_Cache.ContainsKey("count"))
                    {
                        if (CalculateSimilarity(pred_Cache["pred_text"], text_local) >= 0.8)
                        {
                            var time_pred = db.timeGetForMysql(pred_Cache["date_last"]);
                            if (time_pred.AddSeconds(10) >= time_now)
                            {
                                pred_Cache["count"] = (int.Parse(pred_Cache["count"]) + 1).ToString();
                                count = int.Parse(pred_Cache["count"]) + 1;
                                //pred_Cache[""]
                            }
                            else
                            {
                                pred_Cache = temp_dic;
                            }
                        }
                        else
                        {
                            var time_pred = db.timeGetForMysql(pred_Cache["date_last"]);
                            if (time_pred.AddSeconds(2) >= time_now)
                            {
                                pred_Cache["count"] = (int.Parse(pred_Cache["count"]) + 1).ToString();
                                count = int.Parse(pred_Cache["count"]) + 1;
                                //pred_Cache[""]
                            }
                            else
                            {
                                pred_Cache = temp_dic;
                            }
                        }
                        Cache.Set("afBot_" + Vk.m_from_id, pred_Cache, 1);
                    }
                }
                else
                {
                    
                    Cache.Set("afBot_" + Vk.m_from_id, temp_dic, 1);
                }

                if (count >= 4)
                {
                    Cache.Set("afBot_" + Vk.m_from_id, temp_dic, 1);
                    try
                    {
                        db.antifloodAddPriority(Vk.m_from_id);
                        if (peerInfo["set_action_activity"] == "1")
                        {
                            var resultCache = Cache.Get<string>("peerActivityFailKick_" + Vk.m_peer_id + "_" + Vk.m_from_id);
                            if (resultCache != null)
                            {
                                var timed = 0;
                                try
                                {
                                    long.Parse(resultCache);
                                }
                                catch
                                {

                                }
                                if (timed == 0 || DateTimeOffset.Now.ToUnixTimeSeconds() < timed + 5)
                                {
                                    return;
                                }
                            }
                            var kick = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);

                            if (kick == null || kick["error"] != null)
                            {
                                Cache.Set("peerActivityFailKick_" + Vk.m_peer_id + "_" + Vk.m_from_id, DateTimeOffset.Now.ToUnixTimeSeconds().ToString(), 1);
                                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                                Vk.MessagesSend(name_one + " должен быть исключен за подозрительную активность, но он имеет права администратора в самой конференции.<br><br>" +
                                        "Удалите участника вручную, либо снимите с него права администратора в беседе ВК.", 0);
                                //db.peerDeactivate(Vk.m_peer_id);
                                return;
                            }

                            string nick = (Vk.m_from_id <= 0) ? $"[club{Vk.m_from_id.ToString().Substring(1)}|Сообщество] было исключено." :
                            $"[id{Vk.m_from_id}|Пользователь] был исключен.";
                            Vk.MessagesSend($"{nick}<br>Причина: подозрительная активность.<br>" +
                                $"<br><br>Данную настройку в рамках беседы можно настроить в /settings - 2 - 5.", 0);
                        }
                        else if (peerInfo["set_action_activity"] == "2")
                        {
                            //vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                            db.peersMemberSetMute(Vk.m_peer_id, Vk.m_from_id, db.timeGetForString(DateTimeOffset.Now.AddHours(1)));
                            string nick = (Vk.m_from_id <= 0) ? $"[club{Vk.m_from_id.ToString().Substring(1)}|Сообщество] получило блокироку чата." :
                            $"[id{Vk.m_from_id}|Пользователь] получил блокировку чата.";
                            Vk.MessagesSend($"{nick}<br>Причина: подозрительная активность.<br>" +
                                $"Окончание блокировки: {DateTimeOffset.Now.AddHours(1).ToString("G")}<br><br>" +
                                $"Данную настройку в рамках беседы можно настроить в /settings - 2 - 5.", 0);
                        }

                        //db.BotBansAddBan(Vk.m_from_id, 3, -1 * settings.GROUP_ID, "Подозрительная активность", db.timeGetForString(DateTimeOffset.Now.AddHours(1)), "п. 5.2 оферты (подозрительная чрезмерная активность)");
                        
                    }
                    catch
                    {

                    }
                    
                    

                    //Console.WriteLine("dobavil");
                }
            }
            catch
            {

            }
        }

        double CalculateSimilarity(string source, string target)
        {
            if ((source == null) || (target == null)) return 0.0;
            if ((source.Length == 0) || (target.Length == 0)) return 0.0;
            if (source == target) return 1.0;

            int stepsToSame = ComputeLevenshteinDistance(source, target);
            return (1.0 - ((double)stepsToSame / (double)Math.Max(source.Length, target.Length)));
        }

        public static int ComputeLevenshteinDistance(string source, string target)
        {
            if ((source == null) || (target == null)) return 0;
            if ((source.Length == 0) || (target.Length == 0)) return 0;
            if (source == target) return source.Length;

            int sourceWordCount = source.Length;
            int targetWordCount = target.Length;

            // Step 1
            if (sourceWordCount == 0)
                return targetWordCount;

            if (targetWordCount == 0)
                return sourceWordCount;

            int[,] distance = new int[sourceWordCount + 1, targetWordCount + 1];

            // Step 2
            for (int i = 0; i <= sourceWordCount; distance[i, 0] = i++) ;
            for (int j = 0; j <= targetWordCount; distance[0, j] = j++) ;

            for (int i = 1; i <= sourceWordCount; i++)
            {
                for (int j = 1; j <= targetWordCount; j++)
                {
                    // Step 3
                    int cost = (target[j - 1] == source[i - 1]) ? 0 : 1;

                    // Step 4
                    distance[i, j] = Math.Min(Math.Min(distance[i - 1, j] + 1, distance[i, j - 1] + 1), distance[i - 1, j - 1] + cost);
                }
            }

            return distance[sourceWordCount, targetWordCount];
        }

        public static async Task syncAllPeers(Database db, long peerId = 0)
        {
            try
            {
                var count = db.peersGetCount();
                Cache cach = new();
                vk Vk = new(cach);
                long global_current_count = 0;

                List<long> for_data = new();

                long current_list1 = 0;

                for_data = db.peersGetAllIds(0, 500000);
                if (for_data == null || for_data.Count <= 0)
                {
                    return;
                }

                int processedCount = 0;

                foreach (var item in for_data)
                {
                    Interlocked.Increment(ref processedCount);
                    Console.WriteLine($"[ASYNC] SYNC {item}");
                    await syncOnePeer(item);

                    if (processedCount % 1000 == 0)
                    {
                        if (peerId != 0)
                        {
                            Vk.MessagesSend($"[ASYNC] Processed 1000 items. Current item: {item}", 0, peerId);
                        }
                        Console.WriteLine($"[ASYNC] Processed 1000 items. Current item: {item}");
                    }
                }

                Console.WriteLine("[ASYNC] All items processed.");

                /*int maxConcurrent = 1;  // Максимальное количество одновременных задач
                int tasksPerSecond = 1; // Максимальное количество задач в секунду
                int initialCount = maxConcurrent; // Сохраняем начальное значение
                using var semaphore = new SemaphoreSlim(maxConcurrent, maxConcurrent);
                Stopwatch stopwatch = new Stopwatch();
                stopwatch.Start();

                //foreach (var item in for_data)
               // {
                    //Console.WriteLine($"[ASYNC] SYNC {item}");
                    //await syncOnePeer(item);
               // }

                await Parallel.ForEachAsync(for_data, async (item, token) =>
                {
                    //Console.WriteLine($"[ASYNC] Before Wait: {item} - Thread: {System.Threading.Thread.CurrentThread.ManagedThreadId}");
                    await WaitForRateLimit(stopwatch, tasksPerSecond, token, semaphore, initialCount);

                    try
                    {
                        Console.WriteLine($"[ASYNC] SYNC {item} - Thread: {System.Threading.Thread.CurrentThread.ManagedThreadId}");
                        await syncOnePeer(item);
                    }
                    finally
                    {
                        //Console.WriteLine($"[ASYNC] Release: {item} - Thread: {System.Threading.Thread.CurrentThread.ManagedThreadId}");
                        semaphore.Release();
                    }
                });
                */

                //Console.WriteLine("All tasks completed.");
                //Vk.MessagesSend("Синхронизация всех бесед завершена.");
            }
            catch (Exception ex)
            {
                AdminInfo.AddErrorList("Ошибка обработки СИНХРОНИЗАЦИИ", "Дата: " + DateTimeOffset.Now.ToString("G") + "<br>" +
                    " <br>Error: " + ex.Message + "<br>HelpLink:" + ex.HelpLink + "<br>StackTrace" + ex.StackTrace + "<br>Source: " + ex.Source);
                return;
            }
            
        }
    
        public static async Task<bool> syncOnePeer(long peerid)
        {
            try
            {
                Cache cach = new();
                vk Vk = new(cach);
                var db = new Database(cach);
                Dictionary<string, string> parames = new()
                {
                    { "peer_ids", peerid.ToString() },
                };
                var res_vk = await Vk.VkAPI("messages.getConversationsById", parames);

                if (res_vk.ContainsKey("response") && res_vk["response"].ToString() != "False" &&
                    res_vk["response"].ToString() != "" && res_vk["response"].ToString() != "0" && !res_vk.ContainsKey("error") && res_vk["response"]["count"].ToString() != "0")
                {
                    var response = res_vk["response"];
                    var items = response["items"];
                    foreach (var item_peer in items)
                    {
                        var peerid2 = (int)item_peer["peer"]["id"];
                        if (peerid != peerid2)
                        {
                            Console.WriteLine("[ASYNC] Peerid != peerid2 - " + peerid);
                            continue;
                        }


                        var can_write = (bool)item_peer["can_write"]["allowed"];

                        var chat_settings = item_peer["chat_settings"];

                        if (chat_settings == null)
                        {
                            Console.WriteLine("[ASYNC] Chat Settings is null - " + peerid);
                            continue;
                        }

                        string photoUrl = "";
                        var photo = chat_settings["photo"];
                        if (photo != null)
                        {
                            var photo200 = photo["photo_200"];
                            if (photo200 != null)
                            {
                                photoUrl = photo200.ToString();
                            }
                        }



                        var title = chat_settings["title"].ToString();
                        var members_count = (long)chat_settings["members_count"];
                        var owner_id = (long)chat_settings["owner_id"];
                        var state = chat_settings["state"].ToString(); // in

                        

                        if (owner_id != 0)
                        {
                            var owner_info = db.peersGetMember(peerid, owner_id, false, false);

                            if (owner_info != null)
                            {
                                if (owner_info["priority"] != "100")
                                {
                                    db.peersMemberSetPriority(peerid, owner_id, 100);
                                }
                            }
                        }
                        
                        if (owner_id != 0)
                        {
                            db.peerSetData(peerid, title, members_count, photoUrl, owner_id);
                        }
                        else
                        {
                            db.peerSetData(peerid, title, members_count, photoUrl);
                        }

                        if (can_write != true || state != "in")
                        {
                            db.peerDeactivate(peerid);
                            Console.WriteLine("[ASYNC] 2 Deactivate " + peerid);
                            //db.peerMembersDeleteForPeer(peerid);
                        }
                        //var acl = chat_settings["acl"];
                    }

                    string method = "messages.getConversationMembers";
                    Dictionary<string, string> paramesd = new()
                        {
                            { "peer_id", peerid.ToString() }
                        };
                    var answer_vk = await Vk.VkAPI(method, paramesd);
                    if (answer_vk["error"] != null || answer_vk["response"]["items"] == null)
                    {
                        //Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                        //Thread.Sleep(100);
                        Console.WriteLine("[ASYNC] Error not null, response items = null - " + peerid + " | ERROR: " + answer_vk["error"].ToString());
                        return true;
                    }

                    Dictionary<long, long> userids = new();

                    //long[] userids = new long[answer_vk["response"]["items"].Count()];
                    //long i = 0;
                    foreach (var upd in answer_vk["response"]["items"])
                    {
                        try
                        {
                            var id = (long)upd["member_id"];

                            userids.Add(id, (long)upd["invited_by"]);
                        }
                        catch (Exception e)
                        {
                            Console.WriteLine("not user - sync CATCH");
                        }
                        //userids[i] = id;
                        //i++;
                    }

                    //List<long> useridsDb = new();

                    var usersDB = db.peerGetAllMembers(peerid, false, 20000);
                    var useridsDb = new System.Collections.Concurrent.ConcurrentBag<long>();

                    Parallel.ForEach(usersDB, item =>
                    {
                        
                        useridsDb.Add(long.Parse(item["user_id"]));
                        if (userids.ContainsKey(long.Parse(item["user_id"])) && item["leave_peer"] == "1")
                        {
                            Database dbr = new Database(cach);
                            dbr.peersMemberSetLeavePeer(peerid, long.Parse(item["user_id"]), "0");
                            //Console.WriteLine("0");
                        }

                        if (!userids.ContainsKey(long.Parse(item["user_id"])) && item["leave_peer"] == "0")
                        {
                            Database dbr = new Database(cach);
                            dbr.peersMemberSetLeavePeer(peerid, long.Parse(item["user_id"]), "1");
                            //Console.WriteLine("1");
                        }

                        if (userids.ContainsKey(long.Parse(item["user_id"])) && item["invited_by"] != userids[long.Parse(item["user_id"])].ToString())
                        {
                            Database dbr = new Database(cach);
                            dbr.peersMemberSetInviter(peerid, long.Parse(item["user_id"]), userids[long.Parse(item["user_id"])]);
                        }
                    });

                    Parallel.ForEach(userids, item =>
                    {
                        
                        if (!useridsDb.Contains(item.Key))
                        {
                            Database dbr = new Database(cach);
                            dbr.peersGetMember(peerid, item.Key, false, true);
                            //Console.WriteLine("2");
                        }
                    });

                }
                else
                {
                    //db.peerDeactivate(peerid);
                    //db.peerMembersDeleteForPeer(peerid);
                    if (res_vk["response"] != null && res_vk["error"] == null)
                    {
                        var response = res_vk["response"];
                        var count = response["count"];
                        if (count != null)
                        {
                            if (count.ToString() == "0")
                            {
                                Console.WriteLine("[ASYNC] Deactivate " + peerid + " (count = 0)");
                                db.peerDeactivate(peerid);
                            }
                        }
                    }
                    else
                    {
                        Console.WriteLine("[ASYNC] Deactivate " + peerid + " (error: " + res_vk.ToString() + ")");
                    }
                }
                return true;
            }
            catch (Exception e)
            {
                Console.WriteLine("[ASYNC] Error SYNC " + peerid + " | message: " + e.Message + " | stacktrace " + e.StackTrace);
                return false;
            }
            
        }

        private static async Task WaitForRateLimit(Stopwatch stopwatch, int tasksPerSecond, CancellationToken token, SemaphoreSlim semaphore, int initialCount)
        {
            int currentCount = semaphore.CurrentCount;
            if (currentCount < 1)
            {
                // Если все семафоры заняты, ждем их освобождения.
                await semaphore.WaitAsync(token);
                return;
            }


            double elapsedSeconds = stopwatch.Elapsed.TotalSeconds;
            double expectedRate = tasksPerSecond * elapsedSeconds;

            // Вычисляем количество задач, которые уже должны были быть выполнены.
            int currentTasks = initialCount - semaphore.CurrentCount;
            int shouldBeFinished = (int)expectedRate;

            if (currentTasks > shouldBeFinished)
            {
                // Если мы превысили лимит задач за секунду, делаем задержку
                int delay = (int)((currentTasks - shouldBeFinished) * 1000d / tasksPerSecond);
                Console.WriteLine($"[RateLimiter] Delaying by {delay}ms, currentTasks:{currentTasks}, shouldBeFinished:{shouldBeFinished}");
                await Task.Delay(delay, token);
            }


            // Занимаем семафор
            await semaphore.WaitAsync(token);
        }

    }

    class botban
    {
        public vk Vk;
        public settings settings;
        public Database db;
        public botban(vk vks, Database dbs, settings set)
        {
            Vk = vks;
            settings = set;
            db = dbs;
        }

        public async Task<bool> checkBotBan()
        {
            var userBotBan = db.BotBansGetBan(Vk.m_from_id);
            if (userBotBan != null)
            {
                if (settings.isPeer(Vk.m_peer_id))
                {
                    if (userBotBan["type_ban"] == "1")
                    {
                        var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                        if (peerInfo["active"] == "0")
                        {
                            return true;
                        }
                        var result_vk = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                        //Console.WriteLine(result_vk.ToString());
                        if (result_vk["error"] != null || (result_vk["response"] != null && result_vk["response"].ToString() == "False"))
                        {
                            //text = nickname + " не состоит в конференции, либо имеет права Администратора непосредственно в беседе.";
                            string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                            Vk.MessagesSend(name_one + " находится в чёрном списке бота, но он имеет права администратора в самой конференции.<br><br>" +
                                "Обратите внимание, бот перевел эту беседу в статус 'не активирована'. Удалите участника и активируйте беседу заново — /start.", 0);
                            db.peerDeactivate(Vk.m_peer_id);
                            //Interlocked.Decrement(ref AdminInfo.threads);
                            //return;
                        }
                        else
                        {
                            string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                            Vk.MessagesSend(name_one + " находится в чёрном списке бота, он(а) исключен(а) из соображений безопасности.<br><br>" +
                                "Обратите внимание, обратное добавление этого пользователя в беседу будет расценено как подозрительное действие," +
                                " приглашающий участник будет исключен.", 0);
                            
                        }
                    }
                    else if (userBotBan["type_ban"] == "2" || userBotBan["type_ban"] == "3")
                    {
                        var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                        if (peerInfo["active"] == "0")
                        {
                            return true;
                        }
                        Cache cache = new();
                        var target_status = cache.Get<string>("peer_alert_botban_" + Vk.m_peer_id + "_" + Vk.m_from_id);
                        if (target_status == null || target_status == "false" || target_status == "")
                        {
                            if (userBotBan["mention"] == "0")
                            {
                                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");

                                Vk.MessagesSend(name_one + " находится в чёрном списке бота.<br><br>" +
                                    "Обратите внимание, при дальнейшем нахождении этого пользователя в конференции — вы подвергаете свою беседу опасности, " +
                                    "а бот не будет реагировать на команды данного пользователя.", 0);
                                db.BotBansSetMention(Vk.m_from_id, 1);
                            }
                        }
                        else
                        {
                            return true;
                        }
                        cache.Set("peer_alert_botban_" + Vk.m_peer_id + "_" + Vk.m_from_id, "truealert", 600);
                    }
                    return true;
                }
                else
                {
                    return true;
                }
            }
            return false;
        }
    }

    class user_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;

        public user_cmds(vk vks, Database dbs, settings set)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
        }

        public async void command_tests()
        {
            long weather = 2;
            long sun = 1;
            long rain = 2;
            if (weather == sun) { Console.WriteLine(weather); }


            //Vk.MessagesSend(chislo.ToString());
        }


        public async void command_gc()
        {
            try
            {
                //getCPU
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gc", 10))
                {
                    return;
                }

                CpuMemoryMetrics4LinuxUtils CpuMemoryMetrics4LinuxUtilsR = new();
                string cpuText = "не удалось определить";
                string memoryText = "не удалось определить";
                try
                {
                    var cpu = await CpuMemoryMetrics4LinuxUtilsR.GetOverallCpuUsagePercentage();
                    cpuText = cpu.ToString();
                }
                catch
                {

                }
                try
                {
                    var memory = CpuMemoryMetrics4LinuxUtils.GetOccupiedMemoryPercentage();
                    memoryText = memory.ToString();
                }
                catch
                {

                }
                var dateUptime = settings.date_uptime;
                var dateTarget = DateTimeOffset.Now - dateUptime;


                Vk.MessagesSend("CPU Usage: " + cpuText + "%<br>Memory Usage: " + memoryText + "%<br>" +
                    "Uptime: " + setTimeOff.ToReadableString(dateTarget)); //var dateUptime = settings.date_uptime;);

                //var targetCpu = AdminInfo.target_cpu;
                //if (targetCpu == "")
                //{
                //Vk.MessagesSend("Ошибка получения данных.");
                //}
                //else
                //{
                //Vk.MessagesSend("Текущая нагрузка:<br>CPU: " + targetCpu + "%");
                //}
                //
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_quit()
        {

            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "quit", 10))
                {
                    return;
                }

                Dictionary<string, string>? Target_User = null;
                Target_User = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id, false, false);

                string nickname = "Пользователь";

                if (Target_User != null)
                {
                    nickname = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(Target_User["user_id"]));
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = $"[public{Vk.m_from_id.ToString().Substring(1)}|Сообщество]";
                    }
                    else
                    {
                        nickname = $"[id{Vk.m_from_id}|Пользователь]";
                    }
                }

                string text = "";

                JObject result_vk = await Vk.KickUser(Vk.m_peer_id, Vk.m_from_id);
                if (result_vk["error"] != null || (result_vk["response"] != null && result_vk["response"].ToString() == "False"))
                {
                    text = nickname + " имеет права Администратора непосредственно в беседе, поэтому бот не может исключить его.";
                }
                else
                {
                    if (Target_User != null && Target_User["mute"] != "")
                    {
                        db.peersMemberSetMute(Vk.m_peer_id, long.Parse(Target_User["user_id"]), "");
                        text = "⚠ У [id" + Target_User["user_id"] + "|пользователя] была блокировка чата, она автоматически снята.<br><br>";
                    }
                    text = text + nickname + " вышел из конференции.";
                    Vk.MessagesSend(text);
                    return;
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_test()
        {
            //string buttons = Vk.GenerateKeyboard(new string[] { }, new string[] { }, new string[] { }, new long[] { }, true, false);
            //Vk.MessagesSend("𝑽𝑰𝑷 — 1");
            //foreach (var targetin in AdminInfo.requests_ping)
            //{
            //foreach (KeyValuePair<long, long> item in targetin)
            //{
            //if (item.Key < target_time - 120)
            //{
            //continue;
            //}
            //Console.WriteLine(item.Value);
            //}
            //}

            //var res = await Vk.Get("http://35.228.60.211/charts/test.php");

           // string filePath = "MyImage.png";
            //var data = res.Split(',');

           // File.WriteAllBytes(filePath, Convert.FromBase64String(data[1]));

            //var result_photo = await Vk.PostPhotoForPeer(Vk.m_peer_id, "MyImage.png", "MyImage.png");
            //string att = "";
            //if (result_photo != null)
           // {
               // att = "photo" + result_photo["owner_id"] + "_" + result_photo["id"] + "_" + result_photo["access_key"];
               // Vk.MessagesSend("Инфографическая схема", 1, 0, "", false, att);
            //}

            //Vk.MessagesSend("убил марка");
            /*var attachments = Vk.m_attachments;
            if (attachments == null || attachments.Count() <= 0)
            {
                return;
            }
            string[] attachmesnts = new string[attachments.Count()];

            foreach (var item in attachments)
            {
                string type = item["type"].ToString();
                string owner_id = item[type]["owner_id"].ToString();
                string media_id = item[type]["id"].ToString();
                attachmesnts.Append(type + owner_id + "_" + media_id);
            }

            //string type = attachments[0]["type"].ToString();

            Vk.MessagesSend("yees", 1, 0, "", true, string.Join(",", attachmesnts));*/
            /*long con = vk.EmojiCount(Vk.m_text);
            if (con >= 1)
            {
                Vk.MessagesSend("есть - " + con);
            }
            else
            {
                Vk.MessagesSend("nou");
            }*/
            /*var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "int" });

            if (args[0] == "" || args[1] == "" || args[0] == null || args[1] == null)
            {
                return;
            }
            var user_id = long.Parse(args[0]);
            var role = long.Parse(args[1]);
            db.peersMemberSetPriority(Vk.m_peer_id, user_id, role);*/
            //Vk.MessagesSend("d: " + vk.EmojiCount(Vk.m_text));





            /*
            DateTimeOffset current_time = DateTimeOffset.Now;
            string key_day = current_time.Year.ToString() + "_" + current_time.Month.ToString() + "_" + current_time.Day.ToString();
            var info = db.statsGetStatPeerCache(Vk.m_peer_id);


            var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

            if ( args[0] != null && args[0] != "")
            {
                var user_id = long.Parse(args[0]);
                info = null;
                info = db.statsGetStatUserPeerCache(Vk.m_peer_id, user_id);
            }

            string text;
            if (info == null)
            {
                text = "Данных статистики не найдено.";
            }
            else
            {
                var infos = info[key_day];
                text = "Статистика:" + "<br>" +
                "Сообщений: " + infos["messages"] + "<br>" +
                "Символов: " + infos["symbols"] + "<br>" +
                "Слов: " + infos["words"] + "<br>" +
                "Нецензурных слов: "  + infos["obscen_words"] + "<br>" +
                "Команд: " + infos["commands"] + "<br>" +
                "Фотографий: " + infos["photos"] + "<br>" +
                "Видео: " + infos["videos"] + "<br>" +
                "Аудио: " + infos["audios"] + "<br>" +
                "Постов: " + infos["posts"] + "<br>" +
                "Стикеров: " + infos["stickers"] + "<br>" +
                "Смайлов: " + infos["smiles"];
            }
            Vk.MessagesSend(text);
            /*var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
            if (args[0] != null)
            {
                Vk.MessagesSend(long.Parse(args[0]).ToString());
            }*/
           /* List<long> datas = new()
                    {
                        5, 2, 2, 0, 0, 10, 0, 2, 0, 5
                    };
            Chart qc = new Chart();

            qc.Width = 1280;
            qc.Height = 500;
            qc.Config = @"{
    type:'doughnut',
    data: {
            labels:['Команды','Слова','Нецензурная лексика','Голосовые сообщения','Фотографии', 'Видео', 'Аудиозаписи', 'Посты', 'Стикеры', 'Эмодзи'],
            datasets: [{
                data: " + JsonConvert.SerializeObject(datas) + @"
            }] },
    options: {
        plugins: {
            doughnutlabel: {
                labels: [{text:'" + 560 + @"',font:{size:72}},{text:'Сообщений'}]
            }
        }
    }
}";*/
            //qc.ToFile("dsds32.png");
            //var res = await vk.PostPhotoForPeer(Vk.m_peer_id, "dsds32.png", "dsds32.png");
            //att = "";
            //if (res != null)
            //{
                //att = "photo" + res["owner_id"] + "_" + res["id"] + "_" + res["access_key"];
            //}
            //Vk.MessagesSend("Рез", 0, 0, "", true, att);
            //PostPhoto


            if (Vk.format_data != null)
            {
                var formatdata = Vk.format_data;
                var textMarkDown = TextFormatter.ToMarkdown(Vk.m_text, (JObject)formatdata);
                Vk.MessagesSend(textMarkDown);
                return;
            }
            else
            {
                var text = Vk.m_text;
                var targetFormat = TextFormatter.FromMarkdown(text);

                Vk.MessagesSend(targetFormat.PlainText, 1, 0, "", true, "", targetFormat.FormatData.ToString());
            }
        }

        public async void command_kiss()
        {
            try
            {
                //UsersGetName
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "kiss"))
                {
                    return;
                }
                //CommandsCheck
                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }


                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "kiss", 10))
                {
                    return;
                }

                if (Vk.m_from_id < 0)
                {
                    Vk.MessagesSend("Данная команда недоступна для сообществ.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null || long.Parse(args[0]) < 0)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["kiss"]);
                    return;
                }

                string name_vk = await Vk.GetUrlName(long.Parse(args[0]), "acc");
                long[] ids = { Vk.m_from_id };
                var vk_info = await Vk.UsersGetVkInfo(ids);
                string do_kiss = "поцеловал(а)";
                if (vk_info["id" + Vk.m_from_id.ToString()].sex == "2")
                {
                    do_kiss = "поцеловал";
                }
                else if (vk_info["id" + Vk.m_from_id.ToString()].sex == "1")
                {
                    do_kiss = "поцеловала";
                }
                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                Vk.MessagesSend("👄 " + name_one + " " + do_kiss + " " + name_vk, 1, 0, "", false);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ROLEPLAY_USE, Vk.m_from_id, long.Parse(args[0]), do_kiss);

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_obnyat()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "obnyat"))
                {
                    return;
                }
                //CommandsCheck

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "obnyat", 10))
                {
                    return;
                }

                if (Vk.m_from_id < 0)
                {
                    Vk.MessagesSend("Данная команда недоступна для сообществ.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null || long.Parse(args[0]) < 0)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["obnyat"]);
                    return;
                }

                string name_vk = await Vk.GetUrlName(long.Parse(args[0]), "acc");
                long[] ids = { Vk.m_from_id };
                var vk_info = await Vk.UsersGetVkInfo(ids);
                string do_kiss = "обнял(а)";
                if (vk_info["id" + Vk.m_from_id.ToString()].sex == "2")
                {
                    do_kiss = "обнял";
                }
                else if (vk_info["id" + Vk.m_from_id.ToString()].sex == "1")
                {
                    do_kiss = "обняла";
                }
                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                Vk.MessagesSend("👄 " + name_one + " " + do_kiss + " " + name_vk, 1, 0, "", false);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ROLEPLAY_USE, Vk.m_from_id, long.Parse(args[0]), do_kiss);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_iznas()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "iznas"))
                {
                    return;
                }
                //CommandsCheck
                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "iznas", 10))
                {
                    return;
                }

                if (Vk.m_from_id < 0)
                {
                    Vk.MessagesSend("Данная команда недоступна для сообществ.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null || long.Parse(args[0]) < 0)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["iznas"]);
                    return;
                }

                string name_vk = await Vk.GetUrlName(long.Parse(args[0]), "ins");
                long[] ids = { Vk.m_from_id };
                var vk_info = await Vk.UsersGetVkInfo(ids);
                string do_kiss = "надругался(ась)";
                if (vk_info["id" + Vk.m_from_id.ToString()].sex == "2")
                {
                    do_kiss = "надругался над";
                }
                else if (vk_info["id" + Vk.m_from_id.ToString()].sex == "1")
                {
                    do_kiss = "надругалась над";
                }
                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                Vk.MessagesSend("👄 " + name_one + " " + do_kiss + " " + name_vk, 1, 0, "", false);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ROLEPLAY_USE, Vk.m_from_id, long.Parse(args[0]), do_kiss);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_minet()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "minet"))
                {
                    return;
                }
                //CommandsCheck

                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "minet", 10))
                {
                    return;
                }

                if (Vk.m_from_id < 0)
                {
                    Vk.MessagesSend("Данная команда недоступна для сообществ.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null || long.Parse(args[0]) < 0)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["minet"]);
                    return;
                }

                string name_vk = await Vk.GetUrlName(long.Parse(args[0]), "dat");
                long[] ids = { Vk.m_from_id };
                var vk_info = await Vk.UsersGetVkInfo(ids);
                string do_kiss = "сделал(а) минет";
                if (vk_info["id" + Vk.m_from_id.ToString()].sex == "2")
                {
                    do_kiss = "сделал минет";
                }
                else if (vk_info["id" + Vk.m_from_id.ToString()].sex == "1")
                {
                    do_kiss = "сделала минет";
                }
                string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                Vk.MessagesSend("👄 " + name_one + " " + do_kiss + " " + name_vk, 1, 0, "", false);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.ROLEPLAY_USE, Vk.m_from_id, long.Parse(args[0]), do_kiss);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_try()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "try"))
                {
                    return;
                }
                //CommandsCheck
                if (settings.isPeer(Vk.m_peer_id))
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo != null && PeerInfo["set_games"] != "1")
                    {
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "try", 10))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                //Console.WriteLine(args);
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["try"]);
                    return;
                }
                string text = "";
                var rand = new Random();
                long gen = rand.Next(1, 100);
                string result;
                if (gen < 50)
                {
                    result = "неудачно";
                }
                else
                {
                    result = "удачно";
                }
                if (args[0] == "")
                {
                    text = "Необходимо указать действие.<br>/try действие";
                }
                else
                {
                    string nickname = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);
                    text = nickname + " решил испытать свою удачу.<br>Действие: " + args[0] + "<br>Результат: " + result;
                }
                gen = 0;
                //string text = "🔔 DIGITAL FINK удобный и простой бот.<br><br>Разобраться с командами вам поможет статья — vk.com/@fink_manager-aktualnye-komandy";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_voice()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_fakecmd != 1)
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "voice", 10))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                //Console.WriteLine(args);
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["voice"]);
                    return;
                }

                if (settings.isMatchUrl(args[0]))
                {
                    Vk.MessagesSend("Нельзя использовать ссылки от имени бота.");
                    return;
                }

                if (args[0].Any(c => (c >= 'A' && c <= 'z')))
                {
                    Vk.MessagesSend("Нельзя использовать английские буквы от имени бота.");
                    return;
                }

                var argsNullSpaced = args[0].Split(" ");
                if (argsNullSpaced.Count() >= 1)
                {//MatList
                    foreach (var items in argsNullSpaced)
                    {
                        var word = items.ToLower();

                        foreach (var itemMat in CommandsList.MatList)
                        {
                            if (word.Contains(itemMat))
                            {
                                Vk.MessagesSend("Нельзя использовать нецензурные выражения от имени бота.");
                                return;
                            }
                        }
                    }
                }
                else
                {
                    foreach (var itemMat in CommandsList.MatList)
                    {
                        if (args[0].Contains(itemMat))
                        {
                            Vk.MessagesSend("Нельзя использовать нецензурные выражения от имени бота.");
                            return;
                        }
                    }
                }

                /*var cach = new Cache();
                var resultCache = cach.Get<Dictionary<string, string>>("Vip_voiceCount_" + Vk.m_from_id);
                if (resultCache == null)
                {
                    resultCache = new Dictionary<string, string>() { 
                        { "lastDate", db.timeGetForString(DateTimeOffset.Now) },
                        { "countVoice", "0" }
                    };
                    cach.Set("Vip_voiceCount_" + Vk.m_from_id, resultCache, 1440);
                    //1440
                }
                else
                {
                    if (!resultCache.ContainsKey("lastDate"))
                    {
                        resultCache = new Dictionary<string, string>() {
                            { "lastDate", db.timeGetForString(DateTimeOffset.Now) },
                            { "countVoice", "0" }
                        };
                        cach.Set("Vip_voiceCount_" + Vk.m_from_id, resultCache, 1440);
                    }

                    var timeDate = db.timeGetForMysql(resultCache["lastDate"]);
                    if (DateTimeOffset.Now > timeDate.AddDays(1))
                    {
                        resultCache = new Dictionary<string, string>() {
                            { "lastDate", db.timeGetForString(DateTimeOffset.Now) },
                            { "countVoice", "0" }
                        };
                        cach.Set("Vip_voiceCount_" + Vk.m_from_id, resultCache, 1440);
                    }
                    else
                    {
                        var profile = db.usersGetUser(Vk.m_from_id);
                        var targetCount = int.Parse(resultCache["countVoice"]);
                        var targetMax = int.Parse(profile["vip_type"]) * 10;
                        if (targetCount > targetMax)
                        {
                            Vk.MessagesSend("Ваше допустимое количество использований на сегодня для вашего уровня VIP статуса достигло максимума - '" + targetMax + "'<br><br>" +
                                "Для увеличения лимита до '" + (targetMax + 10).ToString() + "' необходим следующий уровень VIP статуса.<br>Подробнее — !vip");
                            return;
                        }
                        else
                        {
                            resultCache["countVoice"] =(targetCount + 1).ToString();
                            cach.Set("Vip_voiceCount_" + Vk.m_from_id, resultCache, 1440);
                        }
                    }
                }*/

                string text = args[0];
                
                var nickname = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                string texLog = " сказал через бота: " + args[0];


                //string text = "🔔 DIGITAL FINK удобный и простой бот.<br><br>Разобраться с командами вам поможет статья — vk.com/@fink_manager-aktualnye-komandy";
                Vk.MessagesSend(text, 0, 0, "", false, Vk.m_attachments.ToString());
                db.logsAddLog(Vk.m_peer_id, Database.logsId.VIP_VOICE, Vk.m_from_id, 0, texLog, args[0]);
                vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_help()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "help"))
                {
                    return;
                }
                //CommandsCheck

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "help", 10))
                {
                    return;
                }

                string text = "🔔 DIGITAL FINK удобный и простой бот.<br><br>" +
                    "📜 Отображена малая часть необходимых команды:<br>" +
                    "!кик — исключить пользователя<br>" +
                    "!бан — заблокировать пользователя<br>" +
                    "!унбан — разблокировать участника<br>" +
                    "!мут — запретить писать в чат<br>" +
                    "!унмут — разрешить писать в чат<br>" +
                    "!warn — выдать предупреждение<br>" +
                    "!unwarn — снять предупреждение<br>" +
                    "!настройки — детальная настройка конференции<br>" +
                    "!админы — отобразить список участников с ролью<br>" +
                    "!role — выдать роль участнику<br>" +
                    "" +
                    "<br><br>Разобраться с остальными командами вам поможет статья — vk.com/@fink_manager-aktualnye-komandy";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_staff()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "staff"))
                {
                    return;
                }
                //CommandsCheck

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "staff", 10))
                {
                    return;
                }

                string type = "";
                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                //Console.WriteLine(args);
                if (args[0] != null && args[0] != "")
                {
                    if (args[0] == "nicks")
                    {
                        type = "nicks";
                    }
                    else
                    {
                        type = "vk";
                    }
                }



                var roles_name = db.peerGetRoles(Vk.m_peer_id);
                //foreach (var item in roles_name)
                //{

                //}
                string text = "";
                var members = db.peerGetMembersWhenRole(Vk.m_peer_id, false, 100);

                if (members.Count <= 0)
                {
                    return;
                }
                Dictionary<string, int> usersPriorities = new();
                foreach (var item in members)
                {
                    var tmp_user = db.peersGetMember(Vk.m_peer_id, item, false, false);
                    if (tmp_user != null)
                    {
                        usersPriorities.Add(tmp_user["user_id"], int.Parse(tmp_user["priority"]));
                        tmp_user = null;
                    }
                }

                /*List<Dictionary<string, string>> users_priority = new();
                foreach (var item in members)
                {
                    var tmp_user = db.peersGetMember(Vk.m_peer_id, item, false, false);
                    if (tmp_user != null)
                    {
                        users_priority.Add(tmp_user);
                        tmp_user = null;
                    }
                }*/

                var users_priority = from entry in usersPriorities orderby entry.Value descending select entry;

                //var sortedDict = from entry in myDict orderby entry.Value ascending select entry;

                long[] userids = new long[users_priority.Count()];

                long iter = 0;
                foreach (var item in users_priority)
                {
                    userids[iter] = long.Parse(item.Key);
                    iter++;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(userids);


                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                bool is_vip = db.PeerIsVip(peerInfo);

                string last_priority = "0";

                int all_count = 0;
                int current_count = 0;

                var nick = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });

                string buttons = "";
                if (type == "")
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "ники" }, new string[] { "staff nicks" }, new string[] { Vk.BUTTON_GREEN }, null, false, true, false);
                }

                if (type == "vk")
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "ники" }, new string[] { "staff nicks" }, new string[] { Vk.BUTTON_GREEN }, null, false, true, false);
                }

                if (type == "nicks")
                {
                    buttons = Vk.GenerateKeyboard(new string[] { "имена" }, new string[] { "staff vk" }, new string[] { Vk.BUTTON_GREEN }, null, false, true, false);
                }

                if (Vk.is_callbackButton)
                {
                    text += "<br>Команду выполнил: " + nick[Vk.m_from_id.ToString()] + "<br><br>";
                }

                foreach (var item in users_priority)
                {
                    all_count++;
                    current_count++;
                    if (last_priority != item.Value.ToString())
                    {
                        if (roles_name.ContainsKey(item.Value.ToString()))
                        {
                            last_priority = item.Value.ToString();
                            text = text + "<br>" + roles_name[item.Value.ToString()].name + ":<br>";
                        }
                        else
                        {
                            var priority = item.Value;
                            if (priority == 100)
                            {
                                last_priority = "100";
                                if (!is_vip)
                                {
                                    text = text + "<br>Владелец:<br>";
                                }
                                else
                                {
                                    text = text + "<br>🔥 Владелец:<br>";
                                }
                            }
                            else if (priority >= 80 && last_priority != "80")
                            {
                                last_priority = "80";
                                if (!is_vip)
                                {
                                    text = text + "<br>Главный администратор:<br>";
                                }
                                else
                                {
                                    text = text + "<br>🔱 Главный администратор:<br>";
                                }
                            }
                            else if (priority >= 60 && last_priority != "60")
                            {
                                last_priority = "60";
                                if (!is_vip)
                                {
                                    text = text + "<br>Администратор:<br>";
                                }
                                else
                                {
                                    text = text + "<br>⚡ Администратор:<br>";
                                }
                            }
                            else if (priority >= 40 && last_priority != "40")
                            {
                                last_priority = "40";
                                if (!is_vip)
                                {
                                    text = text + "<br>Модератор:<br>";
                                }
                                else
                                {
                                    text = text + "<br>⭐ Модератор:<br>";
                                }
                            }
                            else if (priority >= 1 && last_priority != "20")
                            {
                                last_priority = "20";
                                if (!is_vip)
                                {
                                    text = text + "<br>Помощник:<br>";
                                }
                                else
                                {
                                    text = text + "<br>🛡 Помощник:<br>";
                                }
                            }
                            else
                            {
                                last_priority = "0";
                                text = text + "<br>Участник:<br>";
                            }
                        }

                    }

                    if (type == "nicks")
                    {
                        string nickTar = "";
                        
                        var userNick = db.peersGetMember(Vk.m_peer_id, long.Parse(item.Key), false, false);
                        if (userNick != null)
                        {
                            if (userNick["nick"] != "")
                            {
                                nickTar = userNick["nick"];
                            }
                            else
                            {
                                if (long.Parse(item.Key) <= 0)
                                {
                                    nickTar = "Сообщество";
                                }
                                else
                                {
                                    if (users_names_vk.ContainsKey("id" + item.Key))
                                    {
                                        nickTar = users_names_vk["id" + item.Key].first_name
                                        + " " + users_names_vk["id" + item.Key].last_name;
                                    }
                                    else
                                    {
                                        nickTar = "Пользователь";
                                    }
                                }
                            }
                        }
                        else
                        {
                            if (long.Parse(item.Key) <= 0)
                            {
                                nickTar = "Сообщество";
                            }
                            else
                            {
                                if (users_names_vk.ContainsKey("id" + item.Key))
                                {
                                    nickTar =  users_names_vk["id" + item.Key].first_name
                                    + " " + users_names_vk["id" + item.Key].last_name;
                                }
                                else
                                {
                                    nickTar = "Пользователь";
                                }
                            }
                        }


                        if (long.Parse(item.Key) <= 0)
                        {
                            
                            text += "— [club" + item.Key.Substring(1) + "|" + nickTar + "]<br>";
                        }
                        else
                        {
                            text += "— [id" + item.Key + "|" + nickTar + "]<br>";
                        }
                    }
                    else
                    {
                        if (users_names_vk.ContainsKey("id" + item.Key))
                        {
                            text = text + "— [id" + item.Key + "|" + users_names_vk["id" + item.Key].first_name
                            + " " + users_names_vk["id" + item.Key].last_name + "]<br>";
                        }
                        else
                        {
                            if (long.Parse(item.Key) <= 0)
                            {
                                text = text + "— [club" + item.Key.Substring(1) + "|Сообщество]<br>";
                            }
                            else
                            {
                                text = text + "— [id" + item.Key + "|Пользователь]<br>";
                            }
                        }
                    }

                    
                    if(current_count >= 50)
                    {
                        current_count = 0;
                        if (users_priority.Count() >= all_count)
                        {
                            if (type == "")
                            {
                                Cache Cache = new Cache();

                                long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                                Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                                return;
                            }
                            else
                            {
                                Cache Cache = new Cache();
                                var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id);
                                if (last_message != null)
                                {
                                    Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                                    Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                                }
                                else
                                {
                                    long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                                    Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                                }
                            }
                            
                        }
                        else
                        {
                            Vk.MessagesSend(text, 0);
                        }
                        text = "";
                    }
                }
                
                if (current_count <= 49 && current_count != 0)
                {
                    if (type == "")
                    {
                        Cache Cache = new Cache();

                        long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                        Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        return;
                    }
                    else
                    {
                        Cache Cache = new Cache();
                        var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id);
                        if (last_message != null)
                        {
                            Cache.Set("last_message_for_" + Vk.m_peer_id, last_message.ToString());
                            Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                        }
                        else
                        {
                            long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                            Cache.Set("last_message_for_" + Vk.m_peer_id, idmes.ToString());
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_start()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "start", 10))
                {
                    return;
                }
                Dictionary<string, string>? peer_info = db.peersGetPeer(Vk.m_peer_id);
                long peer_id = Vk.m_peer_id;

                if (peer_info["active"] == "1")
                {
                    Vk.MessagesSend("Конференция уже активна.");
                    return;
                }

                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
            {
                { "peer_id", peer_id.ToString() },
                { "fields", "is_owner" }
            };
                var answer_vk = await Vk.VkAPI(method, paramesd);
                if (answer_vk == null || answer_vk.ContainsKey("error") || !answer_vk.ContainsKey("response") || answer_vk["response"].ToString().ToLower() == "false")
                {
                    //Console.WriteLine(answer_vk.ToString());
                    Vk.MessagesSend("Ошибка активации. Возможно, вы не выдали права администратора боту.");
                    return;
                }

                long owner_id = 0;
                long invited_by = 0;
                long is_admin = 0;
                foreach (var upd in answer_vk["response"]["items"])
                {
                    if (upd["is_owner"] != null && (bool)upd["is_owner"] == true)
                    {
                        owner_id = (long)upd["member_id"];
                    }
                    if (upd["member_id"].ToString() == "-" + settings.GROUP_ID.ToString())
                    {
                        invited_by = (int)upd["invited_by"];
                        if (upd["is_admin"] != null && (bool)upd["is_admin"] == true)
                        {
                            is_admin = 1;
                        }
                    }
                    else
                    {
                        if (upd["is_admin"] != null && (bool)upd["is_admin"] == true && (long)upd["member_id"] > 0)
                        {
                            db.peersGetMember(peer_id, (long)upd["member_id"]);
                            db.peersMemberSetPriority(peer_id, (long)upd["member_id"], 80);
                            db.peersGetForLead((long)upd["member_id"], true);
                        }
                    }
                }

                if (owner_id == 0 || is_admin == 0)
                {
                    Console.WriteLine("owner id = " + owner_id + " is admin = " + is_admin);
                    if (owner_id == 0)
                    {
                        if (peer_info["owner"] == "0")
                        {
                            Vk.MessagesSend("Ошибка активации #3. Возможно, создатель беседы вышел из конференции.");
                            return;
                        }
                    }
                    else if (is_admin == 0)
                    {
                        Vk.MessagesSend("Ошибка активации #2. Возможно, вы не выдали права администратора боту.");
                        return;
                    }
                    //return;
                }

                db.peersSetActive(peer_id, 1, invited_by, owner_id);
                db.peersGetMember(peer_id, owner_id);
                var time_red = db.timeGetForMysql(peer_info["date_reg"]);
                var time_vip = time_red.AddYears(1);
                db.peersSetVip(peer_id, db.timeGetForString(time_vip));
                if (owner_id != 0)
                {
                    db.peersMemberSetPriority(peer_id, owner_id, 100);
                }
                


                string keyboard = Vk.GenerateKeyboard(new string[] { "НАСТРОИТЬ" }, new string[] { "setup" }, new string[] { Vk.BUTTON_GREEN }, null, false, true, true);

                Vk.MessagesSend("Ваша конференция успешно активирована и бот готов к работе.<br>Всем администраторам беседы " +
                    "автоматически присвоена роль главного администратора.<br>Вы можете сразу настроить вашу конференцию нажав на кнопку ниже." +
                    "<br><br>Список доступных команд — vk.com/@fink_manager-aktualnye-komandy<br>Пробный VIP статус конференции действует до " + time_vip.ToString("g"), 1, 0, keyboard);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.INIT_BOT, Vk.m_from_id);
                db.peersGetForOwner(owner_id, true);
                Commands.syncOnePeer(Vk.m_peer_id);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_ping()
        {
            try
            {
                //var starttime = settings.GetMicroTime();
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "ping", 10))
                {
                    return;
                }
                
                Dictionary<string, string>? peer_info = db.peersGetPeer(Vk.m_peer_id);
               
                string average_request;
                string average_command;
                if (AdminInfo.average_request != null && AdminInfo.average_request.Count >= 1)
                {
                    decimal average_requestt = AdminInfo.average_request.Average();
                    average_request = Math.Round(average_requestt, 5).ToString() + " s. (" + AdminInfo.average_request.Count + " requests).";
                }
                else
                {
                    average_request = "0";
                }

                if (AdminInfo.average_command != null && AdminInfo.average_command.Count >= 1)
                {
                    decimal average_commandd = AdminInfo.average_command.Average();
                    average_command = Math.Round(average_commandd, 5).ToString() + " s. (" + AdminInfo.average_command.Count + " requests).";
                }
                else
                {
                    average_command = "0";
                }
                var dateUptime = settings.date_uptime;
                var dateTarget = DateTimeOffset.Now - dateUptime;


                Vk.MessagesSend("Average request: " + average_request + "<br>" +
                    "Average command: " + average_command + "<br>" +
                    "Uptime: " + setTimeOff.ToReadableString(dateTarget)); //var dateUptime = settings.date_uptime;
                //var finishtime = settings.GetMicroTime();
                //Console.WriteLine("last " + settings.getSecondsFromMicros(finishtime - starttime));

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_mtop()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "mtop", 2))
                {
                    return;
                }

                var buttons = Vk.GenerateKeyboard(new string[] { "сообщения", "слова", "команды",
                "нецензурные слова", "символы", "голосовые", "фотографии", "видеозаписи", "аудиозаписи", "стикеры" },
                        new string[] { "mtop mes", "mtop words", "mtop commands", "mtop obswords", "mtop symbols", "mtop voices",
                    "mtop photos", "mtop videos", "mtop audios", "mtop stickers" },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE,
                     Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE,
                     Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE },
                        new int[] { 0, 0, 0, 1, 1, 1, 2, 2, 2, 3 }, false, true, true);

                Cache cach = new();

                var args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    string text = "✉ Выберите пункт, по которому хотите отсортировать пользователей:<br>" +
                    "";
                    
                    var idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                    cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    return;
                }

                
                var last_mess = cach.Get<string>("last_message_" + Vk.m_peer_id.ToString());

                string param = "messages";
                string param_text = "Топ пользователей по сообщениям:<br>";
                if (args[0] == "mes")
                {

                }
                else if (args[0] == "words")
                {
                    param = "words";
                    param_text = "Топ пользователей по словам:<br>";
                }
                else if (args[0] == "commands")
                {
                    param = "commands";
                    param_text = "Топ пользователей по командам:<br>";
                }
                else if (args[0] == "obswords")
                {
                    param = "obscen_words";
                    param_text = "Топ пользователей по нецензурным словам:<br>";
                }
                else if (args[0] == "symbols")
                {
                    param = "symbols";
                    param_text = "Топ пользователей по символам:<br>";
                }
                else if (args[0] == "voices")
                {
                    param = "voices";
                    param_text = "Топ пользователей по голосовым сообщениям:<br>";
                }
                else if (args[0] == "photos")
                {
                    param = "photos";
                    param_text = "Топ пользователей по фотографиям:<br>";
                }
                else if (args[0] == "videos")
                {
                    param = "videos";
                    param_text = "Топ пользователей по видеозаписям:<br>";
                }
                else if (args[0] == "audios")
                {
                    param = "audios";
                    param_text = "Топ пользователей по аудиозаписям:<br>";
                }
                else if (args[0] == "stickers")
                {
                    param = "stickers";
                    param_text = "Топ пользователей по стикерам:<br>";
                }
                else
                {
                    string text = "✉ Выберите пункт, по которому хотите отсортировать пользователей:<br>" +
                    "";
                    var idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                    cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    return;
                }

                Dictionary<long, Dictionary<string, long>>? result = db.topMessagesGetPeer(Vk.m_peer_id, param);
                //Dictionary<long, Dictionary<string, long>>? result = db.topMessagesGetPeer(Vk.m_peer_id, param);
                if (result != null)
                {
                    if (result.Count < 1)
                    {
                        string textr = "✉ Статистика данного типа не найдена.<br>" +
                    "";
                        var idmes = await Vk.MessagesSendMassive(textr, new List<long>() { Vk.m_peer_id }, buttons);
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                        return;
                    }
                    string text = param_text + "<br>";
                    long i = 1;
                    List<long> targetIds = new();
                    foreach (var item in result)
                    {
                        if (item.Key <= 0 || item.Value[param] <= 0)
                        {
                            continue;
                        }
                        targetIds.Add(item.Key);
                    }
                    if (targetIds.Count <= 0)
                    {
                        if (last_mess == null || last_mess == "")
                        {
                            var idmes = await Vk.MessagesSendMassive("К сожалению, такой статистики не найдено.", new List<long>() { Vk.m_peer_id }, buttons);
                            cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                        }
                        else
                        {
                            Vk.MessagesEdit("К сожалению, такой статистики не найдено.", Vk.m_peer_id, buttons, true, "", long.Parse(last_mess));
                            cach.Set("last_message_" + Vk.m_peer_id.ToString(), last_mess);
                        }
                        return;
                    }
                    var nicklist = await Vk.UserGetNameUrls(targetIds.ToArray());
                    foreach (var item in result)
                    {
                        if (item.Key <= 0 || item.Value[param] <= 0)
                        {
                            continue;
                        }
                        text += $"{i}. {nicklist[item.Key.ToString()]} — {item.Value[param]}<br>";
                        i++;
                    }

                    if (Vk.is_callbackButton)
                    {
                        var nickCallback = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                        text += "<br><br>Команду обновил: " + nickCallback[Vk.m_from_id.ToString()];
                    }

                    if (last_mess == null || last_mess == "")
                    {
                        var idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    }
                    else
                    {
                        Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_mess));
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), last_mess);
                    }
                    //Vk.MessagesEdit(text, Vk.m_peer_id,);
                }
                else
                {
                    if (last_mess == null || last_mess == "")
                    {
                        var idmes = await Vk.MessagesSendMassive("К сожалению, такой статистики не найдено.", new List<long>() { Vk.m_peer_id }, buttons);
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), idmes.ToString());
                    }
                    else
                    {
                        Vk.MessagesEdit("К сожалению, такой статистики не найдено.", Vk.m_peer_id, buttons, true, "", long.Parse(last_mess));
                        cach.Set("last_message_" + Vk.m_peer_id.ToString(), last_mess);
                    }
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_online()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "online", 30))
                {
                    return;
                }

                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "online"))
                {
                    return;
                }

                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
                {
                    { "peer_id", Vk.m_peer_id.ToString() },
                    { "fields", "online" },
                    { "extended", "1" },
                };

                var answer_vk = await Vk.VkAPI(method, paramesd);
                if (answer_vk["error"] != null || answer_vk["response"]["items"] == null)
                {
                    Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                    return;
                }
                // app3682744 - IOS
                var onlinesUser = new Dictionary<long, string>();

                var items = answer_vk["response"]["profiles"];
                foreach (var item in items)
                {
                    if (item["online"] == null || item["online"].ToString() == "0")
                    {
                        continue;
                    }
                    var targetDevice = "🖥 (полная версия сайта)<br>";
                    if (item["online_mobile"] != null)
                    {
                        if (item["online_app"] == null)
                        {
                            targetDevice = "☎ (мобильная версия сайта)<br>";
                        }
                    }

                    if (item["online_app"] != null)
                    {
                        if (item["online_app"].ToString() == "3682744")
                        {
                            targetDevice = "☎ (🍎 iPad)<br>";
                        }
                        else if (item["online_app"].ToString() == "3140623")
                        {
                            targetDevice = "☎ (🍎 iPhone)<br>";
                        }
                        else if (item["online_app"].ToString() == "3140623")
                        {
                            targetDevice = "☎ (🍎 iOS)<br>";
                        }
                        else if (item["online_app"].ToString() == "2274003")
                        {
                            targetDevice = "☎ (⚙ Android)<br>";
                        }
                        else if (item["online_app"].ToString() == "3697615")
                        {
                            targetDevice = "☎ (⚙ Windows desktop)<br>";
                        }
                        else if (item["online_app"].ToString() == "3502557")
                        {
                            targetDevice = "☎ (⚙ Windows phone)<br>";
                        }
                        else if (item["online_app"].ToString() == "2685278")
                        {
                            targetDevice = "☎ (⚙ Kate Mobile)<br>";
                        }
                        else if (item["online_app"].ToString() == "1")
                        {
                            targetDevice = "☎ (⚙ Android)<br>";
                        }
                        else
                        {
                            targetDevice = "☎ (client " + item["online_app"] + ")<br>";
                        }
                    }

                    onlinesUser.Add(long.Parse(item["id"].ToString()), targetDevice);
                }

                if (onlinesUser.Count <= 0)
                {
                    Vk.MessagesSend("К сожалению, сейчас нет пользователей в сети.");
                    return;
                }

                List<long> targetUserGet = new();
                foreach (var item in onlinesUser)
                {
                    targetUserGet.Add(item.Key);
                }

                var users_names_vk = await Vk.UsersGetVkInfo(targetUserGet.ToArray());
                string text = "Список пользователей в сети:<br><br>";
                int i = 0;
                foreach (var item in onlinesUser)
                {
                    i++;
                    if (users_names_vk.ContainsKey("id" + item.Key))
                    {
                        text += i + ". [id" + item.Key + "|" + users_names_vk["id" + item.Key].first_name
                        + " " + users_names_vk["id" + item.Key].last_name + "] — " + item.Value;
                    }
                    else
                    {
                        if (item.Key <= 0)
                        {
                            text = text + "— [club" + item.Key.ToString().Substring(1) + "|Сообщество] — " + item.Value;
                        }
                        else
                        {
                            text = text + "— [id" + item.Key + "|Пользователь] — " + item.Value;
                        }
                    }
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_rules()
        {
            try
            {
                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "rules", 30))
                {
                    return;
                }

                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 0, "rules"))
                {
                    return;
                }

                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (peerInfo["rules_text"] == "0")
                {

                    Vk.MessagesSend("Правила беседы не установлены. Используйте !setrules для установки.");
                    return;
                }

                string text = "Правила беседы, установленные администратором беседы:<br><br>" + peerInfo["rules_text"] + "<br><br>" +
                    "Чтобы удалить правила - используйте команду !setrules 0";

                var plainInfo = TextFormatter.FromMarkdown(text);

                Vk.MessagesSend(plainInfo.PlainText, 1, 0, "", false, "", plainInfo.FormatData.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sban()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_fakecmd == 0)
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                if (args[0] == "" || args[0] == null || args[0] == Vk.m_from_id.ToString()) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["ban"]);
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                int days = 0;
                string reason = "не указана.";

                if (args.Length >= 2)
                {
                    var explodes = args[1].Split(" ");
                    if (explodes.Length >= 2)
                    {
                        try
                        {
                            var isNumeric = int.TryParse(explodes[0], out days);
                            if (isNumeric)
                            {
                                if (days <= 0 || days >= 365)
                                {
                                    days = 0;
                                }
                                string[] sas_args = await cmdChecker.getArguments("/ban " + args[1], new string[] { "int", "text" });
                                if (sas_args[1] != null && sas_args[1] != "")
                                {
                                    reason = sas_args[1];
                                }
                            }
                            else
                            {
                                if (explodes[0] != null && explodes[0] != "")
                                {
                                    reason = args[1];
                                }
                            }


                        }
                        catch
                        {
                            days = 0;
                        }
                    }
                    else
                    {
                        if (args[1] != null && args[1] != "")
                        {
                            reason = args[1];
                        }
                    }
                }

                Dictionary<string, string>? Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));

                if (Target_User == null)
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.<br><br>" +
                            "Команду выполнил: " + nick_admin);
                        return;
                    }
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }
                string nickname = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(Target_User["user_id"]));
                if (db.bansGetBan(Vk.m_peer_id, long.Parse(args[0])) != null)
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("⛔ " + nickname + " уже находится в списке заблокированных.<br><br>" +
                            "Команду выполнил: " + nick_admin);
                        return;
                    }
                    Vk.MessagesSend("⛔ " + nickname + " уже находится в списке заблокированных.");
                    return;
                }
                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                

                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                

                string ban_time = null;
                string ban_text = "перманентно";
                if (days != 0)
                {
                    ban_time = db.timeGetForString(DateTimeOffset.Now.AddDays(days));
                    ban_text = "до " + DateTimeOffset.Now.AddDays(days).ToString("g");
                }



                string text = "";

                /*
                 */
                //Vk.KickUser(Vk.m_peer_id, long.Parse(Target_User["user_id"]));

                text = "⛔ " + nickname + " получил блокировку.<br><br>Причина: " + reason + "<br>" +
                        "Срок блокировки: " + ban_text + "<br>" +
                        "Заблокировал: " + nick_admin;
                Vk.MessagesSend(text, 1, 0);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

    }

    class helper_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;

        public helper_cmds(vk vks, Database dbs, settings set)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
        }

        public async void command_kick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "kick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "kick", 10))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });

                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "" && args[0] != "0" && args[0] != UserInfo["user_id"])
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, false);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["kick"]);
                    return;
                }
                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                string nickname = "Пользователь";
                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                if (Target_User != null && long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend($"{nameWe} не можете исключить участника, роль которого выше или равна вашей."); 
                    return;
                }
                if (Target_User != null && Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                    {
                        var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                        var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                        Vk.MessagesSend($"{nameWe} не можете исключить участника, поскольку у него иммунитет.<br><br>" +
                            $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] + 
                            $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                            $"<br>Снять иммунитет: /gm @ссылка");
                        return;
                    }
                }

                if (Target_User != null)
                {
                    nickname = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(Target_User["user_id"]));
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        nickname = $"[public{args[0].Substring(1)}|Сообщество]";
                    }
                    else
                    {
                        nickname = $"[id{args[0]}|Пользователь]";
                    }
                }


                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                string reason = "не указана.";

                if (args[1] != "")
                {
                    reason = args[1];
                }

                string text = "";

                List<string> buttons_names = new List<string>()
                {
                    "Заблокировать"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "ban id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                string buttons = "";
                JObject result_vk = await Vk.KickUser(Vk.m_peer_id, long.Parse(args[0]));
                if (result_vk["error"] != null || (result_vk["response"] != null && result_vk["response"].ToString() == "False"))
                {
                    text = nickname + " не состоит в конференции, либо имеет права Администратора непосредственно в беседе.";
                }
                else
                {
                    buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);
                    if (Target_User != null && Target_User["mute"] != "")
                    {
                        db.peersMemberSetMute(Vk.m_peer_id, long.Parse(Target_User["user_id"]), "");
                        text = "⚠ У [id" + Target_User["user_id"] + "|пользователя] была блокировка чата, она автоматически снята.<br><br>";
                    }
                    text = text + nickname + " был исключён из конференции.<br>Причина: " + reason + "<br>" +
                        "Исключил: " + nick_admin;
                    Vk.MessagesSend(text, 1, 0, buttons);
                    if (peerInfo["set_exitremovenick"] == "1")
                    {
                        db.peersMemberSetNickName(Vk.m_peer_id, long.Parse(args[0]), null);
                    }
                    db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), 0);
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_KICK, Vk.m_from_id, long.Parse(args[0]), "исключил");
                    db.peerGetNickNames(Vk.m_peer_id, true);
                    var warns_database = db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), false, 3);
                    if (warns_database != null)
                    {
                        foreach (var item in warns_database)
                        {
                            if (item.deleted == 0)
                            {
                                db.peerWarnsDeleteWarn((int)item.id);
                            }
                            
                        }
                        db.peerMembersSetWarns(Vk.m_peer_id, long.Parse(args[0]), 0);
                    }
                    

                    

                    // исключение из группы
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo["set_kickexitgroup"] != "0" && PeerInfo["group"] != "0" && PeerInfo["access_token"] != "")
                    {
                        var method = "groups.removeUser";
                        var parames = new Dictionary<string, string>();
                        parames.Add("group_id", PeerInfo["group"]);
                        parames.Add("user_id", args[0]);
                        parames.Add("access_token", SysUtils.DecryptString(PeerInfo["access_token"]));
                        var JObject = await Vk.VkAPIs(method, parames);
                        if (!JObject.ContainsKey("response") || JObject.ContainsKey("error"))
                        {
                            if (JObject.ContainsKey("error"))
                            {
                                if (JObject["error"]["error_code"] != null)
                                {
                                    var code = JObject["error"]["error_code"];
                                    if (code.ToString() == "5")
                                    {
                                        //db.peersSetAccessToken(Vk.m_peer_id, "");
                                        Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен.");
                                    }
                                }
                            }
                            db.peersSetAccessToken(Vk.m_peer_id, "");
                        }
                    }

                    // --------------------

                    return;
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_stats()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "stats", false))
                {
                    if (!db.UserIsVip(Vk.m_from_id))
                    {
                        cmdChecker.CommandsCheck(UserInfo, 20, "stats", true);
                        return;
                    }
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "stats", 10))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                Dictionary<string, string>? Target_User_Global = null;

                long targetId = 0;
                try
                {
                    if (args[0] != null)
                        targetId = long.Parse(args[0]);
                }
                catch
                {

                }

                if (args[0] != null)
                {
                    if (targetId == 0)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                        return;
                    }
                    Target_User = db.peersGetMember(Vk.m_peer_id, targetId, false, false);
                    Target_User_Global = db.usersGetUser(targetId);
                }
                else
                {
                    Target_User = UserInfo;
                    Target_User_Global = db.usersGetUser(Vk.m_from_id);
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string status = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                string warns = Target_User["warns"] + "/3";
                string nickname = "";
                string vip_status = "";

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name;
                    }
                    else
                    {
                        nickname = "Сообщество";
                    }
                }
                else
                {
                    nickname = Target_User["nick"];
                }
                string mute = "";
                if (Target_User["mute"] == "")
                {
                    mute = "нет";
                }
                else
                {
                    mute = "есть";
                }

                string vip_time = "∞";

                if (Target_User_Global["vip_type"] == "0")
                {
                    vip_status = "нет";
                }
                else
                {
                    if (Target_User_Global["vip"] != "")
                    {
                        DateTimeOffset time = db.timeGetForMysql(Target_User_Global["vip"]);
                        vip_time = time.ToString("f");
                    }


                    vip_status = "𝑽𝑰𝑷 — " + Target_User_Global["vip_type"];
                }

                var nick_one = "[id" + Target_User["user_id"] + "|пользователе]";
                if (long.Parse(Target_User["user_id"]) < 0)
                {
                    nick_one = "[club" + Target_User["user_id"].Substring(1) + "|сообществе]";
                }

                string helper = "";
                string helperMark = "";
                if (settings.OWNER_IDS.ContainsKey(long.Parse(Target_User["user_id"])))
                {
                    if (settings.OWNER_IDS[long.Parse(Target_User["user_id"])].admin == 1)
                    {
                        helper = $"🐩 SPONSOR FINK №{settings.OWNER_IDS[long.Parse(Target_User["user_id"])].id.ToString()}<br>";
                    }
                    else
                    {
                        helper = $"🐩 Агент поддержки №{settings.OWNER_IDS[long.Parse(Target_User["user_id"])].id.ToString()}<br>" +
                        $"📊 Рассмотрено тикетов: {settings.OWNER_IDS[long.Parse(Target_User["user_id"])].answers}<br>";
                        if (settings.OWNER_IDS.ContainsKey(long.Parse(Target_User["user_id"])) == true && settings.OWNER_IDS[long.Parse(Target_User["user_id"])].answers != 0)
                        {

                            helperMark = "👽 Средняя оценка ответов: " +
                                settings.OWNER_IDS[long.Parse(Target_User["user_id"])].marks /
                                settings.OWNER_IDS[long.Parse(Target_User["user_id"])].answers + "/5 ⭐<br><br>";
                        }
                    }
                }




                string inviter_text = "—";
                try
                {
                    if (Target_User["invited_by"] != "0")
                    {
                        var userInviter = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["invited_by"]) });
                        inviter_text = userInviter[Target_User["invited_by"]];
                    }
                }
                catch
                {

                }
                 

                var targetMessagesStat = db.statsUserGetMessagesForCacheAndDb(Vk.m_peer_id, long.Parse(Target_User["user_id"]));

                var targetMessStat = "";
                if (targetMessagesStat.ContainsKey("messages"))
                {
                    targetMessStat = "<br>✍ Сообщений отправлено: " + targetMessagesStat["messages"];
                }

                string text = "🔍 Информация о " + nick_one + ":<br><br>" +
                    "🗣 Статус: " + status + "<br>" +
                    helper + helperMark +
                    "⚠ Предупреждений: " + warns + "<br>" +
                    "📄 Никнейм: " + nickname + "<br>" +
                    "🚧 Блокировка чата: " + mute + "<br>" +
                    "📅 Дата появления в чате: " + db.timeGetForMysql(Target_User["date_reg"]).ToString("g") + "<br><br>" +
                    "📋 Глобальная информация:<br>" +
                    "💎 VIP статус: " + vip_status + "<br>" +
                    "💎 Действует до: " + vip_time + "" +
                    targetMessStat + "<br>" +
                    "👫 Пригласил(а): " + inviter_text + "<br>" + 
                    "⚙ ID: " + Target_User["user_id"];
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_unmute()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "unmute"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "unmute", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null || args[0] == Vk.m_from_id.ToString()) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["unmute"]);
                    return;
                }

                var Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));
                Dictionary<string, string>? User_Info = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                string nick = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));

                string nick_adm = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["mute"] == "")
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend(nick + " не имеет блокировки чата.<br><br>Команду выполнил: " + nick_adm);
                        return;
                    }
                    Vk.MessagesSend(nick + " не имеет блокировки чата.");
                    return;
                }

                if (long.Parse(User_Info["priority"]) <= long.Parse(Target_User["priority"]))
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Вы не можете разблокировать чат участнику, роль которого выше или равна вашей.<br><br>Команду выполнил: " + nick_adm);
                        return;
                    }
                    Vk.MessagesSend("Вы не можете разблокировать чат участнику, роль которого выше или равна вашей.");
                    return;
                }

                string text = nick + " больше не имеет блокировки чата.<br>" +
                    "Снял блокировку: " + nick_adm;
                db.peersMemberSetMute(Vk.m_peer_id, long.Parse(args[0]), "");
                Vk.MessagesSend(text);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_UNMUTE, Vk.m_from_id, long.Parse(args[0]), "снял блокировку чата");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_mute()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "mute"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "mute", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "int", "text" });
                if (args[0] == "" || args[0] == null || args[1] == null || args[1] == "" || args[0] == Vk.m_from_id.ToString()) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["mute"]);
                    return;
                }

                Dictionary<string, string>? Target_User = null;
                if (args[0] != null)
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));
                }

                string nick_adm = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                Dictionary<string, string>? User_Info = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);

                if (long.Parse(User_Info["priority"]) <= long.Parse(Target_User["priority"]))
                {
                    Vk.MessagesSend("Вы не можете заблокировать чат участнику, роль которого выше или равна вашей.");
                    return;
                }

                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                if (Target_User != null && Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                    {
                        var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                        var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                        Vk.MessagesSend($"{nameWe} не можете выдать мут участнику, поскольку у него иммунитет.<br><br>" +
                            $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                            $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                            $"<br>Снять иммунитет: /gm @ссылка");
                        return;
                    }
                }

                if (args[2] != "" && (args[2] == "минут" || args[2] == "мин" || args[2] == "м" || args[2] == "m" || args[2] == "mins" 
                    || args[2] == "min" || args[2] == "minute" || args[2] == "minutes"))
                {
                    var tmp = new List<string>(args);
                    tmp.RemoveAt(2);
                    args = tmp.ToArray();
                } else if (args[2] != "" && (args[2] == "часов" || args[2] == "час" || args[2] == "ч" || args[2] == "h" || args[2] == "hour"
                    || args[2] == "hours" || args[2] == "hourse" || args[2] == "hourses"))
                {
                    try
                    {
                        args[1] = (long.Parse(args[1]) * 60).ToString();
                    }
                    catch
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["mute"]);
                        return;
                    }
                    var tmp = new List<string>(args);
                    tmp.RemoveAt(2);
                    args = tmp.ToArray();
                }
                //мин, м, min, m, mins, minute

                if (long.Parse(args[1]) >= 10000)
                {
                    Vk.MessagesSend("Максимально допустимое время — 10000 минут.");
                    return;
                }

                string reason = "не указана";
                if (args.Length >= 3)
                {
                    if (args[2] != "")
                    {
                        reason = args[2];
                    }
                    
                }

                string nick = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));
                
                string do_text = "сообщения пользователя будут удаляться.";
                var Peer_info = db.peersGetPeer(Vk.m_peer_id);
                if (Peer_info.ContainsKey("set_typemute") && Peer_info["set_typemute"] == "1")
                {
                    do_text = "пользователь будет исключен из конференции.";
                }


                DateTimeOffset time = db.timeGetDateTimeOffset().AddMinutes(long.Parse(args[1]));

                string text_time = time.ToString("f");
                string text = nick + " получил(а) блокировку чата. " +
                    "В случае нарушения — " + do_text +
                    "<br><br>Причина: " + reason + "<br>" +
                    "Выдал: " + nick_adm + "<br>" +
                    "Дата окончания блокировки: " + text_time;


                string time_data = db.timeGetForString(time);
                db.peersMemberSetMute(Vk.m_peer_id, long.Parse(args[0]), time_data);

                List<string> buttons_names = new List<string>()
                {
                    "Отмена"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "unmute id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_GREEN
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);

                Vk.MessagesSend(text, 1, 0, buttons);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_MUTE, Vk.m_from_id, long.Parse(args[0]), "выдал блокировку чата", reason);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_warn()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "warn"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "warn", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                if (args[0] == "" || args[0] == null || args[0] == Vk.m_from_id.ToString()) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["warn"]);
                    return;
                }

                string reason = "не указана";
                if (args[1] != "")
                {
                    reason = args[1];
                }

                var Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));

                var User_Info = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);

                if (long.Parse(User_Info["priority"]) <= long.Parse(Target_User["priority"]))
                {
                    Vk.MessagesSend("Вы не можете выдать предупреждение участнику, роль которого выше или равна вашей.");
                    return;
                }

                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                if (Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                    {
                        var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                        var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                        Vk.MessagesSend($"{nameWe} не можете выдать предупреждение участнику, поскольку у него иммунитет.<br><br>" +
                            $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                            $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                            $"<br>Снять иммунитет: /gm @ссылка");
                        return;
                    }
                }

                var warns = long.Parse(Target_User["warns"]);
                string text = "";
                var nick_user = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));
                var nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                db.peersAddWarn(Vk.m_peer_id, long.Parse(args[0]), Vk.m_from_id, reason);
                db.peerMembersSetWarns(Vk.m_peer_id, long.Parse(args[0]), warns + 1);
                string buttons = "";
                if (warns >= 2)
                {
                    if (long.Parse(Target_User["priority"]) > 0)
                    {
                        var role_user = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                        text = nick_user + " (" + role_user + ") получил предупреждение (3/3) и был лишён роли.<br>Причина: " + reason + "<br>" +
                        "Выдал: " + nick_admin;
                        db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), 0);
                        db.peerWarnsClear(Vk.m_peer_id, long.Parse(args[0]));
                    }
                    else
                    {
                        // ИСКЛЮЧЕНИЕ
                        text = nick_user + " получил предупреждение (3/3) и был исключён из беседы.<br>Причина: " + reason + "<br>" +
                            "Выдал: " + nick_admin;
                        db.peerWarnsClear(Vk.m_peer_id, long.Parse(args[0]));

                        JObject result = await Vk.KickUser(Vk.m_peer_id, long.Parse(args[0]));
                        if (result.ContainsKey("error"))
                        {
                            text = nick_user + " получил предупреждение (3/3), но бот не смог исключить участника из конференции.";
                        }
                        else
                        {
                            db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), 0);
                            db.peersMemberSetNickName(Vk.m_peer_id, long.Parse(args[0]), null);

                            // исключение из группы
                            var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                            if (PeerInfo["set_kickexitgroup"] != "0" && PeerInfo["group"] != "0" && PeerInfo["access_token"] != "")
                            {
                                var method = "groups.removeUser";
                                var parames = new Dictionary<string, string>();
                                parames.Add("group_id", PeerInfo["group"]);
                                parames.Add("user_id", args[0]);
                                parames.Add("access_token", SysUtils.DecryptString(PeerInfo["access_token"]));
                                var JObject = await Vk.VkAPIs(method, parames);
                                if (!JObject.ContainsKey("response") || JObject.ContainsKey("error"))
                                {
                                    if (JObject.ContainsKey("error"))
                                    {
                                        if (JObject["error"]["error_code"] != null)
                                        {
                                            var code = JObject["error"]["error_code"];
                                            if (code.ToString() == "5")
                                            {
                                                //db.peersSetAccessToken(Vk.m_peer_id, "");
                                                Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен.");
                                            }
                                        }
                                    }
                                    db.peersSetAccessToken(Vk.m_peer_id, "");
                                }
                            }

                            // --------------------
                        }
                    }
                }
                else
                {
                    List<string> buttons_names = new List<string>()
                    {
                        "Отмена"
                    };
                        List<string> buttons_commands = new List<string>()
                    {
                        "unwarn id" + args[0]
                    };
                        List<string> buttons_colors = new List<string>()
                    {
                        Vk.BUTTON_GREEN
                    };

                    buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray());
                    warns++;
                    text = nick_user + " получил предупреждение (" + warns + "/3).<br>Причина: " + reason + "<br>" +
                        "Выдал: " + nick_admin;
                }
                Vk.MessagesSend(text, 1, 0, buttons);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_WARN, Vk.m_from_id, long.Parse(args[0]), "выдал предупреждение", reason);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_unwarn()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "unwarn"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "unwarn", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null || args[0] == Vk.m_from_id.ToString()) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["unwarn"]);
                    return;
                }

                var Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));

                if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                {
                    Vk.MessagesSend("Вы не можете снять предупреждение участнику, роль которого выше или равна вашей.");
                    return;
                }

                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                if (Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                    {
                        var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                        var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                        Vk.MessagesSend($"{nameWe} не можете снять предупреждение участнику, поскольку у него иммунитет.<br><br>" +
                            $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                            $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                            $"<br>Снять иммунитет: /gm @ссылка");
                        return;
                    }
                }

                var warns = long.Parse(Target_User["warns"]);
                if (warns <= 0)
                {
                    var warns_databasetwo = db.peerGetWarnsListActive(Vk.m_peer_id, long.Parse(args[0]), 20);
                    if (warns_databasetwo != null)
                    {
                        foreach (var item in warns_databasetwo)
                        {
                            if (item.deleted != 1)
                            {
                                db.peerWarnsDeleteWarn((int)item.id);
                            }

                        }
                        db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), true, 200);
                    }
                    Vk.MessagesSend("У пользователя нет предупреждений.");
                    return;
                }

                string text = "";
                var nick_user = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));
                var nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                //db.peersAddWarn(Vk.m_peer_id, long.Parse(args[0]), Vk.m_from_id, reason);
                var warns_database = db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), true, 1);
                foreach (var item in warns_database)
                {
                    if (item.deleted != 1)
                    {
                        db.peerWarnsDeleteWarn((int)item.id);
                        break;
                    }
                    
                }
                
                db.peerMembersSetWarns(Vk.m_peer_id, long.Parse(args[0]), warns - 1);

                db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), true, 200);


                text = nick_admin + " снял предупреждение " + nick_user + "<br>" +
                    "Количество предупреждений: " + (warns - 1).ToString() + "/3";
                Vk.MessagesSend(text);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_UNWARN, Vk.m_from_id, long.Parse(args[0]), "снял предупреждение");
                
                db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), true, 1000);
                db.peerGetWarnsMans(Vk.m_peer_id, true);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getwarn()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "getwarn"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getwarn", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getwarn"]);
                    return;
                }

                var Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));

                var nick_user = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));

                var warns = long.Parse(Target_User["warns"]);
                if (warns <= 0)
                {
                    var warns_databasetwo = db.peerGetWarnsListActive(Vk.m_peer_id, long.Parse(args[0]), 20);
                    if (warns_databasetwo != null)
                    {
                        foreach (var item in warns_databasetwo)
                        {
                            if (item.deleted != 1)
                            {
                                db.peerWarnsDeleteWarn((int)item.id);
                            }

                        }
                        db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), true, 200);
                    }
                    Vk.MessagesSend(nick_user + " не имеет предупреждений.");
                    return;
                }
                
                string text = nick_user + " имеет предупреждения.<br><br>";
                var warns_database = db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), false, 20);
                long iteration = 1;
                foreach (var item in warns_database)
                {
                    if (item.deleted != 1)
                    {
                        var nick_admin = db.peersGetNickUrl(Vk.m_peer_id, (int)item.admin_id);
                        text = text + iteration + ". Выдал: " + nick_admin + " | " + item.reason + " | " + item.date_created + "<br>";
                        iteration++;
                    }
                    //db.peerWarnsDeleteWarn((int)item.id);
                }
                if (iteration == 1)
                {
                    db.peerMembersSetWarns(Vk.m_peer_id, long.Parse(args[0]), 0);
                    Vk.MessagesSend(nick_user + " не имеет предупреждений.");
                    return;
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_warnhistory()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "warnhistory"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "warnhistory", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["warnhistory"]);
                    return;
                }

                var nick_user = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));


                string text = nick_user + " имел предупреждения.<br><br>";
                var warns_database = db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), false, 20);
                if (warns_database.Count <= 0)
                {
                    Vk.MessagesSend(nick_user + " не имел предупреждений.");
                    return;
                }

                var targetPeerMember = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, false);
                if (targetPeerMember != null)
                {
                    if (targetPeerMember["warns"] == "0")
                    {
                        var warns_database2 = db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), false, 3);
                        foreach (var item3 in warns_database.ToList())
                        {
                            if (item3.deleted != 0)
                            {
                                db.peerWarnsDeleteWarn((int)item3.id);
                                warns_database.Remove(item3);
                                item3.deleted = 1;
                                warns_database.Add(item3);
                            }
                        }
                    }
                }

                long iteration = 1;
                foreach (var item in warns_database.ToList())
                {
                    var nick_admin = db.peersGetNickUrl(Vk.m_peer_id, (int)item.admin_id);
                    string deleted = "";
                    if (item.deleted >= 1)
                    {
                        deleted = "🚫";
                    }
                    else
                    {
                        deleted = "✅";
                    }
                    text = text + iteration + ". " + deleted + " Выдал: " + nick_admin + " | " + item.reason + " | " + item.date_created + "<br>";
                    iteration++;
                    //db.peerWarnsDeleteWarn((int)item.id);
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_warnlist ()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "warnlist"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "warnlist", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });
                /*if (args[0] == "" || args[0] == null) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["warnlist"]);
                    return;
                }*/

                //var nick_user = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));


                //string text = nick_user + " имел предупреждения.<br><br>";

                var warns_database1 = db.peerGetWarnsMans(Vk.m_peer_id);
                if (warns_database1.Count <= 0)
                {
                    Vk.MessagesSend("Нет пользователей с предупреждениями.");
                    return;
                }


                List<long> userget = new();
                var warns_database = warns_database1;
                foreach (var item in warns_database1.ToList())
                {
                    var targetPeerMember = db.peersGetMember(Vk.m_peer_id, (long)item.user_id, false, false);
                    if (targetPeerMember != null)
                    {
                        if (targetPeerMember["warns"] == "0")
                        {
                            var warns_database2 = db.peerGetWarnsList(Vk.m_peer_id, (long)item.user_id, false, 3);
                            foreach (var item3 in warns_database2.ToList())
                            {
                                if (item3.deleted != 0)
                                {
                                    db.peerWarnsDeleteWarn((int)item3.id);
                                }
                            }
                            warns_database.Remove(item);
                            continue;
                        }
                    }
                    userget.Add((long)item.user_id);
                }

                long[] userids = new long[userget.Count()];
                long iss = 0;
                foreach (var item in userget)
                {
                    userids[iss] = item;
                    iss++;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(userids);


                string text = "Список пользователей с предупреждениями:<br>";
                long i = 1;

                Dictionary<long, List<warns_list>> target_warn_count = new();
                foreach (var item in warns_database)
                {
                    if (target_warn_count.ContainsKey((long)item.user_id))
                    {
                        target_warn_count[(long)item.user_id].Add(item);
                    }
                    else
                    {
                        target_warn_count.Add((long)item.user_id, new List<warns_list>() { item });
                    }
                }


                List<long> usersWarns = new();
                long iteration = 0;
                foreach (var item in warns_database)
                {
                    if (usersWarns.Contains((long)item.user_id))
                    {
                        continue;
                    }



                    usersWarns.Add((long)item.user_id);
                    var nick_admin = db.peersGetNickUrl(Vk.m_peer_id, (long)item.user_id);
                    long target_id = (long)item.user_id;
                    //text = text + iteration + ". Выдал: " + nick_admin + " | " + item.reason + " | " + item.date_created + "<br>";
                    iteration++;

                    long count_target_count = 0;

                    if (target_warn_count.ContainsKey(target_id))
                    {
                        count_target_count = target_warn_count[target_id].Count();
                    }

                    

                    if (users_names_vk.ContainsKey("id" + target_id))
                    {
                        if (target_id < 0)
                        {
                            text = text + iteration + ". [club" + target_id.ToString().Substring(1) + "|" + users_names_vk["id" + target_id].first_name + " " +
                                users_names_vk["id" + target_id].last_name + "] — " + count_target_count + "/3<br>";
                        }
                        else
                        {
                            text = text + iteration + ". [id" + target_id + "|" + users_names_vk["id" + target_id].first_name + " " +
                                users_names_vk["id" + target_id].last_name + "] — " + count_target_count + "/3<br>";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            text = text + iteration + ". [club" + target_id.ToString().Substring(1) + "|Сообщество] — " + count_target_count + "/3<br>";
                        }
                        else
                        {
                            text = text + iteration + ". [id" + target_id + "|Пользователь] — " + count_target_count + "/3<br>";
                        }
                    }
                    //db.peerWarnsDeleteWarn((int)item.id);
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_chatinfo()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "chatinfo"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "chatinfo", 5))
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                string vip = "отсутствует";
                if (db.PeerIsVip(PeerInfo))
                {
                    var vip_time = db.timeGetForMysql(PeerInfo["vip"]);
                    vip = "до " + vip_time.ToString("g") + " (подробнее — vk.cc/)";//https://vk.com/@fink_manager-aktualnye-komandy?anchor=vip-komandy
                }
                var OwnerNick = await Vk.GetUrlName(long.Parse(PeerInfo["owner"]));
                if (long.Parse(PeerInfo["owner"]) < 0)
                {
                    OwnerNick = "[club" + PeerInfo["owner"].Substring(1) + "|Сообщество]";
                }
                string text = "🔍 Информация о беседе:<br><br>" +
                    "⚠ ID: " + Vk.m_chat_id + "<br>" +
                    "🔱 Создатель чата: " + OwnerNick + "<br>" +
                    "👑 VIP статус: " + vip;
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_notmentions()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "notmention"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "notmention", 5))
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                var TargetUser = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id, false);
                if (TargetUser["no_mention"] == "1")
                {
                    Vk.MessagesSend("Теперь вы будете получать оповещения при вызове.");
                    db.peerMembersSetNoMention(Vk.m_peer_id, Vk.m_from_id, false);
                }
                else
                {
                    Vk.MessagesSend("Бот больше не будет Вас оповещать при вызове.");
                    db.peerMembersSetNoMention(Vk.m_peer_id, Vk.m_from_id, true);
                }

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getban()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "getban"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getban", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getban"]);
                    return;
                }
                var nick_user = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(args[0]));

                var BanInfo = db.bansGetBan(Vk.m_peer_id, long.Parse(args[0]));
                if (BanInfo == null || BanInfo.Count <= 0)
                {
                    Vk.MessagesSend(nick_user + " не заблокирован.");
                    return;
                }
                string time_ban = "перманентно";
                if (BanInfo["date_unban"] != "")
                {
                    var ban_time = db.timeGetForMysql(BanInfo["date_unban"]);
                    time_ban = "до " + ban_time.ToString("g");
                }

                string time_giveban = "неизвестно";
                if (BanInfo["date_ban"] != "")
                {
                    var ban_times = db.timeGetForMysql(BanInfo["date_ban"]);
                    time_giveban = ban_times.ToString("g");
                }

                var AdminNick = await Vk.GetUrlName(long.Parse(BanInfo["admin_id"]));
                if (long.Parse(BanInfo["admin_id"]) < 0)
                {
                    AdminNick = "[club" + BanInfo["admin_id"].Substring(1) + "|Сообщество]";
                }

                List<string> buttons_names = new List<string>()
                {
                    "Разблокировать"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "unban id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_GREEN
                };
                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);

                string text = "🔍 Информация о блокировке:<br><br>" +
                    "🐩 " + nick_user + " находится в списке заблокированных.<br>" +
                    "⚠ Заблокировал: " + AdminNick + "<br>" +
                    "🚫 Дата блокировки: " + time_giveban + "<br>" +
                    "🚫 Срок блокировки: " + time_ban + "<br>" +
                    "💬 Причина: " + BanInfo["reason"];
                Vk.MessagesSend(text, 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getnick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "getnick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getnick", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getnick"]);
                    return;
                }

                Dictionary<string, string>? TargetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, false);

                if (TargetUser == null)
                {
                    string d_text = "Никнейм [id" + args[0] + "|пользователя] не установлен.";
                    if (long.Parse(args[0]) < 0)
                    {
                        d_text = "Никнейм [club" + args[0].Substring(1) + "|сообщества] не установлен.";
                    }
                    Vk.MessagesSend(d_text);
                    return;
                }

                string text = "Никнейм [id" + args[0] + "|пользователя] не установлен.";
                string buttons = "";
                if (TargetUser["nick"] != "" && TargetUser["nick"] != null)
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        text = "Никнейм [club" + args[0].Substring(1) + "|сообщества]: " + TargetUser["nick"];
                    }
                    else
                    {
                        text = "Никнейм [id" + args[0] + "|пользователя]: " + TargetUser["nick"];
                    }
                    List<string> buttons_names = new List<string>()
                    {
                        "Удалить ник"
                    };
                        List<string> buttons_commands = new List<string>()
                    {
                        "rnick id" + args[0]
                    };
                        List<string> buttons_colors = new List<string>()
                    {
                        Vk.BUTTON_RED
                    };

                    buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        text = "Никнейм [club" + args[0].Substring(1) + "|сообщества] не установлен.";
                    }
                }

                var plaininfo = TextFormatter.FromMarkdown(text);

                Vk.MessagesSend(plaininfo.PlainText, 1, 0, buttons, true, "", plaininfo.FormatData.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_setnick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "setnick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "setnick", 5))
                {
                    return;
                }

                string originalTextMarkdown = TextFormatter.ToMarkdown(Vk.m_text, (JObject?)Vk.format_data);

                string[] args = await cmdChecker.getArguments(originalTextMarkdown, new string[] { "id", "text" });
                if (args[0] == "" || args[0] == null || args[1] == "" || args[1] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["setnick"]);
                    return;
                }

                Dictionary<string, string>? TargetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));

                if (TargetUser == null)
                {
                    Vk.MessagesSend("Пользователь не найден в базе данных.");
                    return;
                }


                if (vk.EmojiCount(args[1]) >= 1)
                {
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);

                    var globalAccount = db.usersGetUser(Vk.m_from_id);
                    if (args[0] == Vk.m_from_id.ToString())
                    {
                        if (globalAccount["vip_type"] != "0")
                        {
                            if (globalAccount["vip"] != "")
                            {
                                var vip_time_user = db.timeGetForMysql(globalAccount["vip"]);
                                if (vip_time_user.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                                {
                                    if (Vk.m_from_id < 0)
                                    {
                                        Vk.MessagesSend("Действие [club" + Vk.m_from_id.ToString().Substring(1) + "|вашего] " +
                                            "VIP статуса было закончено в " + vip_time_user.ToString("g"));
                                    }
                                    else
                                    {
                                        Vk.MessagesSend("Действие [id" + Vk.m_from_id + "|вашего] " +
                                            "VIP статуса было закончено в " + vip_time_user.ToString("g"));
                                    }

                                    db.usersSetVipType(Vk.m_from_id, 0);
                                    db.usersSetVipTime(Vk.m_from_id, null);

                                    if (PeerInfo["vip"] != "")
                                    {
                                        var vip_time_peer = db.timeGetForMysql(PeerInfo["vip"]);
                                        if (vip_time_peer.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                                        {
                                            Vk.MessagesSend("В никнейме найдены эмодзи. Для их использования необходим VIP статус.<br>" +
                                                "К сожалению у беседы VIP статус закончился " + vip_time_peer.ToString("g") + ". Сообщите нам, если это ошибка — /report.");
                                            db.peersSetVip(Vk.m_peer_id, null);
                                            return;
                                        }
                                    }
                                    else
                                    {
                                        Vk.MessagesSend("В никнейме найдены эмодзи. Для их использования необходим VIP статус.<br>" +
                                                "К сожалению, ни у вас, ни у беседы, статуса VIP нет. Сообщите нам, если это ошибка — /report.");
                                        return;
                                    }
                                }
                            }

                        }
                        else
                        {
                            if (PeerInfo["vip"] != "")
                            {
                                var vip_time_peer = db.timeGetForMysql(PeerInfo["vip"]);
                                if (vip_time_peer.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                                {
                                    Vk.MessagesSend("В никнейме найдены эмодзи. Для их использования необходим VIP статус.<br>" +
                                        "К сожалению у беседы VIP статус закончился " + vip_time_peer.ToString("g") + ". Сообщите нам, если это ошибка — /report.");
                                    db.peersSetVip(Vk.m_peer_id, null);
                                    return;
                                }
                            }
                            else
                            {
                                Vk.MessagesSend("В никнейме найдены эмодзи. Для их использования необходим VIP статус.<br>" +
                                        "К сожалению, ни у вас, ни у беседы, статуса VIP нет. Сообщите нам, если это ошибка — /report.");
                                return;
                            }
                        }
                    }
                    else
                    {
                        if (PeerInfo["vip"] != "")
                        {
                            var vip_time_peer = db.timeGetForMysql(PeerInfo["vip"]);
                            if (vip_time_peer.ToUnixTimeSeconds() < DateTimeOffset.Now.ToUnixTimeSeconds())
                            {
                                Vk.MessagesSend("<br>В никнейме найдены эмодзи. Для их использования на других людях необходим VIP статус беседы.<br>" +
                                    "К сожалению, у вашей беседы статус VIP закончился " + vip_time_peer.ToString("g") + ". Сообщите нам, если это ошибка — /report.");
                                db.peersSetVip(Vk.m_peer_id, null);
                                return;
                            }
                        }
                        else
                        {
                            Vk.MessagesSend("В никнейме найдены эмодзи. Для их использования на других людях необходим VIP статус беседы.<br>" +
                                    "К сожалению, у вашей беседы статуса VIP нет. Сообщите нам, если это ошибка — /report.");
                            return;
                        }
                    }
                }

                string AdminNick = "Undefined";

                if (UserInfo["nick"] != "")
                {
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        AdminNick = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                    else
                    {
                        AdminNick = await Vk.GetUrlName(Vk.m_from_id);
                    }
                }

                string text;
                if (TargetUser["nick"] == "")
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        text = AdminNick + " установил никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                            "Новый никнейм: " + args[1];
                    }
                    else
                    {
                        text = AdminNick + " установил никнейм [id" + args[0] + "|пользователю].<br><br>" +
                            "Новый никнейм: " + args[1];
                    }
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETNICK, Vk.m_from_id, long.Parse(args[0]), "установил никнейм", args[1]);
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        text = AdminNick + " изменил никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                            TargetUser["nick"] + " » " + args[1];
                    }
                    else
                    {
                        text = AdminNick + " изменил никнейм [id" + args[0] + "|пользователю].<br><br>" +
                            TargetUser["nick"] + " » " + args[1];
                    }
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETNICK, Vk.m_from_id, long.Parse(args[0]), "установил никнейм", args[1], TargetUser["nick"]);
                }

                db.peersMemberSetNickName(Vk.m_peer_id, long.Parse(args[0]), args[1]);
                List<string> buttons_names = new List<string>()
                {
                    "Удалить ник"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "rnick id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);

                var plaininfo = TextFormatter.FromMarkdown(text);
                Vk.MessagesSend(plaininfo.PlainText, 1, 0, buttons, true, "", plaininfo.FormatData.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_removenick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "removenick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "removenick", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["removenick"]);
                    return;
                }

                Dictionary<string, string>? TargetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, false);

                string text = "";
                if (TargetUser == null)
                {
                    
                    if (Vk.is_callbackButton)
                    {
                        var nickCallback = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                        text += "<br><br>Команду выполнил: " + nickCallback[Vk.m_from_id.ToString()];
                    }
                    Vk.MessagesSend("Пользователь не найден в базе данных." + text);
                    return;
                }

                string AdminNick = "Undefined";

                if (UserInfo["nick"] != "")
                {
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        AdminNick = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                    else
                    {
                        AdminNick = await Vk.GetUrlName(Vk.m_from_id);
                    }
                }

                if (TargetUser["nick"] != "")
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        text = AdminNick + " удалил никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                            "Прошлый никнейм: " + TargetUser["nick"];
                    }
                    else
                    {
                        text = AdminNick + " удалил никнейм [id" + args[0] + "|пользователю].<br><br>" +
                            "Прошлый никнейм: " + TargetUser["nick"];
                    }

                    var plaininfo = TextFormatter.FromMarkdown(text);

                    Vk.MessagesSend(plaininfo.PlainText, 1, 0, "", true, "", plaininfo.FormatData.ToString());

                   // Vk.MessagesSend(text);
                    db.peersMemberSetNickName(Vk.m_peer_id, long.Parse(args[0]), null);
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_REMOVENICK, Vk.m_from_id, long.Parse(args[0]), "удалил никнейм", TargetUser["nick"]);
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        text = "[club" + args[0].Substring(1) + "|Сообщество] не имеет установленного никнейма.";
                    }
                    else
                    {
                        text = "[id" + args[0] + "|Пользователь] не имеет установленного никнейма.";
                    }
                    if (Vk.is_callbackButton)
                    {
                        var nickCallback = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id });
                        text += "<br><br>Команду выполнил: " + nickCallback[Vk.m_from_id.ToString()];
                    }
                    Vk.MessagesSend(text);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_nicknames()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "nicknames"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "nicknames", 5))
                {
                    return;
                }

                var nicks = db.peerGetNickNames(Vk.m_peer_id);

                if (nicks == null || nicks.Count() <= 0)
                {
                    Vk.MessagesSend("Пользователей с никами не найдено.");
                    return;
                }

                long[] userids = new long[nicks.Count()];

                long iter = 0;
                foreach (var item in nicks)
                {
                    userids[iter] = long.Parse(item["user_id"]);
                    iter++;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(userids);

                string text = "Список пользователей с установленными никнеймами:<br><br>";
                long i = 1;
                foreach (var item in nicks)
                {
                    if (users_names_vk.ContainsKey("id" + item["user_id"]))
                    {
                        if (long.Parse(item["user_id"]) < 0)
                        {
                            text = text + i + ". [club" + item["user_id"].Substring(1) + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                users_names_vk["id" + item["user_id"]].last_name + "] - " + item["nick"] + "<br>";
                        }
                        else
                        {
                            text = text + i + ". [id" + item["user_id"] + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                users_names_vk["id" + item["user_id"]].last_name + "] - " + item["nick"] + "<br>";
                        }
                    }
                    else
                    {
                        if (long.Parse(item["user_id"]) < 0)
                        {
                            text = text + i + ". [club" + item["user_id"].Substring(1) + "|Сообщество] - " + item["nick"] + "<br>";
                        }
                        else
                        {
                            text = text + i + ". [id" + item["user_id"] + "|Пользователь] - " + item["nick"] + "<br>";
                        }
                    }

                    //Vk.MessagesSend("");
                    i++;
                }

                var plaininfo = TextFormatter.FromMarkdown(text);

                Vk.MessagesSend(plaininfo.PlainText, 1, 0, "", true, "", plaininfo.FormatData.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_nonames()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "nonames"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "nonames", 5))
                {
                    return;
                }

                

                /*if (nicks == null)
                {
                    Vk.MessagesSend("Пользователей с никами не найдено.");
                    return;
                }
                */
                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
            {
                { "peer_id", Vk.m_peer_id.ToString() }
            };
                var answer_vk = await Vk.VkAPI(method, paramesd);
                if (answer_vk["error"] != null || answer_vk["response"]["items"] == null)
                {
                    Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                    return;
                }

                long[] userids = new long[answer_vk["response"]["items"].Count()];
                long i = 0;
                foreach (var upd in answer_vk["response"]["items"])
                {
                    var id = (int)upd["member_id"];
                    if (id < 0)
                    {
                        continue;
                    }
                    userids[i] = id;
                    i++;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(userids);

                string text = "Список пользователей без никнеймов:<br><br>";
                long isd = 1;
                foreach (var item in userids)
                {
                    if (item < 0)
                    {
                        continue;
                    }

                    var user = db.peersGetMember(Vk.m_peer_id, item);
                    if (users_names_vk.ContainsKey("id" + item) && user["nick"] == "")
                    {
                        if (item < 0)
                        {
                            text = text + isd + ". [club" + item.ToString().Substring(1) + "|" + users_names_vk["id" + item.ToString()].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + isd + ". [id" + item + "|" + users_names_vk["id" + item].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        continue;
                    }
                    isd++;
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_checknicks()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "checknicks"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "checknicks", 5))
                {
                    return;
                }



                /*if (nicks == null)
                {
                    Vk.MessagesSend("Пользователей с никами не найдено.");
                    return;
                }
                */
                var usersNicks = db.peerGetNickNames(Vk.m_peer_id);
                if (usersNicks == null || usersNicks.Count() <= 0)
                {
                    Vk.MessagesSend("В беседе нет установленных никнеймов.");
                    return;
                }

                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
            {
                { "peer_id", Vk.m_peer_id.ToString() }
            };
                var answer_vk = await Vk.VkAPI(method, paramesd);
                if (answer_vk["error"] != null || answer_vk["response"]["items"] == null)
                {
                    Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                    return;
                }


                List<long> UsersNotKf = new();


                long[] userids = new long[answer_vk["response"]["items"].Count()];
                long i = 0;
                foreach (var upd in answer_vk["response"]["items"])
                {
                    var id = (int)upd["member_id"];
                    if (id < 0)
                    {
                        continue;
                    }
                    userids[i] = id;
                    i++;
                }

                foreach (var item in usersNicks)
                {
                    if (!userids.Contains(long.Parse(item["user_id"])))
                    {
                        UsersNotKf.Add(long.Parse(item["user_id"]));
                    }
                }

                if (UsersNotKf.Count <= 0)
                {
                    Vk.MessagesSend("Все пользователи с никнеймами состоят в беседе.");
                    return;
                }
                var users_names_vk = await Vk.UsersGetVkInfo(UsersNotKf.ToArray());

                string text = "Никнеймы пользователей, которые отсутствуют в конференции удалены:<br><br>";
                long isd = 1;
                foreach (var item in UsersNotKf)
                {
                    if (item < 0)
                    {
                        
                        continue;
                    }

                    var user = db.peersGetMember(Vk.m_peer_id, item);
                    if (users_names_vk.ContainsKey("id" + item))
                    {
                        if (item < 0)
                        {
                            text = text + isd + ". [club" + item.ToString().Substring(1) + "|" + users_names_vk["id" + item.ToString()].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + isd + ". [id" + item + "|" + users_names_vk["id" + item].first_name + " " +
                                users_names_vk["id" + item].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        continue;
                    }
                    isd++;
                }
                Vk.MessagesSend(text);

                foreach (var item in UsersNotKf)
                {
                    db.peersMemberSetNickName(Vk.m_peer_id, item, null);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_zov()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "zov"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "zov", 2))
                {
                    return;
                }

                Cache cach = new();

                string[] args = await cmdChecker.getArguments(Vk.m_text_origin, new string[] { "text" });
                if (args[0] != "" && args[0] != null && args[0] != "all" && args[0] != "user" && args[0] != "roles")
                {
                    var Buttons = Vk.GenerateKeyboard(new string[] { "Все", "Без роли", "С ролью" }, new string[] { "zov all", "zov user", "zov roles" }, 
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_GREEN, Vk.BUTTON_GREEN });
                    Vk.MessagesSend("Выберите, кого вы хотите оповестить.", 1, 0, Buttons);
                    cach.Set("target_selected_zov_" + Vk.m_peer_id + "_" + Vk.m_from_id, args[0]);
                    return;
                }
                else if (args[0] != "all" && args[0] != "user" && args[0] != "roles")
                {
                    Vk.MessagesSend("Использование: !вызов [текст]");
                    return;
                }

                var target_text = cach.Get<string>("target_selected_zov_" + Vk.m_peer_id + "_" + Vk.m_from_id);
                if (target_text == null)
                {
                    Vk.MessagesSend("Вы не ввели текст вызова. Используйте: !вызов [текст]");
                    return;
                }

                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
            {
                { "peer_id", Vk.m_peer_id.ToString() }
            };
                var answer_vk = await Vk.VkAPI(method, paramesd);
                if (answer_vk["error"] != null)
                {
                    Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                    return;
                }

                if (answer_vk["response"]["items"] == null)
                {
                    Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                    return;
                }

                string text = "🔊 Вы были вызваны [id" + Vk.m_from_id + "|Администратором] беседы.<br><br>";
                if (args[0] != "" && args[0] != null)
                {
                    text = text + "Причина: " + target_text + "<br><br>";
                }
                else
                {
                    text = text + "Причина не указана.<br><br>";
                }

                long i = 0;
                long i_all = 0;
                long count_max = answer_vk["response"]["items"].Count();
                foreach (var upd in answer_vk["response"]["items"])
                {
                    var id = (int)upd["member_id"];
                    if (id < 0)
                    {
                        //continue;
                    }

                    if (args[0] == "user")
                    {
                        if (id > 0)
                        {
                            //continue;

                            var target_role = db.peersGetMember(Vk.m_peer_id, id);
                            if (target_role["priority"] == "0")
                            {
                                if (target_role["no_mention"] != "1")
                                {
                                    text = text + "[id" + id + "|❄] "; //❄ //​&#8300;
                                }
                            }
                        }
                    }
                    else if (args[0] == "roles")
                    {
                        if (id > 0)
                        {
                            var target_role = db.peersGetMember(Vk.m_peer_id, id);
                            if (target_role["priority"] != "0")
                            {
                                if (target_role["no_mention"] != "1")
                                {
                                    text = text + "[id" + id + "|​🧠] ";
                                }
                            }
                        }
                            
                    }
                    else if (args[0] == "all")
                    {
                        if (id > 0)
                        {
                            var target_role = db.peersGetMember(Vk.m_peer_id, id);
                            if (target_role["no_mention"] != "1")
                            {
                                text = text + "[id" + id + "|👁] "; //​
                            }
                        }
                    }
                    else
                    {
                        //continue;
                    }
                    i++;
                    i_all++;
                    

                    if (i >= count_max || i >= 40)
                    {
                        text = text + "<br><br>📣 Отправляем уведомления [" + i_all + "/" + answer_vk["response"]["items"].Count() + "]";
                        i = 0;
                        Vk.MessagesSend(text, 0, 0, "", false);
                        text = "";
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_reg()
        {
            try
            {
                //https://vk.com/foaf.php?id=1
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "reg"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "reg", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["reg"]);
                    return;
                }

                var userGlobal = db.usersGetUser(long.Parse(args[0]));
                if (userGlobal["date_reg_vk"] != "")
                {
                    var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) }, false, "gen");
                    string name_url = "[id" + args[0] + "|Пользователя]";

                    if (vkInfo.ContainsKey("id" + args[0]))
                    {
                        name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                            vkInfo["id" + args[0]].last_name + "]";
                    }
                    else
                    {
                        if (long.Parse(args[0]) < 0)
                        {
                            name_url = "[club" + args[0].Substring(1) + "|Сообщества]";
                        }
                    }
                    var unix = db.timeGetForMysql(userGlobal["date_reg_vk"]);
                    //time_text.AddHours(double.Parse("-1"));
                    Vk.MessagesSend("Дата регистрации " + name_url + ": " + unix.ToString("G"));
                    return;
                }



                var resultd = db.getDateRegCache(long.Parse(args[0]));
                if (resultd != null && resultd != "")
                {
                    var vkInfo = await Vk.UsersGetName(new long[] { long.Parse(args[0]) }, false, "gen");
                    string name_url = "[id" + args[0] + "|Пользователя]";

                    if (vkInfo.ContainsKey("id" + args[0]))
                    {
                        name_url = "[id" + args[0] + "|" + vkInfo["id" + args[0]].first_name + " " +
                            vkInfo["id" + args[0]].last_name + "]";
                    }
                    else
                    {
                        if (long.Parse(args[0]) < 0)
                        {
                            name_url = "[club" + args[0].Substring(1) + "|Сообщества]";
                        }
                    }
                    //time_text.AddHours(double.Parse("-1"));
                    Vk.MessagesSend("Дата регистрации " + name_url + ": " + resultd);
                    return;
                }

                long? dateCreated = await VKFetcher.GetDateCreatedAsync(long.Parse(args[0]));

                DateTime time_text = new();

                if (dateCreated.HasValue)
                {
                    // Конвертируем Unix time в обычную дату для вывода
                    time_text = DateTimeOffset.FromUnixTimeSeconds(dateCreated.Value).UtcDateTime;
                    //Console.WriteLine($"Дата регистрации пользователя {userId}: {registrationDate:yyyy-MM-dd HH:mm:ss} UTC");
                }
                else
                {
                    Vk.MessagesSend("Ошибка обработки данных.");
                    return;
                }

                string JavaDateFormat = @"yyyy-MM-ddThh:mm:ss";
                

                var vkInfo5 = await Vk.UsersGetName(new long[] { long.Parse(args[0]) }, false, "gen");
                string name_url5 = "[id" + args[0] + "|Пользователя]";

                if (vkInfo5.ContainsKey("id" + args[0]))
                {
                    name_url5 = "[id" + args[0] + "|" + vkInfo5["id" + args[0]].first_name + " " +
                        vkInfo5["id" + args[0]].last_name + "]";
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        name_url5 = "[club" + args[0].Substring(1) + "|Сообщества]";
                    }
                }
                var unix4 = (DateTimeOffset)time_text.AddHours(-1.0);
                //time_text.AddHours(double.Parse("-1"));
                Vk.MessagesSend("Дата регистрации " + name_url5 + ": " + unix4.ToString("G"));
                db.setDateRegCache(long.Parse(args[0]), unix4.ToString("G"));
                db.setDateRegVkUser(long.Parse(args[0]), db.timeGetForString(unix4));
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_logs()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 20, "logs"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "logs", 15))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "int" });
                if (args[0] == "" || args[0] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["logs"]);
                    return;
                }

                Dictionary<string, string>? TargetUser = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false);

                if (TargetUser == null)
                {
                    Vk.MessagesSend("Пользователь не найден в базе данных.");
                    return;
                }
                var name_url = await Vk.UserGetNameUrls(new long[] { long.Parse(args[0]) });

                string text;

                long list = 1;
                if (args[1] != null && args[1] != "")
                {
                    try
                    {
                        list = long.Parse(args[1]);
                    }
                    catch
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["logs"]);
                        return;
                    }
                    if (list <= 0)
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["logs"]);
                        return;
                    }
                }

                Cache Cache = new Cache();
                var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id + "_" + args[0]);


                long max = list * 25;
                long min = max - 24;
                var logs = db.logsGetForUser(Vk.m_peer_id, long.Parse(args[0]));
                if (logs == null || logs.Count <= 0)
                {
                    Vk.MessagesSend("Последних действий пользователя нет.");
                    return;
                }

                //long all_lists = (int)Math.Round(double.Parse((bans.Count() / 25).ToString()) );

                long all_list = logs.Count() / 25;
                all_list++;
                //else
                //{
                //all_list++;
                //}


                if (logs.Count() < min)
                {
                    Vk.MessagesSend("Указанная страница не найдена. Всего страниц: " + all_list);
                    return;
                }

                List<long> userget = new();
                long iters = 0;
                string my_id = args[0];
                foreach (var item in logs)
                {
                    iters++;
                    if (iters < min || iters > max)
                    {
                        continue;
                    }
                    if (item["user_id"] == my_id)
                    {
                        userget.Add(long.Parse(item["target_id"]));
                    }
                    else
                    {
                        userget.Add(long.Parse(item["user_id"]));
                    }
                }
                userget.Add(long.Parse(my_id));

                long[] userids = new long[userget.Count()];
                long iss = 0;
                foreach (var item in userget)
                {
                    userids[iss] = item;
                    iss++;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(userids);
                //if (all_list == 0)
                //{

                //}

                text = "Список последних действий пользователя: <br><br>";
                long i = min;
                iters = 0;
                foreach (var item in logs)
                {
                    iters++;
                    if (iters < min || iters > max)
                    {
                        continue;
                    }
                    if (users_names_vk.ContainsKey("id" + item["user_id"]))
                    {
                        if (long.Parse(item["user_id"]) < 0)
                        {
                            text = text + i + ". [club" + item["user_id"].Substring(1) + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                users_names_vk["id" + item["user_id"]].last_name + "] ";
                        }
                        else
                        {
                            text = text + i + ". [id" + item["user_id"] + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                users_names_vk["id" + item["user_id"]].last_name + "] ";
                        }
                    }
                    else
                    {
                        if (long.Parse(item["user_id"]) < 0)
                        {
                            text = text + i + ". [club" + item["user_id"].Substring(1) + "|Сообщество] ";
                        }
                        else
                        {
                            text = text + i + ". [id" + item["user_id"] + "|Пользователь] ";
                        }
                    }
                    if (item["type"] == "2")
                    {
                        text += " активировал конференцию";
                    }
                    else
                    {
                        text = text + item["text"] + " ";
                    }
                    

                    if (item["target_id"] != "0")
                    {
                        if (users_names_vk.ContainsKey("id" + item["target_id"]))
                        {
                            if (long.Parse(item["target_id"]) < 0)
                            {
                                text = text + "[club" + item["target_id"].Substring(1) + "|" + users_names_vk["id" + item["target_id"]].first_name + " " +
                                    users_names_vk["id" + item["target_id"]].last_name + "]<br>";
                            }
                            else
                            {
                                text = text + "[id" + item["target_id"] + "|" + users_names_vk["id" + item["target_id"]].first_name + " " +
                                    users_names_vk["id" + item["target_id"]].last_name + "]<br>";
                            }
                        }
                        else
                        {
                            if (long.Parse(item["target_id"]) < 0)
                            {
                                text = text + "[club" + item["target_id"].Substring(1) + "|Сообщество]<br>";
                            }
                            else
                            {
                                text = text + "[id" + item["target_id"] + "|Пользователь]<br>";
                            }
                        }
                    }
                    else
                    {
                        text = text + "<br>";
                    }
                    

                    //Vk.MessagesSend("");
                    i++;
                }
                string buttons = "";
                if (list == 1)
                {
                    if (all_list != 1)
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "—>" },
                        new string[] { $"logs id{args[0]} 2" },
                        new string[] { Vk.BUTTON_WHITE }, null, false, true, true);
                    }
                }
                else if (list == all_list && list != 1)
                {
                    var previus = list - 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—" },
                        new string[] { $"logs id{args[0]} " + previus },
                        new string[] { Vk.BUTTON_WHITE }, null, false, true, true);
                }
                else
                {
                    var previus = list - 1;
                    var next = list + 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—", "—>" },
                        new string[] { $"logs id{args[0]} " + previus, $"logs id{args[0]} " + next },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE }, null, false, true, true);
                }

                text = text + "<br>Страница: " + list + "<br>" +
                    "Всего страниц: " + all_list;
                if (last_message != null)
                {
                    Cache.Set("last_message_for_" + Vk.m_peer_id + "_" + args[0], last_message.ToString());
                    Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                }
                else
                {
                    long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                    Cache.Set("last_message_for_" + Vk.m_peer_id + "_" + args[0], idmes.ToString());
                }
                //Vk.MessagesSend(text, 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

    }

    class moder_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;

        public moder_cmds(vk vks, Database dbs, settings set)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
        }

        public async void command_ban()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "ban"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "ban", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                if (args[0] == "" || args[0] == null || args[0] == Vk.m_from_id.ToString()) // long.Parse(args[0]) < 0 ||
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["ban"]);
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                int days = 0;
                string reason = "не указана.";

                if (args.Length >= 2)
                {
                    var explodes = args[1].Split(" ");
                    if (explodes.Length >= 2)
                    {
                        try
                        {
                            var isNumeric = int.TryParse(explodes[0], out days);
                            if (isNumeric)
                            {
                                if (days <= 0 || days >= 365)
                                {
                                    days = 0;
                                }
                                string[] sas_args = await cmdChecker.getArguments("/ban " + args[1], new string[] { "int", "text" });
                                if (sas_args[1] != null && sas_args[1] != "")
                                {
                                    reason = sas_args[1];
                                }
                            }
                            else
                            {
                                if (explodes[0] != null && explodes[0] != "")
                                {
                                    reason = args[1];
                                }
                            }

                            
                        }
                        catch
                        {
                            days = 0;
                        }
                    }
                    else
                    {
                        if (args[1] != null && args[1] != "")
                        {
                            reason = args[1];
                        }
                    }
                }
                
                Dictionary<string, string>? Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));

                if (Target_User == null)
                {
                    if (Vk.is_callbackButton)
                    {
                        var plaininfo2 = TextFormatter.FromMarkdown("Не удалось найти информацию про этого пользователя.<br><br>" +
                            "Команду выполнил: " + nick_admin);

                        Vk.MessagesSend(plaininfo2.PlainText, 1, 0, "", true, "", plaininfo2.FormatData.ToString());
                        return;
                    }
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }
                string nickname = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(Target_User["user_id"]));
                if (db.bansGetBan(Vk.m_peer_id, long.Parse(args[0])) != null)
                {
                    if (Vk.is_callbackButton)
                    {
                        var plaininfo3 = TextFormatter.FromMarkdown("⛔ " + nickname + " уже находится в списке заблокированных.<br><br>" +
                            "Команду выполнил: " + nick_admin);
                        Vk.MessagesSend(plaininfo3.PlainText, 1, 0, "", true, "", plaininfo3.FormatData.ToString());
                        return;
                    }
                    var plaininfoT = TextFormatter.FromMarkdown("⛔ " + nickname + " уже находится в списке заблокированных.");
                    Vk.MessagesSend(plaininfoT.PlainText, 1, 0, "", true, "", plaininfoT.FormatData.ToString());
                    return;
                }
                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != Vk.m_from_id.ToString())
                {
                    if (Vk.is_callbackButton)
                    {
                        var plaininfo4 = TextFormatter.FromMarkdown("Вы не можете заблокировать участника, роль которого выше или равна вашей.<br><br>" +
                            "Команду выполнил: " + nick_admin);
                        Vk.MessagesSend(plaininfo4.PlainText, 1, 0, "", true, "", plaininfo4.FormatData.ToString());
                        return;
                    }
                    Vk.MessagesSend("Вы не можете заблокировать участника, роль которого выше или равна вашей.");
                    return;
                }

                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                if (Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                    {
                        var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                        var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                        var plaininfo5 = TextFormatter.FromMarkdown($"{nameWe} не можете заблокировать участника, поскольку у него иммунитет.<br><br>" +
                            $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                            $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                            $"<br>Снять иммунитет: /gm @ссылка");
                        Vk.MessagesSend(plaininfo5.PlainText, 1, 0, "", true, "", plaininfo5.FormatData.ToString());
                        return;
                    }
                }

                string ban_time = null;
                string ban_text = "перманентно";
                if (days != 0)
                {
                    ban_time = db.timeGetForString(DateTimeOffset.Now.AddDays(days));
                    ban_text = "до " + DateTimeOffset.Now.AddDays(days).ToString("g");
                }

                

                string text = "";

                /*
                 */
                //Vk.KickUser(Vk.m_peer_id, long.Parse(Target_User["user_id"]));

                JObject result_vk = await Vk.KickUser(Vk.m_peer_id, long.Parse(args[0]));
                if (result_vk["error"] != null || (result_vk["response"] != null && result_vk["response"].ToString().ToLower() == "false"))
                {
                    text = nickname + " не состоит в конференции, либо имеет права Администратора непосредственно в беседе.<br>";
                    //Vk.MessagesSend(text);
                    //return;
                }

                List<string> buttons_names = new List<string>()
                {
                    "Отмена"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "unban id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };
                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);

                text = "⛔ " + nickname + " получил блокировку.<br><br>Причина: " + reason + "<br>" +
                        "Срок блокировки: " + ban_text + "<br>" +
                        "Заблокировал: " + nick_admin;

                var plaininfo6 = TextFormatter.FromMarkdown(text);
                Vk.MessagesSend(plaininfo6.PlainText, 1, 0, buttons, true, "", plaininfo6.FormatData.ToString());
               // Vk.MessagesSend(text, 1, 0, buttons);

                //db.peersDeleteMember(Vk.m_peer_id, long.Parse(args[0]));
                if (peerInfo["set_exitremovenick"] == "1")
                {
                    db.peersMemberSetNickName(Vk.m_peer_id, long.Parse(args[0]), null);
                }
                db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), 0);

                var warns_database = db.peerGetWarnsList(Vk.m_peer_id, long.Parse(args[0]), false, 3);
                if (warns_database != null)
                {
                    foreach (var item in warns_database)
                    {
                        if (item.deleted != 1)
                        {
                            db.peerWarnsDeleteWarn((int)item.id);
                        }

                    }
                    db.peerMembersSetWarns(Vk.m_peer_id, long.Parse(args[0]), 0);
                }

                db.bansAddBan(Vk.m_peer_id, long.Parse(Target_User["user_id"]), Vk.m_from_id, reason, ban_time);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_BAN, Vk.m_from_id, long.Parse(args[0]), "заблокировал", reason, ban_text);


                if (result_vk["error"] == null && (result_vk["response"] != null && result_vk["response"].ToString().ToLower() != "false"))
                {
                    // исключение из группы
                    var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (PeerInfo["set_kickexitgroup"] != "0" && PeerInfo["group"] != "0" && PeerInfo["access_token"] != "")
                    {
                        var method = "groups.removeUser";
                        var parames = new Dictionary<string, string>();
                        parames.Add("group_id", PeerInfo["group"]);
                        parames.Add("user_id", args[0]);
                        parames.Add("access_token", SysUtils.DecryptString(PeerInfo["access_token"]));
                        var JObject = await Vk.VkAPIs(method, parames);
                        if (!JObject.ContainsKey("response") || JObject.ContainsKey("error"))
                        {
                            if (JObject.ContainsKey("error"))
                            {
                                if (JObject["error"]["error_code"] != null)
                                {
                                    var code = JObject["error"]["error_code"];
                                    if (code.ToString() == "5")
                                    {
                                        //db.peersSetAccessToken(Vk.m_peer_id, "");
                                        Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен.");
                                    }
                                }
                            }
                            db.peersSetAccessToken(Vk.m_peer_id, "");
                        }
                    }

                    // --------------------
                }



            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_unban()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "unban"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "unban", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[0] != "")
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, false);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["unban"]);
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User == null)
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.<br><br>" +
                            "Команду выполнил: " + nick_admin);
                        return;
                    }
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }



                var banInfo = db.bansGetBan(Vk.m_peer_id, long.Parse(args[0]));
                string nickname = "";

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }

                if (banInfo == null)
                {
                    if (Vk.is_callbackButton)
                    {
                        Vk.MessagesSend(nickname + " не находится в списке заблокированных.<br><br>" +
                            "Команду выполнил: " + nick_admin);
                        return;
                    }
                    Vk.MessagesSend(nickname + " не находится в списке заблокированных.");
                    return;
                }


                string text = "♻ " + nickname + " был разблокирован." + "<br>" +
                    "Разблокировал: " + nick_admin;
                Vk.MessagesSend(text);

                db.bansDeleteBan(Vk.m_peer_id, long.Parse(args[0]));
                db.bansGetBan(Vk.m_peer_id, long.Parse(args[0]), true);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_UNBAN, Vk.m_from_id, long.Parse(args[0]), "разблокировал");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_addhelper()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "addhelper"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "addhelper", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null)
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["addhelper"]);
                    return;
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nickname;
                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }

                string text;
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                    {
                        Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.");
                        return;
                    }
                    if (long.Parse(Target_User["priority"]) >= 20)
                    {
                        Vk.MessagesSend(nickname + " уже имеет роль с таким же, либо высшим приоритетом.");
                        return;
                    }
                    var old_name = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                    text = nickname + " получил права помощника." + "<br>" +
                    "Выдал: " + nick_admin + "<br>" +
                    "Предыдущая роль: " + old_name;
                }
                else
                {
                    text = nickname + " получил права помощника." + "<br>" +
                    "Выдал: " + nick_admin;
                }
                List<string> buttons_names = new List<string>()
                {
                    "Снять"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "rr id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray());

                Vk.MessagesSend(text, 1, 0, buttons);
                db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), 20);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль", "20");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_setrole()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "setrole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "setrole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[1] != "" && args[1] != "")
                {
                    long targetID = 0;
                    try
                    {
                        targetID = long.Parse(args[0]);
                    }
                    catch
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["setrole"]);
                        return;
                    }
                    
                    Target_User = db.peersGetMember(Vk.m_peer_id, targetID, false, true);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["setrole"]);
                    return;
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                if (Target_User != null && Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                    {
                        var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                        var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                        Vk.MessagesSend($"{nameWe} не можете изменять роль участника, поскольку у него иммунитет.<br><br>" +
                            $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                            $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                            $"<br>Снять иммунитет: /gm @ссылка");
                        return;
                    }
                }

                string nickname;
                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }


                string[] args_role = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "int" });
                int target_role_priority = -1;
                if (args_role[0] == null || args_role[0] == "")
                {
                    string[] args_roletext = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "text" });
                    if (args_roletext[0] == null || args_roletext[0] == "")
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["setrole"]);
                        return;
                    }
                    var roles = db.peerGetRoles(Vk.m_peer_id);
                    args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                    foreach (var item in roles)
                    {
                        var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (args_roletext[0] == name_role)
                        {
                            target_role_priority = item.Value.priority;
                            break;
                        }
                    }
                    if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                    {
                        target_role_priority = 20;
                    }
                    else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                    {
                        target_role_priority = 40;
                    }
                    else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                    {
                        target_role_priority = 60;
                    }
                    else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                        args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                        args_roletext[0] == "spec" || args_roletext[0] == "lead")
                    {
                        target_role_priority = 80;
                    }
                }
                else
                {
                    if (long.Parse(args_role[0]) >= 100 || long.Parse(args_role[0]) <= -1)
                    {
                        Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                        return;
                    }
                    try
                    {
                        target_role_priority = int.Parse(args_role[0]);
                    }
                    catch
                    {
                        target_role_priority = -1;
                    }
                    
                }

                if (target_role_priority <= -1)
                {

                    Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                    return;
                }
                var peerInfo = db.peersGetPeer(Vk.m_peer_id);

                if (long.Parse(UserInfo["priority"]) <= target_role_priority && peerInfo["owner"] != Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Вы не можете выдавать роль, приоритет которой выше или равен вашему.");
                    return;
                }
                if (args[0] == Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Вы не можете выдавать роль себе.");
                    return;
                }

                string text;
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != Vk.m_from_id.ToString())
                    {
                        Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.");
                        return;
                    }
                    if (long.Parse(Target_User["priority"]) == target_role_priority)
                    {
                        Vk.MessagesSend(nickname + " уже имеет данную роль.");
                        return;
                    }
                    var old_name = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                    text = nickname + " получил новую роль." + "<br>" +
                    "Название: " + db.rolesGetName(Vk.m_peer_id, target_role_priority.ToString()) + "<br>" +
                    "Выдал: " + nick_admin + "<br>" +
                    "Предыдущая роль: " + old_name;
                }
                else
                {
                    text = nickname + " получил новую роль." + "<br>" +
                    "Название: " + db.rolesGetName(Vk.m_peer_id, target_role_priority.ToString()) + "<br>" +
                    "Выдал: " + nick_admin;
                }

                List<string> buttons_names = new List<string>()
                {
                    "Снять"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "rr id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray());

                Vk.MessagesSend(text, 1, 0, buttons);
                db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), target_role_priority);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль", target_role_priority.ToString());
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        

        public async void command_removerole()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "removerole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "removerole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] != null)
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["removerole"]);
                    return;
                }

                if (args[0] == Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend("Нельзя снимать с себя роль.");
                    return;
                }

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                if (Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                    {
                        var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                        var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                        Vk.MessagesSend($"{nameWe} не можете снять роль участника, поскольку у него иммунитет.<br><br>" +
                            $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                            $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                            $"<br>Снять иммунитет: /gm @ссылка");
                        return;
                    }
                }

                string nickname;
                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (long.Parse(args[0]) < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }

                string text;
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != Vk.m_from_id.ToString())
                    {
                        Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.");
                        return;
                    }
                    var old_name = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                    text = nickname + " теперь обычный пользователь." + "<br>" +
                    "Роль снял: " + nick_admin + "<br>" +
                    "Предыдущая роль: " + old_name;
                    db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "снял роль", Target_User["priority"]);
                }
                else
                {
                    text = nickname + " уже имеет права пользователя.";
                }

                Vk.MessagesSend(text);
                db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), 0);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gremoverole()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "gremoverole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gremoverole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gremoverole"]);
                    return;

                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }


                string nickname;

                Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });

                foreach (var peerid in ListPeers)
                {
                    Target_User = db.peersGetMember(peerid, long.Parse(args[0]), false, false);

                    UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 40, "gremoverole"))
                    {
                        return;
                    }

                    if (Target_User == null || Target_User.Count <= 0)
                    {
                        if (peerid == Vk.m_peer_id)
                        {
                            Vk.MessagesSend("Данных о пользователе в этой конференции не найдено.");
                        }
                        continue;
                    }
                    var peerInfo = db.peersGetPeer(peerid);
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != Vk.m_from_id.ToString())
                    {
                        if (peerid == Vk.m_peer_id)
                        {
                            Vk.MessagesSend("Вы не можете снять роль пользователю, приоритет которого выше или равен вашему.");
                        }
                        continue;
                    }

                    string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                    if (Target_User["gamemode"] != "0")
                    {
                        if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                        {
                            var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                            var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                            Vk.MessagesSend($"{nameWe} не можете снять роль участнику, поскольку у него иммунитет.<br><br>" +
                                $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                                $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                                $"<br>Снять иммунитет: /gm @ссылка", 0, peerid);
                            continue;
                        }
                    }

                    if (long.Parse(Target_User["priority"]) <= 0)
                    {
                        if (peerid == Vk.m_peer_id)
                        {
                            Vk.MessagesSend("Пользователь уже имеет права пользователя.");
                        }
                        continue;
                    }

                    if (Target_User["nick"] == "")
                    {
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (long.Parse(args[0]) < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }
                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);
                    var old_name = db.rolesGetName(peerid, Target_User["priority"]);
                    string text = nickname + " теперь обычный пользователь." + "<br>" +
                    "Роль снял: " + nick_admin + "<br>" +
                    "Предыдущая роль: " + old_name;

                    Vk.MessagesSend(text, 0, peerid);
                    db.peersMemberSetPriority(peerid, long.Parse(args[0]), 0);
                    db.logsAddLog(peerid, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "снял роль (пулл)", Target_User["priority"]);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_roles()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "roles"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "roles", 5))
                {
                    return;
                }


                string text = "Список доступных ролей (в скобках указан приоритет):<br><br>";

                var roles = db.peerGetRoles(Vk.m_peer_id);
                if (!roles.ContainsKey("0"))
                {
                    roles.Add("0", new NamesRoles() { name = "Пользователь", priority = 0 });
                }
                if (!roles.ContainsKey("20"))
                {
                    roles.Add("20", new NamesRoles() { name = "Помощник", priority = 20 });
                }
                if (!roles.ContainsKey("40"))
                {
                    roles.Add("40", new NamesRoles() { name = "Модератор", priority = 40 });
                }
                if (!roles.ContainsKey("60"))
                {
                    roles.Add("60", new NamesRoles() { name = "Администратор", priority = 60 });
                }
                if (!roles.ContainsKey("80"))
                {
                    roles.Add("80", new NamesRoles() { name = "Главный Администратор", priority = 80 });
                }
                if (!roles.ContainsKey("100"))
                {
                    roles.Add("100", new NamesRoles() { name = "Владелец", priority = 100 });
                }
                var sortedDict = from entry in roles orderby entry.Value.priority ascending select entry;
                long i = 0;
                foreach (var item in sortedDict)
                {
                    i++;
                    text = text + i + ". '" + item.Value.name + "' (" + item.Value.priority + ")<br>";
                }

                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_silence()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "silence"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "silence", 5))
                {
                    return;
                }
                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (peerInfo["silence"] != "0")
                {
                    Vk.MessagesSend("🦠 Режим тишины был отключен. Обычным пользователям теперь можно писать в чат.");
                    db.peersSetSilence(Vk.m_peer_id, 0);
                    return;
                }
                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "" || (args[0] != "kick" && args[0] != "delete" && args[0] != "del")) // long.Parse(args[0]) < 0 ||
                {
                    string buttons = Vk.GenerateKeyboard(new string[] { "Исключать", "Удалять" },
                        new string[] { "silence kick", "silence delete" },
                        new string[] { Vk.BUTTON_RED, Vk.BUTTON_GREEN });
                    Vk.MessagesSend("Выберите, удалять пользователя или удалять сообщения при нарушении режима тишины.", 1, 0, buttons);
                    return;
                }

                long silence = 0;
                string text;
                if (args[0] == "kick" || args[0] == "исключать")
                {
                    silence = 1;
                    if (Vk.m_from_id < 0)
                    {
                        text = "☠ [club" + Vk.m_from_id.ToString().Substring(1) + "|Администратор] включил режим тишины.";
                    }
                    else
                    {
                        text = "☠ [id" + Vk.m_from_id + "|Администратор] включил режим тишины.";
                    }
                    text = text + "<br><br>Обычные участники будут исключены при отправке сообщений в чат!";
                }
                else if (args[0] == "delete" || args[0] == "del" || args[0] == "удалять")
                {
                    silence = 2;
                    if (Vk.m_from_id < 0)
                    {
                        text = "☠ [club" + Vk.m_from_id.ToString().Substring(1) + "|Администратор] включил режим тишины.";
                    }
                    else
                    {
                        text = "☠ [id" + Vk.m_from_id + "|Администратор] включил режим тишины.";
                    }
                    text = text + "<br><br>Сообщения обычных пользователей будут удалены при отправке!";
                }
                else
                {
                    string buttons = Vk.GenerateKeyboard(new string[] { "Исключать", "Удалять" },
                        new string[] { "silence kick", "silence delete" },
                        new string[] { Vk.BUTTON_RED, Vk.BUTTON_GREEN });
                    Vk.MessagesSend("Выберите, удалять пользователя или удалять сообщения при нарушении режима тишины.", 1, 0, buttons);
                    return;
                }
                Vk.MessagesSend(text);
                db.peersSetSilence(Vk.m_peer_id, silence);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_banlist()
        {
            try
            {
                //bansGetBansAll
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "banlist"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "banlist", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });
                long list = 1;
                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        list = long.Parse(args[0]);
                    }
                    catch
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["banlist"]);
                        return;
                    }
                    if (list <= 0)
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["banlist"]);
                        return;
                    }
                }

                long max = list * 25;
                long min = max - 24;

                var bans = db.bansGetBansAll(Vk.m_peer_id);
                if (bans == null || bans.Count <= 0)
                {
                    Vk.MessagesSend("Заблокированных пользователей в этой беседе не найдено.");
                    return;
                }

                //long all_lists = (int)Math.Round(double.Parse((bans.Count() / 25).ToString()) );

                long all_list = bans.Count() / 25;
                all_list++;
                //else
                //{
                //all_list++;
                //}


                if (bans.Count() < min)
                {
                    Vk.MessagesSend("Указанная страница не найдена. Всего страниц: " + all_list);
                    return;
                }

                List<long> userget = new();
                long iters = 0;
                foreach (var item in bans)
                {
                    iters++;
                    if (iters < min || iters > max)
                    {
                        continue;
                    }
                    userget.Add(long.Parse(item["user_id"]));
                }

                long[] userids = new long[userget.Count()];
                long iss = 0;
                foreach (var item in userget)
                {
                    userids[iss] = item;
                    iss++;
                }

                var users_names_vk = await Vk.UsersGetVkInfo(userids);
                //if (all_list == 0)
                //{

                //}

                string text = "Список заблокированных пользователей: <br>";
                long i = min;
                foreach (var item in users_names_vk)
                {
                    if (users_names_vk.ContainsKey("id" + item.Value.id))
                    {
                        if (item.Value.id < 0)
                        {
                            text = text + i + ". [club" + item.Value.id.ToString().Substring(1) + "|" + users_names_vk["id" + item.Value.id].first_name + " " +
                                users_names_vk["id" + item.Value.id].last_name + "]<br>";
                        }
                        else
                        {
                            text = text + i + ". [id" + item.Value.id + "|" + users_names_vk["id" + item.Value.id].first_name + " " +
                                users_names_vk["id" + item.Value.id].last_name + "]<br>";
                        }
                    }
                    else
                    {
                        if (item.Value.id < 0)
                        {
                            text = text + i + ". [club" + item.Value.id.ToString().Substring(1) + "|Сообщество]<br>";
                        }
                        else
                        {
                            text = text + i + ". [id" + item.Value.id + "|Пользователь]<br>";
                        }
                    }

                    //Vk.MessagesSend("");
                    i++;
                }
                string buttons = "";
                if (list == 1)
                {
                    if (all_list != 1)
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "—>" },
                        new string[] { "banlist 2" },
                        new string[] { Vk.BUTTON_WHITE });
                    }
                }
                else if (list == all_list && list != 1)
                {
                    var previus = list - 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—" },
                        new string[] { "banlist " + previus },
                        new string[] { Vk.BUTTON_WHITE });
                }
                else
                {
                    var previus = list - 1;
                    var next = list + 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—", "—>" },
                        new string[] { "banlist " + previus, "banlist " + next },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                }

                text = text + "<br>Страница: " + list + "<br>" +
                    "Всего страниц: " + all_list;

                Cache Cache = new Cache();
                var last_message = Cache.Get<string>("last_message_for_" + Vk.m_peer_id + "_" + Vk.m_from_id);
                if (last_message != null && (args[0] != null && args[0] != ""))
                {
                    Cache.Set("last_message_for_" + Vk.m_peer_id + "_" + Vk.m_from_id, last_message.ToString());
                    Vk.MessagesEdit(text, Vk.m_peer_id, buttons, true, "", long.Parse(last_message));
                }
                else
                {
                    long idmes = await Vk.MessagesSendMassive(text, new List<long>() { Vk.m_peer_id }, buttons);
                    Cache.Set("last_message_for_" + Vk.m_peer_id + "_" + Vk.m_from_id, idmes.ToString());
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_getbynick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "getbynick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "getbynick", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getbynick"]);
                    return;
                }

                var nicknames = db.peerGetNickNames(Vk.m_peer_id);
                if (nicknames.Count <= 0)
                {
                    Vk.MessagesSend("В данной беседе нет установленных никнеймов.<br><br>Установить ник пользователю — !snick");
                    return;
                }

                string current_nick = Regex.Replace(args[0], @"\p{Cs}", "").ToLower().Replace(" ", "");
                if (current_nick == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["getbynick"]);
                    return;
                }
                Regex regexFind = new Regex(@"(\w*)" + current_nick + @"(\w*)", RegexOptions.Compiled | RegexOptions.IgnoreCase);

                List<long> userget = new();
                foreach (var item in nicknames)
                {
                    try
                    {
                        if (item["nick"] == "")
                        {
                            continue;
                        }
                        var nickname_target = Regex.Replace(item["nick"], @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (nickname_target == "")
                        {
                            continue;
                        }
                        MatchCollection matches = regexFind.Matches(nickname_target);
                        if (matches.Count > 0)
                        {
                            userget.Add(long.Parse(item["user_id"]));
                        }
                        else
                        {
                            //Console.WriteLine("Совпадений не найдено");
                        }
                        //if (CalculateSimilarity(current_nick, nickname_target) >= 0.3d)
                        //{
                        //userget.Add(long.Parse(item["user_id"]));
                        //}
                    }
                    catch
                    {

                    }
                    
                }

                long[] userids = new long[userget.Count()];
                string text = "Список пользователей с похожими никнеймами (>30%):<br><br>";

                if (userids.Length >= 1)
                {
                    long iss = 0;
                    foreach (var item in userget)
                    {
                        userids[iss] = item;
                        iss++;
                    }
                    var users_names_vk = await Vk.UsersGetVkInfo(userids);
                    long i = 1;
                    foreach (var item in nicknames)
                    {
                        if (!userids.Contains(long.Parse(item["user_id"])))
                        {
                            continue;
                        }
                        if (users_names_vk.ContainsKey("id" + item["user_id"]))
                        {
                            if (long.Parse(item["user_id"]) < 0)
                            {
                                text = text + i + ". [club" + item["user_id"].Substring(1) + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                    users_names_vk["id" + item["user_id"]].last_name + "] — " + item["nick"] + "<br>";
                            }
                            else
                            {
                                text = text + i + ". [id" + item["user_id"] + "|" + users_names_vk["id" + item["user_id"]].first_name + " " +
                                    users_names_vk["id" + item["user_id"]].last_name + "] — " + item["nick"] + "<br>";
                            }
                        }
                        else
                        {
                            if (long.Parse(item["user_id"]) < 0)
                            {
                                text = text + i + ". [club" + item["user_id"].Substring(1) + "|Сообщество] — " + item["nick"] + "<br>";
                            }
                            else
                            {
                                text = text + i + ". [id" + item["user_id"] + "|Пользователь] — " + item["nick"] + "<br>";
                            }
                        }
                        i++;
                    }
                }

                if (userids.Length <= 0)
                {
                    text = "Пользователи с похожими никнеймами не найдены.";
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gzov()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "gzov"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gzov", 60))
                {
                    return;
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                var listUserPeers = db.unitesGetListUnity(long.Parse(Target_Peer["owner"]));
                if (ListPeers == null || ListPeers.Count < 1 && listUserPeers != null & listUserPeers.Count < 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                var buttons = "";
                

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (listUserPeers != null && listUserPeers.Count >= 1)
                {
                    List<int> buttonsLines = new();
                    int i_button_string = 0;
                    int i_button_line = 0;
                    var PeersNames = new List<string>();
                    var PeersCommands = new List<string>();
                    var PeersColors = new List<string>();
                    string textPeers = "";
                    foreach (var item in listUserPeers)
                    {
                        //var idsPeers = db.unitesGetPeers(long.Parse(item["id"]));
                        //if (idsPeers != null)
                        //{
                           // bool notStated = false;
                           // foreach (var id in idsPeers)
                            //{
                             //   var targetPeer = db.peersGetPeer(id);
                             //   var targetUser = db.peersGetMember(id, Vk.m_from_id, false, false);
                              //  if (targetPeer["active"] == "0")
                              //  {
                                    //notStated = true;
                                    //continue;
                               // }
                               // if (targetUser == null)
                               // {
                                    //notStated = true;
                                    //break;
                               // }
                               // if (targetUser["leave_peer"] != "0")
                               // {
                                    //notStated = true;
                                    //break;
                               // }
                            //}
                           // if (notStated)
                           // {
                              //  continue;
                           // }
                       // }
                        PeersNames.Add("№" + item["id"]);
                        textPeers += "№" + item["id"] + " " + item["name"] + "<br>";

                        PeersColors.Add(Vk.BUTTON_WHITE);
                        PeersCommands.Add("gzovu " + item["id"]);

                        if (i_button_string >= 3)
                        {
                            i_button_string = 0;
                            i_button_line++;
                            buttonsLines.Add(i_button_line);
                            continue;
                        }
                        buttonsLines.Add(i_button_line);

                        i_button_string++;
                    }
                    buttons = Vk.GenerateKeyboard(PeersNames.ToArray(), PeersCommands.ToArray(), PeersColors.ToArray(), buttonsLines.ToArray());
                    Cache cach = new();
                    cach.Set("target_zov_" + Vk.m_from_id, args[0], 5);

                    Vk.MessagesSend("Выберите, в какое объединение вы хотите отправить вызов.<br><br>" + textPeers, 1, 0, buttons);
                    return;
                }

                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 40, "gzov"))
                    {
                        return;
                    }

                    string method = "messages.getConversationMembers";
                    Dictionary<string, string> paramesd = new()
                {
                    { "peer_id", peerid.ToString() }
                };
                    var answer_vk = await Vk.VkAPI(method, paramesd);
                    if (answer_vk["error"] != null || answer_vk["response"] == null)
                    {
                        Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту во всех конференциях.");
                        return;
                    }

                    if (answer_vk["response"].Count() <= 0)
                    {
                        Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту во всех конференциях.");
                        return;
                    }
                    
                    if (answer_vk["response"]["items"] == null)
                    {
                        Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту во всех конференциях.");
                        return;
                    }
                    string text = "🔊 Вы были вызваны [id" + Vk.m_from_id + "|Администратором] беседы.<br><br>";
                    if (args[0] != "" && args[0] != null)
                    {
                        text = text + "Причина: " + args[0];
                    }
                    else
                    {
                        text = text + "Причина не указана.";
                    }

                    long i = 0;
                    long count_max = answer_vk["response"]["items"].Count();
                    foreach (var upd in answer_vk["response"]["items"])
                    {
                        i++;
                        var id = (int)upd["member_id"];
                        if (id > 0)
                        {
                            var target_user = db.peersGetMember(peerid, id, false, false);
                            if (target_user != null)
                            {
                                if (target_user["no_mention"] != "1")
                                {
                                    text = text + "[id" + id + "|​&#8300;]";
                                }
                            }
                            else
                            {
                                text = text + "[id" + id + "|​&#8300;]";
                            }
                        }

                        if (i >= count_max || i >= 40)
                        {
                            text = text + "<br><br>📣 Отправляем уведомления [" + i + "/" + answer_vk["response"]["items"].Count() + "]";
                            i = 0;
                            Vk.MessagesSend(text, 0, peerid, "", false);
                            text = "";
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gzovu()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "gzov"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gzovu", 2))
                {
                    return;
                }

                Cache cach = new();
                var res = cach.Get<string>("target_zov_" + Vk.m_from_id);
                if (res == null)
                {
                    Vk.MessagesSend("Введеный текст был утерян, поскольку прошло более 5 минут. Необходимо ввести команду !вызов ещё раз.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                var target_unitys = cach.Get<string>("target_zovIdUnity_" + Vk.m_from_id);
                if (target_unitys != null && args[0] != "")
                {
                    if (args[0] != "all" && args[0] != "user" && args[0] != "roles")
                    {
                        

                        var Buttons = Vk.GenerateKeyboard(new string[] { "Все", "Без роли", "С ролью" }, new string[] { "gzovu all", "gzovu user", "gzovu roles" },
                                new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_GREEN, Vk.BUTTON_GREEN });
                        Vk.MessagesSend("Выберите, кого вы хотите оповестить.", 1, 0, Buttons);
                        cach.Set("target_selected_uzov_" + Vk.m_peer_id + "_" + Vk.m_from_id, args[0]);
                        cach.Set("target_zovIdUnity_" + Vk.m_from_id, args[0]);
                        return;
                    }
                    //else 
                    //{
                        //Vk.MessagesSend("Вы не выбрали кого оповещать");
                        //return;
                    //}

                    long target_unit = 0;
                    try
                    {
                        target_unit = long.Parse(target_unitys);
                    }
                    catch
                    {
                        Vk.MessagesSend("Укажите необходимое объединение.");
                        return;
                    }

                    var Target_Peer = db.peersGetPeer(Vk.m_peer_id);

                    var target_unity = db.unitesGetUnity(target_unit);

                    if (target_unity == null || target_unity["owner_id"] != Target_Peer["owner"])
                    {
                        Vk.MessagesSend("Создатель этого объединения не является создателем этой беседы.");
                        return;
                    }

                    var ListPeers = db.unitesGetPeers(target_unit);
                    if (ListPeers == null || ListPeers.Count < 1)
                    {
                        Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                        return;
                    }

                    foreach (var peerid in ListPeers)
                    {
                        UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                        if (!cmdChecker.CommandsCheck(UserInfo, 40, "gzov"))
                        {
                            return;
                        }

                        string method = "messages.getConversationMembers";
                        Dictionary<string, string> paramesd = new()
                {
                    { "peer_id", peerid.ToString() }
                };
                        var answer_vk = await Vk.VkAPI(method, paramesd);
                        if (answer_vk["error"] != null || answer_vk["response"]["items"] == null)
                        {
                            Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                            cach.Delete("target_zov_" + Vk.m_from_id);
                            return;
                        }

                        string text = "🔊 Вы были вызваны [id" + Vk.m_from_id + "|Администратором] беседы.<br><br>";
                        if (res != "" && res != null)
                        {
                            text = text + "Причина: " + res;
                        }
                        else
                        {
                            text = text + "Причина не указана.";
                        }

                        long i = 0;
                        long count_max = answer_vk["response"]["items"].Count();
                        foreach (var upd in answer_vk["response"]["items"])
                        {
                            i++;
                            var id = (int)upd["member_id"];
                            if (id > 0)
                            {
                                var targetuser = db.peersGetMember(peerid, id, false, false);
                                if (targetuser != null)
                                {
                                    if (targetuser["no_mention"] != "1")
                                    {
                                        text = text + "[id" + id + "|​&#8300;]";
                                    }
                                }
                                else
                                {
                                    text = text + "[id" + id + "|​&#8300;]";
                                }
                            }

                            if (i >= count_max || i >= 40)
                            {
                                text = text + "<br><br>📣 Отправляем уведомления [" + i + "/" + answer_vk["response"]["items"].Count() + "]";
                                i = 0;
                                Vk.MessagesSend(text, 0, peerid, "", false);
                                text = "";
                            }
                        }
                    }
                    cach.Delete("target_zov_" + Vk.m_from_id);
                    cach.Delete("target_zovIdUnity_" + Vk.m_from_id);
                    return;

                }
                else
                {
                    if (args[0] == null || args[0] == "")
                    {
                        Vk.MessagesSend("Укажите необходимое объединение.");
                        return;
                    }

                    long target_unit = 0;
                    try
                    {
                        target_unit = long.Parse(args[0]);
                    }
                    catch
                    {
                        Vk.MessagesSend("Укажите необходимое объединение.");
                        return;
                    }
                    var Target_Peer = db.peersGetPeer(Vk.m_peer_id);

                    var target_unity = db.unitesGetUnity(target_unit);

                    if (target_unity == null || target_unity["owner_id"] != Target_Peer["owner"])
                    {
                        Vk.MessagesSend("Создатель этого объединения не является создателем этой беседы.");
                        return;
                    }

                    var ListPeers = db.unitesGetPeers(target_unit);
                    if (ListPeers == null || ListPeers.Count < 1)
                    {
                        Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                        return;
                    }

                    cach.Set("target_zovIdUnity_" + Vk.m_from_id, target_unit.ToString());

                    var Buttons = Vk.GenerateKeyboard(new string[] { "Все", "Без роли", "С ролью" }, new string[] { "gzovu all", "gzovu user", "gzovu roles" },
                            new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_GREEN, Vk.BUTTON_GREEN });
                    Vk.MessagesSend("Выберите, кого вы хотите оповестить.", 1, 0, Buttons);
                    cach.Set("target_selected_uzov_" + Vk.m_peer_id + "_" + Vk.m_from_id, args[0]);
                    return;
                }
                

                //cach.Delete("target_zov_" + Vk.m_from_id);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gkick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "gkick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gkick", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gkick"]);
                    return;

                }

                string reason = "не указана.";
                if (args[1] != null && args[1] != "")
                {
                    reason = args[1];
                }

                long user_target_id = long.Parse(args[0]);

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }
                string nickname;
                Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });

                foreach (var peerid in ListPeers)
                {
                    Target_User = db.peersGetMember(peerid, user_target_id, false, true);
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id, false, true);
                    if (UserInfo == null)
                    {
                        continue;
                    }
                    if (!cmdChecker.CommandsCheck(UserInfo, 40, "gkick", false))
                    {
                        continue;
                    }
                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }
                    var peerInfo = db.peersGetPeer(peerid);
                    if (Target_User != null && (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"])) && peerInfo["owner"] != Vk.m_from_id.ToString())
                    {
                        if (peerid == Vk.m_peer_id)
                        {
                            Vk.MessagesSend("Вы не можете исключить пользователя, роль которого выше или равна вашей.");
                        }
                        continue;
                    }

                    string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                    if (Target_User != null && Target_User["gamemode"] != "0")
                    {
                        if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                        {
                            var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                            var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                            Vk.MessagesSend($"{nameWe} не можете исключить участника, поскольку у него иммунитет.<br><br>" +
                                $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                                $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                                $"<br>Снять иммунитет: /gm @ссылка", 0, peerid);
                            continue;
                        }
                    }


                    if (Target_User == null || Target_User["nick"] == "")
                    {
                        if (user_vk.ContainsKey("id" + user_target_id))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + user_target_id].first_name + " " + user_vk["id" + user_target_id].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (Target_User != null && Target_User["nick"] != "")
                        {
                            if (long.Parse(args[0]) < 0)
                            {
                                nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                            }
                            else
                            {
                                nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                            }
                        }
                        else
                        {
                            if (user_vk.ContainsKey("id" + user_target_id))
                            {
                                nickname = "[id" + args[0] + "|" +
                                    user_vk["id" + user_target_id].first_name + " " + user_vk["id" + user_target_id].last_name + "]";
                            }
                            else
                            {
                                nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                            }
                        }
                    }

                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);
                    string text = nickname + " был исключён из конференции." + "<br><br>" +
                    "Исключил: " + nick_admin + "<br>" +
                    "Причина: " + reason;

                    db.peersMemberSetPriority(peerid, user_target_id, 0);

                    if (peerInfo["set_exitremovenick"] == "1")
                    {
                        db.peersMemberSetNickName(peerid, user_target_id, null);
                    }
                    

                    var result = await Vk.KickUser(peerid, user_target_id);

                    if (!result.ContainsKey("error") && (result["response"] != null && result["response"].ToString().ToLower() != "false"))
                    {
                        Vk.MessagesSend(text, 0, peerid);
                        db.logsAddLog(peerid, Database.logsId.USER_KICK, Vk.m_from_id, long.Parse(args[0]), "исключил (пулл)", reason);

                        var warns_database = db.peerGetWarnsList(peerid, user_target_id, false, 3);
                        if (warns_database != null)
                        {
                            foreach (var item in warns_database)
                            {
                                if (item.deleted != 1)
                                {
                                    db.peerWarnsDeleteWarn((int)item.id);
                                }

                            }
                            db.peerMembersSetWarns(peerid, user_target_id, 0);
                        }

                        // исключение из группы
                        var PeerInfo = db.peersGetPeer(peerid);
                        if (PeerInfo["set_kickexitgroup"] != "0" && PeerInfo["group"] != "0" && PeerInfo["access_token"] != "")
                        {
                            var method = "groups.removeUser";
                            var parames = new Dictionary<string, string>();
                            parames.Add("group_id", PeerInfo["group"]);
                            parames.Add("user_id", user_target_id.ToString());
                            parames.Add("access_token", SysUtils.DecryptString(PeerInfo["access_token"]));
                            var JObject = await Vk.VkAPIs(method, parames);
                            if (!JObject.ContainsKey("response") || JObject.ContainsKey("error"))
                            {
                                if (JObject.ContainsKey("error"))
                                {
                                    if (JObject["error"]["error_code"] != null)
                                    {
                                        var code = JObject["error"]["error_code"];
                                        if (code.ToString() == "5")
                                        {
                                            //db.peersSetAccessToken(Vk.m_peer_id, "");
                                            Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен.", 0, peerid);
                                        }
                                    }
                                }
                                db.peersSetAccessToken(peerid, "");
                            }
                        }

                        // --------------------

                    }
                    else if (peerid == Vk.m_peer_id)
                    {
                        Vk.MessagesSend("Указанный пользователь отсутствует в конференции, либо имеет права администратора.");
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_checkpublic()
        {
            try
            {

                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "checkpublic"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "checkpublic", 50))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["checkpublic"]);
                    return;

                }
                if (args[0] != "watch" && args[0] != "kick")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["checkpublic"]);
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (PeerInfo["group"] == "0")
                {
                    Vk.MessagesSend("Проверка на вступление в паблик не установлена.");
                    return;
                }

                string method = "messages.getConversationMembers";
                Dictionary<string, string> paramesd = new()
                {
                    { "peer_id", Vk.m_peer_id.ToString() }
                };
                var answer_vk = await Vk.VkAPI(method, paramesd);
                if (answer_vk["error"] != null || answer_vk["response"]["items"] == null)
                {
                    Vk.MessagesSend("Ошибка получения данных. Возможно, вы не выдали права администратора боту.");
                    return;
                }

                var users = answer_vk["response"]["items"];
                List<long> users_target = new();
                foreach (var item in users)
                {
                    if (item["member_id"].ToString() != "")
                    {
                        long target_id = long.Parse(item["member_id"].ToString());
                        if (target_id > 0)
                        {
                            users_target.Add(target_id);
                        }
                    }
                }

                var target_arrs = users_target.ToArray();
                var arrays = exts.Split(target_arrs, 499);

                List<long> not_member_group = new();

                foreach (var item in arrays)
                {
                    method = "groups.isMember";
                    Dictionary<string, string> prams = new() { { "group_id", PeerInfo["group"] }, { "user_ids", string.Join(",", item) } };
                    var result = await Vk.VkAPI(method, prams);
                    if (result == null || result.ContainsKey("error") || !result.ContainsKey("response") || result["response"].ToString() == "0")
                    {

                        Vk.MessagesSend($"Ошибка обработки команды. Код ошибки: [#sw345]", 0);
                        return;
                    }
                    foreach (var itemr in result["response"])
                    {
                        if (itemr["member"].ToString() == "0")
                        {
                            not_member_group.Add(long.Parse(itemr["user_id"].ToString()));
                        }
                    }
                }
                if (not_member_group.Count < 1)
                {
                    Vk.MessagesSend("Все пользователи в беседе подписаны на необходимое сообщество.");
                    return;
                }

                if (args[0] == "watch")
                {
                    string text = $"Список пользователей, не состоящих в [club{PeerInfo["group"]}|группе]:<br>";
                    var nicks = await Vk.UserGetNameUrls(not_member_group.ToArray());
                    long i = 0;
                    foreach (var item in not_member_group)
                    {
                        i++;
                        text += $"{i}. " + nicks[item.ToString()] + "<br>";
                    }
                    Vk.MessagesSend(text);
                }
                else
                {
                    Vk.MessagesSend($"Исключение пользователей, не состоящих в [club{PeerInfo["group"]}|группе]..");
                    foreach (var item in not_member_group)
                    {
                        Vk.KickUser(Vk.m_peer_id, item);
                    }
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }

        }

        /*static double StringCompare(string a, string b)
        {
            if (a == b) //Same string, no iteration needed.
                return 100;
            if ((a.Length == 0) || (b.Length == 0)) //One is empty, second is not
            {
                return 0;
            }
            double maxLen = a.Length > b.Length ? a.Length : b.Length;
            int minLen = a.Length < b.Length ? a.Length : b.Length;
            int sameCharAtIndex = 0;
            for (int i = 0; i < minLen; i++) //Compare char by char
            {
                if (a[i] == b[i])
                {
                    sameCharAtIndex++;
                }
            }
            return sameCharAtIndex / maxLen * 100;
        }*/

        public async void command_gsetnick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "gsetnick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gsetnick", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                Dictionary<string, string>? Target_User = null;
                if (args.Length < 2)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gsnick"]);
                    return;
                }
                if (args[0] == null || args[0] == "" || args[1] == null || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gsnick"]);
                    return;

                }

                string nick = "";
                
                if (args[1] != null && args[1] != "")
                {
                    nick = args[1];
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (vk.EmojiCount(nick) >= 1)
                {
                    if (!db.UserIsVip(Vk.m_from_id) && !db.PeerIsVip(Target_Peer))
                    {
                        Vk.MessagesSend("В никнейме найдены эмодзи. Для их использования необходим VIP статус.<br>" +
                                        "К сожалению, ни у вас, ни у беседы, статуса VIP нет. Сообщите нам, если это ошибка — /report.");
                        return;
                    }
                }

                long user_target_id = long.Parse(args[0]);

                
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }
                string nickname;
                //Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });

                var adminNickVk = await Vk.GetUrlName(Vk.m_from_id);
                foreach (var peerid in ListPeers)
                {
                    
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 40, "gsnick"))
                    {
                        Vk.MessagesSend("У вас недостаточный приоритет для выдачи ника (gsnick) в этой беседе.", 0, peerid);
                        continue;
                    }
                    Target_User = db.peersGetMember(peerid, user_target_id, false, true);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    var peerInfo = db.peersGetPeer(peerid);
                    if (Target_User != null && (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"])) && peerInfo["owner"] != Vk.m_from_id.ToString())
                    {
                        if (peerid == Vk.m_peer_id)
                        {
                            Vk.MessagesSend("Вы не можете менять ник пользователя, роль которого выше или равна вашей.");
                        }
                        continue;
                    }

                    if (vk.EmojiCount(nick) >= 1)
                    {
                        if (!db.UserIsVip(Vk.m_from_id) && !db.PeerIsVip(peerInfo))
                        {
                            continue;
                        }
                    }

                    string AdminNick = "";
                    if (UserInfo["nick"] != "")
                    {
                        if (Vk.m_from_id < 0)
                        {
                            AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                        }
                        else
                        {
                            AdminNick = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                        }
                    }
                    else
                    {
                        if (Vk.m_from_id < 0)
                        {
                            AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                        }
                        else
                        {
                            AdminNick = adminNickVk;
                        }
                    }

                    string text;
                    if (Target_User["nick"] == "")
                    {
                        if (long.Parse(args[0]) < 0)
                        {
                            text = AdminNick + " установил никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                                "Новый никнейм: " + args[1];
                        }
                        else
                        {
                            text = AdminNick + " установил никнейм [id" + args[0] + "|пользователю].<br><br>" +
                                "Новый никнейм: " + args[1];
                        }
                        db.logsAddLog(peerid, Database.logsId.USER_SETNICK, Vk.m_from_id, long.Parse(args[0]), "установил никнейм (пулл)", args[1]);
                    }
                    else
                    {
                        if (long.Parse(args[0]) < 0)
                        {
                            text = AdminNick + " изменил никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                                Target_User["nick"] + " » " + args[1];
                        }
                        else
                        {
                            text = AdminNick + " изменил никнейм [id" + args[0] + "|пользователю].<br><br>" +
                                Target_User["nick"] + " » " + args[1];
                        }
                        db.logsAddLog(peerid, Database.logsId.USER_SETNICK, Vk.m_from_id, long.Parse(args[0]), "установил никнейм (пулл)", args[1], Target_User["nick"]);
                    }

                    db.peersMemberSetNickName(peerid, long.Parse(args[0]), args[1]);
                    List<string> buttons_names = new List<string>()
                    {
                        "Удалить ник"
                    };
                        List<string> buttons_commands = new List<string>()
                    {
                        "rnick id" + args[0]
                    };
                        List<string> buttons_colors = new List<string>()
                    {
                        Vk.BUTTON_RED
                    };

                    var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);

                    Vk.MessagesSend(text, 0, peerid, buttons);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gremovenick()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 40, "gremovenick"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gremovenick", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id"});
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["grnick"]);
                    return;

                }

                string nick = "";

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);

                long user_target_id = long.Parse(args[0]);

                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }
                string nickname;
                //Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(args[0]) });

                var adminNickVk = await Vk.GetUrlName(Vk.m_from_id);
                foreach (var peerid in ListPeers)
                {
                    Target_User = db.peersGetMember(peerid, user_target_id, false, false);
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 40, "gremovenick"))
                    {
                        continue;
                    }

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }
                    var peerInfo = db.peersGetPeer(peerid);
                    if (Target_User != null && (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"])) && peerInfo["owner"] != Vk.m_from_id.ToString())
                    {
                        if (peerid == Vk.m_peer_id)
                        {
                            Vk.MessagesSend("Вы не можете менять ник пользователя, роль которого выше или равна вашей.");
                        }
                        continue;
                    }
                    string AdminNick = "";
                    if (UserInfo["nick"] != "")
                    {
                        if (Vk.m_from_id < 0)
                        {
                            AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                        }
                        else
                        {
                            AdminNick = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                        }
                    }
                    else
                    {
                        if (Vk.m_from_id < 0)
                        {
                            AdminNick = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                        }
                        else
                        {
                            AdminNick = adminNickVk;
                        }
                    }
                    string text = "";
                    if (Target_User["nick"] != "")
                    {
                        if (long.Parse(args[0]) < 0)
                        {
                            text = AdminNick + " удалил никнейм [club" + args[0].Substring(1) + "|сообществу].<br><br>" +
                                "Прошлый никнейм: " + Target_User["nick"];
                        }
                        else
                        {
                            text = AdminNick + " удалил никнейм [id" + args[0] + "|пользователю].<br><br>" +
                                "Прошлый никнейм: " + Target_User["nick"];
                        }

                        Vk.MessagesSend(text, 0, peerid);
                        db.peersMemberSetNickName(peerid, long.Parse(args[0]), null);
                        db.logsAddLog(peerid, Database.logsId.USER_REMOVENICK, Vk.m_from_id, long.Parse(args[0]), "удалил никнейм (пулл)", Target_User["nick"]);
                    }
                    else
                    {
                        if (long.Parse(args[0]) < 0)
                        {
                            text = "[club" + args[0].Substring(1) + "|Сообщество] не имеет установленного никнейма.";
                        }
                        else
                        {
                            text = "[id" + args[0] + "|Пользователь] не имеет установленного никнейма.";
                        }
                        if (Vk.is_callbackButton)
                        {
                            var nickCallback = adminNickVk;
                            text += "<br><br>Команду выполнил: " + nickCallback;
                        }
                        Vk.MessagesSend(text, 0, peerid);
                    }



                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }


        public static int StringCompare(string reco, string gypo)
        {
            if (reco == gypo)
            {
                return 100;
            }
            int count = 0, percant = 0, percant1 = 0, percant2 = 0;
            char[] recos = reco.ToCharArray();
            char[] gypos = gypo.ToCharArray();
            for (int i = 0; i < recos.Length; i++)
            {
                for (int j = 0; j < gypos.Length; j++)
                {
                    if (recos[i] == gypos[j])
                    { count++; }
                }
            }
            if (count > 0)
            {
                percant1 = (100 / reco.Length) * count;
                percant2 = (100 / gypo.Length) * count;
                percant = (percant1 + percant2) / 2;
            }
            else
            { percant = 0; }
            return percant;
        }


        public static int ComputeLevenshteinDistance(string source, string target)
        {
            if ((source == null) || (target == null)) return 0;
            if ((source.Length == 0) || (target.Length == 0)) return 0;
            if (source == target) return source.Length;

            int sourceWordCount = source.Length;
            int targetWordCount = target.Length;

            // Step 1
            if (sourceWordCount == 0)
                return targetWordCount;

            if (targetWordCount == 0)
                return sourceWordCount;

            int[,] distance = new int[sourceWordCount + 1, targetWordCount + 1];

            // Step 2
            for (int i = 0; i <= sourceWordCount; distance[i, 0] = i++) ;
            for (int j = 0; j <= targetWordCount; distance[0, j] = j++) ;

            for (int i = 1; i <= sourceWordCount; i++)
            {
                for (int j = 1; j <= targetWordCount; j++)
                {
                    // Step 3
                    int cost = (target[j - 1] == source[i - 1]) ? 0 : 1;

                    // Step 4
                    distance[i, j] = Math.Min(Math.Min(distance[i - 1, j] + 1, distance[i, j - 1] + 1), distance[i - 1, j - 1] + cost);
                }
            }

            return distance[sourceWordCount, targetWordCount];
        }

        double CalculateSimilarity(string source, string target)
        {
            if ((source == null) || (target == null)) return 0.0;
            if ((source.Length == 0) || (target.Length == 0)) return 0.0;
            if (source == target) return 1.0;

            int stepsToSame = ComputeLevenshteinDistance(source, target);
            return (1.0 - ((double)stepsToSame / (double)Math.Max(source.Length, target.Length)));
        }
    }

    class admin_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;

        public admin_cmds(vk vks, Database dbs, settings set)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
        }

        public async void command_gsetrole()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "gsetrole"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gsetrole", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });

                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[1] != "" && args[1] != "")
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"]);
                    return;
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                string nickname;
                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);
                long target_id = long.Parse(args[0]);
                foreach (var peerid in ListPeers)
                {
                    Target_User = db.peersGetMember(peerid, target_id, false, true);
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);

                    if (!cmdChecker.CommandsCheck(UserInfo, 60, "gsetrole", false))
                    {
                        Vk.MessagesSend("В этой беседе у Вас недостаточно прав для выполнения данной команды.", 0, peerid);
                        continue;
                    }

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                    if (Target_User != null && Target_User["gamemode"] != "0")
                    {
                        if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                        {
                            var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                            var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                            Vk.MessagesSend($"{nameWe} не можете изменить роль участника, поскольку у него иммунитет.<br><br>" +
                                $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                                $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                                $"<br>Снять иммунитет: /gm @ссылка", 0, peerid);
                            continue;
                        }
                    }

                    if (Target_User["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { target_id });
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }

                    string[] args_role = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "int" });
                    int target_role_priority = -1;
                    if (args_role[0] == null || args_role[0] == "")
                    {
                        string[] args_roletext = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "text" });
                        if (args_roletext[0] == null || args_roletext[0] == "")
                        {
                            Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"], 0, peerid);
                            continue;
                        }
                        var roles = db.peerGetRoles(peerid);
                        args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                        foreach (var item in roles)
                        {
                            var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                            if (args_roletext[0] == name_role)
                            {
                                target_role_priority = item.Value.priority;
                                break;
                            }
                        }
                        if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                        {
                            target_role_priority = 20;
                        }
                        else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                        {
                            target_role_priority = 40;
                        }
                        else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                        {
                            target_role_priority = 60;
                        }
                        else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                            args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                            args_roletext[0] == "spec" || args_roletext[0] == "lead")
                        {
                            target_role_priority = 80;
                        }
                    }
                    else
                    {
                        if (long.Parse(args_role[0]) >= 100 || long.Parse(args_role[0]) <= -1)
                        {
                            Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles", 0, peerid);
                            continue;
                        }
                        target_role_priority = int.Parse(args_role[0]);
                    }

                    if (target_role_priority <= -1)
                    {
                        Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles", 0, peerid);
                        continue;
                    }
                    string text;

                    var peerInfo = db.peersGetPeer(peerid);

                    if (peerInfo == null)
                    {
                        continue;
                    }

                    if (long.Parse(Target_User["priority"]) != 0)
                    {
                        if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != Vk.m_from_id.ToString())
                        {
                            Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.", 0, peerid);
                            return;
                        }
                        if (long.Parse(UserInfo["priority"]) <= target_role_priority && peerInfo["owner"] != Vk.m_from_id.ToString())
                        {
                            Vk.MessagesSend("Вы не можете выдавать роль, приоритет которой выше или равен вашему.", 0, peerid);
                            return;
                        }
                        if (long.Parse(Target_User["priority"]) == target_role_priority)
                        {
                            Vk.MessagesSend(nickname + " уже имеет данную роль.", 0, peerid);
                            return;
                        }
                        var old_name = db.rolesGetName(peerid, Target_User["priority"]);
                        text = nickname + " получил новую роль." + "<br>" +
                        "Название: " + db.rolesGetName(peerid, target_role_priority.ToString()) + "<br>" +
                        "Выдал: " + nick_admin + "<br>" +
                        "Предыдущая роль: " + old_name;
                    }
                    else
                    {
                        text = nickname + " получил новую роль." + "<br>" +
                        "Название: " + db.rolesGetName(peerid, target_role_priority.ToString()) + "<br>" +
                        "Выдал: " + nick_admin;
                    }

                    Vk.MessagesSend(text, 0, peerid);
                    db.peersMemberSetPriority(peerid, long.Parse(args[0]), target_role_priority);
                    db.logsAddLog(peerid, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль (пулл)", target_role_priority.ToString(), Target_User["priority"]);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gsyssetrole()
        {
            try
            {
                if (!settings.OWNER_IDS.ContainsKey(Vk.m_from_id))
                {
                    return;
                }

                if (settings.OWNER_IDS[Vk.m_from_id].access_sysrole == 0)
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });

                Dictionary<string, string>? Target_User = null;
                if (args[0] != null && args[1] != "" && args[1] != "")
                {
                    Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"]);
                    return;
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                string nickname;
                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);
                long target_id = long.Parse(args[0]);
                foreach (var peerid in ListPeers)
                {
                    Target_User = db.peersGetMember(peerid, target_id, false, true);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";

                    if (Target_User["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { target_id });
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }

                    string[] args_role = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "int" });
                    int target_role_priority = -1;
                    if (args_role[0] == null || args_role[0] == "")
                    {
                        string[] args_roletext = await cmdChecker.getArguments("/setrole " + args[1], new string[] { "text" });
                        if (args_roletext[0] == null || args_roletext[0] == "")
                        {
                            Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"], 0, peerid);
                            continue;
                        }
                        var roles = db.peerGetRoles(peerid);
                        args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                        foreach (var item in roles)
                        {
                            var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                            if (args_roletext[0] == name_role)
                            {
                                target_role_priority = item.Value.priority;
                                break;
                            }
                        }
                        if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                        {
                            target_role_priority = 20;
                        }
                        else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                        {
                            target_role_priority = 40;
                        }
                        else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                        {
                            target_role_priority = 60;
                        }
                        else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                            args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                            args_roletext[0] == "spec" || args_roletext[0] == "lead")
                        {
                            target_role_priority = 80;
                        }
                    }
                    else
                    {
                        if (long.Parse(args_role[0]) >= 100 || long.Parse(args_role[0]) <= -1)
                        {
                            Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles", 0, peerid);
                            continue;
                        }
                        target_role_priority = int.Parse(args_role[0]);
                    }

                    if (target_role_priority <= -1)
                    {
                        Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles", 0, peerid);
                        continue;
                    }
                    string text;

                    var peerInfo = db.peersGetPeer(peerid);

                    if (long.Parse(Target_User["priority"]) != 0)
                    { 
                        if (long.Parse(Target_User["priority"]) == target_role_priority)
                        {
                            Vk.MessagesSend(nickname + " уже имеет данную роль.", 0, peerid);
                            return;
                        }
                        var old_name = db.rolesGetName(peerid, Target_User["priority"]);
                        text = nickname + " получил новую роль." + "<br>" +
                        "Название: " + db.rolesGetName(peerid, target_role_priority.ToString()) + "<br>" +
                        "Выдал: " + nick_admin + "<br>" +
                        "Предыдущая роль: " + old_name;
                    }
                    else
                    {
                        text = nickname + " получил новую роль." + "<br>" +
                        "Название: " + db.rolesGetName(peerid, target_role_priority.ToString()) + "<br>" +
                        "Выдал: " + nick_admin + " (системный адмиинстратор)";
                    }

                    Vk.MessagesSend(text, 0, peerid);
                    db.peersMemberSetPriority(peerid, long.Parse(args[0]), target_role_priority);
                    db.logsAddLog(peerid, Database.logsId.ADMIN_GSYSROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль (пулл system admin)", target_role_priority.ToString(), Target_User["priority"]);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_ghelper()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "ghelper"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "ghelper", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["ghelper"]);
                    return;
                }

                string nickname;

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                long target_id = long.Parse(args[0]);

                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 60, "ghelper", false))
                    {
                        continue;
                    }

                    Target_User = db.peersGetMember(peerid, target_id, false, true);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);

                    if (Target_User["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }

                    string text;
                    if (long.Parse(Target_User["priority"]) != 0)
                    {
                        if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                        {
                            Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.", 0, peerid);
                            continue;
                        }
                        if (long.Parse(Target_User["priority"]) >= 20)
                        {
                            Vk.MessagesSend(nickname + " уже имеет роль с большим, либо таким же приоритетом.", 0, peerid);
                            continue;
                        }
                        var old_name = db.rolesGetName(peerid, Target_User["priority"]);
                        text = nickname + " получил права помощника." + "<br>" +
                        "Выдал: " + nick_admin + "<br>" +
                        "Предыдущая роль: " + old_name;
                    }
                    else
                    {
                        text = nickname + " получил права помощника." + "<br>" +
                        "Выдал: " + nick_admin;
                    }

                    Vk.MessagesSend(text, 0, peerid);
                    db.peersMemberSetPriority(peerid, target_id, 20);
                    db.logsAddLog(peerid, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль (пулл)", "20", Target_User["priority"]);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gmoder()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "gmoder"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gmoder", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gmoder"]);
                    return;
                }

                string nickname;

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                long target_id = long.Parse(args[0]);

                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 60, "gmoder", false))
                    {
                        continue;
                    }

                    Target_User = db.peersGetMember(peerid, target_id, false, true);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);

                    if (Target_User["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }

                    string text;
                    if (long.Parse(Target_User["priority"]) != 0)
                    {
                        if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                        {
                            Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.", 0, peerid);
                            continue;
                        }
                        if (long.Parse(Target_User["priority"]) >= 40)
                        {
                            Vk.MessagesSend(nickname + " уже имеет роль с большим, либо таким же приоритетом.", 0, peerid);
                            continue;
                        }
                        var old_name = db.rolesGetName(peerid, Target_User["priority"]);
                        text = nickname + " получил права модератора." + "<br>" +
                        "Выдал: " + nick_admin + "<br>" +
                        "Предыдущая роль: " + old_name;
                    }
                    else
                    {
                        text = nickname + " получил права модератора." + "<br>" +
                        "Выдал: " + nick_admin;
                    }

                    Vk.MessagesSend(text, 0, peerid);
                    db.peersMemberSetPriority(peerid, target_id, 40);
                    db.logsAddLog(peerid, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль (пулл)", "40", Target_User["priority"]);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_moder()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "addmoder"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "addmoder", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["addmoder"]);
                    return;
                }

                string nickname;

                long target_id = long.Parse(args[0]);


                UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);

                Target_User = db.peersGetMember(Vk.m_peer_id, target_id, false, true);

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (target_id < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }

                string text;
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                    {
                        Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.");
                        return;
                    }
                    if (long.Parse(Target_User["priority"]) >= 40)
                    {
                        Vk.MessagesSend(nickname + " уже имеет роль с большим, либо таким же приоритетом.");
                        return;
                    }
                    var old_name = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                    text = nickname + " получил права модератора." + "<br>" +
                    "Выдал: " + nick_admin + "<br>" +
                    "Предыдущая роль: " + old_name;
                }
                else
                {
                    text = nickname + " получил права модератора." + "<br>" +
                    "Выдал: " + nick_admin;
                }
                List<string> buttons_names = new List<string>()
                {
                    "Снять"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "rr id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray());

                Vk.MessagesSend(text, 1, 0, buttons);
                db.peersMemberSetPriority(Vk.m_peer_id, target_id, 40);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль", "40", Target_User["priority"]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
        
        public async void command_gban()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "gban"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gban", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id", "text" });
                if (args[0] == "" || args[0] == null || args[0] == Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gban"]);
                    return;
                }

                int days = 0;
                string reason = "не указана.";
                if (args.Length >= 2)
                {
                    var explodes = args[1].Split(" ");
                    if (explodes.Length >= 2)
                    {
                        try
                        {
                            var isNumeric = int.TryParse(explodes[0], out days);
                            if (isNumeric)
                            {
                                if (days <= 0 || days >= 365)
                                {
                                    days = 0;
                                }
                                string[] sas_args = await cmdChecker.getArguments("/gban " + args[1], new string[] { "int", "text" });
                                if (sas_args[1] != null && sas_args[1] != "")
                                {
                                    reason = sas_args[1];
                                }
                            }
                            else
                            {
                                if (explodes[0] != null && explodes[0] != "")
                                {
                                    reason = args[1];
                                }
                            }


                        }
                        catch
                        {
                            days = 0;
                        }
                    }
                    else
                    {
                        if (args[1] != null && args[1] != "")
                        {
                            reason = args[1];
                        }
                    }
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                long target_id = long.Parse(args[0]);

                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 60, "gban", false))
                    {
                        continue;
                    }

                    Dictionary<string, string>? Target_User = db.peersGetMember(peerid, target_id);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    string nickname = db.peersGetNickUrl(peerid, long.Parse(Target_User["user_id"]));
                    if (db.bansGetBan(peerid, target_id) != null)
                    {
                        Vk.MessagesSend("⛔ " + nickname + " уже находится в списке заблокированных.", 0, peerid);
                        continue;
                    }

                    var peerInfo = db.peersGetPeer(peerid);

                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]) && peerInfo["owner"] != Vk.m_from_id.ToString())
                    {
                        Vk.MessagesSend("Вы не можете заблокировать участника, роль которого выше или равна вашей.", 0, peerid);
                        continue;
                    }

                    string nameWe = (long.Parse(args[0]) <= 0) ? "[club" + args[0].Substring(1) + "|Вы]" : $"[id{args[0]}|Вы]";
                    if (Target_User != null && Target_User["gamemode"] != "0")
                    {
                        if (long.Parse(UserInfo["priority"]) < long.Parse(Target_User["gamemode"]))
                        {
                            var namesVkAdmin = await Vk.UserGetNameUrls(new long[] { long.Parse(Target_User["gamemode_by"]) });
                            var targetRole = db.rolesGetName(Vk.m_peer_id, Target_User["gamemode"]);

                            Vk.MessagesSend($"{nameWe} не можете заблокировать участника, поскольку у него иммунитет.<br><br>" +
                                $"Выдан: " + namesVkAdmin[Target_User["gamemode_by"]] +
                                $"<br>Необходимая роль для взаимодействия: {targetRole} ({Target_User["gamemode"]} приоритет)." +
                                $"<br>Снять иммунитет: /gm @ссылка", 0, peerid);
                            continue;
                        }
                    }
                    string ban_time = null;
                    string ban_text = "перманентно";
                    if (days != 0)
                    {
                        ban_time = db.timeGetForString(DateTimeOffset.Now.AddDays(days));
                        ban_text = "до " + DateTimeOffset.Now.AddDays(days).ToString("g");
                    }

                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);

                    string text = "";

                    Vk.KickUser(peerid, target_id);
                    /*// исключение из группы
                        var PeerInfo = db.peersGetPeer(peerid);
                        if (PeerInfo["set_kickexitgroup"] != "0" && PeerInfo["group"] != "0" && PeerInfo["access_token"] != "")
                        {
                            var method = "groups.removeUser";
                            var parames = new Dictionary<string, string>();
                            parames.Add("group_id", PeerInfo["group"]);
                            parames.Add("user_id", user_target_id.ToString());
                            parames.Add("access_token", PeerInfo["access_token"]);
                            var JObject = await Vk.VkAPIs(method, parames);
                            if (!JObject.ContainsKey("response") || JObject.ContainsKey("error"))
                            {
                                if (JObject.ContainsKey("error"))
                                {
                                    if (JObject["error"]["error_code"] != null)
                                    {
                                        var code = JObject["error"]["error_code"];
                                        if (code.ToString() == "5")
                                        {
                                            //db.peersSetAccessToken(Vk.m_peer_id, "");
                                            Vk.MessagesSend("Ошибка исключения участника из группы — токен доступа недействителен.", 0, peerid);
                                        }
                                    }
                                }
                                db.peersSetAccessToken(peerid, "");
                            }
                        }

                        // --------------------*/

                    text = "⛔ " + nickname + " получил блокировку.<br><br>Причина: " + reason + "<br>" +
                            "Срок блокировки: " + ban_text + "<br>" +
                            "Заблокировал: " + nick_admin;
                    Vk.MessagesSend(text, 0, peerid);
                    //db.peersDeleteMember(peerid, target_id);
                    db.peersMemberSetPriority(peerid, target_id, 0);

                    if (peerInfo["set_exitremovenick"] == "1")
                    {
                        db.peersMemberSetNickName(peerid, target_id, null);
                    }

                    var warns_database = db.peerGetWarnsList(peerid, target_id, false, 3);
                    if (warns_database != null)
                    {
                        foreach (var item in warns_database)
                        {
                            if (item.deleted != 1)
                            {
                                db.peerWarnsDeleteWarn((int)item.id);
                            }

                        }
                        db.peerMembersSetWarns(peerid, target_id, 0);
                    }

                    db.bansAddBan(peerid, target_id, Vk.m_from_id, reason, ban_time);
                    db.logsAddLog(peerid, Database.logsId.USER_BAN, Vk.m_from_id, target_id, "заблокировал (пулл)", reason, ban_text);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gunban()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "gunban"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gunban", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gunban"]);
                    return;
                }

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                long target_id = long.Parse(args[0]);
                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 60, "gunban", false))
                    {
                        continue;
                    }
                    Target_User = db.peersGetMember(peerid, target_id, false, true);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    var banInfo = db.bansGetBan(peerid, target_id);
                    //Dictionary<string, string> banInfo = null;
                    string nickname = "";

                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);

                    if (Target_User["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }

                    if (banInfo == null)
                    {
                        Vk.MessagesSend(nickname + " не находится в списке заблокированных.", 0, peerid);
                        continue;
                    }


                    string text = "♻ " + nickname + " был разблокирован." + "<br>" +
                        "Разблокировал: " + nick_admin;
                    Vk.MessagesSend(text, 0, peerid);

                    db.bansDeleteBan(peerid, target_id);
                    db.logsAddLog(peerid, Database.logsId.USER_UNBAN, Vk.m_from_id, target_id, "разблокировал (пулл)");
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_delete()
        {
            //delete
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "delete"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "delete", 5))
                {
                    return;
                }

                if (Vk.m_reply_message == null)
                {
                    Vk.MessagesSend("Необходимо переслать (кнопка 'ответить', удалить можно только одно сообщение) то, что вы хотите удалить.");
                    return;
                }
                if (Vk.m_reply_message["conversation_message_id"] == null)
                {
                    Console.WriteLine(Vk.m_reply_message);
                    Vk.MessagesSend("Необходимо переслать (кнопка 'ответить', удалить можно только одно сообщение) то, что вы хотите удалить.");
                    return;
                }
                else
                {
                    vk.DeleteMessage(Vk.m_peer_id, Vk.m_reply_message["conversation_message_id"].ToString());
                    vk.DeleteMessage(Vk.m_peer_id, Vk.m_conversation_message_id.ToString());
                    //Vk.MessagesSend("Сообщение удалено. В случае, если это не так — проверьте, является ли пользователь администратором в самой беседе ВК.", 0);
                }
                //Console.WriteLine(Vk.m_reply_message);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gm()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "gm"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gm", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gm"]);
                    return;
                }

                string nickname;

                long target_id = long.Parse(args[0]);

                UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);

                Target_User = db.peersGetMember(Vk.m_peer_id, target_id, false, true);

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (target_id < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }

                string text;
                string nameWe = (Vk.m_from_id <= 0) ? "[club" + Vk.m_from_id.ToString().Substring(1) + "|Вы]" : $"[id{Vk.m_from_id}|Вы]";
                if (Target_User["gamemode"] != "0")
                {
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                    {
                        
                        Vk.MessagesSend($"{nameWe} не можете снять иммунитет человеку, роль которого выше или равна вашей.");
                        return;
                    }
                    string nick_adminTwo = db.peersGetNickUrl(Vk.m_peer_id, long.Parse(Target_User["gamemode_by"]));
                    text = nickname + " лишился иммунитета." + "<br>" +
                    "Снял: " + nick_admin + "<br>" +
                    "Выдавал ранее: " + nick_adminTwo;
                    db.peersMemberSetGamemode(Vk.m_peer_id, target_id, 0, 0);
                    Vk.MessagesSend(text);
                    return;
                }

                if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                {
                    Vk.MessagesSend($"{nameWe} не можете выдать иммунитет человеку, роль которого выше или равна вашей.");
                    return;
                }
                    
                var roleName = db.rolesGetName(Vk.m_peer_id, UserInfo["priority"]);
                text = nickname + " получил иммунитет." + "<br>" +
                "Выдал: " + nick_admin + "<br>" +
                "Роль, необходимая для взаимодействия (блокировка/мут/исключение/предупреждение): "+ roleName + " и выше.";

                List<string> buttons_names = new List<string>()
                {
                    "Отменить"
                };
                var targetIdArg = (long.Parse(args[0]) <= 0) ? "club" + args[0].Substring(1) : $"id{args[0]}";
                List<string> buttons_commands = new List<string>()
                {
                    "gm " + targetIdArg
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray(), null, false, true, false);

                Vk.MessagesSend(text, 1, 0, buttons);
                db.peersMemberSetGamemode(Vk.m_peer_id, target_id, int.Parse(UserInfo["priority"]), Vk.m_from_id);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_GAMEMODE, Vk.m_from_id, long.Parse(args[0]), "выдал иммунитет");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gms()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "gms"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gms", 5))
                {
                    return;
                }

                string nickname;


                UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);

                var baseGms = db.peerGetGamemodes(Vk.m_peer_id);
                if (baseGms == null || baseGms.Count() <= 0)
                {
                    Vk.MessagesSend("Нет пользователей с иммунитетом.<br><br>Вы можете выдать иммунитет командой '!gm' или '!иммунитет'");
                    return;
                }
                string text = "Список пользователей, имеющих иммунитет:<br><br>";
                int i = 1;
                foreach (var user in baseGms)
                {
                    try
                    {
                        long userId = long.Parse(user["user_id"]);
                        int gamemode = int.Parse(user["gamemode"]);
                        long adminId = long.Parse(user["gamemode_by"]);
                        var userVkName = await Vk.UserGetNameUrls(new long[] { userId, adminId });

                        text += $"{i}. {userVkName[userId.ToString()]} ({gamemode} приоритет), выдал: {userVkName[adminId.ToString()]}.<br>";
                        i++;
                    }
                    catch
                    {

                    }
                }

                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_filters()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "filters"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "filters", 5))
                {
                    return;
                }

                //string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                //Dictionary<string, string>? Target_User = null;
                //if (args[0] != null && args[1] != "" && args[1] != "")
                //{
                  //  Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                //}
                //else
                //{
                //    Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"]);
               //     return;
                //}

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                

                var ListWords = db.FilterWordsGetWords(Vk.m_peer_id);
                if (ListWords == null || ListWords.Count <= 0)
                {
                    Vk.MessagesSend("В данной беседе нет установленых Администратором запрещенных слов.<br><br>Вы можете добавить слово в черный список: /filteradd");
                    return;
                }
                string text = "Список запрещенных фраз Администратором:<br>";

                int i = 1;
                foreach (var word in ListWords)
                {
                    string typeAct = (word.Value["type"] == "1") ? "удалять сообщение" : (word.Value["type"] == "2") ? "исключать" : "предупреждать пользователя";
                    text += $"{i}. '{word.Key}' — {typeAct}<br>";
                    i++;
                }

                text += $"<br>Всего фраз: {ListWords.Count}<br>Редактировать фразу: /filteredit [фраза]<br>Удалить фразу: /filterdel [фраза]";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_filteradd()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "filteradd"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "filteradd", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Испльзование: /filteradd [слово или фраза]");
                    return;
                }


                //Dictionary<string, string>? Target_User = null;
                //if (args[0] != null && args[1] != "" && args[1] != "")
                //{
                //  Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                //}
                //else
                //{
                //    Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"]);
                //     return;
                //}

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);


                var ListWords = db.FilterWordsGetWords(Vk.m_peer_id);
                if (ListWords != null && ListWords.Count >= 1)
                {
                    foreach (var item in ListWords)
                    {
                        if (item.Value["word"].ToLower().Replace(" ", "") == args[0].ToLower().Replace(" ", ""))
                        {
                            Vk.MessagesSend("В данной беседе уже есть указанное слово.<br><br>Вы можете посмотреть список слов: /filters");
                            return;
                        }
                    }
                    
                }

                db.FilterWordsAddWord(Vk.m_peer_id, args[0], Vk.m_from_id);
                Vk.MessagesSend("Слово успешно добавлено в список запрещенных. Настройте фразу: /filteredit [фраза]");
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_filterdel()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "filterdel"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "filterdel", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Испльзование: /filterdel [слово или фраза]");
                    return;
                }


                //Dictionary<string, string>? Target_User = null;
                //if (args[0] != null && args[1] != "" && args[1] != "")
                //{
                //  Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                //}
                //else
                //{
                //    Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"]);
                //     return;
                //}

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);


                var ListWords = db.FilterWordsGetWords(Vk.m_peer_id);
                if (ListWords != null && ListWords.Count >= 1)
                {
                    foreach (var item in ListWords)
                    {
                        if (item.Value["word"].ToLower().Replace(" ", "") == args[0].ToLower().Replace(" ", ""))
                        {
                            db.FilterWordsDelWord(Vk.m_peer_id, item.Value["word"]);
                            Vk.MessagesSend("Фраза удалена.");
                            return;
                        }
                    }

                }

                //db.FilterWordsAddWord(Vk.m_peer_id, args[0], Vk.m_from_id);
                Vk.MessagesSend("Слово не найдено. Посмотрите список слов: /filters");
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_filteredit()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 60, "filteredit"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "filteredit", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Испльзование: /filteredit [слово или фраза]");
                    return;
                }


                //Dictionary<string, string>? Target_User = null;
                //if (args[0] != null && args[1] != "" && args[1] != "")
                //{
                //  Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]), false, true);
                //}
                //else
                //{
                //    Vk.MessagesSend(CommandsList.CommandsHelp["gsetrole"]);
                //     return;
                //}

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);


                var ListWords = db.FilterWordsGetWords(Vk.m_peer_id);
                if (ListWords != null && ListWords.Count >= 1)
                {
                    foreach (var item in ListWords)
                    {
                        if (item.Value["word"].ToLower().Replace(" ", "") == args[0].ToLower().Replace(" ", ""))
                        {
                            int next_options = 1;
                            string next_text = "удалять сообщения";
                            if (item.Value["type"] == "1")
                            {
                                next_options = 2;
                                next_text = "исключать пользователя";
                            }
                            if (item.Value["type"] == "2")
                            {
                                next_options = 3;
                                next_text = "выдавать предупреждение";
                            }
                            //db.FilterWordsDelWord(Vk.m_peer_id, item.Value["word"]);
                            db.FilterWordsSetType(Vk.m_peer_id, item.Value["word"], next_options);
                            Vk.MessagesSend("Новое действие при отправке сообщения: " + next_text);
                            return;
                        }
                    }

                }

                //db.FilterWordsAddWord(Vk.m_peer_id, args[0], Vk.m_from_id);
                Vk.MessagesSend("Слово не найдено. Посмотрите список слов: /filters");
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        static double StringCompare(string a, string b)
        {
            if (a == b) //Same string, no iteration needed.
                return 100;
            if ((a.Length == 0) || (b.Length == 0)) //One is empty, second is not
            {
                return 0;
            }
            double maxLen = a.Length > b.Length ? a.Length : b.Length;
            int minLen = a.Length < b.Length ? a.Length : b.Length;
            int sameCharAtIndex = 0;
            for (int i = 0; i < minLen; i++) //Compare char by char
            {
                if (a[i] == b[i])
                {
                    sameCharAtIndex++;
                }
            }
            return sameCharAtIndex / maxLen * 100;
        }
    }

    class owner_cmds
    {
        public vk Vk;
        public settings settings;
        public Database db;
        private AntiFlood antiflood;
        private check_for_cmd cmdChecker;
        private Cache Cache;

        public owner_cmds(vk vks, Database dbs, settings set, Cache cache)
        {
            Vk = vks;
            settings = set;
            db = dbs;
            antiflood = new(vks);
            cmdChecker = new(db, vks);
            Cache = cache;
        }

        public async void command_settings_set(long is_menu = 0)
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "setsettings"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "setsettings", 1))
                {
                    return;
                }

                MenuList MenuList = new(Cache);

                if (is_menu != 0)
                {
                    string low_text = Vk.m_text.ToLower();
                    if (is_menu == (int)MenuList.ListMenu.SETUP_STEP2)
                    {
                        if (low_text == "да" || low_text == "lf")
                        {
                            Vk.m_text = "/setsettings 2 1 1";
                        }
                        else if (low_text == "нет" || low_text == "ytn")
                        {
                            Vk.m_text = "/setsettings 2 2 1";
                        }
                        else
                        {
                            MenuList.setMenuSelect(Vk.m_from_id, 0);
                            return;
                        }
                    }

                    if (is_menu == (int)MenuList.ListMenu.SETUP_STEP3)
                    {
                        if (low_text == "исключать" || low_text == "bcrk.xfnm")
                        {
                            Vk.m_text = "/setsettings 3 1 1";
                        }
                        else if (low_text == "удалять" || low_text == "удалять сообщения" || low_text == "elfkznm" || low_text == "elfkznm cjj,otybz")
                        {
                            Vk.m_text = "/setsettings 3 2 1";
                        }
                        else
                        {
                            MenuList.setMenuSelect(Vk.m_from_id, 0);
                            return;
                        }
                    }
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int", "int", "int" });
                if (args[0] == "" || args[0] == null || long.Parse(args[0]) < 0 || args[1] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["setsettings"]);
                    return;
                }

                if (args[0] != "1" && args[0] != "2" && args[0] != "3")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["setsettings"]);
                    return;
                }

                if (args[0] == "1")
                {
                    string text = "";
                    string keyboard = "";
                    if (args[1] == "1")
                    {
                        if (is_menu != 0 || args[2] == "1")
                        {
                            text = "🔱 Теперь обычные пользователи при выходе из конференции будут исключены.<br><br>" +
                                "Теперь укажите, исключать ли пользователей с ролью выше пользователя, если он выйдет из конференции? (да/нет)";
                            keyboard = Vk.GenerateKeyboard(new string[] { "ДА", "НЕТ" },
                                new string[] { "setsettings 2 1 1", "setsettings 2 2 1" },
                                new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED });
                            MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.SETUP_STEP2);
                        }
                        else
                        {
                            text = "🔱 Теперь обычные пользователи при выходе из конференции будут исключены.";
                        }
                        db.peersSetKickexit(Vk.m_peer_id, 1);
                    }
                    else if (args[1] == "2")
                    {
                        if (is_menu != 0 || args[2] == "1")
                        {
                            text = "🔱 Бот не будет исключать пользователей без роли при выходе из конференции.<br><br>" +
                                "Теперь укажите, исключать ли пользователей с ролью выше пользователя, если он выйдет из конференции? (да/нет)";
                            keyboard = Vk.GenerateKeyboard(new string[] { "ДА", "НЕТ" },
                                new string[] { "setsettings 2 1 1", "setsettings 2 2 1" },
                                new string[] { Vk.BUTTON_GREEN, Vk.BUTTON_RED });
                            MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.SETUP_STEP2);
                        }
                        else
                        {
                            text = "🔱 Бот не будет исключать пользователей без роли при выходе из конференции.";
                        }
                        db.peersSetKickexit(Vk.m_peer_id, 2);
                    }
                    Vk.MessagesSend(text, 1, 0, keyboard);
                    return;
                }
                else if (args[0] == "2")
                {
                    string text = "";
                    string keyboard = "";
                    if (args[1] == "1")
                    {
                        if (is_menu != 0 || args[2] == "1")
                        {
                            text = "🔱 Теперь пользователи с ролью выше пользователя будут исключены при выходе из конференции.<br><br>" +
                                "Укажите, что делать если пользователь нарушит блокировку чата (напишет в чат)? (исключать/удалять сообщения)";
                            keyboard = Vk.GenerateKeyboard(new string[] { "ИСКЛЮЧАТЬ", "УДАЛЯТЬ СООБЩЕНИЯ" },
                                new string[] { "setsettings 3 1 1", "setsettings 3 2 1" },
                                new string[] { Vk.BUTTON_RED, Vk.BUTTON_GREEN });
                            MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.SETUP_STEP3);
                        }
                        else
                        {
                            text = "🔱 Теперь пользователи с ролью будут исключены при выходе из конференции.";
                        }
                        db.peersSetKickExitRole(Vk.m_peer_id, 1);
                    }
                    else if (args[1] == "2")
                    {
                        if (is_menu != 0 || args[2] == "1")
                        {
                            text = "🔱 Пользователи с ролью выше пользователя при выходе из конференции не будут исключены.<br><br>" +
                                "Укажите, что делать если пользователь нарушит блокировку чата (напишет в чат)? (исключать/удалять сообщения)";
                            keyboard = Vk.GenerateKeyboard(new string[] { "ИСКЛЮЧАТЬ", "УДАЛЯТЬ СООБЩЕНИЯ" },
                                new string[] { "setsettings 3 1 1", "setsettings 3 2 1" },
                                new string[] { Vk.BUTTON_RED, Vk.BUTTON_GREEN });
                            MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.SETUP_STEP3);
                        }
                        else
                        {
                            text = "🔱 Теперь пользователи с ролью не будут исключены при выходе из конференции.";
                        }
                        db.peersSetKickExitRole(Vk.m_peer_id, 2);
                    }
                    Vk.MessagesSend(text, 1, 0, keyboard);
                    return;
                }
                else if (args[0] == "3")
                {
                    string text = "";
                    string keyboard = "";
                    if (args[1] == "1")
                    {
                        if (is_menu != 0 || args[2] == "1")
                        {
                            text = "🔱 Если пользователь нарушит блокировку чата — его исключит.<br><br>" +
                                "На этом базовые настройки конференции завершены. Для более детальной настройки используйте /settings";
                            MenuList.setMenuSelect(Vk.m_from_id, 0);
                            /*keyboard = Vk.GenerateKeyboard(new string[] { "ДА", "НЕТ" },
                                new string[] { "setsettings 3 1 1", "setsettings 3 2 1" },
                                new string[] { Vk.BUTTON_RED, Vk.BUTTON_GREEN });
                            MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.SETUP_STEP3);*/
                        }
                        else
                        {
                            text = "🔱 Если участники конференции будут нарушать блокировку чата — они будут исключены.";
                        }
                        db.peersSetTypeMute(Vk.m_peer_id, 1);
                    }
                    else if (args[1] == "2")
                    {
                        if (is_menu != 0 || args[2] == "1")
                        {
                            text = "🔱 Если пользователь нарушит блокировку чата — его сообщения будут удаляться.<br><br>" +
                                "На этом базовые настройки конференции завершены. Для более детальной настройки используйте /settings";
                            MenuList.setMenuSelect(Vk.m_from_id, 0);
                            /*keyboard = Vk.GenerateKeyboard(new string[] { "ДА", "НЕТ" },
                                new string[] { "setsettings 3 1 1", "setsettings 3 2 1" },
                                new string[] { Vk.BUTTON_RED, Vk.BUTTON_GREEN });
                            MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.SETUP_STEP3);*/
                        }
                        else
                        {
                            text = "🔱 Если участники конференции будут нарушать блокировку чата — их сообщения будут автоматически удалены.";
                        }
                        db.peersSetTypeMute(Vk.m_peer_id, 2);
                    }
                    Vk.MessagesSend(text, 1, 0, keyboard);
                    return;
                }

                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_setup(long is_menu = 0)
        {
            try
            {
                MenuList MenuList = new(Cache);
                //UsersGetName
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "setup"))
                {
                    return;
                }
                //CommandsCheck

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "setup", 2))
                {
                    return;
                }

                if (is_menu != 0)
                {
                    string low_text = Vk.m_text.ToLower();
                    if (low_text == "да" || low_text == "lf")
                    {
                        Vk.m_text = "/setsettings 1 1 1";
                        command_settings_set(is_menu);
                        return;
                    }
                    else if (low_text == "нет" || low_text == "ytn")
                    {
                        Vk.m_text = "/setsettings 1 2 1";
                        command_settings_set(is_menu);
                        return;
                    }
                    else
                    {
                        MenuList.setMenuSelect(Vk.m_from_id, 0);
                        return;
                    }
                }

                string text = "🛠 Приступим к настройке конференции. Вы можете выбирать с помощью клавиатуры, либо просто отвечая 'да' или 'нет'.<br>" +
                    "Выберите, исключать ли обычных пользователей при выходе?";
                MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.SETUP_MAIN);
                string keyb = Vk.GenerateKeyboard(new string[] { "ДА", "НЕТ" }, new string[] { "setsettings 1 1 1", "setsettings 1 2 1" }, new string[] { Vk.BUTTON_RED, Vk.BUTTON_GREEN });
                //string name_vk = await Vk.GetUrlName(long.Parse(args[0]), "gen");
                //string name_one = await Vk.GetUrlName(Vk.m_from_id, "nom");
                //Vk.MessagesSend("👄 " + name_one + " поцеловал " + name_vk, 1, 0, "", false);
                Vk.MessagesSend(text, 1, 0, keyb);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_settings()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 80, "settings"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "settings", 3))
                {
                    return;
                }

                string text = "Выберите необходимый для настройки раздел.<br><br>" +
                    "1. Приглашение участников в конференцию и выход из неё<br>" +
                    "2. Фильтр отправки сообщений";

                string keyb = Vk.GenerateKeyboard(new string[] { "1", "2" },
                        new string[] { "settingsinvite", "settingsfilter" },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                Vk.MessagesSend(text, 0, 0, keyb);
                return;
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_sync()
        {
            try
            {
                //UsersGetName
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "sync"))
                {
                    return;
                }
                //CommandsCheck

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "sync", 60))
                {
                    return;
                }

                bool res = await Commands.syncOnePeer(Vk.m_peer_id);

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                Vk.MessagesSend("Конференция '" + PeerInfo["title"] + "' была успешно синхронизирована.");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_unity()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "unity"))
                {
                    return;
                }
                //CommandsCheck

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "unity", 10))
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (!PeerInfo.ContainsKey("in_pool") || PeerInfo["in_pool"] == "0")
                {
                    Vk.MessagesSend("Данная беседа не состоит в объединении.<br><br>Для добавления в объединение используйте команду — /addunity<br>" +
                        "Для просмотра списка доступных объединений введите — /unites");
                    return;
                }

                var unityInfo = db.unitesGetUnity(long.Parse(PeerInfo["in_pool"]));
                if (unityInfo == null)
                {
                    Vk.MessagesSend("Данная беседа не состоит в объединении.<br><br>Для добавления в объединение используйте команду — /addunity<br>" +
                        "Для просмотра списка доступных объединений введите — /unites");
                    return;
                }
                string nickname;
                Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(unityInfo["owner_id"]) });
                if (user_vk.ContainsKey("id" + unityInfo["owner_id"]))
                {
                    nickname = "[id" + unityInfo["owner_id"] + "|" +
                        user_vk["id" + unityInfo["owner_id"]].first_name + " " + user_vk["id" + unityInfo["owner_id"]].last_name + "]";
                }
                else
                {
                    nickname = "[club" + unityInfo["owner_id"].Substring(1) + "|Сообщество]";
                }
                string text = "Беседа состоит в объединении №" + unityInfo["id"] + ".<br><br>" +
                    "Владелец: " + nickname + "<br>" +
                    "Название: " + unityInfo["name"] + "<br>" +
                    "Описание: " + unityInfo["description"] + "<br>Список бесед:<br>";

                var unityPeers = db.unitesGetPeers(long.Parse(unityInfo["id"]));
                if (unityPeers == null || unityPeers.Count <= 0)
                {
                    Vk.MessagesSend(text);
                    return;
                }

                int i = 0;
                foreach (var item in unityPeers)
                {
                    var peer = db.peersGetPeer(item);
                    i++;
                    text += i + ". " + peer["title"] + "<br>";
                }
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_unites()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }
                //CommandsCheck

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "unites", 10))
                {
                    return;
                }

                var unites = db.unitesGetListUnity(Vk.m_from_id);
                if (unites == null)
                {
                    Vk.MessagesSend("Вы не имеете объединений.<br><br>Для создания объединения используйте команду — /createunity");
                    return;
                }


                string nickname;
                if (UserInfo["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(UserInfo["user_id"]) });
                    if (user_vk.ContainsKey("id" + UserInfo["user_id"]))
                    {
                        nickname = "[id" + Vk.m_from_id + "|" +
                            user_vk["id" + UserInfo["user_id"]].first_name + " " + user_vk["id" + UserInfo["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }

                string text = nickname + " имеет " + unites.Count() + " объединений.<br><br>";

                foreach (var item in unites)
                {
                    text = text + "№" + item["id"] + " — " + item["name"] + " (" + item["peers"] + " бесед).<br>";
                }
                text += "<br>Используйте /addunity [ID] для добавления бесед в объединение.";
                Vk.MessagesSend(text);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_addunity()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "addunity", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                
                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                string nickname;

                var unityList = db.unitesGetListUnity(Vk.m_from_id);

                if (UserInfo["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(UserInfo["user_id"]) });
                    if (user_vk.ContainsKey("id" + UserInfo["user_id"]))
                    {
                        nickname = "[id" + Vk.m_from_id + "|" +
                            user_vk["id" + UserInfo["user_id"]].first_name + " " + user_vk["id" + UserInfo["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }
                string text = "";
                if (unityList == null)
                {
                    var targetid = db.unitesAddUnity(Vk.m_from_id);
                    text += nickname + $" создал новое объединение №{targetid}.<br><br>";
                    //Vk.MessagesSend(text);
                    if (args[0] == null || args[0] == "")
                    {
                        args[0] = targetid.ToString();
                    }
                    unityList = db.unitesGetListUnity(Vk.m_from_id, true);

                }

                if (unityList.Count <= 0)
                {
                    var targetid = db.unitesAddUnity(Vk.m_from_id);
                    text += nickname + $" создал новое объединение №{targetid}.<br><br>";
                    //Vk.MessagesSend(text);
                    if (args[0] == null || args[0] == "")
                    {
                        args[0] = targetid.ToString();
                    }
                    unityList = db.unitesGetListUnity(Vk.m_from_id, true);
                }


                if (args[0] == null || args[0] == "")
                {
                    if (unityList.Count == 1)
                    {
                        foreach (var item in unityList)
                        {
                            args[0] = item["id"];
                        }
                    }
                //Vk.MessagesSend(CommandsList.CommandsHelp["addunity"]);
                //return;
                }

                string[] args_unity = await cmdChecker.getArguments("/addunity " + args[0], new string[] { "int" });
                long target_unity = -1;
                Dictionary<string, string> targetInfoUnity = new();
                
                if (args_unity[0] == null || args_unity[0] == "")
                {
                    string name = Regex.Replace(args[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                    foreach (var item in unityList)
                    {
                        var name_role = Regex.Replace(item["name"], @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (name == name_role)
                        {
                            target_unity = long.Parse(item["id"]);
                            targetInfoUnity = item;
                            break;
                        }
                    }
                }
                else
                {
                    foreach (var item in unityList)
                    {
                        if (item["id"] == args[0])
                        {
                            target_unity = long.Parse(item["id"]);
                            targetInfoUnity = item;
                            break;
                        }
                    }
                }

                if (target_unity <= -1)
                {

                    Vk.MessagesSend("К сожалению, объединение с таким ID/названием не найдено.<br>Список доступных объединений: /unites<br><br>" +
                        "Статья поможет Вам разобраться — vk.com/@grand_manager-kak-obedinit-besedy");
                    return;
                }

                if (peerInfo["in_pool"] != "0")
                {
                    if (peerInfo["in_pool"] == targetInfoUnity["id"])
                    {
                        Vk.MessagesSend("Беседа уже находится в указанном объединении.<br><br>" +
                            "Статья поможет Вам разобраться — vk.com/@grand_manager-kak-obedinit-besedy");
                        return;
                    }
                    if (targetInfoUnity.ContainsKey("peers") && long.Parse(targetInfoUnity["peers"]) >= 32)
                    {
                        if (!db.UserIsVip(Vk.m_from_id))
                        {
                            Vk.MessagesSend("Максимальное кол-во бесед (32) в объединении уже достигнуто. ");
                            return;
                        }
                        else
                        {
                            Vk.MessagesSend("Максимальное кол-во бесед (32) в объединении уже достигнуто. ");
                            return;
                            /*var UserVipInfo = db.usersGetUser(Vk.m_from_id);
                            int lvlVip = int.Parse(UserVipInfo["vip_type"]);
                            if (long.Parse(targetInfoUnity["peers"]) >= 7 && int.Parse(UserVipInfo["vip_type"]) <= 1)
                            {
                                Vk.MessagesSend("Максимальное кол-во бесед (7) в объединении для вашего VIP (тип 1) уже достигнуто. " +
                                "Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                "(будет доступно 12 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                return;
                            }
                            else if (long.Parse(targetInfoUnity["peers"]) >= 12 && int.Parse(UserVipInfo["vip_type"]) <= 2)
                            {
                                Vk.MessagesSend("Максимальное кол-во бесед (12) в объединении для вашего VIP (тип 2) уже достигнуто. " +
                                "Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                "(будет доступно 16 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                return;
                            }
                            else if (long.Parse(targetInfoUnity["peers"]) >= 16 && int.Parse(UserVipInfo["vip_type"]) <= 3)
                            {
                                Vk.MessagesSend("Максимальное кол-во бесед (16) в объединении для вашего VIP (тип 3) уже достигнуто. " +
                                "Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                "(будет доступно 21 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                return;
                            }
                            else
                            {
                                
                                double mnoji = 5.33;
                                int max_peers = (int)(lvlVip * mnoji);
                                int Nextmax_peers = (int)((lvlVip+1) * mnoji);
                                if (long.Parse(targetInfoUnity["peers"]) >= max_peers)
                                {
                                    Vk.MessagesSend($"Максимальное кол-во бесед ({max_peers}) в объединении для вашего VIP (тип {lvlVip}) уже достигнуто. " +
                                $"Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                $"(будет доступно {Nextmax_peers} бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                    return;
                                }
                            }*/
                        }
                        //
                    }
                    db.unitesMinusUnity(long.Parse(peerInfo["in_pool"]), 1);
                    text = nickname + " изменил объединение №" + peerInfo["in_pool"] + " » №" + targetInfoUnity["id"] + " (" + targetInfoUnity["name"] + ").";
                }
                else
                {
                    if (targetInfoUnity.ContainsKey("peers") && long.Parse(targetInfoUnity["peers"]) >= 32)
                    {
                        if (!db.UserIsVip(Vk.m_from_id))
                        {
                            Vk.MessagesSend("Максимальное кол-во бесед (32) в объединении уже достигнуто. ");
                            return;
                        }
                        else
                        {
                            Vk.MessagesSend("Максимальное кол-во бесед (32) в объединении уже достигнуто. ");
                            return;
                            /*
                            var UserVipInfo = db.usersGetUser(Vk.m_from_id);
                            int lvlVip = int.Parse(UserVipInfo["vip_type"]);
                            if (long.Parse(targetInfoUnity["peers"]) >= 7 && int.Parse(UserVipInfo["vip_type"]) <= 1)
                            {
                                Vk.MessagesSend("Максимальное кол-во бесед (7) в объединении для вашего VIP (тип 1) уже достигнуто. " +
                                "Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                "(будет доступно 12 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                return;
                            }
                            else if (long.Parse(targetInfoUnity["peers"]) >= 12 && int.Parse(UserVipInfo["vip_type"]) <= 2)
                            {
                                Vk.MessagesSend("Максимальное кол-во бесед (12) в объединении для вашего VIP (тип 2) уже достигнуто. " +
                                "Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                "(будет доступно 16 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                return;
                            }
                            else if (long.Parse(targetInfoUnity["peers"]) >= 16 && int.Parse(UserVipInfo["vip_type"]) <= 3)
                            {
                                Vk.MessagesSend("Максимальное кол-во бесед (16) в объединении для вашего VIP (тип 3) уже достигнуто. " +
                                "Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                "(будет доступно 21 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                return;
                            }
                            else
                            {
                                double mnoji = 5;
                                int max_peers = (int)(lvlVip * mnoji);
                                int Nextmax_peers = (int)((lvlVip + 1) * mnoji);
                                if (long.Parse(targetInfoUnity["peers"]) >= max_peers)
                                {
                                    Vk.MessagesSend($"Максимальное кол-во бесед ({max_peers}) в объединении для вашего VIP (тип {lvlVip}) уже достигнуто. " +
                                $"Вы можете увеличить размер объединения купив VIP статус следующего уровня для аккаунта " +
                                $"(будет доступно {Nextmax_peers} бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                    return;
                                }
                            }*/
                        }
                        //
                    }
                    text = nickname + " присоединил беседу к объединению №" + targetInfoUnity["id"] + " (" + targetInfoUnity["name"] + ").";
                }

                Vk.MessagesSend(text);
                db.unitesPlusUnity(target_unity, 1);
                db.peersSetInPool(Vk.m_peer_id, target_unity);
                
                db.unitesGetListUnity(Vk.m_from_id, true);
                db.unitesGetPeers(target_unity, true);

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_createunity()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "createunity", 5))
                {
                    return;
                }
                string nickname;

                if (UserInfo["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(UserInfo["user_id"]) });
                    if (user_vk.ContainsKey("id" + UserInfo["user_id"]))
                    {
                        nickname = "[id" + Vk.m_from_id + "|" +
                            user_vk["id" + UserInfo["user_id"]].first_name + " " + user_vk["id" + UserInfo["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }

                var unites = db.unitesGetListUnity(Vk.m_from_id);

                string text;

                if (unites.Count() >= 32)
                {
                    if (!db.UserIsVip(Vk.m_from_id))
                    {
                        Vk.MessagesSend("Максимальное количество объединений (32) для обычного аккаунта уже достигнуто. ");
                        return;
                    }
                    else
                    {
                        Vk.MessagesSend("Максимальное количество объединений (32) для обычного аккаунта уже достигнуто. ");
                        return;
                        /*var UserVipInfo = db.usersGetUser(Vk.m_from_id);
                        int lvlVip = int.Parse(UserVipInfo["vip_type"]);
                        if (unites.Count() >= 6 && int.Parse(UserVipInfo["vip_type"]) <= 1)
                        {
                            Vk.MessagesSend("Максимальное количество объединений (6) для вашего VIP аккаунта уже достигнуто. " +
                                "Вы можете увеличить количество объединений купив более высокий VIP статус " +
                                "(будет доступно 9 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                            return;
                        }
                        else if (unites.Count() >= 9 && int.Parse(UserVipInfo["vip_type"]) <= 2)
                        {
                            Vk.MessagesSend("Максимальное количество объединений (9) для вашего VIP аккаунта уже достигнуто. " +
                                "Вы можете увеличить количество объединений купив более высокий VIP статус " +
                                "(будет доступно 12 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                            return;
                        }
                        else if (unites.Count() >= 12 && int.Parse(UserVipInfo["vip_type"]) <= 3)
                        {
                            Vk.MessagesSend("Максимальное количество объединений (12) для вашего VIP аккаунта уже достигнуто. " +
                                "Вы можете увеличить количество объединений купив более высокий VIP статус " +
                                "(будет доступно 15 бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                            return;
                        }
                        else
                        {
                            double mnoji = 3;
                            int max_peers = (int)(lvlVip * mnoji) + 3;
                            int Nextmax_peers = (int)((lvlVip + 1) * mnoji) + 3;
                            if (unites.Count() >= max_peers)
                            {
                                Vk.MessagesSend($"Максимальное кол-во объединений ({max_peers}) для вашего VIP—{lvlVip} уже достигнуто. " +
                            $"Вы можете увеличить количество объединений купив VIP статус следующего уровня для аккаунта " +
                            $"(будет доступно {Nextmax_peers} бесед в объединении).<br><br>Улучшить/продлить VIP статус можно через наш сайт — https://grandmanager.space/shop");
                                return;
                            }
                        }*/
                    }
                }

                
                var targetid = db.unitesAddUnity(Vk.m_from_id);
                text = nickname + $" создал новое объединение №{targetid}. Используйте /addunity {targetid} для добавления беседы в объединение.";
                Vk.MessagesSend(text);

            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_removeunity()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }
                //CommandsCheck

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "removeunity", 10))
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (!PeerInfo.ContainsKey("in_pool") || PeerInfo["in_pool"] == "0")
                {
                    Vk.MessagesSend("Данная беседа не состоит в объединении.<br><br>Для добавления в объединение используйте команду — /addunity<br>" +
                        "Для просмотра списка доступных объединений введите — /unites");
                    return;
                }

                var unityInfo = db.unitesGetUnity(long.Parse(PeerInfo["in_pool"]));
                if (unityInfo == null)
                {
                    Vk.MessagesSend("Данная беседа не состоит в объединении.<br><br>Для добавления в объединение используйте команду — /addunity<br>" +
                        "Для просмотра списка доступных объединений введите — /unites");
                    return;
                }

                string nickname;
                if (UserInfo["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(UserInfo["user_id"]) });
                    if (user_vk.ContainsKey("id" + UserInfo["user_id"]))
                    {
                        nickname = "[id" + Vk.m_from_id + "|" +
                            user_vk["id" + UserInfo["user_id"]].first_name + " " + user_vk["id" + UserInfo["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }
                string text = nickname + " инициировал выход беседы из объединения №" + unityInfo["id"] + ".";

                Vk.MessagesSend(text);
                db.unitesMinusUnity(long.Parse(PeerInfo["in_pool"]), 1);
                db.peersSetInPool(Vk.m_peer_id, 0);
                db.unitesGetListUnity(Vk.m_from_id, true);
                db.unitesGetPeers(long.Parse(unityInfo["id"]), true);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_editunity_desc(long is_menu = 0)
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                if (is_menu == 0)
                {
                    MenuList MenuList = new(Cache);
                    MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.MENU_EDITUNITY_SETDESCRIPTION);
                    Vk.MessagesSend("Введите описание следующим сообщением. Обращаем внимание, что максимальная длина составляет 100 символов," +
                        " а сообщение должно быть отправлено не позже чем через 15 минут.");
                    return;
                }
                else if (is_menu == (int)MenuList.ListMenu.MENU_EDITUNITY_SETDESCRIPTION)
                {
                    Dictionary<string, string>? target_unity = Cache.Get<Dictionary<string, string>>("unitytarget_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id);
                    if (target_unity == null)
                    {
                        Vk.MessagesSend("Время на ввод описания истекло. Используйте /editunity для редактирования.");
                        MenuList MenuList = new(Cache);
                        MenuList.setMenuSelect(Vk.m_from_id, 0);
                        return;
                    }
                    string name = Vk.m_text;
                    if (name.Length > 100)
                    {
                        Vk.MessagesSend("Введенное описание для объединения слишком длинное (" + name.Length + "/100). Используйте /editunity для повторного редактирования.");
                        MenuList MenuList = new(Cache);
                        MenuList.setMenuSelect(Vk.m_from_id, 0);
                        return;
                    }
                    string old_name = target_unity["description"];
                    db.unitesSetDesc(long.Parse(target_unity["id"]), name);
                    db.unitesGetListUnity(long.Parse(target_unity["owner_id"]), true);
                    Vk.MessagesSend("Вы успешно изменили описание объединения №" + target_unity["id"] + ".<br><br>" +
                        name);
                    MenuList MenuListt = new(Cache);
                    MenuListt.setMenuSelect(Vk.m_from_id, 0);
                    //Cache.Set("unitytarget_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id, targetInfoUnity, 20);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_editunity_name(long is_menu = 0)
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                if (is_menu == 0)
                {
                    MenuList MenuList = new(Cache);
                    MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.MENU_EDITUNITY_SETNAME);
                    Vk.MessagesSend("Введите название следующим сообщением. Обращаем внимание, что максимальная длина составляет 50 символов," +
                        " а сообщение должно быть отправлено не позже чем через 15 минут.");
                    return;
                }
                else if (is_menu == (int)MenuList.ListMenu.MENU_EDITUNITY_SETNAME)
                {
                    Dictionary<string, string>? target_unity = Cache.Get<Dictionary<string, string>>("unitytarget_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id);
                    if (target_unity == null)
                    {
                        Vk.MessagesSend("Время на ввод названия истекло. Используйте /editunity для редактирования.");
                        MenuList MenuList = new(Cache);
                        MenuList.setMenuSelect(Vk.m_from_id, 0);
                        return;
                    }
                    string name = Vk.m_text;
                    if (name.Length > 50)
                    {
                        Vk.MessagesSend("Введенное название для объединения слишком длинное (" + name.Length + "/50). Используйте /editunity для повторного редактирования.");
                        MenuList MenuList = new(Cache);
                        MenuList.setMenuSelect(Vk.m_from_id, 0);
                        return;
                    }
                    string old_name = target_unity["name"];
                    db.unitesSetName(long.Parse(target_unity["id"]), name);
                    db.unitesGetListUnity(long.Parse(target_unity["owner_id"]), true);
                    Vk.MessagesSend("Вы успешно изменили название объединения №" + target_unity["id"] + ".<br><br>" +
                        "Старое название: " + old_name + "<br>" +
                        "Новое название: " + name);
                    MenuList MenuListt = new(Cache);
                    MenuListt.setMenuSelect(Vk.m_from_id, 0);
                    //Cache.Set("unitytarget_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id, targetInfoUnity, 20);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_editunity()
        {
            try
            {
                //MenuList MenuList = new(Cache);
                //MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.MENU_EDITUNITY_SETNAME);

                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "editunity", 3))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["editunity"]);
                    return;
                }


                string[] args_unity = await cmdChecker.getArguments("/addunity " + args[0], new string[] { "int" });
                long target_unity = -1;
                Dictionary<string, string> targetInfoUnity = new();
                var unityList = db.unitesGetListUnity(Vk.m_from_id);
                if (args_unity[0] == null || args_unity[0] == "")
                {
                    string name = Regex.Replace(args[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                    foreach (var item in unityList)
                    {
                        var name_role = Regex.Replace(item["name"], @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (name == name_role)
                        {
                            target_unity = long.Parse(item["id"]);
                            targetInfoUnity = item;
                            break;
                        }
                    }
                }
                else
                {
                    foreach (var item in unityList)
                    {
                        if (item["id"] == args[0])
                        {
                            target_unity = long.Parse(item["id"]);
                            targetInfoUnity = item;
                            break;
                        }
                    }
                }

                if (target_unity <= -1)
                {

                    Vk.MessagesSend("К сожалению, объединение с таким ID/названием не найдено.<br>Список доступных объединений: /unites");
                    return;
                }
                string buttons = Vk.GenerateKeyboard(new string[] { "Название", "Описание" },
                        new string[] { "editunityname " + targetInfoUnity["id"], "editunitydesc " + targetInfoUnity["id"] },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                string text;
                text = "Для редактирования названия или описания объединения №"
                    + targetInfoUnity["id"] + " (" + targetInfoUnity["name"] + ") нажмите на соответствующую кнопку ниже.";

                Vk.MessagesSend(text, 1, 0, buttons);
                Cache.Set("unitytarget_" + Vk.m_from_id.ToString() + "_" + Vk.m_peer_id, targetInfoUnity, 20);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_deleteunity()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "deleteunity", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["deleteunity"]);
                    return;
                }
                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                string nickname;

                if (UserInfo["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(UserInfo["user_id"]) });
                    if (user_vk.ContainsKey("id" + UserInfo["user_id"]))
                    {
                        nickname = "[id" + Vk.m_from_id + "|" +
                            user_vk["id" + UserInfo["user_id"]].first_name + " " + user_vk["id" + UserInfo["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (Vk.m_from_id < 0)
                    {
                        nickname = "[club" + Vk.m_from_id.ToString().Substring(1) + "|" + UserInfo["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + Vk.m_from_id + "|" + UserInfo["nick"] + "]";
                    }
                }


                string[] args_unity = await cmdChecker.getArguments("/addunity " + args[0], new string[] { "int" });
                long target_unity = -1;
                Dictionary<string, string> targetInfoUnity = new();
                var unityList = db.unitesGetListUnity(Vk.m_from_id);
                if (args_unity[0] == null || args_unity[0] == "")
                {
                    string name = Regex.Replace(args[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                    foreach (var item in unityList)
                    {
                        var name_role = Regex.Replace(item["name"], @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (name == name_role)
                        {
                            target_unity = long.Parse(item["id"]);
                            targetInfoUnity = item;
                            break;
                        }
                    }
                }
                else
                {
                    foreach (var item in unityList)
                    {
                        if (item["id"] == args[0])
                        {
                            target_unity = long.Parse(item["id"]);
                            targetInfoUnity = item;
                            break;
                        }
                    }
                }

                if (target_unity <= -1)
                {

                    Vk.MessagesSend("К сожалению, объединение с таким ID/названием не найдено.<br>Список доступных объединений: /unites");
                    return;
                }

                string text;
                if (peerInfo["in_pool"] != "0")
                {
                    if (peerInfo["in_pool"] == targetInfoUnity["id"])
                    {
                        db.peersSetInPool(Vk.m_peer_id, 0);
                    }
                }
                text = nickname + " удалил объединение №" + targetInfoUnity["id"] + " (" + targetInfoUnity["name"] + ").";
                Vk.MessagesSend(text);
                db.unitesDeleteUnity(target_unity);
                db.unitesGetListUnity(Vk.m_from_id, true);
                db.peersClearUnityFromUnity(target_unity);
                db.unitesGetPeers(target_unity, true);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_addspec()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "addspec"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "addspec", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });

                Dictionary<string, string>? Target_User = null;

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["addspec"]);
                    return;
                }

                string nickname;

                long target_id = long.Parse(args[0]);

                Target_User = db.peersGetMember(Vk.m_peer_id, target_id, false, true);

                if (Target_User == null)
                {
                    Vk.MessagesSend("Не удалось найти информацию про этого пользователя.");
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                if (Target_User["nick"] == "")
                {
                    Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                    if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                    {
                        nickname = "[id" + args[0] + "|" +
                            user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                    }
                    else
                    {
                        nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                    }
                }
                else
                {
                    if (target_id < 0)
                    {
                        nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                    }
                    else
                    {
                        nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                    }
                }

                string text;
                if (long.Parse(Target_User["priority"]) != 0)
                {
                    if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                    {
                        Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.");
                        return;
                    }
                    if (long.Parse(Target_User["priority"]) >= 80)
                    {
                        Vk.MessagesSend(nickname + " уже имеет роль с большим, либо таким же приоритетом.");
                        return;
                    }
                    var old_name = db.rolesGetName(Vk.m_peer_id, Target_User["priority"]);
                    text = nickname + " получил права главного администратора." + "<br>" +
                    "Выдал: " + nick_admin + "<br>" +
                    "Предыдущая роль: " + old_name;
                }
                else
                {
                    text = nickname + " получил права главного администратора." + "<br>" +
                    "Выдал: " + nick_admin;
                }

                List<string> buttons_names = new List<string>()
                {
                    "Снять"
                };
                List<string> buttons_commands = new List<string>()
                {
                    "rr id" + args[0]
                };
                List<string> buttons_colors = new List<string>()
                {
                    Vk.BUTTON_RED
                };

                var buttons = Vk.GenerateKeyboard(buttons_names.ToArray(), buttons_commands.ToArray(), buttons_colors.ToArray());

                Vk.MessagesSend(text, 1, 0, buttons);
                db.peersMemberSetPriority(Vk.m_peer_id, target_id, 80);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETROLE, Vk.m_from_id, target_id, "выдал роль", "80", Target_User["priority"]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_gaddspec()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "gaddspec"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "gaddspec", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["gaddspec"]);
                    return;
                }

                string nickname;

                var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                if (Target_Peer["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    return;
                }

                var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                if (ListPeers == null || ListPeers.Count <= 1)
                {
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                long target_id = long.Parse(args[0]);

                foreach (var peerid in ListPeers)
                {
                    UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                    if (!cmdChecker.CommandsCheck(UserInfo, 80, "gaddspec"))
                    {
                        continue;
                    }

                    Target_User = db.peersGetMember(peerid, target_id, false, true);

                    if (Target_User == null)
                    {
                        Vk.MessagesSend("Не удалось найти информацию про этого пользователя.", 0, peerid);
                        continue;
                    }

                    string nick_admin = db.peersGetNickUrl(peerid, Vk.m_from_id);

                    if (Target_User["nick"] == "")
                    {
                        Dictionary<string, usersNameVk> user_vk = await Vk.UsersGetName(new long[] { long.Parse(Target_User["user_id"]) });
                        if (user_vk.ContainsKey("id" + Target_User["user_id"]))
                        {
                            nickname = "[id" + args[0] + "|" +
                                user_vk["id" + Target_User["user_id"]].first_name + " " + user_vk["id" + Target_User["user_id"]].last_name + "]";
                        }
                        else
                        {
                            nickname = "[club" + args[0].Substring(1) + "|Сообщество]";
                        }
                    }
                    else
                    {
                        if (target_id < 0)
                        {
                            nickname = "[club" + args[0].Substring(1) + "|" + Target_User["nick"] + "]";
                        }
                        else
                        {
                            nickname = "[id" + args[0] + "|" + Target_User["nick"] + "]";
                        }
                    }

                    string text;
                    if (long.Parse(Target_User["priority"]) != 0)
                    {
                        if (long.Parse(UserInfo["priority"]) <= long.Parse(Target_User["priority"]))
                        {
                            Vk.MessagesSend("Вы не можете изменять группу человека, роль которого выше или равна вашей.", 0, peerid);
                            continue;
                        }
                        if (long.Parse(Target_User["priority"]) >= 80)
                        {
                            Vk.MessagesSend(nickname + " уже имеет роль с большим, либо таким же приоритетом.", 0, peerid);
                            continue;
                        }
                        var old_name = db.rolesGetName(peerid, Target_User["priority"]);
                        text = nickname + " получил права главного администратора." + "<br>" +
                        "Выдал: " + nick_admin + "<br>" +
                        "Предыдущая роль: " + old_name;
                    }
                    else
                    {
                        text = nickname + " получил права главного администратора." + "<br>" +
                        "Выдал: " + nick_admin;
                    }

                    Vk.MessagesSend(text, 0, peerid);
                    db.peersMemberSetPriority(peerid, target_id, 80);
                    db.logsAddLog(peerid, Database.logsId.USER_SETROLE, Vk.m_from_id, target_id, "выдал роль (пулл)", "80", Target_User["priority"]);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_wipe()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "wipe"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "wipe", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });

                Dictionary<string, string>? Target_User = null;

                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["wipe"]);
                    return;
                }
                args[0] = args[0].ToLower();
                //warns/bans/roles/nicks
                if (args[0] != "warns" && args[0] != "bans" && args[0] != "nicks" && args[0] != "roles")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["wipe"]);
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);

                string text = nick_admin + " произвел очистку ";

                if (args[0] == "warns")
                {
                    text = text + "предупреждений.<br><br>Пожалуйста, подождите окончания процесса очистки..";
                    Vk.MessagesSend(text);
                    await db.peerTruncuteWarns(Vk.m_peer_id);
                    Vk.MessagesSend("Очистка предупреждений прошла успешно.");
                }
                else if (args[0] == "bans")
                {
                    text = text + "черного листа пользователей.<br><br>Пожалуйста, подождите окончания процесса очистки..";
                    Vk.MessagesSend(text);
                    await db.peerTruncuteBans(Vk.m_peer_id);
                    Vk.MessagesSend("Очистка блокировок прошла успешно.");
                }
                else if (args[0] == "nicks")
                {
                    text = text + "никнеймов.<br><br>Пожалуйста, подождите окончания процесса очистки..";
                    Vk.MessagesSend(text);
                    await db.peerTruncuteNicknames(Vk.m_peer_id);
                    Vk.MessagesSend("Очистка никнеймов прошла успешно.");
                }
                else if (args[0] == "roles")
                {
                    text = text + "ролей.<br><br>Пожалуйста, подождите окончания процесса очистки..";
                    Vk.MessagesSend(text);
                    await db.peerTruncuteRolesUsers(Vk.m_peer_id);
                    Vk.MessagesSend("Очистка ролей прошла успешно.");
                }
                else
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["wipe"]);
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_migration()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "migration"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "migration", 15))
                {
                    return;
                }

                if (Vk.m_reply_message == null || Vk.m_reply_message["from_id"] == null)
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["migration"]);
                    return;
                }
                long from_id;

                try
                {
                    from_id = long.Parse(Vk.m_reply_message["from_id"].ToString());
                }
                catch
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["migration"]);
                    return;
                }

                if (from_id >= 0)
                {
                    Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                    return;
                }

                // КВИК: ЧАТ МЕНЕДЖЕР
                if (from_id == -206422000)
                {
                    string text = Vk.m_reply_message["text"].ToString();

                    if (text == "")
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    string[] lines = text.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    if (lines.Length <= 1)
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    // Список пользователей с ником:

                    if (lines.Length >= 2)
                    {
                        if (lines[0] == "Список пользователей с ником:")
                        {
                            Vk.MessagesSend("Загрузка списка никнеймов участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            foreach (var item in lines)
                            {
                                if (item == "Список пользователей с ником:" || item == "")
                                {
                                    continue;
                                }
                                //1. [id552349558|Антон Андреев] - Vladimir_Putin
                                string[] temp_explode_tire = item.Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_tire.Length <= 0)
                                {
                                    continue;
                                }

                                string[] temp_explode_space = temp_explode_tire[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_space.Length <= 0)
                                {
                                    continue;
                                }

                                string[] id_flow = temp_explode_space[1].Replace("[", "").Replace("]", "")
                                    .Replace("id", "").Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                long id_member;
                                try
                                {
                                    id_member = long.Parse(id_flow[0]);
                                }
                                catch
                                {
                                    continue;
                                }
                                string nickname = temp_explode_tire[1].Substring(1);

                                if (nickname == "")
                                {
                                    continue;
                                }
                                var user = db.peersGetMember(Vk.m_peer_id, id_member);
                                db.peersMemberSetNickName(Vk.m_peer_id, id_member, nickname);
                            }
                            Vk.MessagesSend("Загрузка никнеймов прошла успешно.", 0);
                        }
                        else if (lines[0] == "Список пользователей в блокировке:")
                        {
                            Vk.MessagesSend("Загрузка списка заблокированных участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            foreach (var item in lines)
                            {
                                if (item == "Список пользователей в блокировке:" || item == "")
                                {
                                    continue;
                                }
                                //1. [id1|Павел Дуров]
                                string[] temp_explode_tire = item.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_tire.Length <= 0)
                                {
                                    continue;
                                }

                                string[] temp_explode_space = temp_explode_tire[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_space.Length <= 0)
                                {
                                    continue;
                                }

                                string[] id_flow = temp_explode_space[1].Replace("[", "").Replace("]", "")
                                    .Replace("id", "").Replace("club", "-").Replace("public", "-").Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                long id_member;
                                try
                                {
                                    id_member = long.Parse(id_flow[0]);
                                }
                                catch
                                {
                                    continue;
                                }
                                string ban_time = null;

                                if (db.bansGetBan(Vk.m_peer_id, id_member) != null)
                                {
                                    continue;
                                }

                                db.bansAddBan(Vk.m_peer_id, id_member, Vk.m_from_id, "Миграция блокировки", ban_time);
                            }
                            Vk.MessagesSend("Загрузка блокировок прошла успешно.", 0);
                        }
                        else
                        {
                            Vk.MessagesSend("Не удается распознать тип миграции.");
                        }
                    }
                    else
                    {
                        Vk.MessagesSend("Не удается распознать тип миграции.");
                    }
                }
                else if (from_id == -199631114) // Chat Manager
                {
                    string text = Vk.m_reply_message["text"].ToString();

                    if (text == "")
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    string[] lines = text.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    if (lines.Length <= 1)
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    // Список пользователей с ником:

                    if (lines.Length >= 2)
                    {
                        if (lines[0] == "Список пользователей с никами:")
                        {
                            Vk.MessagesSend("Загрузка списка никнеймов участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            foreach (var item in lines)
                            {
                                if (item == "Список пользователей с никами:" || item == "")
                                {
                                    continue;
                                }
                                //1. [id552349558|Антон Андреев] - Vladimir_Putin
                                string[] temp_explode_tire = item.Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_tire.Length <= 0)
                                {
                                    continue;
                                }

                                string[] temp_explode_space = temp_explode_tire[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_space.Length <= 0)
                                {
                                    continue;
                                }

                                string[] id_flow = temp_explode_space[1].Replace("[", "").Replace("]", "")
                                    .Replace("id", "").Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                long id_member;
                                try
                                {
                                    id_member = long.Parse(id_flow[0]);
                                }
                                catch
                                {
                                    continue;
                                }
                                string nickname = "";
                                if (temp_explode_tire.Length >= 3)
                                {
                                    var temp_tire = temp_explode_tire[0];
                                    nickname = string.Join("-", temp_explode_tire).Replace(temp_tire, "").Substring(1);
                                    //nickname = temp_explode_tire.Substring(1);

                                }
                                else
                                {
                                    nickname = temp_explode_tire[1].Substring(1);
                                }

                                if (nickname == "")
                                {
                                    continue;
                                }
                                var user = db.peersGetMember(Vk.m_peer_id, id_member);
                                db.peersMemberSetNickName(Vk.m_peer_id, id_member, nickname);
                            }
                            Vk.MessagesSend("Загрузка никнеймов прошла успешно.", 0);
                        }
                        else if (lines[0] == "Список заблокированных пользователей:")
                        {
                            Vk.MessagesSend("Загрузка списка заблокированных участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            foreach (var item in lines)
                            {
                                if (item == "Список заблокированных пользователей:" || item == "")
                                {
                                    continue;
                                }
                                //1. [id1|Павел Дуров]
                                string[] temp_explode_tire = item.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_tire.Length <= 0)
                                {
                                    continue;
                                }

                                string[] temp_explode_space = temp_explode_tire[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_space.Length <= 0)
                                {
                                    continue;
                                }

                                string[] id_flow = temp_explode_space[1].Replace("[", "").Replace("]", "")
                                    .Replace("id", "").Replace("club", "-").Replace("public", "-").Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                long id_member;
                                try
                                {
                                    id_member = long.Parse(id_flow[0]);
                                }
                                catch
                                {
                                    continue;
                                }
                                string ban_time = null;

                                if (db.bansGetBan(Vk.m_peer_id, id_member) != null)
                                {
                                    continue;
                                }

                                db.bansAddBan(Vk.m_peer_id, id_member, Vk.m_from_id, "Миграция блокировки", ban_time);
                            }
                            Vk.MessagesSend("Загрузка блокировок прошла успешно.", 0);
                        }
                        else
                        {
                            Vk.MessagesSend("Не удается распознать тип миграции.");
                        }
                    }
                    else
                    {
                        Vk.MessagesSend("Не удается распознать тип миграции.");
                    }
                }
                else if (from_id == -178513588) // CONFERENCE MANAGER
                {
                    string text = Vk.m_reply_message["text"].ToString();

                    if (text == "")
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    string[] lines = text.Split(new char[] { '\n' }, StringSplitOptions.RemoveEmptyEntries);
                    if (lines.Length <= 1)
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    // Список пользователей с ником:

                    if (lines.Length >= 2)
                    {
                        if (lines[0] == "Список пользователей с ником:")
                        {
                            Vk.MessagesSend("Загрузка списка никнеймов участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            foreach (var item in lines)
                            {
                                if (item == "Список пользователей с ником:" || item == "")
                                {
                                    continue;
                                }
                                //1. [id552349558|Антон Андреев] - Vladimir_Putin
                                string[] temp_explode_tire = item.Split(new char[] { '-' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_tire.Length <= 0)
                                {
                                    continue;
                                }

                                string[] temp_explode_space = temp_explode_tire[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_space.Length <= 0)
                                {
                                    continue;
                                }

                                string[] id_flow = temp_explode_space[1].Replace("[", "").Replace("]", "")
                                    .Replace("id", "").Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                long id_member;
                                try
                                {
                                    id_member = long.Parse(id_flow[0]);
                                }
                                catch
                                {
                                    continue;
                                }
                                string nickname = "";
                                if (temp_explode_tire.Length >= 3)
                                {
                                    var temp_tire = temp_explode_tire[0];
                                    nickname = string.Join("-", temp_explode_tire).Replace(temp_tire, "").Substring(1);
                                    //nickname = temp_explode_tire.Substring(1);

                                }
                                else
                                {
                                    nickname = temp_explode_tire[1].Substring(1);
                                }

                                

                                if (nickname == "")
                                {
                                    continue;
                                }
                                var user = db.peersGetMember(Vk.m_peer_id, id_member);
                                db.peersMemberSetNickName(Vk.m_peer_id, id_member, nickname);
                            }
                            Vk.MessagesSend("Загрузка никнеймов прошла успешно.", 0);
                        }
                        else if (lines[0] == "Список заблокированных пользователей:")
                        {
                            Vk.MessagesSend("Загрузка списка заблокированных участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            foreach (var item in lines)
                            {
                                if (item == "Список заблокированных пользователей:" || item == "")
                                {
                                    continue;
                                }
                                //1. [id1|Павел Дуров]
                                string[] temp_explode_tire = item.Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_tire.Length <= 0)
                                {
                                    continue;
                                }

                                string[] temp_explode_space = temp_explode_tire[0].Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                                if (temp_explode_space.Length <= 0)
                                {
                                    continue;
                                }

                                string[] id_flow = temp_explode_space[1].Replace("[", "").Replace("]", "")
                                    .Replace("id", "").Replace("club", "-").Replace("public", "-").Split(new char[] { '|' }, StringSplitOptions.RemoveEmptyEntries);
                                long id_member;
                                try
                                {
                                    id_member = long.Parse(id_flow[0]);
                                }
                                catch
                                {
                                    continue;
                                }
                                string ban_time = null;

                                if (db.bansGetBan(Vk.m_peer_id, id_member) != null)
                                {
                                    continue;
                                }

                                db.bansAddBan(Vk.m_peer_id, id_member, Vk.m_from_id, "Миграция блокировки", ban_time);
                            }
                            Vk.MessagesSend("Загрузка блокировок прошла успешно.", 0);
                        }
                        else
                        {
                            Vk.MessagesSend("Не удается распознать тип миграции.");
                        }
                    }
                    else
                    {
                        Vk.MessagesSend("Не удается распознать тип миграции.");
                    }
                }
                else if (from_id == -174105461) // IRIS
                {
                    string text = Vk.m_reply_message["text"].ToString();

                    if (text == "")
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    string[] lines = text.Split("\n");
                    if (lines.Length <= 1)
                    {
                        Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                        return;
                    }

                    // Список пользователей с ником:

                    if (lines.Length >= 2)
                    {
                        if (lines[0] == "🗓 Список ников беседы:")
                        {
                            Vk.MessagesSend("Загрузка списка никнеймов участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            foreach (var item in lines)
                            {
                                if (item == "🗓 Список ников беседы:" || item == "" || item == "💬 Чтобы установить себе ник, введите команду \"+ник {Ваш_ник}\"")
                                {
                                    continue;
                                }
                                //1. [id6645564|трешр па па па] — Николай Николай
                                string[] temp_explode_tire = item.Split("—");
                                if (temp_explode_tire.Length <= 1)
                                {
                                    continue;
                                }

                                string[] temp_explode_space = temp_explode_tire[0].Split("|");
                                if (temp_explode_space.Length <= 0)
                                {
                                    continue;
                                }

                                var explode_skovka = temp_explode_space[0].Split("[");
                                if (explode_skovka.Length <= 0)
                                {
                                    continue;
                                }

                                string id_flow = explode_skovka[1].Replace("[", "").Replace("id", "");
                                long id_member;
                                try
                                {
                                    id_member = long.Parse(id_flow);
                                }
                                catch
                                {
                                    continue;
                                }
                                string nickname = temp_explode_space[1].Replace("]", "").Replace("'", "").Replace("\"", "");

                                if (nickname == "")
                                {
                                    continue;
                                }
                                var user = db.peersGetMember(Vk.m_peer_id, id_member);
                                db.peersMemberSetNickName(Vk.m_peer_id, id_member, nickname);
                            }
                            Vk.MessagesSend("Загрузка никнеймов прошла успешно.", 0);
                        }
                        else if (lines[0] == "🗓 Список последних забаненных пользователей беседы:")
                        {
                            Vk.MessagesSend("Загрузка списка заблокированных участников успешна начата..<br>" +
                                "Это может занять некоторое время, просим подождать..", 0);
                            long target_user_id = 0;
                            string? target_time = null;
                            var target_reason = "Миграция блокировки";
                            long target_admin = 0;
                            foreach (var item in lines)
                            {
                                if (item == "🗓 Список последних забаненных пользователей беседы:" || item == "")
                                {
                                    continue;
                                }
                                //1. [id1|Павел Дуров]
                                /*1. [id1|Александра Владимирова] забанен [5]
⏱ До 14.08.2023 20:53:47
💬 Причина: треш
Забанил: Николай Николай*/
                                var explodes_space = item.Split(" ");
                                if (explodes_space.Length <= 0)
                                {
                                    continue;
                                }

                                if (explodes_space[0].Contains("."))
                                {

                                    if (explodes_space.Length <= 1)
                                    {
                                        continue;
                                    }
                                    var explode_slash = explodes_space[1].Split("|");
                                    if (explode_slash.Length <= 0)
                                    {
                                        continue;
                                    }
                                    var target_localuser_id = long.Parse(explode_slash[0].Replace("[id", ""));

                                    if (target_user_id != 0 && target_localuser_id != target_user_id)
                                    {
                                        if (db.bansGetBan(Vk.m_peer_id, target_user_id) == null)
                                        {
                                            db.bansAddBan(Vk.m_peer_id, target_user_id, target_admin, target_reason, target_time);
                                            
                                        }
                                        target_user_id = 0;
                                        target_admin = 0;
                                        target_reason = "Миграция блокировки (Iris)";
                                        target_time = null;
                                    }

                                    target_user_id = target_localuser_id;

                                }
                                else if (explodes_space[0] == "⏱")
                                {
                                    if (item.Contains("Навсегда"))
                                    {
                                        target_time = null;
                                        continue;
                                    }

                                    var results = item.Split("До ");
                                    if (results.Length <= 1)
                                    {
                                        target_time = null;
                                        continue;
                                    }
                                    //DateTimeOffset.Parse()
                                    // var result_time = DateTimeOffset.ParseExact(results[1], "dd/MM/yyyy HH.mm.ss", CultureInfo.InvariantCulture);
                                    var result_time = DateTimeOffset.Parse(results[1]);
                                    if (result_time == null || result_time.ToUnixTimeSeconds() <= DateTimeOffset.Now.ToUnixTimeSeconds())
                                    {
                                        continue;
                                    }
                                    else
                                    {
                                        target_time = db.timeGetForString(result_time);
                                    }
                                }
                                else if (explodes_space[0].Contains("💬"))
                                {
                                    var results = item.Split("Причина:");
                                    if (results.Length <= 1)
                                    {
                                        target_reason = "Миграция блокировки (Iris)";
                                        continue;
                                    }
                                    else
                                    {
                                        target_reason = results[1];
                                    }
                                }
                                else if (explodes_space[0].Contains("Забанил:"))
                                {
                                    if (explodes_space.Length <= 0)
                                    {
                                        continue;
                                    }
                                    var explode_slash = explodes_space[1].Split("|");
                                    if (explode_slash.Length <= 0)
                                    {
                                        continue;
                                    }
                                    var target_adminuser_id = long.Parse(explode_slash[0].Replace("[id", ""));

                                    target_admin = target_adminuser_id;

                                    if (target_user_id != 0)
                                    {
                                        if (db.bansGetBan(Vk.m_peer_id, target_user_id) != null)
                                        {
                                            continue;
                                        }

                                        db.bansAddBan(Vk.m_peer_id, target_user_id, target_admin, target_reason, target_time);
                                        target_user_id = 0;
                                        target_admin = 0;
                                        target_reason = "Миграция блокировки (Iris)";
                                        target_time = null;
                                    }
                                }
                                
                            }
                            Vk.MessagesSend("Загрузка блокировок прошла успешно.", 0);
                        }
                        else
                        {
                            Vk.MessagesSend("Не удается распознать тип миграции.");
                        }
                    }
                    else
                    {
                        Vk.MessagesSend("Не удается распознать тип миграции.");
                    }
                }
                else
                {
                    Vk.MessagesSend("Пересланное сообщение не является сообщением группы, либо указанный бот не поддерживается.<br>" +
                        "Список доступных для миграции ботов: vk.cc/ckZmPs");
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_settings_invite()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "settings"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "settings", 3))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);

                string kick_exit = (PeerInfo["set_kickexit"] == "1") ? "включено" : "выключено";
                string kick_exitrole = (PeerInfo["set_kickexitrole"] == "1") ? "включено" : "выключено";
                string set_kickinviter = (PeerInfo["set_kickinviter"] == "1") ? "включено" : "выключено";
                string set_kick_exitkickgroup = (PeerInfo["set_kickexitgroup"] == "1") ? "включено" : "выключено";
                string set_inviterrole = db.rolesGetName(Vk.m_peer_id, PeerInfo["set_inviterrole"]);
                string set_exitremovenick = (PeerInfo["set_exitremovenick"] == "1") ? "удалять ник" : "оставлять ник";

                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {

                    string kick_exitkickgroup = (PeerInfo["group"] != "0" && PeerInfo["access_token"] != "") ? "<br>6. Исключать участников из группы при выходе из беседы — " 
                        + set_kick_exitkickgroup + "<br>" : "<br>";
                    string text = "Выберите настройку, затем измените параметр, кликнув по кнопке.<br><br>" +
                        "1. При выходе исключать пользователей без роли — " + kick_exit + "<br>" +
                        "2. При выходе исключать пользователей с ролью — " + kick_exitrole + "<br>" +
                        "3. Исключать пользователя без необходимой роли при приглашении им участников — " + set_kickinviter + "<br>" +
                        "4. Необходимая роль для приглашения участников (см. №3) — " + set_inviterrole + " (" + PeerInfo["set_inviterrole"] + ")<br>" +
                        $"5. При выходе пользователя — {set_exitremovenick}<br>" + kick_exitkickgroup ;
                    string keyb;
                    if (PeerInfo["group"] != "0" && PeerInfo["access_token"] != "")
                    {
                        keyb = Vk.GenerateKeyboard(new string[] { "1", "2", "3", "4", "5", "6" },
                        new string[] { "settingsinvite 1", "settingsinvite 2", "settingsinvite 3", "settingsinvite 4", "settingsinvite 5", "settingsinvite 6" },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                    }
                    else
                    {
                        keyb = Vk.GenerateKeyboard(new string[] { "1", "2", "3", "4", "5" },
                        new string[] { "settingsinvite 1", "settingsinvite 2", "settingsinvite 3", "settingsinvite 4", "settingsinvite 5" },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                    }
                    
                    Vk.MessagesSend(text, 0, 0, keyb);
                    return;
                }

                if (args[0] == "4")
                {
                    string text = $"Чтобы изменить необходимую роль для приглашения участников необходимо ввести команду /setroleinviter [РОЛЬ]<br><br>" +
                        $"В качестве роли вы можете использовать как название, так и приоритет нужной роли.";
                    Vk.MessagesSend(text, 0, 0);
                    return;
                }

                if (args[0] == "1")
                {
                    string target_r = (PeerInfo["set_kickexit"] == "1") ? "выключена" : "включена";
                    long target_rr = (PeerInfo["set_kickexit"] == "1") ? 0 : 1;
                    string text = $"Настройка 'При выходе исключать пользователей без роли' была {target_r}";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickexit(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "2")
                {
                    string target_r = (PeerInfo["set_kickexitrole"] == "1") ? "выключена" : "включена";
                    long target_rr = (PeerInfo["set_kickexitrole"] == "1") ? 0 : 1;
                    string text = $"Настройка 'При выходе исключать пользователей с ролью' была {target_r}";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickExitRole(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "3")
                {
                    string target_r = (PeerInfo["set_kickinviter"] == "1") ? "выключена" : "включена";
                    long target_rr = (PeerInfo["set_kickinviter"] == "1") ? 0 : 1;
                    string text = $"Настройка 'Исключать пользователя без необходимой роли при приглашении им участников' была {target_r}";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickInviter(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "5")
                {
                    string target_r = (PeerInfo["set_exitremovenick"] == "1") ? "выключена" : "включена";
                    long target_rr = (PeerInfo["set_exitremovenick"] == "1") ? 0 : 1;
                    string text = $"Настройка 'Удалять никнейм при выходе из конференции' была {target_r}";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetExitRemoveNick(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "6")
                {
                    if (PeerInfo["access_token"] == "")
                    {
                        Vk.MessagesSend("Токен доступа не привязан к данной беседе. Используйте !settoken для продолжения.");
                        return;
                    }

                    string target_r = (PeerInfo["set_kickexitgroup"] == "1") ? "выключена" : "включена";
                    long target_rr = (PeerInfo["set_kickexitgroup"] == "1") ? 0 : 1;
                    string text = $"Настройка 'Исключать участников из группы при выходе из беседы' была {target_r}";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickExitGroup(Vk.m_peer_id, target_rr);
                    return;
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_settings_filter()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "settings"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "settings", 3))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);

                string kick_photo = (PeerInfo["set_kickphotos"] == "0") ? "ничего не делать" : (PeerInfo["set_kickphotos"] == "1") ? "удалять сообщения" : "исключать пользователя";
                string kick_wall = (PeerInfo["set_kickposts"] == "0") ? "ничего не делать" : (PeerInfo["set_kickposts"] == "1") ? "удалять сообщения" : "исключать пользователя";
                string set_kicklinks = (PeerInfo["set_kicklinks"] == "0") ? "ничего не делать" : (PeerInfo["set_kicklinks"] == "1") ? "удалять сообщения" : "исключать пользователя";
                string set_kickobscen = (PeerInfo["set_kickobscen"] == "0") ? "ничего не делать" : (PeerInfo["set_kickobscen"] == "1") ? "удалять сообщения" : "исключать пользователя";
                string set_action_activity = (PeerInfo["set_action_activity"] == "0") ? "ничего не делать" : (PeerInfo["set_action_activity"] == "1") ? "исключать пользователя" : "выдавать блокировку чата";

                string set_kicknsfw = (PeerInfo["set_kicknsfw"] == "0") ? "ничего не делать" : (PeerInfo["set_kicknsfw"] == "1") ? "удалять сообщения" : "исключать пользователя";

                //string set_inviterrole = db.rolesGetName(Vk.m_peer_id, PeerInfo["set_inviterrole"]);
                //set_action_activity


                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    string text = "Выберите настройку, затем измените параметр, кликнув по кнопке.<br><br>" +
                        "1. При отправке фотографий в чат — " + kick_photo + "<br>" +
                        "2. При пересылке постов в чат — " + kick_wall + "<br>" +
                        "3. При отправке ссылок в чат — " + set_kicklinks + "<br>" + 
                        "4. Использование нецензурной брани в чате — " + set_kickobscen + "<br>" +
                        "5. Подозрительная активность (флуд) — " + set_action_activity + "<br>" +
                        "6. Отправка NSFW — " + set_kicknsfw;
                    //"4. Необходимая роль для приглашения участников (см. №3) — " + set_inviterrole + " (" + PeerInfo["set_inviterrole"] + ")";
                    string keyb = Vk.GenerateKeyboard(new string[] { "1", "2", "3", "4", "5", "6" },
                        new string[] { "settingsfilter 1", "settingsfilter 2", "settingsfilter 3", "settingsfilter 4", "settingsfilter 5", "settingsfilter 6" },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                    Vk.MessagesSend(text, 0, 0, keyb);
                    return;
                }

                if (args[0] == "1")
                {
                    string target_r = (PeerInfo["set_kickphotos"] == "1") ? "исключать пользователя" : (PeerInfo["set_kickphotos"] == "2") ? "ничего не делать" : "удалять сообщения";
                    long target_rr = (PeerInfo["set_kickphotos"] == "1") ? 2 : (PeerInfo["set_kickphotos"] == "2") ? 0 : 1;
                    string text = $"Новое действие при отправке фотографий пользователем в чат — {target_r}<br>" +
                        "Обратите внимание, на пользователей с ролью выше пользователя - данное правило не распространяется.";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickPhotos(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "2")
                {
                    string target_r = (PeerInfo["set_kickposts"] == "1") ? "исключать пользователя" : (PeerInfo["set_kickposts"] == "2") ? "ничего не делать" : "удалять сообщения";
                    long target_rr = (PeerInfo["set_kickposts"] == "1") ? 2 : (PeerInfo["set_kickposts"] == "2") ? 0 : 1;
                    string text = $"Новое действие при отправке постов пользователем в чат — {target_r}<br>" +
                        "Обратите внимание, на пользователей с ролью выше пользователя - данное правило не распространяется.";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickWalls(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "3")
                {
                    string target_r = (PeerInfo["set_kicklinks"] == "1") ? "исключать пользователя" : (PeerInfo["set_kicklinks"] == "2") ? "ничего не делать" : "удалять сообщения";
                    long target_rr = (PeerInfo["set_kicklinks"] == "1") ? 2 : (PeerInfo["set_kicklinks"] == "2") ? 0 : 1;
                    string text = $"Новое действие при отправке ссылок пользователем в чат — {target_r}<br>" +
                        "Обратите внимание, на пользователей с ролью выше пользователя - данное правило не распространяется.";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickLinks(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "4")
                {
                    string target_r = (PeerInfo["set_kickobscen"] == "1") ? "исключать пользователя" : (PeerInfo["set_kickobscen"] == "2") ? "ничего не делать" : "удалять сообщения";
                    long target_rr = (PeerInfo["set_kickobscen"] == "1") ? 2 : (PeerInfo["set_kickobscen"] == "2") ? 0 : 1;
                    string text = $"Новое действие при отправке нецензурных сообщений в чат — {target_r}<br>" +
                        "Обратите внимание, на пользователей с ролью выше пользователя - данное правило не распространяется.";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetKickObscen(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "5")
                {
                    string target_r = (PeerInfo["set_action_activity"] == "1") ? "выдавать блокировку чата" : (PeerInfo["set_action_activity"] == "2") ? "ничего не делать" : "исключать пользователя";
                    long target_rr = (PeerInfo["set_action_activity"] == "1") ? 2 : (PeerInfo["set_action_activity"] == "2") ? 0 : 1;
                    string text = $"Новое действие при подозрительной активности — {target_r}<br>" +
                        "Обратите внимание, на пользователей с ролью выше пользователя - данное правило не распространяется.";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetActionActive(Vk.m_peer_id, target_rr);
                    return;
                }

                if (args[0] == "6")
                {
                    string target_r = (PeerInfo["set_kicknsfw"] == "1") ? "исключать пользователя" : (PeerInfo["set_kicknsfw"] == "2") ? "ничего не делать" : "удалять сообщения";
                    long target_rr = (PeerInfo["set_kicknsfw"] == "1") ? 2 : (PeerInfo["set_kicknsfw"] == "2") ? 0 : 1;
                    string text = $"Новое действие при отправке NSFW — {target_r}<br>" +
                        "Обратите внимание, на пользователей с ролью выше пользователя - данное правило не распространяется.";
                    Vk.MessagesSend(text, 0, 0);
                    db.peersSetActionKickNsfw(Vk.m_peer_id, target_rr);
                    return;
                }

                //
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_games()
        {
            try
            {
                //
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "settings"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "settings", 3))
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                var nickadm = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);
                if (PeerInfo["set_games"] == "0")
                {
                    Vk.MessagesSend("Игровые функции были включены " + nickadm);
                    db.peersSetGames(Vk.m_peer_id, 1);
                }
                else
                {
                    Vk.MessagesSend("Игровые функции были отключены " + nickadm);
                    db.peersSetGames(Vk.m_peer_id, 0);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
        
        public async void command_mentions()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "settings"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "settings", 3))
                {
                    return;
                }

                var PeerInfo = db.peersGetPeer(Vk.m_peer_id);
                var nickadm = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);
                if (PeerInfo["set_mentions"] == "0")
                {
                    Vk.MessagesSend("Уведомления были включены " + nickadm);
                    db.peersSetMentions(Vk.m_peer_id, 1);
                }
                else
                {
                    Vk.MessagesSend("Уведомления были отключены " + nickadm);
                    db.peersSetMentions(Vk.m_peer_id, 0);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_owner()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["owner"]);
                    return;
                }
                string text = "⚠ Вы хотите добавить владельца в беседе.<br><br>" +
                    "🔊 Пользователь получит полный доступ к управлению, сможет добавлять владельцев.<br><br>" +
                    "Если вы уверены, что хотите добавить владельца — нажмите на кнопку ниже, либо введите /addowner [ID/ссылка]";
                string keyb = Vk.GenerateKeyboard(new string[] { "Передать" },
                        new string[] { "addowner id" + args[0] },
                        new string[] { Vk.BUTTON_RED });
                Vk.MessagesSend(text, 1, 0, keyb);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_addowner()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "id" });
                Dictionary<string, string>? Target_User = null;
                if (args[0] == null || args[0] == "" || args[0] == Vk.m_from_id.ToString())
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["addowner"]);
                    return;
                }
                Target_User = db.peersGetMember(Vk.m_peer_id, long.Parse(args[0]));
                if (Target_User == null)
                {
                    Vk.MessagesSend("К сожалению, пользователь не найден в базе данных.");
                    return;
                }
                var urls = await Vk.UserGetNameUrls(new long[] { Vk.m_from_id, long.Parse(args[0]) });
                string text = urls[args[0]] + $" получил права владельца конференции.<br><br>Выдал: " + urls[Vk.m_from_id.ToString()];
                db.peersMemberSetPriority(Vk.m_peer_id, long.Parse(args[0]), 100);
                Vk.MessagesSend(text);
                db.logsAddLog(Vk.m_peer_id, Database.logsId.USER_SETROLE, Vk.m_from_id, long.Parse(args[0]), "выдал роль", "100", Target_User["priority"]);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_peertoken()
        {
            try
            {

                Dictionary<string, string>? UserInfoM = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfoM, 100, "peertoken"))
                {
                    //Vk.MessagesSend("Токен для аккаунта не установлен.");
                    return;
                }

                Dictionary<string, string>? UserInfo = db.usersGetUser(Vk.m_from_id);

                if (UserInfo["access_token"] == "")
                {
                    Vk.MessagesSend("Токен для аккаунта не установлен. Используйте /settoken (в ЛИЧНЫЕ СООБЩЕНИЯ)");
                    return;
                }


                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (peerInfo["group"] == "0")
                {
                    Vk.MessagesSend("Токен доступа используется только для исключения участников из привязанной группы беседы, однако " +
                        "беседа не имеет проверки на вступление в группу. Используйте /setpublic для привязки группы.");
                    return;
                }

                var method = "account.getInfo";
                var parames = new Dictionary<string, string>() { { "access_token", SysUtils.DecryptString(UserInfo["access_token"]) } };
                var result = await Vk.VkAPIs(method, parames);

                if (result.ContainsKey("error"))
                {
                    Vk.MessagesSend("Токен, привязанный к аккаунту - введен неверно, он был автоматически отвязан.<br>" +
                        "Для повторной привязки используйте !settoken (обязательно в личные сообщения боту).");
                    db.usersSetAccessToken(Vk.m_from_id, "");
                    return;
                }

                method = "groups.unban";
                parames.Add("group_id", peerInfo["group"]);
                parames.Add("owner_id", "1");
                var resultTwo = await Vk.VkAPIs(method, parames);
                if (resultTwo.ContainsKey("error"))
                {
                    var error = resultTwo["error"];
                    if (error["error_msg"] != null)
                    {
                        if (error["error_msg"].ToString().ToLower() != "access denied: user not blacklisted")
                        {
                            Vk.MessagesSend("Аккаунт не имеет прав Модератора в привязанной группе.<br>" +
                                "Проверьте, является ли привязанный аккаунт (его токен) Модератором (или выше) сообщества.");
                            return;
                        }
                    }
                }

                db.peersSetAccessToken(Vk.m_peer_id, UserInfo["access_token"]);

                Vk.MessagesSend("Токен доступа успешно установлен.<br>" +
                    "!kickgroup — исключить участников, не состоящих в беседе.");
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_editcmd(long is_menu = 0)
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "editcmd"))
                {
                    return;
                }

                if (is_menu == 0)
                {
                    if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "editcmd", 3))
                    {
                        return;
                    }

                    string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                    if (args[0] == null || args[0] == "")
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["editcmd"]);
                        return;
                    }

                    var tot_command = args[0].ToLower().Replace("!", "").Replace("/", "").Replace("+", "").Replace("-", "");

                    if (tot_command == "")
                    {
                        Vk.MessagesSend($"Указанная вами команда не найдена. Введена команда: '{tot_command}'");
                        return;
                    }

                    string target_command = "null";
                    foreach (var item in CommandsList.AnalogsCommands)
                    {
                        var temp_command = item.Value.ToLower();
                        var commands = temp_command.Split("/");
                        if (commands == null || commands.Length <= 0)
                        {
                            if (temp_command == tot_command)
                            {
                                target_command = item.Key;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }

                        foreach (var temp_commande in commands)
                        {
                            if (temp_commande == tot_command)
                            {
                                target_command = item.Key;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }

                    if (target_command == "null")
                    {
                        Vk.MessagesSend($"Указанная вами команда не найдена. Введена команда: '{tot_command}'");
                        return;
                    }

                    //string? result_cache = Cache.Get<string>("target_command_" + Vk.m_peer_id.ToString() + "_" + Vk.m_from_id.ToString());
                    Cache.Set("target_command_" + Vk.m_peer_id.ToString() + "_" + Vk.m_from_id.ToString(), target_command, 10);

                    Vk.MessagesSend($"Введена команда: '{tot_command}'.<br>Следующим сообщением отправьте необходимую роль для выполнения этой команды без лишних символов." +
                        $"<br><br>Для отмены отправьте любой символ, который никак не связан ни с одной существующей ролью в конференции.");
                    MenuList MenuList = new(Cache);
                    MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.MENU_EDITCMD);
                }
                else
                {
                    string? result_cache = Cache.Get<string>("target_command_" + Vk.m_peer_id.ToString() + "_" + Vk.m_from_id.ToString());
                    if (result_cache == null || result_cache == "")
                    {
                        MenuList MenuList = new(Cache);
                        MenuList.setMenuSelect(Vk.m_from_id, 0);
                        return;
                    }


                    string[] args_role = await cmdChecker.getArguments("/setrole " + Vk.m_text, new string[] { "int" });
                    long target_role_priority = -1;
                    if (args_role[0] == null || args_role[0] == "")
                    {
                        string[] args_roletext = await cmdChecker.getArguments("/setrole " + Vk.m_text, new string[] { "text" });
                        if (args_roletext[0] == null || args_roletext[0] == "")
                        {
                            MenuList MenuList = new(Cache);
                            MenuList.setMenuSelect(Vk.m_from_id, 0);
                            Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                            return;
                        }
                        var roles = db.peerGetRoles(Vk.m_peer_id);
                        args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                        foreach (var item in roles)
                        {
                            var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                            if (args_roletext[0] == name_role)
                            {
                                target_role_priority = item.Value.priority;
                                break;
                            }
                        }
                        if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                        {
                            target_role_priority = 20;
                        }
                        else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                        {
                            target_role_priority = 40;
                        }
                        else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                        {
                            target_role_priority = 60;
                        }
                        else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                            args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                            args_roletext[0] == "spec" || args_roletext[0] == "lead")
                        {
                            target_role_priority = 80;
                        }
                    }
                    else
                    {
                        if (long.Parse(args_role[0]) > 100 || long.Parse(args_role[0]) <= -1)
                        {
                            MenuList MenuList = new(Cache);
                            MenuList.setMenuSelect(Vk.m_from_id, 0);
                            Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                            return;
                        }
                        target_role_priority = long.Parse(args_role[0]);
                    }

                    if (target_role_priority <= -1)
                    {
                        MenuList MenuList = new(Cache);
                        MenuList.setMenuSelect(Vk.m_from_id, 0);
                        Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                        return;
                    }

                    Vk.MessagesSend($"Команда '{result_cache}' теперь будет доступна с роли '{db.rolesGetName(Vk.m_peer_id, target_role_priority.ToString())}'.");
                    db.CommandsSetRuleDb(Vk.m_peer_id, result_cache, target_role_priority, Vk.m_from_id);
                    MenuList MenuListt = new(Cache);
                    MenuListt.setMenuSelect(Vk.m_from_id, 0);
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
            // CommandsSetRuleDb
        }

        public async void command_geditcmd(long is_menu = 0)
        {
            //try
            //{
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (UserInfo["priority"] != "100")
                {
                    return;
                }

                var Target_PeerInf = db.peersGetPeer(Vk.m_peer_id);
                if (Target_PeerInf["in_pool"] == "0")
                {
                    Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                    MenuList MenuList2 = new(Cache);
                    MenuList2.setMenuSelect(Vk.m_from_id, 0);
                    return;
                }

                var ListPeersinf = db.unitesGetPeers(long.Parse(Target_PeerInf["in_pool"]));
                if (ListPeersinf == null || ListPeersinf.Count <= 1)
                {
                    MenuList MenuList3 = new(Cache);
                    MenuList3.setMenuSelect(Vk.m_from_id, 0);
                    Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                    return;
                }

                if (is_menu == 0)
                {
                    if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "geditcmd", 3))
                    {
                        return;
                    }

                    string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                    if (args[0] == null || args[0] == "")
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["editcmd"]);
                        return;
                    }

                    var tot_command = args[0].ToLower().Replace("!", "").Replace("/", "").Replace("+", "").Replace("-", "");

                    if (tot_command == "")
                    {
                        Vk.MessagesSend($"Указанная вами команда не найдена. Введена команда: '{tot_command}'");
                        return;
                    }

                    string target_command = "null";
                    foreach (var item in CommandsList.AnalogsCommands)
                    {
                        var temp_command = item.Value.ToLower();
                        var commands = temp_command.Split("/");
                        if (commands == null || commands.Length <= 0)
                        {
                            if (temp_command == tot_command)
                            {
                                target_command = item.Key;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }

                        foreach (var temp_commande in commands)
                        {
                            if (temp_commande == tot_command)
                            {
                                target_command = item.Key;
                                break;
                            }
                            else
                            {
                                continue;
                            }
                        }
                    }

                    if (target_command == "null")
                    {
                        Vk.MessagesSend($"Указанная вами команда не найдена. Введена команда: '{tot_command}'");
                        return;
                    }

                    var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                    if (Target_Peer["in_pool"] == "0")
                    {
                        Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                        return;
                    }

                    var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                    if (ListPeers == null || ListPeers.Count <= 1)
                    {
                        Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                        return;
                    }

                    //string? result_cache = Cache.Get<string>("target_command_" + Vk.m_peer_id.ToString() + "_" + Vk.m_from_id.ToString());
                    Cache.Set("target_gcommand_" + Vk.m_peer_id.ToString() + "_" + Vk.m_from_id.ToString(), target_command, 10);

                    Vk.MessagesSend($"Введена команда: '{tot_command}'.<br>Следующим сообщением отправьте необходимую роль для выполнения этой команды без лишних символов." +
                        $"<br><br>Для отмены отправьте любой символ, который никак не связан ни с одной существующей ролью в конференции.");
                    MenuList MenuList = new(Cache);
                    MenuList.setMenuSelect(Vk.m_from_id, (int)MenuList.ListMenu.MENU_GEDITCMD);
                }
                else
                {
                    MenuList MenuList = new(Cache);
                    MenuList.setMenuSelect(Vk.m_from_id, 0);
                    string? result_cache = Cache.Get<string>("target_gcommand_" + Vk.m_peer_id.ToString() + "_" + Vk.m_from_id.ToString());
                    if (result_cache == null || result_cache == "")
                    {
                        return;
                    }


                    string[] args_role = await cmdChecker.getArguments("/setrole " + Vk.m_text, new string[] { "int" });

                    if (args_role.Length <= 0)
                    {

                        Vk.MessagesSend("Указанная роль не найдена [#2345]. Для повторного редактирования введите команду /editcmd ещё раз.");
                        return;
                    }

                    var Target_Peer = db.peersGetPeer(Vk.m_peer_id);
                    if (Target_Peer["in_pool"] == "0")
                    {
                        Vk.MessagesSend("Беседа не состоит в объединении. Используйте /addunity для включения конференции в объединение.");
                        return;
                    }

                    var ListPeers = db.unitesGetPeers(long.Parse(Target_Peer["in_pool"]));
                    if (ListPeers == null || ListPeers.Count <= 1)
                    {
                        Vk.MessagesSend("Данную команду можно применять в объединениях, у которых есть 2 и более бесед.");
                        return;
                    }

                    long target_role_priority = -1;

                    

                    foreach (var peerid in ListPeers)
                    {
                        UserInfo = db.peersGetMember(peerid, Vk.m_from_id);
                        if (UserInfo["priority"] != "100")
                        {
                            continue;
                        }

                        if (args_role[0] == null || args_role[0] == "")
                        {
                            string[] args_roletext = await cmdChecker.getArguments("/setrole " + Vk.m_text, new string[] { "text" });
                            if (args_roletext.Length <= 0)
                            {
                                if (Vk.m_peer_id == peerid)
                                {
                                    Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                                }
                                continue;
                            }
                            if (args_roletext[0] == null || args_roletext[0] == "")
                            {
                                if (Vk.m_peer_id == peerid)
                                {
                                    Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                                }
                                continue;
                            }


                            var roles = db.peerGetRoles(peerid);
                            args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                            foreach (var item in roles)
                            {
                                var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                                if (args_roletext[0] == name_role)
                                {
                                    target_role_priority = item.Value.priority;
                                    break;
                                }
                            }
                            if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                            {
                                target_role_priority = 20;
                            }
                            else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                            {
                                target_role_priority = 40;
                            }
                            else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                            {
                                target_role_priority = 60;
                            }
                            else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                                args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                                args_roletext[0] == "spec" || args_roletext[0] == "lead")
                            {
                                target_role_priority = 80;
                            }
                        }
                        else
                        {
                            if (long.Parse(args_role[0]) > 100 || long.Parse(args_role[0]) <= -1)
                            {
                                if (Vk.m_peer_id == peerid)
                                {
                                    Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                                }
                                //Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                                continue;
                            }
                            target_role_priority = long.Parse(args_role[0]);
                        }

                        if (target_role_priority <= -1)
                        {
                            if (Vk.m_peer_id == peerid)
                            {
                                Vk.MessagesSend("Указанная роль не найдена. Для повторного редактирования введите команду /editcmd ещё раз.");
                            }
                            continue;
                        }

                        Vk.MessagesSend($"Команда '{result_cache}' теперь будет доступна с роли '{db.rolesGetName(peerid, target_role_priority.ToString())}'.", 0, peerid);
                        db.CommandsSetRuleDb(peerid, result_cache, target_role_priority, Vk.m_from_id);
                    }
                }
            //}
            //catch (Exception ex)
            //{
                //AdminInfo.ErrorAddCommand(ex, Vk);
            //}
            // CommandsSetRuleDb
        }

        public async void command_whitelistlinks()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "whitelistlinks"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "whitelistlinks", 5))
                {
                    return;
                }

                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (peerInfo["set_kicklinks"] == "0")
                {
                    Vk.MessagesSend("В данной беседе выключен фильтр ссылок. Для его настройки используйте !settings.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "int" });
                long list = 1;
                string text;


                if (args[0] != null && args[0] != "")
                {
                    try
                    {
                        list = long.Parse(args[0]);
                    }
                    catch
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["whitelistlinks"]);
                        return;
                    }
                    if (list <= 0)
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["whitelistlinks"]);
                        return;
                    }
                }

                long max = list * 25;
                long min = max - 24;

                var links = db.whiteListLinksGet(Vk.m_peer_id);

                if (links == null || links.Count <= 0)
                {
                    Vk.MessagesSend("В данной беседе все ссылки запрещены (разрешенных не найдено).<br><br>Используйте /addlink [ссылка] для добавления.");
                    return;
                }

                //long all_lists = (int)Math.Round(double.Parse((bans.Count() / 25).ToString()) );

                long all_list = links.Count() / 25;
                all_list++;
                //else
                //{
                //all_list++;
                //}


                if (links.Count() < min)
                {
                    Vk.MessagesSend("Указанная страница не найдена. Всего страниц: " + all_list);
                    return;
                }

                List<long> userget = new();
                long iters = 0;

                text = "Список разрешенных ссылок: <br><br>";
                long i = min;
                iters = 0;
                foreach (var item in links)
                {
                    iters++;
                    if (iters < min || iters > max)
                    {
                        continue;
                    }


                    text = text + i + ". Домен: " + item["domain"] + "<br>";
                    //Vk.MessagesSend("");
                    i++;
                }
                string buttons = "";
                if (list == 1)
                {
                    if (all_list != 1)
                    {
                        buttons = Vk.GenerateKeyboard(new string[] { "—>" },
                        new string[] { $"whitelistlinks 2" },
                        new string[] { Vk.BUTTON_WHITE });
                    }
                }
                else if (list == all_list && list != 1)
                {
                    var previus = list - 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—" },
                        new string[] { $"whitelistlinks " + previus },
                        new string[] { Vk.BUTTON_WHITE });
                }
                else
                {
                    var previus = list - 1;
                    var next = list + 1;
                    buttons = Vk.GenerateKeyboard(new string[] { "<—", "—>" },
                        new string[] { $"whitelistlinks " + previus, $"whitelistlinks " + next },
                        new string[] { Vk.BUTTON_WHITE, Vk.BUTTON_WHITE });
                }

                text = text + "<br>Страница: " + list + "<br>" +
                    "Всего страниц: " + all_list;
                Vk.MessagesSend(text, 1, 0, buttons);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_addlink()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "whitelistlinks"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "whitelistlinks", 5))
                {
                    return;
                }

                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (peerInfo["set_kicklinks"] == "0")
                {
                    Vk.MessagesSend("В данной беседе выключен фильтр ссылок. Для его настройки используйте !settings.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать ссылку на сайт.");
                    return;
                }
                string text = args[0];

                try
                {
                    if (Vk.IsUrlValid(text) != null)
                    {
                        try
                        {
                            UriBuilder builder = new UriBuilder(text);

                            string host = builder.Host;

                            var lists = db.whiteListLinksGet(Vk.m_peer_id);
                            foreach (var item in lists)
                            {
                                if (item["domain"] == host)
                                {
                                    Vk.MessagesSend("Данный домен уже находится в разрешенном списке.");
                                    return;
                                }
                            }

                            Vk.MessagesSend("'" + host + "' был успешно добавлен в список разрешенных доменов.");
                            db.whiteListLinksAdd(Vk.m_peer_id, host, Vk.m_from_id);
                        }
                        catch
                        {
                            Vk.MessagesSend("Exception");
                        }

                    }
                    else
                    {
                        Vk.MessagesSend("Указанная ссылка - не распознана.");
                    }
                }
                catch
                {
                    Vk.MessagesSend("Exception 2");
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_removelink()
        {
            try
            {
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "removelink"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "removelink", 5))
                {
                    return;
                }

                var peerInfo = db.peersGetPeer(Vk.m_peer_id);
                if (peerInfo["set_kicklinks"] == "0")
                {
                    Vk.MessagesSend("В данной беседе выключен фильтр ссылок. Для его настройки используйте !settings.");
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend("Необходимо указать ссылку на сайт.");
                    return;
                }
                string text = args[0];

                try
                {
                    if (Vk.IsUrlValid(text) != null)
                    {
                        try
                        {
                            UriBuilder builder = new UriBuilder(text);

                            string host = builder.Host;

                            var lists = db.whiteListLinksGet(Vk.m_peer_id);
                            bool finded = false;
                            foreach (var item in lists)
                            {
                                if (item["domain"] == host)
                                {
                                    finded = true;
                                    break;
                                }
                            }
                            if (!finded)
                            {
                                Vk.MessagesSend("'" + host + "' не был найден среди списка разрешенных доменов.");
                                return;
                            }
                            Vk.MessagesSend("'" + host + "' был удалён из списка разрешенных доменов.");
                            db.whiteListLinksDel(Vk.m_peer_id, host);
                            return;

                        }
                        catch
                        {
                            Vk.MessagesSend("Exception");
                        }

                    }
                    else
                    {
                        Vk.MessagesSend("Указанная ссылка - не распознана.");
                    }
                }
                catch
                {
                    Vk.MessagesSend("Exception 2");
                }
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }

        public async void command_setroleinviter()
        {
            try
            {
                //rolesDelName
                Dictionary<string, string>? UserInfo = db.peersGetMember(Vk.m_peer_id, Vk.m_from_id);
                if (!cmdChecker.CommandsCheck(UserInfo, 100, "setroleinviter"))
                {
                    return;
                }

                if (!antiflood.checkCommand(Vk.m_from_id, Vk.m_peer_id, "setroleinviter", 5))
                {
                    return;
                }

                string[] args = await cmdChecker.getArguments(Vk.m_text, new string[] { "text" });
                if (args[0] == null || args[0] == "")
                {
                    Vk.MessagesSend(CommandsList.CommandsHelp["setroleinviter"]);
                    return;
                }

                string nick_admin = db.peersGetNickUrl(Vk.m_peer_id, Vk.m_from_id);


                string[] args_role = await cmdChecker.getArguments("/setrole " + args[0], new string[] { "int" });
                long target_role_priority = -1;
                if (args_role[0] == null || args_role[0] == "")
                {
                    string[] args_roletext = await cmdChecker.getArguments("/setrole " + args[0], new string[] { "text" });
                    if (args_roletext[0] == null || args_roletext[0] == "")
                    {
                        Vk.MessagesSend(CommandsList.CommandsHelp["setroleinviter"]);
                        return;
                    }
                    var roles = db.peerGetRoles(Vk.m_peer_id);
                    args_roletext[0] = Regex.Replace(args_roletext[0], @"\p{Cs}", "").ToLower().Replace(" ", "");

                    foreach (var item in roles)
                    {
                        var name_role = Regex.Replace(item.Value.name, @"\p{Cs}", "").ToLower().Replace(" ", "");
                        if (args_roletext[0] == name_role)
                        {
                            target_role_priority = item.Value.priority;
                            break;
                        }
                    }
                    if (args_roletext[0] == "helper" || args_roletext[0] == "хелпер" || args_roletext[0] == "помощник" || args_roletext[0] == "help")
                    {
                        target_role_priority = 20;
                    }
                    else if (args_roletext[0] == "moder" || args_roletext[0] == "модер" || args_roletext[0] == "модератор" || args_roletext[0] == "moderator")
                    {
                        target_role_priority = 40;
                    }
                    else if (args_roletext[0] == "admin" || args_roletext[0] == "админ" || args_roletext[0] == "администратор" || args_roletext[0] == "administrator")
                    {
                        target_role_priority = 60;
                    }
                    else if (args_roletext[0] == "gadmin" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "glavadmin" || args_roletext[0] == "gadmin" ||
                        args_roletext[0] == "gadministrator" || args_roletext[0] == "гадмин" || args_roletext[0] == "главныйадмин" || args_roletext[0] == "главныйадминистратор" ||
                        args_roletext[0] == "spec" || args_roletext[0] == "lead")
                    {
                        target_role_priority = 80;
                    }
                }
                else
                {
                    if (long.Parse(args_role[0]) > 100 || long.Parse(args_role[0]) <= -1)
                    {
                        Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                        return;
                    }
                    target_role_priority = long.Parse(args_role[0]);
                }

                if (target_role_priority <= -1)
                {

                    Vk.MessagesSend("К сожалению, роль с таким приоритетом/названием не найдена.<br>Список доступных ролей: /roles");
                    return;
                }
                if (long.Parse(UserInfo["priority"]) < target_role_priority)
                {
                    Vk.MessagesSend("Вы не можете установить роль, приоритет которой выше, чем ваш.");
                    return;
                }

                string text;
                text = nick_admin + " установил роль для приглашения в конференцию с приоритетом " + target_role_priority;

                Vk.MessagesSend(text);
                db.peersSetRoleInviter(Vk.m_peer_id, target_role_priority);
            }
            catch (Exception ex)
            {
                AdminInfo.ErrorAddCommand(ex, Vk);
            }
        }
    }



    class check_for_cmd
    {
        Database db;
        vk Vk;
        public check_for_cmd(Database dbh, vk vks)
        {
            db = dbh;
            Vk = vks;
        }

        public bool CommandsCheck(Dictionary<string, string>UserInfo, int priority_command, string command, bool answer = true)
        {
            Dictionary<string, rules_cmds>? rules = db.CommandsGetRulesDb(long.Parse(UserInfo["peer_id"]), false);
            int priority_user = int.Parse(UserInfo["priority"]);
            if (rules == null || !rules.ContainsKey(command))
            {
                if (priority_command <= priority_user)
                {
                    return true;
                }
                else
                {
                    if (answer)
                    {
                        string vas = (long.Parse(UserInfo["user_id"]) <= 0) ? $"[club{UserInfo["user_id"]}|Вас]" : $"[id{UserInfo["user_id"]}|Вас]";
                        var rolesName = db.rolesGetName(long.Parse(UserInfo["peer_id"]), priority_command.ToString());
                        var rolesUser = db.rolesGetName(long.Parse(UserInfo["peer_id"]), priority_user.ToString());
                        Vk.MessagesSend($"🤖 У {vas} недостаточно высокий приоритет для использования этой команды.<br>" +
                            $"Необходимая роль: '{rolesName}' (№{priority_command}), ваша роль: '{rolesUser}' (№{priority_user}).", 0, long.Parse(UserInfo["peer_id"]));
                        vas = "";
                        rolesName = "";
                        rolesUser = "";
                    }
                    return false;
                }
            }

            if (rules[command].priority <= priority_user)
            {
                return true;
            }
            else
            {
                if (answer)
                {
                    string vas = (long.Parse(UserInfo["user_id"]) <= 0) ? $"[club{UserInfo["user_id"]}|Вас]" : $"[id{UserInfo["user_id"]}|Вас]";
                    var rolesName = db.rolesGetName(long.Parse(UserInfo["peer_id"]), rules[command].priority.ToString());
                    var rolesUser = db.rolesGetName(long.Parse(UserInfo["peer_id"]), priority_user.ToString());
                    Vk.MessagesSend($"🤖 У {vas} недостаточно высокий приоритет для использования этой команды.<br>" +
                        $"Необходимая роль: '{rolesName}' (№{rules[command].priority}), ваша роль: '{rolesUser}' (№{priority_user}).", 0, long.Parse(UserInfo["peer_id"]));
                    vas = "";
                    rolesName = "";
                    rolesUser = "";
                }
                return false;
            }
        }

        public async Task<string[]> getArguments(string text, string[] types, bool get_id_for_reply = true)
        {
            string lowercase = text.ToLower();
            string[] parames = text.Split(" ");
            string[] parames_low = lowercase.Split(" ");

            string[]? arguments = new string[types.Length];

            int offset = 0;
            for (int i = 0; i < types.Length; i++)
            {
                if (types[i] == "id")
                {
                    if (Vk.m_reply_message != null)
                    {
                        if (Vk.m_reply_message["from_id"] != null && Vk.m_reply_message["from_id"].ToString() != "")
                        {
                            if (Vk.m_reply_message["from_id"].ToString() == "-" + settings.GROUP_ID.ToString())
                            {
                                arguments[i] = "";
                            }
                            else
                            {
                                arguments[i] = Vk.m_reply_message["from_id"].ToString();
                                offset--;
                            }
                        }
                    }
                    else 
                    {
                        if (parames.Length < offset + 2)
                        {
                            arguments[i] = null;
                            continue;
                        }
                        else
                        {
                            arguments[i] = await getIdArgument(parames[offset + 1]);
                            if (arguments[i] != null && arguments[i] != "" && long.Parse(arguments[i]) == settings.GROUP_ID * -1)
                            {
                                arguments[i] = null;
                            }
                        }
                    }
                }
                else if (types[i] == "int")
                {
                    if (parames.Length < offset + 2)
                    {
                        arguments[i] = null;
                        continue;
                    }
                    else
                    {
                        try
                        {
                            long num = Int32.Parse(parames[offset + 1].Trim());
                            arguments[i] = num.ToString();
                        }
                        catch
                        {
                            arguments[i] = null;
                        }
                    }
                }
                else if (types[i] == "text")
                {
                    int positi = offset + 1;
                    if (positi <= types.Length)
                    {
                        parames = parames.Skip(positi).ToArray();
                        arguments[i] = string.Join(' ', parames).Trim();
                    }
                    else
                    {
                        arguments[i] = null;
                    }
                }
                offset++;
            }
            return arguments;
        }

        private async Task<string> getIdArgument(string argument)
        {
            argument = argument.Trim();
            if (argument.Contains('['))
            {
                if (argument.Contains('|'))
                {
                    string[] link = argument.Split("|");
                    if (link.Length >= 1)
                    {
                        if (link[0].Contains("club"))
                        {
                            return "-" + link[0].Substring(5);
                        }
                        return link[0].Substring(3);
                    }
                    return null;
                }
                return null;
                //return argument.Substring(0, argument.IndexOf(']'));
            }
            else if (argument.Contains("vk.com"))
            {
                string addres = "";
                if (argument.Contains("https://vk.com"))
                {
                    addres = argument.Substring(15);
                }
                else if (argument.Contains("https://m.vk.com"))
                {
                    addres = argument.Substring(17);
                }
                else if (argument.Contains("vk.com"))
                {
                    addres = argument.Substring(7);
                }
                JObject result = await Vk.VkAPI("utils.resolveScreenName", new Dictionary<string, string>(){ { "screen_name", addres } });
                if (result.ContainsKey("error") || !result.ContainsKey("response"))
                {
                    return null;
                }

                if (result["response"].Count() <= 0)
                {
                    return null;
                }
                if (result["response"]["type"] == null || result["response"]["object_id"] == null)
                {
                    return null;
                }
                if (result["response"]["type"].ToString() == "group")
                {
                    return "-" + result["response"]["object_id"].ToString();
                }
                else if (result["response"]["type"].ToString() == "user")
                {
                    return result["response"]["object_id"].ToString();
                }
                else
                {
                    return null;
                }
                //if(argument.Contains("https://vk.com"))
            }
            else if (argument.Contains("vk.ru"))
            {
                string addres = "";
                if (argument.Contains("https://vk.ru"))
                {
                    addres = argument.Substring(12);
                }
                else if (argument.Contains("vk.ru"))
                {
                    addres = argument.Substring(6);
                }
                JObject result = await Vk.VkAPI("utils.resolveScreenName", new Dictionary<string, string>() { { "screen_name", addres } });
                if (result.ContainsKey("error") || !result.ContainsKey("response"))
                {
                    return null;
                }

                if (result["response"].Count() <= 0)
                {
                    return null;
                }
                if (result["response"]["type"].ToString() == "group")
                {
                    return "-" + result["response"]["object_id"].ToString();
                }
                else if (result["response"]["type"].ToString() == "user")
                {
                    return result["response"]["object_id"].ToString();
                }
                else
                {
                    return null;
                }
                //if(argument.Contains("https://vk.com"))
            }
            else
            {
                if (argument == "id0" || argument == "0")
                {
                    return null;
                }
                JObject result = await Vk.VkAPI("utils.resolveScreenName", new Dictionary<string, string>() { { "screen_name", argument } });
                if (result.ContainsKey("error") || !result.ContainsKey("response"))
                {
                    return null;
                }

                if (result["response"].Count() <= 0)
                {
                    return null;
                }
                if (result["response"]["type"].ToString() == "group")
                {
                    return "-" + result["response"]["object_id"].ToString();
                }
                else if (result["response"]["type"].ToString() == "user")
                {
                    return result["response"]["object_id"].ToString();
                }
                else
                {
                    return null;
                }
            }
        }

        public System.Numerics.BigInteger getArgumentMoney(string argument)
        {
            argument = argument.ToLower().Replace("к", "000").Replace("k", "000").Replace("тыс", "000").Replace("т", "000").Replace("тысяч", "000")
                .Replace("тысяча", "000").Replace("тысячи", "000")
                .Replace("млн", "000000").Replace("м", "000000").Replace("миллион", "000000").Replace("миллионов", "000000").Replace("million", "000000")
                .Replace("millions", "000000").Replace("млрд", "000000000").Replace("миллиард", "000000000").Replace("миллиардов", "000000000")
                .Replace("миллиарда", "000000000").Replace("трлн", "000000000000").Replace("триллион", "000000000000");
            System.Numerics.BigInteger result = 0;
            try
            {
                result = System.Numerics.BigInteger.Parse(argument);
            }
            catch
            {

            }
            return result;
        }
    }
}
