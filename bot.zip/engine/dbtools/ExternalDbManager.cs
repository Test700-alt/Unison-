using Npgsql;
using System;
using System.Collections.Concurrent;
using System.Collections.Generic;
using System.Data;
using System.Data.Common;
using System.Linq;
using System.Threading;
using System.Threading.Tasks;
using MC = MySqlConnector;

namespace GrandManager.engine.dbtools
{
    internal class ExternalDbCredentials
    {
        public string DbType { get; set; } = "";
        public string Host { get; set; } = "";
        public int Port { get; set; }
        public string Database { get; set; } = "";
        public string Username { get; set; } = "";
        public string Password { get; set; } = "";
    }

    internal class ExternalDbManager
    {
        private static readonly ConcurrentDictionary<string, DbConnection> _pools = new();
        private static readonly ConcurrentDictionary<string, long> _lastUsed = new();
        private static Timer _cleanupTimer;
        private const int IDLE_TIMEOUT_MS = 180_000;
        private const int MAX_POOLS = 30;

        public static void Start()
        {
            _cleanupTimer = new Timer(_ => EvictIdle(), null, 60_000, 60_000);
            Console.WriteLine("[ExternalDB] Менеджер пулов запущен");
        }

        public static string GetPoolKey(long peerId) => $"extdb_{peerId}";

        public static async Task<DbConnection> GetConnection(long peerId, ExternalDbCredentials creds)
        {
            string key = GetPoolKey(peerId);

            if (_pools.TryGetValue(key, out var existing))
            {
                if (existing.State == ConnectionState.Open)
                {
                    _lastUsed[key] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                    return existing;
                }
                await SafeClose(existing);
                _pools.TryRemove(key, out _);
            }

            if (_pools.Count >= MAX_POOLS)
                EvictLRU();

            var conn = await CreateConnection(creds);
            if (conn != null)
            {
                _pools[key] = conn;
                _lastUsed[key] = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
            }
            return conn;
        }

        private static async Task<DbConnection> CreateConnection(ExternalDbCredentials creds)
        {
            if (creds.DbType == "mysql")
            {
                var builder = new MC.MySqlConnectionStringBuilder
                {
                    Server = creds.Host,
                    Port = (uint)creds.Port,
                    Database = creds.Database,
                    UserID = creds.Username,
                    Password = creds.Password,
                    ConnectionTimeout = 10,
                    DefaultCommandTimeout = 20,
                    CharacterSet = "utf8mb4",
                    SslMode = MC.MySqlSslMode.None,
                };
                var conn = new MC.MySqlConnection(builder.ConnectionString);
                await conn.OpenAsync();
                return conn;
            }

            if (creds.DbType == "postgres")
            {
                var builder = new NpgsqlConnectionStringBuilder
                {
                    Host = creds.Host,
                    Port = creds.Port,
                    Database = creds.Database,
                    Username = creds.Username,
                    Password = creds.Password,
                    Timeout = 8,
                    CommandTimeout = 20
                };
                var conn = new NpgsqlConnection(builder.ConnectionString);
                await conn.OpenAsync();
                return conn;
            }

            throw new Exception($"Неподдерживаемый тип БД: {creds.DbType}");
        }

        public static async Task<List<Dictionary<string, object>>> Execute(
            long peerId, ExternalDbCredentials creds, string sql, params object[] parameters)
        {
            var conn = await GetConnection(peerId, creds);
            if (conn == null) throw new Exception("Не удалось подключиться к БД");

            if (conn is MC.MySqlConnection mysqlConn)
                return await ExecuteMysql(mysqlConn, sql, parameters);

            if (conn is NpgsqlConnection pgConn)
                return await ExecutePostgres(pgConn, sql, parameters);

            throw new Exception("Неизвестный тип соединения");
        }

        public static async Task<int> ExecuteNonQuery(
            long peerId, ExternalDbCredentials creds, string sql, params object[] parameters)
        {
            var conn = await GetConnection(peerId, creds);
            if (conn == null) throw new Exception("Не удалось подключиться к БД");

            if (conn is MC.MySqlConnection mysqlConn)
            {
                using var command = new MC.MySqlCommand(sql, mysqlConn);
                for (int i = 0; i < parameters.Length; i++)
                    command.Parameters.AddWithValue($"@p{i}", parameters[i] ?? DBNull.Value);
                return await command.ExecuteNonQueryAsync();
            }

            if (conn is NpgsqlConnection pgConn)
            {
                var pgSql = ConvertToPgParams(sql);
                using var command = new NpgsqlCommand(pgSql, pgConn);
                for (int i = 0; i < parameters.Length; i++)
                    command.Parameters.AddWithValue(parameters[i] ?? DBNull.Value);
                return await command.ExecuteNonQueryAsync();
            }

            throw new Exception("Неизвестный тип соединения");
        }

        private static async Task<List<Dictionary<string, object>>> ExecuteMysql(
            MC.MySqlConnection conn, string sql, object[] parameters)
        {
            using var command = new MC.MySqlCommand(sql, conn);
            for (int i = 0; i < parameters.Length; i++)
                command.Parameters.AddWithValue($"@p{i}", parameters[i] ?? DBNull.Value);

            using var reader = await command.ExecuteReaderAsync();
            var result = new List<Dictionary<string, object>>();
            while (await reader.ReadAsync())
            {
                var row = new Dictionary<string, object>();
                for (int i = 0; i < reader.FieldCount; i++)
                    row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                result.Add(row);
            }
            return result;
        }

        private static async Task<List<Dictionary<string, object>>> ExecutePostgres(
            NpgsqlConnection conn, string sql, object[] parameters)
        {
            var pgSql = ConvertToPgParams(sql);
            using var command = new NpgsqlCommand(pgSql, conn);
            for (int i = 0; i < parameters.Length; i++)
                command.Parameters.AddWithValue(parameters[i] ?? DBNull.Value);

            using var reader = await command.ExecuteReaderAsync();
            var result = new List<Dictionary<string, object>>();
            while (await reader.ReadAsync())
            {
                var row = new Dictionary<string, object>();
                for (int i = 0; i < reader.FieldCount; i++)
                    row[reader.GetName(i)] = reader.IsDBNull(i) ? null : reader.GetValue(i);
                result.Add(row);
            }
            return result;
        }

        private static string ConvertToPgParams(string sql)
        {
            int index = 0;
            var result = new System.Text.StringBuilder();
            bool inQuote = false;
            for (int i = 0; i < sql.Length; i++)
            {
                char c = sql[i];
                if (c == '\'' || c == '"') inQuote = !inQuote;
                if (c == '?' && !inQuote)
                    result.Append($"${++index}");
                else
                    result.Append(c);
            }
            return result.ToString();
        }

        public static async Task<(bool success, string error)> TestConnection(ExternalDbCredentials creds)
        {
            DbConnection conn = null;
            try
            {
                conn = await CreateConnection(creds);
                return (conn != null && conn.State == ConnectionState.Open, "");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"[ExternalDB] TestConnection FAILED: {ex.GetType().Name}: {ex.Message}");
                return (false, ex.Message);
            }
            finally
            {
                if (conn != null) await SafeClose(conn);
            }
        }

        public static async Task RemovePool(long peerId)
        {
            string key = GetPoolKey(peerId);
            if (_pools.TryRemove(key, out var conn))
            {
                _lastUsed.TryRemove(key, out _);
                await SafeClose(conn);
                Console.WriteLine($"[ExternalDB] Пул для peer {peerId} удалён. Активных: {_pools.Count}");
            }
        }

        private static async Task SafeClose(DbConnection conn)
        {
            try { await conn.CloseAsync(); conn.Dispose(); }
            catch { }
        }

        private static void EvictIdle()
        {
            try
            {
                long now = DateTimeOffset.UtcNow.ToUnixTimeMilliseconds();
                var toRemove = new List<string>();

                foreach (var kvp in _lastUsed)
                {
                    if (now - kvp.Value > IDLE_TIMEOUT_MS)
                        toRemove.Add(kvp.Key);
                }

                foreach (var key in toRemove)
                {
                    if (_pools.TryRemove(key, out var conn))
                    {
                        _lastUsed.TryRemove(key, out _);
                        _ = SafeClose(conn);
                    }
                }

                if (toRemove.Count > 0)
                    Console.WriteLine($"[ExternalDB] Вытеснено {toRemove.Count} неактивных пулов");
            }
            catch { }
        }

        private static void EvictLRU()
        {
            string oldestKey = null;
            long oldestTime = long.MaxValue;

            foreach (var kvp in _lastUsed)
            {
                if (kvp.Value < oldestTime)
                {
                    oldestTime = kvp.Value;
                    oldestKey = kvp.Key;
                }
            }

            if (oldestKey != null && _pools.TryRemove(oldestKey, out var conn))
            {
                _lastUsed.TryRemove(oldestKey, out _);
                _ = SafeClose(conn);
            }
        }

        public static int ActiveCount => _pools.Count;
    }
}
