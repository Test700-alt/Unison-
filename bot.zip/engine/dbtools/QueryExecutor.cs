using System;
using System.Collections.Generic;
using System.Linq;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace GrandManager.engine.dbtools
{
    internal static class QueryExecutor
    {
        private static readonly Regex IdentifierRegex = new(@"^[a-zA-Z_][a-zA-Z0-9_]{0,63}$");

        private static void ValidateIdentifier(string name, string label)
        {
            if (string.IsNullOrEmpty(name) || !IdentifierRegex.IsMatch(name))
                throw new Exception($"Недопустимое имя {label}: \"{name}\"");
        }

        private static string EscapeIdentifier(string name, string dbType)
        {
            ValidateIdentifier(name, "идентификатора");
            return dbType == "postgres" ? $"\"{name}\"" : $"`{name}`";
        }

        public static async Task<bool> TableExists(long peerId, ExternalDbCredentials creds, string tableName)
        {
            ValidateIdentifier(tableName, "таблицы");

            List<Dictionary<string, object>> rows;
            if (creds.DbType == "mysql")
            {
                rows = await ExternalDbManager.Execute(peerId, creds,
                    "SELECT TABLE_NAME FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ?",
                    creds.Database, tableName);
            }
            else
            {
                rows = await ExternalDbManager.Execute(peerId, creds,
                    "SELECT table_name FROM information_schema.tables WHERE table_schema = ? AND table_name = ?",
                    "public", tableName);
            }

            return rows.Count > 0;
        }

        public static async Task<bool> ColumnExists(long peerId, ExternalDbCredentials creds, string tableName, string columnName)
        {
            ValidateIdentifier(tableName, "таблицы");
            ValidateIdentifier(columnName, "колонки");

            List<Dictionary<string, object>> rows;
            if (creds.DbType == "mysql")
            {
                rows = await ExternalDbManager.Execute(peerId, creds,
                    "SELECT COLUMN_NAME FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? AND COLUMN_NAME = ?",
                    creds.Database, tableName, columnName);
            }
            else
            {
                rows = await ExternalDbManager.Execute(peerId, creds,
                    "SELECT column_name FROM information_schema.columns WHERE table_schema = ? AND table_name = ? AND column_name = ?",
                    "public", tableName, columnName);
            }

            return rows.Count > 0;
        }

        public static async Task<List<Dictionary<string, object>>> GetTableColumns(
            long peerId, ExternalDbCredentials creds, string tableName)
        {
            ValidateIdentifier(tableName, "таблицы");

            if (creds.DbType == "mysql")
            {
                return await ExternalDbManager.Execute(peerId, creds,
                    "SELECT COLUMN_NAME as name, DATA_TYPE as type FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = ? AND TABLE_NAME = ? ORDER BY ORDINAL_POSITION",
                    creds.Database, tableName);
            }

            return await ExternalDbManager.Execute(peerId, creds,
                "SELECT column_name as name, data_type as type FROM information_schema.columns WHERE table_schema = ? AND table_name = ? ORDER BY ordinal_position",
                "public", tableName);
        }

        public static async Task<List<Dictionary<string, object>>> GetTablesList(
            long peerId, ExternalDbCredentials creds)
        {
            if (creds.DbType == "mysql")
            {
                return await ExternalDbManager.Execute(peerId, creds,
                    "SELECT TABLE_NAME as name FROM information_schema.TABLES WHERE TABLE_SCHEMA = ? ORDER BY TABLE_NAME",
                    creds.Database);
            }

            return await ExternalDbManager.Execute(peerId, creds,
                "SELECT table_name as name FROM information_schema.tables WHERE table_schema = ? ORDER BY table_name",
                "public");
        }

        public static async Task<int> ExecuteUpdate(long peerId, ExternalDbCredentials creds,
            string tableName, string searchColumn, string searchValue, string targetColumn, string targetValue)
        {
            ValidateIdentifier(tableName, "таблицы");
            ValidateIdentifier(searchColumn, "колонки поиска");
            ValidateIdentifier(targetColumn, "целевой колонки");

            string table = EscapeIdentifier(tableName, creds.DbType);
            string search = EscapeIdentifier(searchColumn, creds.DbType);
            string target = EscapeIdentifier(targetColumn, creds.DbType);

            string sql;
            if (creds.DbType == "mysql")
                sql = $"UPDATE {table} SET {target} = ? WHERE {search} = ? LIMIT 1";
            else
                sql = $"UPDATE {table} SET {target} = ? WHERE {search} = ?";

            return await ExternalDbManager.ExecuteNonQuery(peerId, creds, sql, targetValue, searchValue);
        }

        public static async Task<List<Dictionary<string, object>>> ExecuteSelect(
            long peerId, ExternalDbCredentials creds,
            string tableName, string searchColumn, string searchValue, List<string> columns = null)
        {
            ValidateIdentifier(tableName, "таблицы");
            ValidateIdentifier(searchColumn, "колонки поиска");

            columns ??= new List<string> { "*" };
            var safeColumns = columns.Select(c =>
                c == "*" ? "*" : EscapeIdentifier(c, creds.DbType)
            );

            string table = EscapeIdentifier(tableName, creds.DbType);
            string search = EscapeIdentifier(searchColumn, creds.DbType);

            string sql = $"SELECT {string.Join(", ", safeColumns)} FROM {table} WHERE {search} = ? LIMIT 10";

            return await ExternalDbManager.Execute(peerId, creds, sql, searchValue);
        }
    }
}
